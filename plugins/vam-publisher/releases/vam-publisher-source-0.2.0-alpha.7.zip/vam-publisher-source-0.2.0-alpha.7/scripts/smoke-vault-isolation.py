"""Exercise a released Manager in two real Obsidian vaults with one app profile."""
import argparse
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import tempfile
import time
from zipfile import ZipFile

from playwright.sync_api import sync_playwright

args = argparse.ArgumentParser()
args.add_argument("--obsidian", type=Path, required=True)
args.add_argument("--sync-zip", type=Path, required=True)
args.add_argument("--headless", action="store_true")
options = args.parse_args()
root = Path(__file__).resolve().parents[1]

with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as temp, sync_playwright() as playwright:
    home = Path(temp)
    first, second = home / "A" / "Test", home / "B" / "Test"
    profile = home / "profile"
    profile.mkdir()
    for vault in [first, second]:
        plugins = vault / ".obsidian" / "plugins"
        plugins.mkdir(parents=True)
        with ZipFile(options.sync_zip) as archive:
            archive.extractall(plugins)
    shutil.copytree(root / "dist/vam-publisher", first / ".obsidian/plugins/vam-publisher")

    repository = {}

    def visit(vault, callback):
        (vault / '.obsidian/community-plugins.json').write_text('[]', encoding='utf-8')
        identifier = "0123456789abcdef" if vault == first else "fedcba9876543210"
        (profile / "obsidian.json").write_text(json.dumps({"vaults": {identifier: {"path": str(vault), "ts": int(time.time()*1000), "open": True}}}), encoding="utf-8")
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        flags = ["--headless", "--ozone-platform=headless", "--disable-gpu", "--no-sandbox"] if options.headless else []
        env = dict(os.environ, APPDATA=str(home/"roaming"), LOCALAPPDATA=str(home/"local"), XDG_CONFIG_HOME=str(home/"config"), XDG_DATA_HOME=str(home/"data"), XDG_CACHE_HOME=str(home/"cache"))
        proc = subprocess.Popen([str(options.obsidian), *flags, "--remote-debugging-address=127.0.0.1", f"--remote-debugging-port={port}", "--user-data-dir="+str(profile)], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            deadline = time.monotonic()+65
            while True:
                try:
                    browser = playwright.chromium.connect_over_cdp(f"http://127.0.0.1:{port}", timeout=1500)
                    page = browser.contexts[0].pages[0]
                    page.wait_for_function("!!window.app?.plugins?.enablePluginAndSave")
                    break
                except Exception:
                    if time.monotonic() >= deadline: raise
                    time.sleep(.2)
            assert Path(page.evaluate("app.vault.adapter.getBasePath()")) == vault
            page.evaluate("(state)=>Object.assign(localStorage,state)", repository)
            page.evaluate("""async()=>{ const p=app.plugins; if(!p.isEnabled())await p.setEnable(true); await p.loadManifests();
              window.fetch=async (url,init={})=>{
                if(!String(url).startsWith('https://api.github.com/repos/fixture/private')) throw Error('offline fixture');
                const path=String(url).split('/contents/')[1]; if(!path)return Response.json({private:true});
                if(path==='vam/requests')return Response.json([]);
                if(init.method==='PUT'){localStorage.setItem(path,JSON.parse(init.body).content);return Response.json({}, {status:201});}
                const content=localStorage.getItem(path);return content?Response.json({sha:'1',encoding:'base64',content}):Response.json({}, {status:404});
              };}""")
            result = callback(page)
            repository.update(page.evaluate("()=>Object.fromEntries(Object.entries(localStorage).filter(([k])=>k.startsWith('vam/')))"))
            return result
        finally:
            proc.kill()
            proc.wait(timeout=20)

    def enter(first_page):
        release = first_page.evaluate("""async()=>{await app.plugins.enablePlugin('vam-publisher');
            const p=app.plugins.plugins['vam-publisher'], row=await p.publisher.create({adminId:'Fixture',defaultPassword:'fixture-password',bootstrapToken:'fixture-token',bundleId:'test',repository:{baseUrl:'https://api.github.com',owner:'fixture',repo:'private'}});
            return {files:(await p.prepare(row.tenantId)).files, setup:await p.publisher.issueSetup(row.tenantId)};}""")
        for path, data in release["files"].items():
            for vault in [first, second]:
                if vault == second and path.endswith("styles.css"): continue
                dest = vault / ".obsidian/plugins" / path
                dest.parent.mkdir(exist_ok=True)
                dest.write_text(data, encoding="utf-8")
        first_page.evaluate("""async code=>{const p=app.plugins;await p.loadManifests();await p.enablePluginAndSave('refsync');await p.enablePluginAndSave('vault-access-manager');
            const rt=p.plugins['vault-access-manager'].accessV4;await rt.ready; await rt.loginAdministrator('fixture-password','',null,code);
            if(!rt.service.isAdministrator())throw Error('expected authenticated A');p.plugins.refsync.gate.require();}""", release["setup"])
        return first_page.evaluate("app.plugins.plugins['vault-access-manager'].accessV4.device.keyId")

    def check(page):
        return page.evaluate("""async()=>{const p=app.plugins;await p.enablePluginAndSave('vault-access-manager');await p.enablePluginAndSave('refsync');
            const rt=p.plugins['vault-access-manager'].accessV4;await rt.ready;await p.plugins.refsync.ready;
            if(rt.session||rt.service?.isAdministrator()||p.plugins.refsync.gate.refresh()==='vamGranted')throw Error('unexpected session');
            if(!document.querySelector('.vam-login-modal'))throw Error('login UI missing');
            return rt.device.keyId;}""")

    key = visit(first, enter)
    assert visit(second, check) == key
    def restored(page):
        return page.evaluate("""async()=>{const p=app.plugins; await p.enablePluginAndSave('vault-access-manager'); await p.enablePluginAndSave('refsync');
            const rt=p.plugins['vault-access-manager'].accessV4; await rt.ready; await p.plugins.refsync.ready;
            if(!rt.service?.isAdministrator()) throw Error('A session missing: '+rt.status+' '+rt.error);
            p.plugins.refsync.gate.require();
            return rt.device.keyId;}""")
    assert visit(first, restored) == key
    print("Same installation: A explicitly granted, B (main.js + manifest.json) signed out with login UI, A restored after restart.")
