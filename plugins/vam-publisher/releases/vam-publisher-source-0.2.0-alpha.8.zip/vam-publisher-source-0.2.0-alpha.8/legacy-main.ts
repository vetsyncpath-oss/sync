import { Notice, Plugin, PluginSettingTab, type App } from 'obsidian';
import { IssuerService } from './manager/src/issuer/service';
import { ownerFingerprint, verifyOwnerRequest } from './manager/src/issuer/protocol';

export default class PublisherPlugin extends Plugin {
    issuer = new IssuerService();
    loadError = '';
    ownerRequestDraft = '';
    async acceptOwnerRequest(code: string): Promise<void> {
        await verifyOwnerRequest(code.trim());
        this.ownerRequestDraft = code.trim();
        this.app.setting?.open(); this.app.setting?.openTabById(this.manifest.id);
        new Notice('Заявка получена. Разблокируйте издателя, проверьте получателя и подпишите назначение.');
    }
    async sendToManager(code: string): Promise<void> {
        if (!code) throw new Error('Сначала подпишите назначение');
        const managers = Object.values(this.app.plugins?.plugins ?? {}).filter((p: any) => typeof p?.accessV3?.receiveOwnerCertificate === 'function');
        if (managers.length !== 1) throw new Error('Не найден единственный активный менеджер. Скопируйте сертификат и вставьте его в нужный менеджер вручную.');
        await (managers[0] as any).accessV3.receiveOwnerCertificate(code);
    }
    async onload(): Promise<void> {
        try { await this.issuer.start(); } catch { this.loadError = 'Не удалось открыть ключ издателя. Сохранённый профиль не перезаписан.'; }
        this.addSettingTab(new PublisherTab(this.app, this));
        this.addCommand({ id: 'publisher-open', name: 'Выпустить назначение хозяина', callback: () => { this.app.setting?.open(); this.app.setting?.openTabById(this.manifest.id); } });
        this.addCommand({ id: 'publisher-lock', name: 'Заблокировать ключ издателя', callback: () => { this.issuer.lock(); new Notice('Ключ издателя заблокирован'); } });
    }
    onunload(): void { this.issuer.dispose(); }
}

class PublisherTab extends PluginSettingTab {
    constructor(app: App, private publisher: PublisherPlugin) { super(app, publisher); }
    private text(parent: HTMLElement, text: string): HTMLElement { const el = document.createElement('p'); el.textContent = text; parent.append(el); return el; }
    private field(parent: HTMLElement, title: string, value = '', type = 'text', readonly = false): HTMLInputElement | HTMLTextAreaElement {
        const label = document.createElement('label'); label.className = 'vam-publisher-field'; label.textContent = title;
        const input = document.createElement(type === 'textarea' ? 'textarea' : 'input'); input.value = value; input.readOnly = readonly;
        if (input instanceof HTMLInputElement) { input.type = type; input.autocomplete = 'off'; } else input.rows = 5;
        input.spellcheck = false; label.append(input); parent.append(label); return input;
    }
    private button(parent: HTMLElement, text: string, action: () => Promise<void> | void, redraw = false): void {
        const b = document.createElement('button'); b.textContent = text; b.className = 'vam-publisher-button'; parent.append(b);
        b.onclick = async () => { b.disabled = true; try { await action(); if (redraw) this.display(); } catch (e) { new Notice(e instanceof Error ? e.message : 'Операция не выполнена'); } finally { b.disabled = false; } };
    }
    private download(name: string, content: string): void {
        const url = URL.createObjectURL(new Blob([content], { type: 'text/plain;charset=utf-8' }));
        const a = document.createElement('a'); a.href = url; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    }
    display(): void {
        const root = this.containerEl; root.replaceChildren(); root.classList.add('vam-publisher');
        const s = this.publisher.issuer;
        this.text(root, 'VAM Publisher — отдельный инструмент создателя. Выпускает сертификат назначения хозяина; пользовательский менеджер не получает приватный ключ издателя.');
        if (this.publisher.loadError) { this.text(root, this.publisher.loadError); return; }
        if (this.publisher.ownerRequestDraft) this.text(root, 'Заявка хозяина уже передана из менеджера и сохранена для этой сессии. После разблокировки перейдите к её проверке ниже.');
        const password = this.field(root, 'Пароль издателя (не менее 12 символов)', '', 'password');
        if (!s.profile) {
            this.text(root, 'Если ключ уже был создан через CLI, импортируйте его. Новый ключ не восстановит доверие в ранее выпущенных менеджерах.');
            const id = this.field(root, 'Постоянный ID издателя');
            this.button(root, 'Создать новый ключ издателя', async () => { await s.create(id.value.trim(), password.value); }, true);
            const restore = this.field(root, 'Зашифрованная резервная копия издателя', '', 'textarea');
            this.button(root, 'Восстановить резервную копию', async () => { await s.restore(restore.value, password.value); }, true);
            const file = this.field(root, 'Либо импортировать существующий publisher-private.json из CLI', '', 'file') as HTMLInputElement; file.accept = '.json';
            this.button(root, 'Импортировать CLI-ключ и защитить паролем', async () => {
                if (!file.files?.[0]) throw new Error('Выберите файл ключа CLI');
                await s.importCli(await file.files[0].text(), password.value);
            }, true);
            return;
        }
        this.text(root, `Издатель: ${s.profile.publisherId}. ${s.unlocked ? 'Ключ разблокирован.' : 'Ключ заблокирован.'}`);
        if (!s.unlocked) this.button(root, 'Разблокировать издателя', () => s.unlock(password.value), true);
        else this.button(root, 'Заблокировать издателя', () => s.lock(), true);
        this.text(root, 'Шаг 1. Сохраните зашифрованную резервную копию отдельно от пароля. Затем экспортируйте публичный корень в исходники менеджера: src/auth-v2/trusted-publishers.ts. Выполните npm run build и перезагрузите менеджер. Корень не добавляется автоматически из сертификата.');
        const exported = this.field(root, 'Экспорт (только публичный корень или зашифрованная копия)', '', 'textarea', true);
        this.button(root, 'Показать публичный корень', () => { exported.value = s.exportAnchor(); });
        this.button(root, 'Скачать trusted-publishers.ts', () => this.download('trusted-publishers.ts', s.exportAnchor()));
        this.button(root, 'Показать зашифрованную копию', () => { exported.value = s.exportBackup(); });
        this.button(root, 'Скачать зашифрованную копию', () => this.download('publisher-backup.json', s.exportBackup()));
        if (!s.unlocked) return;
        this.text(root, 'Шаг 2. В менеджере откройте первичную настройку хозяина, создайте новый административный ключ и скопируйте заявку издателю. Старая локальная роль owner и старый пароль не являются подписанным назначением.');
        const request = this.field(root, 'Заявка хозяина из менеджера', this.publisher.ownerRequestDraft, 'textarea');
        const fingerprint = this.field(root, 'Проверенный отпечаток хозяина', '', 'text', true);
        const tenantId = this.field(root, 'Организация из заявки', '', 'text', true), bundleId = this.field(root, 'Бандл из заявки', '', 'text', true);
        const confirmation = document.createElement('label'), checked = document.createElement('input'); checked.type = 'checkbox'; confirmation.append(checked, ' Я сверил получателя и отпечаток хозяина по доверенному каналу'); root.append(confirmation);
        let verifiedCode = '';
        const output = this.field(root, 'Готовый сертификат назначения — передайте хозяину', '', 'textarea', true);
        request.addEventListener('input', () => { verifiedCode = ''; fingerprint.value = ''; tenantId.value = ''; bundleId.value = ''; checked.checked = false; output.value = ''; });
        this.button(root, 'Проверить заявку', async () => {
            const code = request.value.trim(), owner = await verifyOwnerRequest(code);
            const hash = await ownerFingerprint(code);
            if (request.value.trim() !== code) throw new Error('Заявка изменилась во время проверки');
            fingerprint.value = hash; tenantId.value = owner.tenantId; bundleId.value = owner.bundleId; verifiedCode = code; checked.checked = false;
        });
        this.text(root, 'Шаг 3. Укажите два разных приватных репозитория. Издатель подписывает их адреса, но не проверяет Git и не запрашивает PAT. Хозяин проверит подключение в менеджере.');
        const api = this.field(root, 'API GitHub/Gitea', 'https://api.github.com');
        const accessOwner = this.field(root, 'Владелец репозитория прав'), accessRepo = this.field(root, 'Репозиторий прав');
        const requestsOwner = this.field(root, 'Владелец репозитория заявок'), requestsRepo = this.field(root, 'Репозиторий заявок');
        const expires = this.field(root, 'Назначение действует по дату включительно (UTC)', new Date(Date.now() + 365 * 86400_000).toISOString().slice(0, 10), 'date');
        this.button(root, 'Подписать назначение хозяина', async () => {
            if (!checked.checked || !verifiedCode || verifiedCode !== request.value.trim()) throw new Error('Проверьте заявку и подтвердите получателя');
            output.value = await s.issue(verifiedCode, { tenantId: tenantId.value, bundleId: bundleId.value,
                access: { baseUrl: api.value.trim(), owner: accessOwner.value.trim(), repo: accessRepo.value.trim() },
                requests: { baseUrl: api.value.trim(), owner: requestsOwner.value.trim(), repo: requestsRepo.value.trim() }, expiresAt: Date.parse(expires.value) + 86400_000 }, fingerprint.value);
        });
        this.button(root, 'Передать назначение в менеджер', () => this.publisher.sendToManager(output.value));
        this.button(root, 'Копировать назначение для передачи вручную', async () => { if (!output.value) throw new Error('Сначала подпишите назначение'); try { await navigator.clipboard.writeText(output.value); new Notice('Сертификат скопирован'); } catch { output.focus(); output.select(); new Notice('Скопируйте выделенный сертификат сочетанием Ctrl+C'); } });
        this.button(root, 'Скачать tenant.jws', () => { if (!output.value) throw new Error('Сначала подпишите назначение'); this.download('tenant.jws', output.value + '\n'); });
        this.text(root, 'Шаг 4. Хозяин вставляет сертификат в менеджер, задаёт свои PAT и нажимает «Проверить и сохранить», затем «Инициализировать новый реестр». Существующий реестр не перезаписывается.');
    }
}
