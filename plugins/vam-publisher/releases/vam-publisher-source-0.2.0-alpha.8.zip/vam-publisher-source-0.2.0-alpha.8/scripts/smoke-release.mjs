import 'fake-indexeddb/auto';
import { readFile, mkdtemp, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import assert from 'node:assert/strict';
import { parseHTML } from 'linkedom';
import { webcrypto } from 'node:crypto';
if (!globalThis.crypto) globalThis.crypto = webcrypto;
class Plugin {
    constructor(app, manifest) { this.app = app; this.manifest = manifest; this.commands = []; }
    async saveData(data) { this.data = data; }
    addSettingTab(tab) { this.tab = tab; }
    addCommand(command) { this.commands.push(command); }
    async loadData() { return { role: 'owner' }; }
}
class PluginSettingTab { constructor(app, plugin) { this.app = app; this.plugin = plugin; this.containerEl = document.createElement('div'); } }
class Modal {
    constructor(app) { this.app = app; this.contentEl = document.createElement('div'); this.modalEl = document.createElement('div'); this.modalEl.append(this.contentEl); }
    open() { document.body.append(this.modalEl); this.onOpen?.(); }
    close() { this.onClose?.(); this.modalEl.remove(); }
}
class Notice { constructor() {} }
const obsidian = { Plugin, PluginSettingTab, Modal, Notice };
function load(source) {
    const module = { exports: {} }; new Function('module', 'exports', 'require', source)(module, module.exports, name => { if (name !== 'obsidian') throw new Error('Unexpected runtime dependency: ' + name); return obsidian; }); return module.exports.default;
}
const directory = await mkdtemp(join(tmpdir(), 'vam-baking-smoke-'));
let publisher, manager;
const originalFetch = globalThis.fetch;
const { window: dom } = parseHTML('<!doctype html><html><body></body></html>');
const globals = new Map(['document', 'HTMLElement', 'HTMLInputElement', 'HTMLTextAreaElement'].map(name => [name, Object.getOwnPropertyDescriptor(globalThis, name)]));
for (const name of globals.keys()) Object.defineProperty(globalThis, name, { configurable: true, value: dom[name] });
try {
    const Publisher = load(await readFile('dist/vam-publisher/main.js', 'utf8'));
    publisher = new Publisher({ vault: {} }, { id: 'vam-publisher', version: 'smoke' }); await publisher.onload();
    const adminId = 'smoke-' + crypto.randomUUID(), profile = await publisher.publisher.create({ adminId, defaultPassword: 'Smoke-Password', bundleId: 'smoke-bundle', repository: { baseUrl: 'https://api.github.com', owner: 'smoke', repo: 'private' } });
    const release = await publisher.prepare(profile.tenantId);
    assert(release.files['vault-access-manager/styles.css'].includes('.vam-login-cards'));
    assert.equal(Object.keys(release.files).length, 3); assert.equal(release.archive[0], 0x50); assert.equal(release.archive[1], 0x4b);
    const archivePath = join(directory, 'manager.zip'); await writeFile(archivePath, release.archive);
    // Read each standard stored ZIP entry independently of the writer's code.
    let offset = 0, entries = 0; const bytes = Buffer.from(release.archive);
    while (bytes.readUInt32LE(offset) === 0x04034b50) {
        assert.equal(bytes.readUInt16LE(offset + 8), 0); const size = bytes.readUInt32LE(offset + 18), nameSize = bytes.readUInt16LE(offset + 26), extra = bytes.readUInt16LE(offset + 28), name = bytes.subarray(offset + 30, offset + 30 + nameSize).toString('utf8'), start = offset + 30 + nameSize + extra;
        assert.equal(bytes.subarray(start, start + size).toString('utf8'), release.files[name]); offset = start + size; entries++;
    }
    assert.equal(entries, 3); assert.equal(bytes.readUInt32LE(offset), 0x02014b50);
    const Manager = load(release.files['vault-access-manager/main.js']);
    const files = new Map(); let sha = 0;
    const fetcher = async function (input, init) {
        assert.equal(this, globalThis, 'Obsidian fetch must retain its global receiver');
        const url = String(input), path = url.split('/contents/')[1];
        if (!path) return Response.json({ private: true });
        if (init?.method === 'PUT') { const body = JSON.parse(init.body), existing = files.get(path); if ((existing?.sha ?? null) !== (body.sha ?? null)) return Response.json({}, { status: 409 }); files.set(path, { sha: String(++sha), text: Buffer.from(body.content, 'base64').toString('utf8') }); return Response.json({}, { status: existing ? 200 : 201 }); }
        if (path === 'vam/requests') return Response.json([]);
        const file = files.get(path); return file ? Response.json({ sha: file.sha, encoding: 'base64', content: Buffer.from(file.text).toString('base64') }) : Response.json({}, { status: 404 });
    };
    globalThis.fetch = fetcher;
    manager = new Manager({ appId: 'smoke-vault', vault: {}, workspace: { onLayoutReady(callback) { callback(); } } }, { id: 'vault-access-manager', version: 'smoke' }); await manager.onload();
    assert.equal(manager.accessV4.build.tenantId, profile.tenantId); assert.equal(manager.accessV4.build.repository.repo, 'private');
    assert.equal(manager.accessV4.decision.status, 'blocked');
    assert.equal(document.querySelectorAll('.vam-card').length, 3);
    document.querySelectorAll('.vam-card')[2].onclick();
    const inputs = document.querySelectorAll('input[type=password]'); inputs[0].value = 'Smoke-Password'; inputs[1].value = 'smoke-token'; document.querySelector('textarea').value = await publisher.publisher.issueSetup(profile.tenantId);
    await document.querySelector('.vam-login-form .mod-cta').onclick();
    assert.equal(manager.accessV4.service.isAdministrator(), true); assert.equal(document.querySelector('.vam-login-modal'), null);
    assert.equal(globalThis.__VAM__.getStatus(), 'granted'); assert.equal(manager.auth.getState().status, 'ok');
    const valid = files.get('vam/config.json'); assert(!valid.text.includes('Smoke-Password'));
    files.set('vam/config.json',{...valid,text:JSON.stringify({adminPassword:'Replacement-Password'})});
    await manager.accessV4.tick(); assert.equal(manager.accessV4.decision.status,'blocked');
    files.set('vam/config.json',valid); await manager.accessV4.tick(); assert.equal(manager.accessV4.decision.status,'granted');
    await manager.accessV4.logout(); assert.equal(manager.accessV4.decision.status, 'blocked');
    assert.equal(globalThis.__VAM__.getStatus(), 'blocked'); assert.equal(document.querySelectorAll('.vam-card').length, 3);
    assert(manager.commands.some(command => command.id === 'vam-logout'));
    console.log('Baked release: compiled publisher → ZIP with styles → startup cards → administrator UI login → legacy API → signed registry tampering rejected → logout cards passed.');
} finally {
    globalThis.fetch = originalFetch; manager?.onunload(); publisher?.onunload();
    for (const [name, descriptor] of globals) { if (descriptor) Object.defineProperty(globalThis, name, descriptor); else delete globalThis[name]; }
    await rm(directory, { recursive: true, force: true });
}
