/** Offline publisher tool. Private issuer material must never enter the plugin/repositories. */
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { generateIdentity, importIdentity } from '../manager/src/auth-v2/crypto';
import { issueTenant } from '../manager/src/issuer/protocol';

async function main(): Promise<void> {
    const [command, ...args] = process.argv.slice(2);
    if (command === 'init-publisher' && args.length === 2) {
        const [directory, publisherId] = args;
        if (!/^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,127}$/.test(publisherId)) throw new Error('Invalid publisher ID');
        const identity = await generateIdentity();
        await mkdir(directory, { recursive: true, mode: 0o700 });
        await writeFile(join(directory, 'publisher-private.json'), JSON.stringify({ publisherId, key: await crypto.subtle.exportKey('jwk', identity.privateKey) }, null, 2), { flag: 'wx', mode: 0o600 });
        await writeFile(join(directory, 'trusted-publishers.ts'), `// Public release-time anchor. Keep the private key offline.\nexport const TRUSTED_PUBLISHERS: Readonly<Record<string, JsonWebKey>> = Object.freeze(${JSON.stringify({ [publisherId]: identity.publicKey }, null, 2)});\n`, { flag: 'wx' });
        console.log('Publisher created. Review trusted-publishers.ts, copy its public anchor into manager/src/auth-v2/trusted-publishers.ts, then rebuild.');
        return;
    }
    if (command === 'issue-tenant' && args.length === 4) {
        const [publisherPath, ownerRequestPath, configPath, outputPath] = args;
        const publisher = JSON.parse(await readFile(publisherPath, 'utf8'));
        const config = JSON.parse(await readFile(configPath, 'utf8'));
        const ownerCode = (await readFile(ownerRequestPath, 'utf8')).trim();
        const identity = await importIdentity(publisher.key);
        const certificate = await issueTenant(publisher.publisherId, identity, ownerCode, { ...config, expiresAt: Date.parse(config.expiresAt) });
        await writeFile(outputPath, certificate + '\n', { flag: 'wx' });
        console.log(`Signed tenant appointment written to ${outputPath}. Verify the recipient fingerprint before distribution.`);
        return;
    }
    throw new Error('Usage:\n  issuer init-publisher <private-directory> <publisher-id>\n  issuer issue-tenant <publisher-private.json> <owner-request.jws> <tenant-config.json> <output.jws>');
}
main().catch(error => { console.error(error instanceof Error ? error.message : 'Issuer failed'); process.exitCode = 1; });
