import { build } from 'esbuild';
import { mkdtemp, writeFile, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';

const dir = await mkdtemp(join(tmpdir(), 'vam-issuer-smoke-'));
try {
    await build({ entryPoints: { crypto: 'manager/src/auth-v2/crypto.ts', model: 'manager/src/auth-v3/model.ts', enrollment: 'manager/src/auth-v3/enrollment.ts' }, bundle: true, platform: 'node', format: 'esm', outdir: dir, outExtension: { '.js': '.mjs' } });
    const { generateIdentity, signJws, keyId } = await import(pathToFileURL(join(dir, 'crypto.mjs')));
    const { generateInbox } = await import(pathToFileURL(join(dir, 'enrollment.mjs')));
    const { verifyTenant } = await import(pathToFileURL(join(dir, 'model.mjs')));
    const run = args => execFileSync(process.execPath, ['dist/issuer.mjs', ...args], { encoding: 'utf8', stdio: 'pipe' });
    run(['init-publisher', join(dir, 'issuer'), 'test-publisher']);
    assert.throws(() => run(['init-publisher', join(dir, 'issuer'), 'test-publisher']));
    const owner = await generateIdentity(), now = Date.now();
    const inbox = await generateInbox();
    const request = await signJws({ v: 3, type: 'owner-request', tenantId: 'test-tenant', bundleId: 'example', key: owner.publicKey, inboxKey: inbox.publicKey,
        label: 'Test owner', requestId: crypto.randomUUID(), issuedAt: now, expiresAt: now + 86400_000 }, owner);
    await writeFile(join(dir, 'owner.jws'), request);
    const repo = name => ({ baseUrl: 'https://api.github.com', owner: 'test', repo: name });
    await writeFile(join(dir, 'config.json'), JSON.stringify({ tenantId: 'test-tenant', bundleId: 'example',
        authority: repo('authority'), access: repo('access'), requests: repo('requests'), expiresAt: new Date(now + 86400_000).toISOString() }));
    run(['issue-tenant', join(dir, 'issuer/publisher-private.json'), join(dir, 'owner.jws'), join(dir, 'config.json'), join(dir, 'tenant.jws')]);
    const publisher = JSON.parse(await readFile(join(dir, 'issuer/publisher-private.json'), 'utf8'));
    const tenant = await verifyTenant((await readFile(join(dir, 'tenant.jws'), 'utf8')).trim(), { 'test-publisher': publisher.key }, Date.now());
    assert.equal(await keyId(tenant.ownerKey), owner.keyId);
    assert.equal(tenant.bundleId, 'example'); assert.equal(tenant.inboxKey.n, inbox.publicKey.n);
    console.log('Issuer CLI: key generation, overwrite protection, owner request and tenant signature passed. No network used.');
} finally { await rm(dir, { recursive: true, force: true }); }
