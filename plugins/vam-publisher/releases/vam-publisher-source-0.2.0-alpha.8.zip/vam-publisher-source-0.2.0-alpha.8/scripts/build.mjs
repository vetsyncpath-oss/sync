import { build, context } from 'esbuild';
import { mkdir, copyFile, readFile } from 'node:fs/promises';
import { watch as watchPath } from 'node:fs';

// Layout: the repository root is the Publisher project. The manager it bakes lives in ./manager.
//   manager/            sources, manifest and styles of the manager (the template the Publisher embeds)
//   main.ts, src/       the Publisher plugin
//   main.js             the compiled Publisher in the project root (standard Obsidian layout; also usable as a dev plugin folder)
//   manager/main.js     the compiled manager template
//   dist/manager/       manager template for packaging (main.js, manifest.json, styles.css)
//   dist/vam-publisher/ the installable Publisher plugin
const watch = process.argv.includes('--watch');
const runtimeOptions = {
    metafile: true,
    entryPoints: ['manager/main.ts'],
    bundle: true,
    platform: 'browser',
    format: 'cjs',
    external: ['obsidian'],
    outfile: 'manager/main.js',
    logLevel: 'info',
    plugins: [{
        name: 'exclude-legacy-authorization',
        setup(builder) {
            builder.onEnd(result => {
                const inputs = Object.keys(result.metafile?.inputs ?? {});
                // Nothing from the Publisher (or anything else outside manager/) may enter the manager bundle.
                if (inputs.some(path => !path.startsWith('manager/') && !path.startsWith('node_modules/'))) {
                    return { errors: [{ text: 'Publisher code entered the manager bundle' }] };
                }
                if (inputs.some(path => /legacy-manager|auth-v[23]\/(?:runtime|service|enrollment|settings-tab)\.ts|manager\/src\/issuer\//.test(path))) {
                    return { errors: [{ text: 'Legacy authorization entered the release bundle' }] };
                }
            });
        },
    }],
};

async function buildIssuer() { await build({ entryPoints: ['scripts/issuer.ts'], bundle: true, platform: 'node', format: 'esm', outfile: 'dist/issuer.mjs', logLevel: 'warning' }); }

/** The Publisher embeds the compiled manager as its template, so it is always built after the manager.
 *  Output follows the standard Obsidian layout in the project root (main.js beside manifest.json and styles.css)
 *  and is also copied to dist/vam-publisher/ for packaging. */
async function buildPublisher() {
    const template = { main: await readFile('manager/main.js', 'utf8'), manifest: await readFile('manager/manifest.json', 'utf8'), styles: await readFile('manager/styles.css', 'utf8') };
    if (template.main.split(JSON.stringify('__VAM_PROFILE_V4_JSON__')).length !== 2) throw new Error('Manager template must contain exactly one baking marker');
    await mkdir('dist/manager', { recursive: true }); await mkdir('dist/vam-publisher', { recursive: true });
    await copyFile('manager/main.js', 'dist/manager/main.js'); await copyFile('manager/styles.css', 'dist/manager/styles.css'); await copyFile('manager/manifest.json', 'dist/manager/manifest.json');
    await build({ entryPoints: ['main.ts'], bundle: true, platform: 'browser', format: 'cjs', external: ['obsidian'], outfile: 'main.js', logLevel: 'warning', define: { __VAM_MANAGER_TEMPLATE__: JSON.stringify(template) } });
    await copyFile('main.js', 'dist/vam-publisher/main.js'); await copyFile('manifest.json', 'dist/vam-publisher/manifest.json'); await copyFile('styles.css', 'dist/vam-publisher/styles.css');
}

if (watch) {
    // Rebuild the Publisher whenever the manager or the Publisher's own sources change.
    let queued, running = Promise.resolve();
    const rebuild = () => { clearTimeout(queued); queued = setTimeout(() => { running = running.then(() => buildPublisher()).then(() => console.log('Publisher rebuilt: main.js'), error => console.error(error instanceof Error ? error.message : error)); }, 150); };
    const watcher = await context({ ...runtimeOptions, plugins: [...runtimeOptions.plugins, { name: 'rebuild-publisher', setup(builder) { builder.onEnd(result => { if (!result.errors.length) rebuild(); }); } }] });
    await watcher.watch();
    const sources = [watchPath('main.ts', rebuild), watchPath('src', rebuild)];
    let closing = false;
    const close = async () => {
        if (closing) return;
        closing = true;
        sources.forEach(source => source.close());
        await watcher.dispose();
        process.exit(0);
    };
    process.once('SIGINT', close);
    process.once('SIGTERM', close);
} else {
    await build(runtimeOptions);
    await buildIssuer();
    await buildPublisher();
}
