"""Package the complete source tree and built distribution without local credentials."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time
import zipfile

ROOT = Path(__file__).resolve().parent.parent
VERSION = json.loads((ROOT / 'package.json').read_text())['version']
MANAGER_VERSION = json.loads((ROOT / 'manager/manifest.json').read_text())['version']
PREFIX = f'vam-publisher-source-{VERSION}'
OUTPUT = ROOT / 'artifacts'


def archive_time():
    """Reproducible and honest: SOURCE_DATE_EPOCH if set, otherwise the time of the last commit (never a fixed 1980/1970 date)."""
    epoch = os.environ.get('SOURCE_DATE_EPOCH') or subprocess.check_output(['git', 'log', '-1', '--format=%ct'], cwd=ROOT).decode().strip()
    return max(time.gmtime(int(epoch))[:6], (1980, 1, 1, 0, 0, 0))


ARCHIVE_TIME = archive_time()


def write_zip(target, entries):
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(entries):
            entry = zipfile.ZipInfo(name, date_time=ARCHIVE_TIME)
            entry.compress_type = zipfile.ZIP_DEFLATED
            entry.external_attr = 0o100644 << 16
            archive.writestr(entry, data)
    with zipfile.ZipFile(target) as archive:
        assert archive.testzip() is None, 'Archive CRC check failed'
        assert len(archive.namelist()) == len(entries)
        for name, data in entries:
            assert archive.read(name) == data, name


# The previous file named .zip was actually RAR and contained the old SDK.
write_zip(ROOT / 'manager/src/sdk/vam-guard.zip', [('vam-guard.ts', (ROOT / 'manager/vam-guard.ts').read_bytes())])
assert (ROOT / 'manager/vam-guard.ts').read_bytes() == (ROOT / 'manager/src/sdk/vam-guard.ts').read_bytes()
paths = subprocess.check_output(['git', 'ls-files', '-z', '--cached', '--others', '--exclude-standard'], cwd=ROOT).decode().split('\0')
files = set()
for name in paths:
    if not name:
        continue
    path = Path(name)
    if any(part in {'.git', 'node_modules', '.issuer', 'artifacts', '__pycache__'} for part in path.parts):
        continue
    if path.name.startswith('.env') or path.name == 'publisher-private.json' or path.suffix in {'.pem', '.key'}:
        raise RuntimeError(f'Unexpected secret material: {name}')
    source = ROOT / path
    if source.is_symlink() or not source.is_file():
        raise RuntimeError(f'Unexpected source file: {name}')
    files.add(name)
for name in ['manager/main.js', 'manager/manifest.json', 'manager/styles.css', 'issuer.mjs', 'vam-publisher/main.js', 'vam-publisher/manifest.json', 'vam-publisher/styles.css']:
    path = 'dist/' + name
    if not (ROOT / path).is_file():
        raise RuntimeError('Build first: npm run test:release')
    files.add(path)
assert (ROOT / 'main.js').exists(), 'Run npm run build first: the compiled Publisher main.js ships beside manifest.json and styles.css'
files.add('main.js')
entries = [(f'{PREFIX}/{name}', (ROOT / name).read_bytes()) for name in sorted(files)]
OUTPUT.mkdir(exist_ok=True)
target = OUTPUT / f'{PREFIX}.zip'
write_zip(target, entries)
checksum = hashlib.sha256(target.read_bytes()).hexdigest()
publisher_version = json.loads((ROOT / 'manifest.json').read_text())['version']
publisher_target = OUTPUT / f'vam-publisher-{publisher_version}.zip'
write_zip(publisher_target, [(f'vam-publisher/{name}', (ROOT / f'dist/vam-publisher/{name}').read_bytes()) for name in ['main.js', 'manifest.json', 'styles.css']])
publisher_checksum = hashlib.sha256(publisher_target.read_bytes()).hexdigest()
(OUTPUT / 'SHA256SUMS').write_text(f'{checksum}  {target.name}\n{publisher_checksum}  {publisher_target.name}\n')
print(f'{publisher_target.relative_to(ROOT)}: installable publisher plugin')
print(f'{target.relative_to(ROOT)}: {len(entries)} files, {target.stat().st_size} bytes')
print(f'SHA256: {checksum}')
print(f'Manager template version inside: {MANAGER_VERSION}')
