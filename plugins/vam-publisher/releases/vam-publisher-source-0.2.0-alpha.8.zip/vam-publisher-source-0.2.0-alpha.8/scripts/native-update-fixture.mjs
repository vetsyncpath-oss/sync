// Evaluated inside the disposable desktop vault by smoke-vault-isolation.py.
async ({ operation, files, signature, version }) => {
    if (operation === 'sign') {
        const pair = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign','verify']);
        const utf8 = new TextEncoder();
        const base64 = bytes => btoa(String.fromCharCode(...bytes)).replaceAll('+','-').replaceAll('/','_').replace(/=+$/, '');
        const json = item => base64(utf8.encode(JSON.stringify(item)));
        const metadata = {};
        for (const [name, contents] of Object.entries(files)) {
            const bytes = utf8.encode(contents);
            const hash = new Uint8Array(await crypto.subtle.digest('SHA-256',bytes));
            metadata[name] = { size: bytes.length, sha256: Array.from(hash,b=>b.toString(16).padStart(2,'0')).join('') };
        }
        const data = json({alg:'ES256',typ:'vam+jws'}) + '.' + json({kind:'vam-release-1',component:'refsync',version,files:metadata});
        const proof = new Uint8Array(await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},pair.privateKey,utf8.encode(data)));
        return {publicKey:await crypto.subtle.exportKey('jwk',pair.publicKey),signature:data+'.'+base64(proof)};
    }
    const manager = app.plugins.plugins['vault-access-manager'], runtime=manager.accessV4, studio=app.plugins.plugins.refsync;
    await Promise.all([runtime.ready,studio.ready]);
    if (operation === 'verify') {
        for (let i=0;i<100;i++) {
            if (runtime.profile.receipts?.some(r=>r.status==='applied') && studio.manifest.version===version) return;
            await new Promise(resolve=>setTimeout(resolve,100));
        }
        throw Error('Missing successful Studio activation receipt');
    }
    studio.setDispatchBinding({tenantId:runtime.build.tenantId,bundleId:runtime.build.bundleId});
    const git = window.fetch, base='https://assets.example.invalid/fixture/';
    window.fetch = (url,init) => String(url).startsWith(base) ? Promise.resolve(new Response(files[String(url).slice(base.length)])) : git(url,init);
    await runtime.syncInstallation(true);
    const fleet=runtime.profile.installations;
    if (!fleet.some(r=>r.instance===runtime.instanceId)) throw Error('Missing installation receipt');
    await runtime.service.dispatch([runtime.instanceId],'refsync',signature,base,Date.now()+600000,'Desktop update test',fleet,runtime.service.document.revision);

    let release, started, queued;
    const entered=new Promise(resolve=>{started=resolve;}), lock=new Promise(resolve=>{release=resolve;});
    const waiting=new Promise(resolve=>{queued=resolve;});
    const current=studio.scheduler.serial(async()=>{started();await lock;});
    await entered;
    const updateWindow=studio.withUpdateWindow.bind(studio);
    studio.withUpdateWindow=(...args)=>{queued();return updateWindow(...args);};
    const task=runtime.processCampaigns();
    const path=app.vault.configDir+'/plugins/refsync/manifest.json';
    let timer;
    try {
        await Promise.race([waiting,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('Update did not enter the scheduler')),15000);})]);
        if (JSON.parse(await app.vault.adapter.read(path)).version===version) throw Error('Update wrote during active work');
    } finally { clearTimeout(timer); release(); }
    await Promise.all([current,task]);
    if (JSON.parse(await app.vault.adapter.read(path)).version!==version) throw Error('Did not stage signed update');
}
