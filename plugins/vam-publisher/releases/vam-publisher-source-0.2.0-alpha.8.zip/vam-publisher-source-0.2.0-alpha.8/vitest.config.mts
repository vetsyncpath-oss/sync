// vitest.config.mts — рантайм-алиас модуля 'obsidian' на честный мок.
// В реальном Obsidian модуль предоставляет платформа; типы — src/types/obsidian-shims.d.ts.
import { defineConfig } from 'vitest/config';
import { fileURLToPath } from 'node:url';

export default defineConfig({
    resolve: {
        alias: {
            obsidian: fileURLToPath(new URL('./test/mocks/obsidian.ts', import.meta.url)),
        },
    },
    test: {
        environment: 'node',
        include: ['test/**/*.test.ts'],
        // main.ts запускает setInterval при onload: фейковые таймеры в тестах
        // управляются самими тестами; но страховка от зависших воркеров не помешает.
        testTimeout: 15_000,
        hookTimeout: 15_000,
    },
});
