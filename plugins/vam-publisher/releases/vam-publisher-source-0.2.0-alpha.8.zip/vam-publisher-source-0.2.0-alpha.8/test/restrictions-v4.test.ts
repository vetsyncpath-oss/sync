import {attachVaultFile} from './helpers/vault-file';
import 'fake-indexeddb/auto';
import { parseHTML } from 'linkedom';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { Notice, Plugin } from 'obsidian';
import { Runtime } from '../manager/src/auth-v4/runtime';
import { SettingsTab } from '../manager/src/auth-v4/settings-tab';
import { UiRestrictions, isNoteOrFolder } from '../manager/src/auth-v4/restrictions';
import { LocalStore } from '../manager/src/auth-v3/local';
import { decodeCode, encodeCode, validateDocument, type AccessCode, type Document } from '../manager/src/auth-v4/model';
import { zip } from '../src/zip';
import { build, Repository } from './helpers/v4';

const runtimes: Runtime[] = [];
beforeEach(() => { const { window } = parseHTML('<!doctype html><html><body></body></html>'); for (const name of ['document', 'HTMLElement', 'HTMLInputElement', 'HTMLTextAreaElement', 'Event']) vi.stubGlobal(name, (window as any)[name]); Notice.messages.length = 0; });
afterEach(() => { runtimes.splice(0).forEach(r => r.dispose()); delete (globalThis as any).__VAM__; delete (globalThis as any).vaultSyncAuth; vi.unstubAllGlobals(); });

const md = { path: 'a.md', extension: 'md' }, canvas = { path: 'b.canvas', extension: 'canvas' }, png = { path: 'c.png', extension: 'png' }, folder = { path: 'dir', children: [] as unknown[] };

/** A vault whose methods live on the prototype, as in Obsidian, so restoring must not leave own properties behind. */
function fakeApp(withSetting = true) {
    class FakeVault { calls: string[] = []; async trash(file: any, system: boolean) { this.calls.push(`trash:${file.path}:${system}:${this === (app.vault as any)}`); } async delete(file: any) { this.calls.push(`delete:${file.path}`); } }
    class FakeFileManager { calls: string[] = []; async trashFile(file: any) { this.calls.push(`trashFile:${file.path}`); } promptForDeletion(file: any) { this.calls.push(`prompt:${file.path}`); } promptForFolderDeletion(file: any) { this.calls.push(`promptFolder:${file.path}`); } }
    const app: any = { vault: new FakeVault(), fileManager: new FakeFileManager() };
    if (withSetting) app.setting = { calls: [] as string[], open() { this.calls.push('open'); }, openTabById(id: string) { this.calls.push('tab:' + id); } };
    return app;
}

describe('UiRestrictions: soft guards wrapped around Obsidian API', () => {
    it('recognises notes and folders but not attachments', () => {
        expect([md, canvas, folder].every(isNoteOrFolder)).toBe(true);
        expect([png, null, undefined, 'x'].some(isNoteOrFolder)).toBe(false);
    });
    it('refuses to delete notes and folders through every API path, keeps attachments deletable and the original receiver', async () => {
        const app = fakeApp(), messages: string[] = [], guard = new UiRestrictions(app, m => messages.push(m)); guard.update(['note.delete']);
        await app.vault.trash(md, false); await app.vault.delete(canvas); await app.fileManager.trashFile(folder); app.fileManager.promptForDeletion(md); app.fileManager.promptForFolderDeletion(folder);
        expect(app.vault.calls).toEqual([]); expect(app.fileManager.calls).toEqual([]);
        await app.vault.trash(png, true); await app.fileManager.trashFile(png);
        expect(app.vault.calls).toEqual(['trash:c.png:true:true']); expect(app.fileManager.calls).toEqual(['trashFile:c.png']);
        expect(messages).toHaveLength(1); // throttled: one notice for a burst
    });
    it('refuses to open settings and its tabs only while the guard is on, and removes every wrapper afterwards', () => {
        const app = fakeApp(), guard = new UiRestrictions(app, () => {}); guard.update(['settings.open']);
        app.setting.open(); app.setting.openTabById('x'); expect(app.setting.calls).toEqual([]);
        guard.update([]); app.setting.open(); app.setting.openTabById('x'); expect(app.setting.calls).toEqual(['open', 'tab:x']);
        guard.update(['note.delete']); guard.dispose();
        expect(Object.prototype.hasOwnProperty.call(app.vault, 'trash')).toBe(false); // prototype method restored by deleting our own property
        expect(Object.prototype.hasOwnProperty.call(app.fileManager, 'trashFile')).toBe(false);
    });
    it('is idempotent and never stacks wrappers on repeated updates', async () => {
        const app = fakeApp(), original = Object.getPrototypeOf(app.vault).trash, guard = new UiRestrictions(app, () => {});
        guard.update(['note.delete']); const wrapped = app.vault.trash; for (let i = 0; i < 5; i++) guard.update(['note.delete']);
        expect(app.vault.trash).toBe(wrapped); guard.update([]); expect(app.vault.trash).toBe(original);
    });
    it('does not break a wrapper that another plugin installed on top of ours', async () => {
        const app = fakeApp(), guard = new UiRestrictions(app, () => {}); guard.update(['note.delete']);
        const ours = app.vault.trash, seen: string[] = []; app.vault.trash = async function (this: any, file: any, system: boolean) { seen.push(file.path); return ours.call(this, file, system); };
        guard.update([]); await app.vault.trash(md, false);
        expect(seen).toEqual(['a.md']); expect(app.vault.calls).toEqual(['trash:a.md:false:true']); // passes through; neither blocked nor lost
    });
    it('retries a target that does not exist yet and ignores methods absent in this Obsidian version', () => {
        const app = fakeApp(false), guard = new UiRestrictions(app, () => {}); guard.update(['settings.open', 'note.delete']);
        app.setting = { calls: [] as string[], open() { this.calls.push('open'); }, openTabById() {} }; guard.update(['settings.open', 'note.delete']);
        app.setting.open(); expect(app.setting.calls).toEqual([]);
        expect(typeof app.fileManager.promptForDeletion).toBe('function'); // exists here; absent targets would simply be skipped
    });
    it('shows a fresh notice again after the throttle window and toggles body classes', async () => {
        let at = 1000; const app = fakeApp(), messages: string[] = [], guard = new UiRestrictions(app, m => messages.push(m), () => at);
        guard.update(['note.delete', 'settings.open']);
        expect(document.body.classList.contains('vam-restrict-delete')).toBe(true); expect(document.body.classList.contains('vam-restrict-settings')).toBe(true);
        await app.vault.trash(md, false); at += 1000; await app.vault.trash(md, false); at += 3000; await app.vault.trash(md, false); expect(messages).toHaveLength(2);
        guard.update(['settings.open']); expect(document.body.classList.contains('vam-restrict-delete')).toBe(false);
        guard.dispose(); expect(document.body.classList.contains('vam-restrict-settings')).toBe(false);
    });
});

describe('restrictions in the shared configuration', () => {
    const base = (members: unknown[]): unknown => ({ v: 4, tenantId: build.tenantId, bundleId: build.bundleId, adminId: build.adminId, adminPassword: 'x', revision: 1, updatedAt: 1, transport: { token: 't', version: 1, expiresOn: null }, members, invitations: [], receipts: [] });
    const member = (restrictions: unknown) => ({ accountId: 'u1', label: '', password: 'p', active: true, expiresAt: null, maxDevices: 1, devices: [], blockedDevices: [], ...(restrictions === undefined ? {} : { restrictions }) });
    it('accepts known and unknown names, so a newer Administrator never invalidates an older client', () => {
        expect(() => validateDocument(base([member(['note.delete', 'settings.open', 'future.feature'])]), build)).not.toThrow();
        expect(() => validateDocument(base([member(undefined)]), build)).not.toThrow();
    });
    it('rejects malformed restriction lists', () => {
        for (const bad of ['note.delete', [1], ['Note Delete'], ['a', 'a'], Array.from({ length: 33 }, (_, i) => 'r' + i)]) expect(() => validateDocument(base([member(bad)]), build)).toThrow('ограничения');
    });
});

describe('access key cleaning', () => {
    const code: AccessCode = { v: 4, tenantId: build.tenantId, bundleId: build.bundleId, accountId: 'a1b2', purpose: 'update', transport: { token: 'ghp_' + 'x'.repeat(80), version: 1, expiresOn: null } };
    it('ignores line wrapping, spaces and zero-width characters inserted by messengers', () => {
        const text = encodeCode(code);
        for (const variant of [text.replace(/(.{40})/g, '$1\n'), text.slice(0, 50) + ' ' + text.slice(50), text.slice(0, 20) + '\u200b' + text.slice(20), ' \u00a0' + text + '\r\n']) expect(decodeCode(variant, build).accountId).toBe('a1b2');
    });
    it('still rejects garbage', () => { expect(() => decodeCode('VAM4.@@@', build)).toThrow('Некорректный ключ'); });
});

describe('ZIP timestamps', () => {
    const when = Date.UTC(2026, 9, 16, 9, 15, 30);
    it('stores the release time in DOS and extended-timestamp fields and Unix permissions', () => {
        const archive = zip({ 'plugin/a.txt': 'hello' }, when), view = new DataView(archive.buffer), nameLength = view.getUint16(26, true), extra = 30 + nameLength;
        const time = view.getUint16(10, true), date = view.getUint16(12, true);
        expect([(date >> 9) + 1980, (date >> 5) & 15, date & 31, time >> 11, (time >> 5) & 63, (time & 31) * 2]).toEqual([2026, 10, 16, 9, 15, 30]);
        expect(view.getUint16(extra, true)).toBe(0x5455); expect(view.getUint32(extra + 5, true)).toBe(Math.floor(when / 1000));
        const central = view.getUint32(archive.length - 6, true); expect(view.getUint32(central + 38, true) >>> 16).toBe(0o100644);
    });
    it('defaults to the current time rather than 1980 and refuses impossible dates', () => {
        const view = new DataView(zip({ 'a.txt': 'x' }).buffer), date = view.getUint16(12, true); expect((date >> 9) + 1980).toBeGreaterThanOrEqual(2026);
        expect(() => zip({ 'a.txt': 'x' }, Date.UTC(1975, 0, 1))).toThrow('дата'); expect(() => zip({ 'a.txt': 'x' }, NaN)).toThrow('дата');
    });
});

function user(repo: Repository, installation: string, app: any, awaitRefresh = true, fetcher: typeof fetch = repo.fetcher) {
    const plugin = new Plugin({ appId: 'vault-' + installation, vault: { adapter: { getBasePath: () => '/' + installation } }, workspace: { onLayoutReady() {} }, ...app } as any, { id: 'vault-access-manager', version: 'test' });
    attachVaultFile(plugin,installation); const runtime = new Runtime(plugin, { ...build, bootstrapToken: 'old-token' }, { fetcher }, new LocalStore(installation)); runtimes.push(runtime);
    return { runtime, start: () => runtime.start({ awaitRefresh }) };
}

describe('restrictions follow the signed-in user, end to end', () => {
    async function enrol() {
        const repo = new Repository(), adminSide = user(repo, crypto.randomUUID(), fakeApp()); await adminSide.start(); await adminSide.runtime.loginAdministrator(build.defaultPassword);
        const invitation = await adminSide.runtime.service!.invite('Alice', { accountId: 'alice', password: 'alice-password' });
        const installation = crypto.randomUUID(), app = fakeApp(), alice = user(repo, installation, app); await alice.start(); await alice.runtime.applyCode(invitation.code);
        await adminSide.runtime.tick(); await alice.runtime.tick(); expect(alice.runtime.decision.status).toBe('granted');
        return { repo, admin: adminSide.runtime, alice: alice.runtime, app, installation };
    }
    it('applies after the Administrator sets them, lifts when removed, and never touches the Administrator', async () => {
        const { admin, alice, app } = await enrol();
        await app.vault.trash(md, false); expect(app.vault.calls).toHaveLength(1); app.setting.open(); expect(app.setting.calls).toEqual(['open']);
        await admin.service!.setRestrictions('alice', ['note.delete', 'settings.open']); await alice.tick();
        await app.vault.trash(md, false); app.setting.open(); expect(app.vault.calls).toHaveLength(1); expect(app.setting.calls).toEqual(['open']);
        expect(admin.service!.restrictions()).toEqual([]); // the Administrator's own session is never restricted
        await admin.service!.setRestrictions('alice', []); await alice.tick(); await app.vault.trash(md, false); expect(app.vault.calls).toHaveLength(2);
    });
    it('keeps unknown names written by a newer version when a known set is saved, and rejects invalid input', async () => {
        const { repo, admin } = await enrol();
        repo.edit(d => { d.members[0].restrictions = ['future.feature']; }); await admin.tick();
        await admin.service!.setRestrictions('alice', ['note.delete']); expect(repo.document().members[0].restrictions).toEqual(['note.delete', 'future.feature']);
        await admin.service!.setRestrictions('alice', []); expect(repo.document().members[0].restrictions).toEqual(['future.feature']);
        await expect(admin.service!.setRestrictions('alice', ['nope' as any])).rejects.toThrow('Некорректные'); await expect(admin.service!.setRestrictions('ghost', [])).rejects.toThrow('не найден');
    });
    it('lifts every guard on sign-out and on unload', async () => {
        const { admin, alice, app } = await enrol(); await admin.service!.setRestrictions('alice', ['note.delete']); await alice.tick();
        await app.vault.trash(md, false); expect(app.vault.calls).toHaveLength(0);
        await alice.logout(); await app.vault.trash(md, false); expect(app.vault.calls).toHaveLength(1);
        await alice.loginUser('alice', 'alice-password'); await app.vault.trash(md, false); expect(app.vault.calls).toHaveLength(1);
        alice.dispose(); await app.vault.trash(md, false); expect(app.vault.calls).toHaveLength(2);
    });
    it('enforces the saved policy on a cold start with no network, before the first check finishes', async () => {
        const { repo, admin, alice, installation } = await enrol(); await admin.service!.setRestrictions('alice', ['note.delete', 'settings.open']); await alice.tick();
        alice.dispose(); await new Promise(resolve => setTimeout(resolve, 50)); // let the profile finish saving and close
        const app = fakeApp(), offline: typeof fetch = async () => { throw new TypeError('network down'); };
        const again = user(repo, installation, app, false, offline); await again.start();
        expect(again.runtime.session?.kind).toBe('user'); expect(again.runtime.decision.status).toBe('granted');
        await app.vault.trash(md, false); app.setting.open(); expect(app.vault.calls).toEqual([]); expect(app.setting.calls).toEqual([]);
        await again.runtime.ready; await app.vault.trash(md, false); expect(app.vault.calls).toEqual([]); // a failed check keeps the cached policy
    });
    it('opens the manager\'s own profile window instead of Obsidian settings for a restricted user, and keeps it open', async () => {
        const { admin, alice, app } = await enrol(); await admin.service!.setRestrictions('alice', ['settings.open']); await alice.tick();
        const { Modal } = await import('obsidian'); (Modal as any).opened = [];
        alice.openSettings(); expect(app.setting.calls).toEqual([]); expect((Modal as any).opened).toHaveLength(1);
        alice.changed(); alice.changed(); expect((Modal as any).opened).toHaveLength(1); // not closed by the periodic refresh
        for (const m of [...(Modal as any).opened]) m.close();
    });
});

describe('startup and background work', () => {
    it('returns from start() before a slow network answers and settles `ready` afterwards', async () => {
        const repo = new Repository(); let release!: () => void; const gate = new Promise<void>(resolve => { release = resolve; });
        const slow: typeof fetch = async (input, init) => { await gate; return repo.fetcher(input, init); };
        let layout: (() => void) | undefined; const plugin = new Plugin({ appId: 'slow', vault: { adapter: { getBasePath: () => '/slow' } }, workspace: { onLayoutReady(cb: () => void) { layout = cb; } } } as any, { id: 'vault-access-manager', version: 'test' });
        const runtime = new Runtime(plugin, { ...build, bootstrapToken: 'old-token' }, { fetcher: slow }, new LocalStore(crypto.randomUUID())); runtimes.push(runtime);
        await runtime.start({ awaitRefresh: false });
        expect(layout).toBeTypeOf('function'); expect(runtime.service).not.toBeNull(); expect(runtime.service!.online).toBe(false);
        layout!(); expect(document.querySelector('.vam-login-modal')).not.toBeNull(); // login cards do not wait for Git
        release(); await runtime.ready; expect(runtime.service!.online).toBe(true);
    });
    it('refreshes when the app becomes visible again', async () => {
        const repo = new Repository(), { runtime, start } = user(repo, crypto.randomUUID(), fakeApp()); await start();
        const spy = vi.spyOn(runtime, 'tick'); Object.defineProperty(document, 'hidden', { value: false, configurable: true });
        document.dispatchEvent(new (document.defaultView as any).Event('visibilitychange')); expect(spy).toHaveBeenCalled();
    });
});

describe('Administrator request processing', () => {
    it('does not read a processed or invalid request file again on every minute tick', async () => {
        const repo = new Repository(), original = repo.fetcher; let reads = 0;
        repo.fetcher = async (input, init) => { if (/\/contents\/vam\/requests\/[^/]+$/.test(new URL(String(input)).pathname) && (init?.method ?? 'GET') === 'GET') reads++; return original(input, init); };
        const admin = user(repo, crypto.randomUUID(), fakeApp()); await admin.start(); await admin.runtime.loginAdministrator(build.defaultPassword);
        const invitation = await admin.runtime.service!.invite('Bob', { accountId: 'bob', password: 'bob-password' });
        const bob = user(repo, crypto.randomUUID(), fakeApp()); await bob.start(); await bob.runtime.applyCode(invitation.code);
        repo.files.set('vam/requests/garbage.json', { sha: 'g1', text: '{"v":4,"deviceProof":"not-a-jws"}' });
        await admin.runtime.tick(); const afterFirst = reads; expect(afterFirst).toBeGreaterThanOrEqual(2);
        await admin.runtime.tick(); await admin.runtime.tick(); expect(reads).toBe(afterFirst);
        expect(admin.runtime.service!.rejected).toBe(1); // the invalid file is still counted, without being fetched again
    });
});

describe('interface: Administrator toggles and phone-friendly ID field', () => {
    const labelled = (root: ParentNode, title: string, which: 'first' | 'last' = 'last') => { const found = Array.from(root.querySelectorAll('label')).filter(l => l.firstChild?.textContent === title); const label = which === 'first' ? found[0] : found[found.length - 1]; if (!label) throw new Error('Missing field: ' + title); return label.querySelector('input,textarea') as HTMLInputElement; };
    const pressed = (root: ParentNode, title: string) => { const b = Array.from(root.querySelectorAll('button')).find(b => b.textContent === title || b.querySelector('.vam-card-title')?.textContent === title); if (!b) throw new Error('Missing button: ' + title); return b as HTMLButtonElement; };
    it('lets the Administrator save restrictions for a user and shows the saved state', async () => {
        const repo = new Repository(), side = user(repo, crypto.randomUUID(), fakeApp()); await side.start(); await side.runtime.loginAdministrator(build.defaultPassword);
        await side.runtime.service!.addUser('Alice', { accountId: 'alice', password: 'alice-password' });
        const view = new SettingsTab((side.runtime as any).plugin.app, (side.runtime as any).plugin, side.runtime); document.body.append(view.containerEl); view.display();
        expect(document.body.textContent).toContain('Ограничения интерфейса'); expect(document.body.textContent).toContain('а не от намеренного обхода');
        const box = labelled(document, 'Запретить удаление заметок и папок'); expect(box.checked).toBe(false); box.checked = true;
        await (pressed(document, 'Сохранить изменения').onclick as any)({ preventDefault() {} });
        expect(repo.document().members[0].restrictions).toEqual(['note.delete']);
        view.display(); expect(labelled(document, 'Запретить удаление заметок и папок').checked).toBe(true); expect(labelled(document, 'Запретить вход в настройки Obsidian').checked).toBe(false);
    });
    it('keeps phone keyboards from capitalising or correcting the user ID', async () => {
        const repo = new Repository(), side = user(repo, crypto.randomUUID(), fakeApp()); await side.start();
        const view = new SettingsTab((side.runtime as any).plugin.app, (side.runtime as any).plugin, side.runtime); document.body.append(view.containerEl); view.display();
        await (pressed(document, 'Я уже подключён').onclick as any)({ preventDefault() {} });
        const id = labelled(document, 'ID пользователя');
        expect([id.getAttribute('autocapitalize'), id.getAttribute('autocorrect'), id.getAttribute('autocomplete')]).toEqual(['off', 'off', 'username']);
    });
});

describe('restrictions before the first key, and the one permanent user key', () => {
    const device = (repo: Repository, app = fakeApp()) => ({ app, ...user(repo, crypto.randomUUID(), app) });
    async function admin(repo: Repository) { const side = user(repo, crypto.randomUUID(), fakeApp()); await side.start(); await side.runtime.loginAdministrator(build.defaultPassword); return side.runtime; }
    /** The key alone connects a device: no ID or password is typed. */
    async function connect(repo: Repository, adminRuntime: Runtime, key: string) {
        const d = device(repo); await d.start(); await d.runtime.applyCode(key); await adminRuntime.tick(); await d.runtime.tick(); return d;
    }

    it('stores restrictions when the user is added and enforces them from the very first connection', async () => {
        const repo = new Repository(), a = await admin(repo);
        const added = await a.service!.addUser('Alice', { accountId: 'alice', password: 'alice-password', restrictions: ['note.delete', 'settings.open'] });
        expect(repo.document().members[0].restrictions).toEqual(['note.delete', 'settings.open']);
        const alice = await connect(repo, a, added.code); expect(alice.runtime.decision.status).toBe('granted');
        await alice.app.vault.trash(md, false); alice.app.setting.open(); expect(alice.app.vault.calls).toEqual([]); expect(alice.app.setting.calls).toEqual([]);
    });
    it('also accepts restrictions when a key is issued with invite(), and validates every input', async () => {
        const repo = new Repository(), a = await admin(repo);
        await a.service!.invite('Bob', { accountId: 'bob', restrictions: ['note.delete'] }); expect(repo.document().members[0].restrictions).toEqual(['note.delete']);
        await expect(a.service!.addUser('X', { restrictions: ['nope' as any] })).rejects.toThrow('Некорректные'); await expect(a.service!.addUser('X', { restrictions: ['note.delete', 'note.delete'] })).rejects.toThrow('Некорректные');
        await expect(a.service!.addUser('X', { maxDevices: 0 })).rejects.toThrow('Лимит'); await expect(a.service!.addUser('X', { maxDevices: 101 })).rejects.toThrow('Лимит');
        await a.service!.addUser('Carol', { accountId: 'carol' }); await expect(a.service!.addUser('Again', { accountId: 'carol' })).rejects.toThrow('уже существует');
        expect(repo.document().members.find(m => m.accountId === 'carol')!.restrictions).toBeUndefined(); // an empty choice leaves the field out
    });
    it('is one key: shown again and again, connects every device while places remain, then stops', async () => {
        const repo = new Repository(), a = await admin(repo), added = await a.service!.addUser('Dana', { accountId: 'dana', password: 'dana-password', maxDevices: 2 });
        expect(a.service!.userKey('dana')).toBe(added.code); expect(a.service!.userKey('dana')).toBe(added.code); // never consumed
        const first = await connect(repo, a, added.code), second = await connect(repo, a, a.service!.userKey('dana')!);
        expect([first.runtime.decision.status, second.runtime.decision.status]).toEqual(['granted', 'granted']); expect(repo.document().members[0].devices).toHaveLength(2);
        expect(a.service!.userKey('dana')).toBe(added.code); expect(repo.document().invitations.filter(i => i.standing && i.consumedBy === null)).toHaveLength(1);
        const third = device(repo); await third.start(); await third.runtime.applyCode(added.code); await a.tick(); // above the limit: the request waits for the Administrator
        expect(third.runtime.decision.status).not.toBe('granted'); expect(a.service!.pending.map(p => [p.kind, p.accountId])).toEqual([['extra', 'dana']]);
        await a.service!.approve(a.service!.pending[0].code); await a.tick(); await third.runtime.tick(); expect(third.runtime.decision.status).toBe('granted'); expect(repo.document().members[0].maxDevices).toBe(3);
    });
    it('with the default limit of one, a second device waits for a decision; a connected device may re-apply the key to recover', async () => {
        const repo = new Repository(), a = await admin(repo), added = await a.service!.addUser('Eli', { accountId: 'eli' });
        const first = await connect(repo, a, added.code); expect(first.runtime.decision.status).toBe('granted');
        const second = device(repo); await second.start(); await second.runtime.applyCode(added.code); await a.tick(); expect(second.runtime.decision.status).not.toBe('granted'); expect(a.service!.pending).toHaveLength(1);
        await first.runtime.applyCode(a.service!.userKey('eli')!); await a.tick(); await first.runtime.tick(); expect(first.runtime.decision.status).toBe('granted');
    });
    it('reissue replaces the key at once without touching connected devices; a password change keeps it', async () => {
        const repo = new Repository(), a = await admin(repo), added = await a.service!.addUser('Fay', { accountId: 'fay', maxDevices: 3 });
        const one = await connect(repo, a, added.code), fresh = await a.service!.reissueKey('fay'); expect(fresh).not.toBe(added.code); expect(a.service!.userKey('fay')).toBe(fresh);
        const stale = device(repo); await stale.start(); await expect(stale.runtime.applyCode(added.code)).rejects.toThrow('недействителен');
        await a.tick(); await one.runtime.tick(); expect(one.runtime.decision.status).toBe('granted');
        const two = await connect(repo, a, fresh); expect(two.runtime.decision.status).toBe('granted');
        await a.service!.updateMember('fay', { label: 'Fay', password: 'new-password-1', active: true, expiresAt: null }); expect(a.service!.userKey('fay')).toBe(fresh);
        expect(repo.document().invitations.filter(i => i.standing)).toHaveLength(1);
    });
    it('gives a key to a user who has none (added before permanent keys), and none to a revoked user', async () => {
        const repo = new Repository(), a = await admin(repo); await a.service!.invite('Old', { accountId: 'old' });
        repo.edit(d => { d.invitations = []; }); await a.tick(); expect(a.service!.userKey('old')).toBeNull();
        const key = await a.service!.reissueKey('old'); expect(a.service!.userKey('old')).toBe(key);
        await a.service!.change('revoke-member', 'old'); expect(a.service!.userKey('old')).toBeNull(); await expect(a.service!.reissueKey('old')).rejects.toThrow('действующего');
        const late = device(repo); await late.start(); await expect(late.runtime.applyCode(key)).rejects.toThrow('недействителен');
    });
    it('ignores a "used" mark written by an older manager, so a mixed-version team never loses the key', async () => {
        const repo = new Repository(), a = await admin(repo), added = await a.service!.addUser('Ivy', { accountId: 'ivy', maxDevices: 2 });
        repo.edit(d => { d.invitations.find(i => i.standing)!.consumedBy = 'request-from-an-older-manager'; }); await a.tick();
        expect(a.service!.userKey('ivy')).toBe(added.code); const one = await connect(repo, a, added.code); expect(one.runtime.decision.status).toBe('granted');
        const two = await connect(repo, a, added.code); expect(two.runtime.decision.status).toBe('granted');
    });
    it('does not bring back a revoked device, and keeps working through a PAT change', async () => {
        const repo = new Repository(), a = await admin(repo), added = await a.service!.addUser('Gus', { accountId: 'gus', maxDevices: 2 });
        const one = await connect(repo, a, added.code), id = one.runtime.device!.keyId; await a.service!.change('remove-device', 'gus', id);
        await one.runtime.tick(); expect(one.runtime.decision.status).toBe('blocked'); await one.runtime.applyCode(added.code).catch(() => {}); await a.tick(); await one.runtime.tick(); expect(one.runtime.decision.status).not.toBe('granted');
        const before = decodeCode(a.service!.userKey('gus')!, build).transport; await a.service!.rotateToken('new-token', null);
        const after = decodeCode(a.service!.userKey('gus')!, build); expect([after.transport.version, after.transport.token]).toEqual([before.version + 1, 'new-token']); expect(after.secret).toBe(decodeCode(added.code, build).secret);
    });
    it('keeps the recovery code for devices that missed a PAT change, and still refuses it on a device that was never connected', async () => {
        const repo = new Repository(), a = await admin(repo), added = await a.service!.addUser('Hal', { accountId: 'hal' }), hal = await connect(repo, a, added.code);
        const fresh = device(repo); await fresh.start(); await expect(fresh.runtime.applyCode(a.service!.recoveryCode('hal'))).rejects.toThrow('ранее подключённого'); // fresh device, update code
        await hal.runtime.applyCode(a.service!.recoveryCode('hal')); expect(hal.runtime.decision.status).toBe('granted');
    });
});

describe('administrator card shows the one permanent key', () => {
    const open = async () => {
        const repo = new Repository(), side = user(repo, crypto.randomUUID(), fakeApp()); await side.start(); await side.runtime.loginAdministrator(build.defaultPassword);
        const view = new SettingsTab((side.runtime as any).plugin.app, (side.runtime as any).plugin, side.runtime); document.body.append(view.containerEl); view.display();
        return { repo, runtime: side.runtime, view };
    };
    const labelledAll = (title: string) => Array.from(document.querySelectorAll('label')).filter(l => l.firstChild?.textContent === title).map(l => l.querySelector('input,textarea') as HTMLInputElement);
    const click = async (title: string) => { const b = Array.from(document.querySelectorAll('button')).find(b => b.textContent === title) as HTMLButtonElement; await (b.onclick as any)({ preventDefault() {} }); };
    const standing = () => document.querySelector('textarea[data-standing]') as HTMLTextAreaElement | null;
    it('takes restrictions and a device limit in the add form, then shows that same key in the card for good', async () => {
        const { repo, runtime } = await open();
        labelledAll('ID пользователя (пусто — создать автоматически)')[0].value = 'alice'; labelledAll('Имя или метка пользователя')[0].value = 'Alice'; labelledAll('Лимит устройств')[0].value = '2';
        labelledAll('Запретить удаление заметок и папок')[0].checked = true; await click('Выдать ключ доступа');
        const member = repo.document().members[0]; expect([member.maxDevices, member.restrictions]).toEqual([2, ['note.delete']]);
        const output = labelledAll('Данные для личной передачи пользователю')[0].value; expect(output).toContain('VAM4.'); expect(output).toContain('ID: alice');
        expect(standing()).toBeNull(); await click('Показать ключ пользователя'); expect(standing()).not.toBeNull(); expect(standing()!.value).toBe(runtime.service!.userKey('alice')); expect(output).toContain(standing()!.value); // one key, not two
        const shown = standing()!.value; await runtime.tick(); runtime.changed(); runtime.changed(); expect(standing()!.value).toBe(shown); // background refreshes keep it
        expect(document.body.textContent).toContain('Подключает устройство без ID и пароля'); expect(document.body.textContent).toContain('Скопировать приглашение');
    });
    it('redraws the key after a PAT change, offers to create one for an old user, and hides it for a revoked user', async () => {
        const { repo, runtime } = await open(); await runtime.service!.addUser('Bob', { accountId: 'bob' }); runtime.changed();
        await click('Показать ключ пользователя'); const first = standing()!.value; await runtime.service!.rotateToken('new-token', null); runtime.changed();
        await click('Показать ключ пользователя'); expect(standing()!.value).not.toBe(first); expect(standing()!.value).toBe(runtime.service!.userKey('bob'));
        repo.edit(d => { d.invitations = []; }); await runtime.tick(); runtime.changed();
        expect(standing()).toBeNull(); expect(document.body.textContent).toContain('ещё нет постоянного ключа');
        await click('Создать постоянный ключ'); await click('Показать ключ пользователя'); expect(standing()!.value).toBe(runtime.service!.userKey('bob')); expect(standing()!.value).toContain('VAM4.');
        await runtime.service!.change('revoke-member', 'bob'); runtime.changed();
        expect(standing()).toBeNull(); expect(document.body.textContent).toContain('Доступ отозван'); expect(document.body.textContent).toContain('Восстановить доступ');
    });
});

