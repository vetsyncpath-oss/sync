import 'fake-indexeddb/auto';
import { afterEach, describe, expect, it } from 'vitest';
import { Plugin } from 'obsidian';
import { Runtime } from '../manager/src/auth-v3/runtime';
import { IssuerService } from '../manager/src/issuer/service';
import { issueTenant, ownerFingerprint, publicAnchor, verifyOwnerRequest } from '../manager/src/issuer/protocol';
import { LocalStore } from '../manager/src/auth-v3/local';
import { generateIdentity, inspectJws, signJws, verifyJws } from '../manager/src/auth-v2/crypto';
import { verifyTenant, DAY } from '../manager/src/auth-v3/model';
import { fixture } from './helpers/v3';
import PublisherPlugin from '../legacy-main';
const password = 'publisher protected passphrase';
const active: Array<{ dispose(): void }> = [];
function issuer(name = crypto.randomUUID()) { const service = new IssuerService(new LocalStore(name)); active.push(service); return service; }
afterEach(() => active.splice(0).forEach(s => s.dispose()));
async function ownerRequest(f: Awaited<ReturnType<typeof fixture>>) { return signJws({ v: 3, type: 'owner-request', tenantId: f.tenant.tenantId, bundleId: f.tenant.bundleId, key: f.owner.publicKey, inboxKey: f.inbox.publicKey, issuedAt: f.now, expiresAt: f.now + DAY }, f.owner); }
function config(f: Awaited<ReturnType<typeof fixture>>) { return { tenantId: f.tenant.tenantId, bundleId: f.tenant.bundleId, access: f.tenant.access, requests: f.tenant.requests, expiresAt: f.tenant.expiresAt }; }

describe('separate publisher plugin', () => {
    it('imports existing publisher identity, exports only a public root, and issues a compatible certificate', async () => {
        const f = await fixture(), s = issuer(); await s.start();
        const key = await crypto.subtle.exportKey('jwk', f.publisher.privateKey);
        await s.importCli(JSON.stringify({ publisherId: 'publisher', key }), password);
        const request = await ownerRequest(f), hash = await ownerFingerprint(request);
        const certificate = await s.issue(request, config(f), hash);
        expect((await verifyTenant(certificate, f.roots, Date.now())).ownerKey).toEqual((await verifyOwnerRequest(request)).key);
        expect(s.exportAnchor()).toContain(f.publisher.publicKey.x); expect(s.exportAnchor()).not.toContain(key.d);
        expect(s.exportBackup()).not.toContain(key.d); expect(s.exportBackup()).not.toContain('privateKey');
        await expect(s.issue(request, config(f), 'unconfirmed')).rejects.toThrow('отпечаток');
        s.lock(); await expect(s.issue(request, config(f), hash)).rejects.toThrow('Разблокируйте');
    });
    it('retains the encrypted publisher after restart, requires password and rejects profile metadata tampering', async () => {
        const name = crypto.randomUUID(), s = issuer(name); await s.create('publisher', password); const backup = s.exportBackup(); s.dispose();
        const next = issuer(name); await next.start(); expect(next.unlocked).toBe(false);
        await expect(next.unlock('wrong password')).rejects.toThrow(); await next.unlock(password); expect(next.unlocked).toBe(true);
        const target = issuer(), changed = JSON.parse(backup); changed.publisherId = 'attacker';
        await expect(target.restore(JSON.stringify(changed), password)).rejects.toThrow('не совпадает');
        await target.restore(backup, password); expect(target.exportAnchor()).toBe(next.exportAnchor());
        await expect(target.restore(backup, password)).rejects.toThrow('перезаписать');
    });
    it('does not overwrite a publisher when two windows initialize concurrently', async () => {
        const name = crypto.randomUUID(), a = issuer(name), b = issuer(name);
        const results = await Promise.allSettled([a.create('publisher-a', password), b.create('publisher-b', password)]);
        expect(results.filter(r => r.status === 'fulfilled')).toHaveLength(1);
        const loaded = issuer(name); await loaded.start(); await loaded.unlock(password); expect(loaded.unlocked).toBe(true);
    });
    it('cancels an in-flight unlock after the user locks the signing key', async () => {
        const s = issuer(); await s.create('publisher', password); s.lock();
        const task = s.unlock(password); s.lock(); await expect(task).rejects.toThrow('отменена'); expect(s.unlocked).toBe(false);
    });
    it('rejects an expired request, changed context, invalid signature and a shared requests/access repository', async () => {
        const f = await fixture(), request = await ownerRequest(f);
        await expect(verifyOwnerRequest(request, f.now + DAY)).rejects.toThrow();
        await expect(issueTenant('publisher', f.publisher, request, { ...config(f), tenantId: 'foreign' })).rejects.toThrow('не совпадают');
        await expect(issueTenant('publisher', f.publisher, request, { ...config(f), requests: f.tenant.access })).rejects.toThrow('separate');
        const attacker = await generateIdentity();
        await expect(verifyOwnerRequest(await signJws(inspectJws(request), attacker))).rejects.toThrow();
        expect(publicAnchor('publisher', { ...f.publisher.publicKey, d: 'secret' })).not.toContain('secret');
    });
    it('bootstraps a legacy owner through the issuer and preserves the old settings without trusting them', async () => {
        const f = await fixture(), name = crypto.randomUUID(); f.stores.access.files.clear();
        const host = new Plugin({ vault: {}, initialSettings: { role: 'owner', legacyPassword: 'unchanged' } } as any, { id: 'manager', version: 'test' });
        const old = new Runtime(host, {}, f.fetcher, new LocalStore(name)); active.push(old); await old.start();
        expect(old.legacyOwnerDetected).toBe(true); expect(old.hasTrustRoots).toBe(false); expect(old.decision.status).toBe('blocked');
        const request = await old.createOwner(password, 'org-a', 'bundle-a'), backup = old.exportOwner(); old.lockOwner();
        expect(old.profile.ownerDraft).toMatchObject({ tenantId: 'org-a', bundleId: 'bundle-a', request });
        const publisherPlugin = new PublisherPlugin(host.app, { id: 'vam-publisher', version: 'test' }); await publisherPlugin.onload();
        active.push({ dispose: () => publisherPlugin.onunload() });
        (host.app as any).plugins = { plugins: { 'vam-publisher': publisherPlugin } };
        await old.sendToPublisher(request); expect(publisherPlugin.ownerRequestDraft).toBe(request); expect(publisherPlugin.issuer.unlocked).toBe(false);
        // The key's valid backup is a recovery path even if the current encrypted box already exists.
        await old.restoreOwner(backup, password); expect(old.ownerUnlocked).toBe(true);
        const foreignBox = await (async () => { const other = new Runtime(new Plugin({ vault: {} } as any, { id: 'other', version: 'test' }), {}, f.fetcher, new LocalStore(crypto.randomUUID())); active.push(other); await other.start(); await other.createOwner(password, 'org-a', 'bundle-a'); return other.exportOwner(); })();
        await expect(old.restoreOwner(foreignBox, password)).rejects.toThrow('другому хозяину');
        const publisher = issuer(); await publisher.create('publisher', password);
        const certificate = await publisher.issue(request, config(f), await ownerFingerprint(request));
        await expect(old.configureOwner(certificate, f.ownerConnection.credentials, { access: null, requests: null })).rejects.toThrow('Unknown publisher');
        old.dispose();
        // Simulate reloading a manager built with the explicitly exported public anchor.
        const ready = new Runtime(host, { publisher: publisher.profile!.publicKey }, f.fetcher, new LocalStore(name)); active.push(ready); await ready.start();
        expect(ready.profile.ownerDraft!.request).toBe(request);
        (host.app as any).plugins.plugins['vault-access-manager'] = { accessV3: ready };
        await publisherPlugin.sendToManager(certificate); expect(ready.profile.ownerCertificateDraft).toBe(certificate);
        expect(ready.ownerUnlocked).toBe(false); expect(ready.ownerService).toBeNull();
        await ready.unlockOwner(password); await ready.configureOwner(certificate, f.ownerConnection.credentials, { access: null, requests: null });
        await ready.ownerService!.initialize(); expect(ready.ownerService!.isOwner()).toBe(true); expect(ready.ownerService!.state!.revision).toBe(1);
        expect(ready.decision.status).toBe('blocked'); expect((host.app as any).savedSettings).toBeUndefined();
    });
    it('has no manager gate side effects when loaded alongside the manager', async () => {
        const gate = { version: '6', marker: 'existing-manager' }; (globalThis as any).__VAM__ = gate;
        const plugin = new PublisherPlugin({ vault: {} } as any, { id: 'vam-publisher', version: 'test' });
        await plugin.onload(); expect((globalThis as any).__VAM__).toBe(gate); plugin.onunload(); expect((globalThis as any).__VAM__).toBe(gate);
        delete (globalThis as any).__VAM__;
    });
});
