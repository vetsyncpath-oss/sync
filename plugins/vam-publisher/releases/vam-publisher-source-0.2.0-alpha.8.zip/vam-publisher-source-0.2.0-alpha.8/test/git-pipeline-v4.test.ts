import 'fake-indexeddb/auto';
import { afterEach, describe, expect, it } from 'vitest';
import { Plugin } from 'obsidian';
import { LocalStore } from '../manager/src/auth-v3/local';
import { Runtime } from '../manager/src/auth-v4/runtime';
import { build, Repository } from './helpers/v4';
const active: Runtime[] = [];
afterEach(() => { active.splice(0).forEach(runtime => runtime.dispose()); delete (globalThis as any).__VAM__; delete (globalThis as any).vaultSyncAuth; });
describe('full HTTP pipeline with original browser transport constraints', () => {
    it.each([
        ['https://api.github.com', false, 'PUT'],
        ['https://api.github.com', true, 'PUT'],
        ['https://gitea.example/api/v1', false, 'POST'],
        ['https://gitea.example/api/v1', true, 'POST'],
    ] as const)('initializes, enrolls and rotates PAT on %s (raw=%s)', async (baseUrl, rawFiles, createMethod) => {
        const profile = { ...build, repository: { ...build.repository, baseUrl } }, repo = new Repository(profile), calls: Array<{ method: string; url: string; token: string }> = [];
        repo.rawFiles = rawFiles; repo.gitBlobShas = rawFiles;
        const browserFetch: typeof fetch = async function(this: unknown, input, init) {
            if (this !== globalThis) throw new TypeError("Failed to execute 'fetch' on 'Window': Illegal invocation");
            calls.push({ url: String(input), method: init!.method!, token: (init!.headers as any).Authorization }); return repo.fetcher(input, init);
        };
        const make = () => { const runtime = new Runtime(new Plugin({ vault: {} } as any, { id: 'vault-access-manager', version: 'test' }), profile, { fetcher: browserFetch }, new LocalStore(crypto.randomUUID())); active.push(runtime); return runtime; };
        const admin = make(), user = make(); await admin.start(); await user.start();
        await admin.loginAdministrator(profile.defaultPassword, 'old-token'); expect(admin.service!.isAdministrator()).toBe(true);
        const invitation = await admin.service!.invite('User', { accountId: 'alice', password: 'alice-pass' }); await user.applyCode(invitation.code); await admin.tick(); await user.tick();
        expect(user.decision.status).toBe('granted'); expect(repo.document().members[0].devices).toHaveLength(1);
        const device = user.device.keyId; await admin.rotateToken('new-token', null); await user.tick(); expect(user.profile.transport!.token).toBe('new-token'); repo.tokens.delete('old-token'); await user.tick(); expect(user.decision.status).toBe('granted'); expect(user.device.keyId).toBe(device);
        await user.logout(); await user.loginUser('alice', 'alice-pass'); expect(user.decision.status).toBe('granted'); expect([...repo.files.keys()].filter(p => p.startsWith('vam/requests/'))).toHaveLength(1);
        repo.edit(document => { document.adminPassword = 'new-password'; }); await admin.tick(); expect(admin.session).toBeNull(); await admin.loginAdministrator('new-password'); expect(admin.service!.isAdministrator()).toBe(true);
        expect(calls.find(c => c.method !== 'GET')!.method).toBe(createMethod); expect(calls.some(c => c.method === 'PUT' && c.token === 'Bearer new-token')).toBe(true);
    });
});
