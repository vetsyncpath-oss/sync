import {describe,it,expect} from 'vitest';
import {studioLines} from '../manager/src/auth-v4/studio-diagnostics';
import type {App,Plugin} from 'obsidian';
describe('optional local Sync Studio report',()=>{
  const manager={} as Plugin;
  const lines=(studio?:unknown)=>studioLines({plugins:{plugins:{refsync:studio}}} as unknown as App,manager);
  it('reads protocol 1 on demand and supports older payloads',()=>{
    expect(lines().join(' ')).toContain('не установлен');
    expect(lines({}).join(' ')).toContain('0.8.1');
    expect(lines({getDispatchStatus: (caller:Plugin)=>{expect(caller).toBe(manager);return null;}})).toHaveLength(1);
    expect(lines({getDispatchStatus:()=>({protocol:1,phase:'idle',access:'vamGranted',version:'0.8.1'})}).join(' ')).toContain('Разрешено');
  });
  it('discards unrecognized fields, free text and invalid timestamps',()=>{
    const secret='private/user.md';
    const report={protocol:1, pluginId:'refsync', phase:secret, access:secret, version:secret, lastSuccessAt:Infinity, failedProfiles:-1, lastErrorCode:secret,
      events:[{code:'failed',at:1000,errorCode:secret},{code:secret,at:1000}],path:secret};
    const text=lines({getDispatchStatus:()=>report}).join(' ');
    expect(text).not.toContain(secret);expect(text).toContain('Ошибка применения');expect(text).not.toContain('Invalid Date');
    expect(lines({getDispatchStatus:()=>({...report,protocol:4})})).toHaveLength(1);
  });
});
