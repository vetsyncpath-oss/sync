import { describe, it, expect } from 'vitest';
import { generateIdentity, signJws, verifyJws, inspectJws, keyId, encryptIdentity, decryptIdentity } from '../manager/src/auth-v2/crypto';
import { AccessService, type Store, type Connection } from '../manager/src/auth-v2/service';
import { verifyTenant, verifyAuthority, verifyJoin, type TenantGrant } from '../manager/src/auth-v2/model';
import { GitConflict, type VersionedFile } from '../manager/src/auth-v2/git-store';

import { fixture } from './helpers/v2';

describe('signed tenant authorization', () => {
    it('grants only the appointed subject, tenant, product and capability; owner gets no implicit product access', async () => {
        const f = await fixture();
        expect(f.admin.isOwner()).toBe(true);
        expect(f.admin.access(f.query).status).toBe('blocked');
        await f.admin.grantMember(f.request, ['product-a'], ['use'], f.now + 3600_000);
        await f.member.refresh();
        expect(f.member.access(f.query).status).toBe('granted');
        for (const q of [{ ...f.query, tenantId: 'org-b' }, { ...f.query, productId: 'cloud-vault-sync' }, { ...f.query, capability: 'admin' }]) expect(f.member.access(q).status).toBe('blocked');
        const otherDevice = await f.connect(await generateIdentity()); await otherDevice.refresh();
        expect(otherDevice.access(f.query).status).toBe('blocked');
    });
    it('does not trust the owner of another organization or a key supplied by an invitation', async () => {
        const f = await fixture();
        const foreign = await generateIdentity();
        const foreignCert = await signJws({ ...f.tenant, tenantId: 'org-b', ownerKey: foreign.publicKey }, f.publisher);
        const foreignService = await AccessService.connect({ ...f.connection, certificate: foreignCert }, foreign, f.roots, { stores: f.stores });
        expect(foreignService.isOwner()).toBe(true);
        expect(foreignService.access(f.query).status).toBe('blocked');
        await foreignService.refresh();
        await expect(foreignService.grantMember(f.request, ['product-a'], ['use'], f.now + 10000)).rejects.toThrow();
        const forged = await signJws({ ...f.tenant, ownerKey: foreign.publicKey }, foreign);
        await expect(verifyTenant(forged, f.roots, f.now)).rejects.toThrow('Signature');
        await expect(verifyTenant(f.connection.certificate, {}, f.now)).rejects.toThrow('Unknown publisher');
    });
    it('rejects tampering, algorithm substitution and wrong document types', async () => {
        const f = await fixture();
        const sections = f.connection.certificate.split('.');
        const payload = { ...(inspectJws(f.connection.certificate) as object), tenantId: 'org-b' };
        sections[1] = Buffer.from(JSON.stringify(payload)).toString('base64url');
        await expect(verifyTenant(sections.join('.'), f.roots, f.now)).rejects.toThrow('Signature');
        sections[0] = Buffer.from(JSON.stringify({ alg: 'none', typ: 'vam+jws' })).toString('base64url');
        await expect(verifyTenant(sections.join('.'), f.roots, f.now)).rejects.toThrow('header');
        await expect(verifyAuthority(await signJws({ ...f.tenant, type: 'tenant' }, f.owner), f.tenant, f.now)).rejects.toThrow('type');
    });
    it('refuses credentials/rights in a request repository and rejects malformed scopes', async () => {
        const f = await fixture();
        await expect(verifyTenant(await signJws({ ...f.tenant, requests: f.tenant.access }, f.publisher), f.roots, f.now)).rejects.toThrow('separate');
        await expect(f.admin.grantMember(f.request, ['not-licensed'], ['use'], f.now + 10000)).rejects.toThrow('member');
        await expect(f.admin.grantMember(f.request, [], ['use'], f.now + 10000)).rejects.toThrow('scope');
    });
    it('blocks on first 401 and never promotes a request into authority', async () => {
        const f = await fixture();
        await f.member.submitRequest(f.request);
        expect(f.stores.requests.files.size).toBe(1);
        expect(f.member.access(f.query).status).toBe('blocked');
        f.stores.authority.fail = true;
        await f.member.refresh();
        expect(f.member.access(f.query).status).toBe('blocked');
        expect(f.member.error).toContain('401');
    });
    it('rejects a user-signed access snapshot even with write access to the repository', async () => {
        const f = await fixture();
        await f.admin.grantMember(f.request, ['product-a'], ['use'], f.now + 10000);
        const saved = f.stores.access.files.get('access.jws')!;
        const payload = inspectJws(saved.text) as any;
        payload.signer = f.user.keyId;
        payload.members[0].products.push('cloud-vault-sync');
        f.stores.access.files.set('access.jws', { sha: 'forged', text: await signJws(payload, f.user) });
        await f.member.refresh();
        expect(f.member.access(f.query).status).toBe('blocked');
        expect(f.member.error).toContain('signer');
    });
    it('handles administrator assignment, privilege boundaries and revocation without sharing owner keys', async () => {
        const f = await fixture();
        const adminIdentity = await generateIdentity();
        const delegated = await f.connect(adminIdentity);
        const request = await delegated.createRequest('admin', 'Operator');
        await f.admin.grantAdmin(request, f.now + 86400_000);
        await delegated.refresh();
        expect(await delegated.isAdmin()).toBe(true);
        expect(delegated.isOwner()).toBe(false);
        expect(delegated.access(f.query).status).toBe('blocked');
        await expect(delegated.grantAdmin(await f.member.createRequest('admin', 'Escalation'), f.now + 10000)).rejects.toThrow('прав');
        await delegated.grantMember(f.request, ['product-a'], ['use'], f.now + 3600_000);
        await f.member.refresh(); expect(f.member.access(f.query).status).toBe('granted');
        await f.admin.revokeAdmin(adminIdentity.keyId);
        await delegated.refresh(); expect(await delegated.isAdmin()).toBe(false);
        await expect(delegated.revokeMember(f.user.keyId)).rejects.toThrow('прав');
        await f.member.refresh(); expect(f.member.access(f.query).status).toBe('granted');
    });
    it('refuses admin delegation when authority and access share a repository', async () => {
        const f = await fixture();
        const t = { ...f.tenant, access: f.tenant.authority };
        const certificate = await signJws(t, f.publisher);
        const service = await AccessService.connect({ ...f.connection, certificate }, f.owner, f.roots, { stores: f.stores });
        await expect(service.grantAdmin(await f.member.createRequest('admin', ''), f.now + 10000)).rejects.toThrow('separate');
    });
    it('temporary administrators can edit existing longer grants, but cannot extend their own signing authority', async () => {
        const f = await fixture();
        await f.admin.grantMember(f.request, ['product-a'], ['use'], f.now + 86400_000);
        const delegated = await f.connect(await generateIdentity());
        await f.admin.grantAdmin(await delegated.createRequest('admin', 'Temporary'), f.now + 1000);
        await delegated.grantMember(f.request, ['product-a'], ['use'], f.now + 86400_000);
        await f.member.refresh();
        expect(f.member.access(f.query).status).toBe('granted');
        expect(f.member.access(f.query).validUntil).toBe(f.now + 1000);
        f.advance(1001);
        expect(f.member.access(f.query).status).toBe('blocked');
        // Invalid access must not lock the owner out of the independent authority.
        await f.admin.revokeAdmin(delegated.subject);
        await expect(f.admin.resetMemberAccess('wrong-tenant')).rejects.toThrow('идентификатор');
        await f.admin.resetMemberAccess('org-a');
        await f.admin.grantMember(f.request, ['product-a'], ['use'], f.now + 1000);
        await f.member.refresh(); expect(f.member.access(f.query).status).toBe('granted');
    });
    it('revokes a member immediately after refresh and enforces expiry without refresh', async () => {
        const f = await fixture();
        await f.admin.grantMember(f.request, ['product-a'], ['use'], f.now + 1000);
        await f.member.refresh(); expect(f.member.access(f.query).status).toBe('granted');
        f.advance(1001); expect(f.member.access(f.query).status).toBe('blocked');
        await f.admin.grantMember(f.request, ['product-a'], ['use'], f.now + 1000);
        await f.member.refresh(); expect(f.member.access(f.query).status).toBe('granted');
        await f.admin.revokeMember(f.user.keyId);
        await f.member.refresh(); expect(f.member.access(f.query).status).toBe('blocked');
    });
    it('checks request signature, tenant, expiry, purpose and full key fingerprint', async () => {
        const f = await fixture();
        const request = await verifyJoin(f.request, 'org-a', f.now);
        expect(await keyId(request.key)).toBe(f.user.keyId);
        expect(f.user.keyId).toHaveLength(43);
        await expect(verifyJoin(f.request, 'org-b', f.now)).rejects.toThrow('request');
        await expect(verifyJoin(f.request, 'org-a', f.now + 8 * 86400_000)).rejects.toThrow('expired');
        await expect(f.admin.grantMember(await f.member.createRequest('admin', ''), ['product-a'], ['use'], f.now + 10000)).rejects.toThrow('member request');
    });
    it('detects rollback and equal-revision replacement within the session', async () => {
        const f = await fixture();
        await f.admin.grantMember(f.request, ['product-a'], ['use'], f.now + 10000);
        const old = f.stores.access.files.get('access.jws')!;
        await f.member.refresh();
        await f.admin.revokeMember(f.user.keyId);
        await f.member.refresh();
        f.stores.access.files.set('access.jws', old);
        await f.member.refresh(); expect(f.member.error).toContain('rollback');
        expect(f.member.access(f.query).status).toBe('blocked');
    });
    it('does not restore a session after dispose while a network read is in flight', async () => {
        const f = await fixture();
        await f.admin.grantMember(f.request, ['product-a'], ['use'], f.now + 10000);
        const original = f.stores.authority.read.bind(f.stores.authority);
        let release!: () => void;
        const wait = new Promise<void>(resolve => { release = resolve; });
        f.stores.authority.read = async p => { await wait; return original(p); };
        const loading = f.member.refresh();
        f.member.dispose(); release(); await loading;
        expect(f.member.access(f.query).status).toBe('blocked');
        expect(f.member.isOwner()).toBe(false);
    });
    it('rejects concurrent stale writes instead of resurrecting revoked data', async () => {
        const f = await fixture();
        await f.admin.grantMember(f.request, ['product-a'], ['use'], f.now + 10000);
        const stale = f.stores.access.files.get('access.jws')!;
        await f.admin.revokeMember(f.user.keyId);
        await expect(f.stores.access.write('access.jws', stale.text, stale.sha)).rejects.toBeInstanceOf(GitConflict);
        await f.member.refresh(); expect(f.member.access(f.query).status).toBe('blocked');
    });
    it('a competing service cannot overwrite a revocation after signing an older snapshot', async () => {
        const f = await fixture();
        await f.admin.grantMember(f.request, ['product-a'], ['use'], f.now + 10000);
        const secondOwner = await f.connect(f.owner);
        const original = f.stores.access.write.bind(f.stores.access);
        let release!: () => void, reached!: () => void;
        const gate = new Promise<void>(resolve => { release = resolve; });
        const started = new Promise<void>(resolve => { reached = resolve; });
        let delayFirst = true;
        f.stores.access.write = async (path, text, sha) => {
            if (delayFirst) { delayFirst = false; reached(); await gate; }
            return original(path, text, sha);
        };
        const updating = secondOwner.grantMember(f.request, ['product-a'], ['use'], f.now + 20000);
        const rejected = expect(updating).rejects.toBeInstanceOf(GitConflict);
        await started;
        await f.admin.revokeMember(f.user.keyId);
        release(); await rejected;
        await f.member.refresh(); expect(f.member.access(f.query).status).toBe('blocked');
    });
    it('encrypts identity backups and rejects wrong passwords/tampering', async () => {
        const identity = await generateIdentity();
        const encrypted = await encryptIdentity(identity, 'a long test passphrase');
        expect(JSON.stringify(encrypted)).not.toContain((await crypto.subtle.exportKey('jwk', identity.privateKey)).d!);
        expect((await decryptIdentity(encrypted, 'a long test passphrase')).keyId).toBe(identity.keyId);
        await expect(decryptIdentity(encrypted, 'incorrect')).rejects.toThrow();
        await expect(encryptIdentity(identity, 'short')).rejects.toThrow('12');
        const sig = await signJws({ test: 'proof' }, identity);
        expect(await verifyJws(sig, identity.publicKey)).toEqual({ test: 'proof' });
    });
});
