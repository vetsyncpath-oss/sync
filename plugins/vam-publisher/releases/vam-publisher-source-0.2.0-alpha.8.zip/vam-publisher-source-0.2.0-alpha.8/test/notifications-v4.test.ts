import 'fake-indexeddb/auto';
import { afterEach, describe, expect, it } from 'vitest';
import { Notice, Plugin } from 'obsidian';
import { Notifications, type NotificationState } from '../manager/src/auth-v4/notifications';
import { Runtime } from '../manager/src/auth-v4/runtime';
import { LocalStore } from '../manager/src/auth-v3/local';
import { Repository, build } from './helpers/v4';
const active: Runtime[] = [];
afterEach(() => { active.splice(0).forEach(r => r.dispose()); delete (globalThis as any).__VAM__; delete (globalThis as any).vaultSyncAuth; });
const state = (status: 'granted' | 'pending' | 'blocked', reason: string | null = null): NotificationState => ({ decision: { status, reason, validUntil: null }, role: 'user', requestSubmitted: false, requestFailed: false, pending: [], pluginError: '' });
async function fixture() { const repo = new Repository(), plugin = new Plugin({ vault: {} } as any, { id: 'vault-access-manager', version: 'test' }); const r = new Runtime(plugin, build, { fetcher: repo.fetcher }, new LocalStore(crypto.randomUUID())); active.push(r); await r.start(); await r.loginAdministrator(build.defaultPassword, 'old-token'); (Notice as any).messages = []; return { repo, r }; }
describe('episode-based notices instead of settings-only errors', () => {
    it('notifies once on access loss, remains quiet on polls and notifies about a later new incident', () => {
        const messages: string[] = [], n = new Notifications(s => messages.push(s));
        n.update(state('granted')); for (let i = 0; i < 10; i++) n.update(state('blocked', 'access-revoked-or-expired'));
        expect(messages).toHaveLength(1); expect(messages[0]).toContain('отозван');
        n.update(state('granted')); n.update(state('blocked', 'device-revoked')); expect(messages).toHaveLength(2);
    });
    it('keeps intentional logout quiet and does not repeat old restore errors', () => {
        const messages: string[] = [], n = new Notifications(s => messages.push(s)); n.update(state('granted')); n.reset(); n.update({ ...state('blocked', 'signed-out'), role: null, pluginError: 'old error' }); expect(messages).toEqual([]);
    });
    it('announces submitted/approved enrollment and deduplicates failures and replacement requests', () => {
        const messages: string[] = [], n = new Notifications(s => messages.push(s)); n.update(state('blocked')); n.update({ ...state('pending'), requestFailed: true }); n.update({ ...state('pending'), requestFailed: true });
        n.update({ ...state('pending'), requestSubmitted: true }); n.update(state('granted'));
        expect(messages).toHaveLength(3);
        const admin = { ...state('granted'), role: 'administrator' as const, pending: ['request-1'] }; n.update(admin); n.update(admin); n.update({ ...admin, pending: [] }); n.update(admin); expect(messages).toHaveLength(4);
    });
    it('reports a lost administrative session once after a repository password change', async () => {
        const { repo, r } = await fixture(); repo.edit(d => { d.adminPassword = 'new-password'; }); await r.tick(); await r.tick();
        const messages = (Notice as any).messages.map((m: any[]) => m[0]); expect(messages.filter((m: string) => m.includes('Вход Администратора'))).toHaveLength(1); expect(r.session).toBeNull();
    });
    it('warns when a previously distant PAT expiry enters the warning window during a running session', async () => {
        const { repo, r } = await fixture(); repo.edit(d => { d.transport.expiresOn = new Date(Date.now() + 20 * 86400000).toISOString().slice(0, 10); }); await r.tick(); expect((Notice as any).messages).toHaveLength(0);
        repo.edit(d => { d.transport.expiresOn = new Date(Date.now() + 5 * 86400000).toISOString().slice(0, 10); }); await r.tick(); await r.tick();
        expect((Notice as any).messages).toHaveLength(1); expect((Notice as any).messages[0][0]).toContain('5 дней');
    });
});
