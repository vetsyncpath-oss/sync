export class Plugin {
  app: any; manifest: any; commands: any[] = []; intervals: any[] = [];
  constructor(app: any, manifest: any) { if (!('appId' in app)) app.appId = 'test-vault'; this.app = app; this.manifest = manifest; }
  async loadData() { return this.app.initialSettings ?? null; }
  async saveData(data: any) { this.app.savedSettings = structuredClone(data); }
  registerInterval(id: any) { this.intervals.push(id); }
  addCommand(c: any) { this.commands.push(c); }
  addSettingTab() {}
}
export class Notice { static messages: unknown[][] = []; constructor(...args: any[]) { Notice.messages.push(args); } }
export class Modal {
  static opened: Modal[] = [];
  app: any; contentEl: any; modalEl: any;
  constructor(app: any) { this.app = app; if (typeof document !== 'undefined') { this.contentEl = document.createElement('div'); this.modalEl = document.createElement('div'); this.modalEl.append(this.contentEl); } }
  open() { Modal.opened.push(this); if (this.modalEl) { document.body.append(this.modalEl); (this as any).onOpen?.(); } }
  close() { (this as any).onClose?.(); this.modalEl?.remove(); Modal.opened = Modal.opened.filter(m => m !== this); }
}
export class PluginSettingTab { app: any; containerEl: any; constructor(app: any) { this.app = app; if (typeof document !== 'undefined') this.containerEl = document.createElement('div'); } }
export class Setting {}
