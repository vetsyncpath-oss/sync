import { generateIdentity, signJws, type Identity } from '../../manager/src/auth-v2/crypto';
import { generateInbox, enrollment } from '../../manager/src/auth-v3/enrollment';
import { verifyPackage, DAY, type Connection, type Tenant } from '../../manager/src/auth-v3/model';
import { Service } from '../../manager/src/auth-v3/service';
import { GitError, type Store, type File } from '../../manager/src/auth-v3/git-store';
export class MemoryStore implements Store {
    files = new Map<string, File>(); writes = 0; failure: Error | null = null;
    async read(path: string) { if (this.failure) throw this.failure; return structuredClone(this.files.get(path) ?? null); }
    async write(path: string, text: string, sha: string | null) {
        if (this.failure) throw this.failure;
        if ((this.files.get(path)?.sha ?? null) !== sha) throw new GitError('conflict');
        this.files.set(path, { text, sha: String(++this.writes) });
    }
    async listRequests() { if (this.failure) throw this.failure; return [...this.files.keys()]; }
}
export async function fixture() {
    const publisher = await generateIdentity(), owner = await generateIdentity(), user = await generateIdentity(), device = await generateIdentity(), inbox = await generateInbox();
    let now = Date.now();
    const repo = (name: string) => ({ baseUrl: 'https://api.github.com', owner: 'company', repo: name });
    const tenant: Tenant = { v: 3, type: 'tenant', tenantId: 'org-a', bundleId: 'bundle-a', publisherId: 'publisher', ownerKey: owner.publicKey, inboxKey: inbox.publicKey, access: repo('access'), requests: repo('requests'), issuedAt: now, expiresAt: now + 365 * DAY };
    const roots = { publisher: publisher.publicKey }, certificate = await signJws(tenant, publisher);
    const ownerConnection: Connection = { certificate, credentials: { access: 'owner-access', requests: 'owner-requests' }, version: 1, accountId: 'owner' };
    const stores = { access: new MemoryStore(), requests: new MemoryStore() };
    const admin = await Service.connect(ownerConnection, user, device, roots, { stores, now: () => now });
    await admin.unlockOwner(owner, inbox.privateKey); await admin.initialize();
    const credentials = { access: 'user-access', requests: 'user-requests' };
    const invite = await admin.invite('account label', credentials, 1);
    const p = (await verifyPackage(invite, roots, now)).package;
    const connection: Connection = { certificate, credentials, version: 1, accountId: p.accountId };
    const connect = (u: Identity = user, d: Identity = device, c = connection) => Service.connect(c, u, d, roots, { stores, now: () => now });
    const request = await enrollment(invite, p, tenant, user, device, now);
    const query = { tenantId: tenant.tenantId, bundleId: tenant.bundleId };
    const fetcher: typeof fetch = async (url, init) => {
        const parsed = new URL(String(url)), match = parsed.pathname.match(/^\/repos\/company\/(access|requests)(?:\/contents\/(.+))?$/);
        if (!match) return Response.json({}, { status: 404 });
        const token = (init?.headers as any)?.Authorization?.replace('Bearer ', '');
        if (!['owner-access', 'owner-requests', 'user-access', 'user-requests', 'new-user-access', 'new-user-requests'].includes(token)) return Response.json({}, { status: 401 });
        const store = stores[match[1] as 'access' | 'requests'];
        if (!match[2]) return Response.json({ private: true });
        const path = match[2];
        if (!init?.method || init.method === 'GET') {
            if (path === 'requests') return Response.json([...store.files.keys()].map(p => ({ name: p.split('/').pop() })));
            const f = await store.read(path); if (!f) return Response.json({}, { status: 404 });
            return Response.json({ sha: f.sha, encoding: 'base64', content: Buffer.from(f.text).toString('base64') });
        }
        if (match[1] === 'access' && token !== 'owner-access') return Response.json({}, { status: 403 });
        const body = JSON.parse(init.body as string);
        try { await store.write(path, Buffer.from(body.content, 'base64').toString(), body.sha ?? null); }
        catch { return Response.json({}, { status: 409 }); }
        return Response.json({}, { status: 201 });
    };
    return { publisher, owner, user, device, inbox, tenant, roots, certificate, ownerConnection, connection, stores, admin, invite, p, request, query, connect, fetcher, credentials, get now() { return now; }, advance(ms: number) { now += ms; } };
}
