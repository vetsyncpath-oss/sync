import { GitError, type Store, type File } from '../../manager/src/auth-v3/git-store';
import { CONFIG_PATH, type BuildProfile, type Document } from '../../manager/src/auth-v4/model';
import { createHash } from 'node:crypto';
export const build: BuildProfile = { v: 4, adminId: 'Test Administrator', tenantId: 'org-v4', bundleId: 'bundle-all', defaultPassword: 'initial-password', repository: { baseUrl: 'https://api.github.com', owner: 'test', repo: 'private-org' } };
export class Repository {
    constructor(readonly profile = build) {}
    rawFiles = false;
    gitBlobShas = false;
    files = new Map<string, File>();
    tokens = new Set(['old-token', 'new-token']);
    privateRepo = true;
    failure: Error | null = null;
    writes = 0;
    sequence = 0;
    beforeWrite?: (path: string) => void;
    readonly store = (token: string): Store => {
        const check = () => { if (this.failure) throw this.failure; if (!this.tokens.has(token)) throw new GitError('authentication', 401); };
        return {
            checkPrivate: async () => { check(); if (!this.privateRepo) throw new Error('Репозиторий должен быть приватным'); },
            read: async path => { check(); return structuredClone(this.files.get(path) ?? null); },
            write: async (path, text, sha) => { check(); this.beforeWrite?.(path); if ((this.files.get(path)?.sha ?? null) !== sha) throw new GitError('conflict', 409); this.files.set(path, { sha: this.nextSha(text), text }); this.writes++; },
            listRequests: async () => { check(); return [...this.files.keys()].filter(path => path.startsWith('vam/requests/')).sort(); },
        };
    };
    document(): Document { return JSON.parse(this.files.get(CONFIG_PATH)!.text); }
    private nextSha(text: string): string { this.sequence++; return this.gitBlobShas ? createHash('sha1').update(`blob ${Buffer.byteLength(text)}\0`).update(text).digest('hex') : String(this.sequence); }
    edit(work: (document: Document) => void): void { const document = this.document(); work(document); const text = JSON.stringify(document); this.files.set(CONFIG_PATH, { sha: this.nextSha(text), text }); }
    fetcher: typeof fetch = async (input, init) => {
        const url = new URL(String(input)), token = String((init?.headers as any)?.Authorization ?? '').replace(/^Bearer /, '');
        if (!this.tokens.has(token)) return Response.json({}, { status: 401 });
        const api = new URL(this.profile.repository.baseUrl), base = api.pathname.replace(/\/$/, '') + `/repos/${this.profile.repository.owner}/${this.profile.repository.repo}`;
        if (url.origin !== api.origin || (url.pathname !== base && !url.pathname.startsWith(base + '/contents/'))) return Response.json({}, { status: 404 });
        const path = decodeURIComponent(url.pathname.slice((base + '/contents/').length));
        if (url.pathname === base) return Response.json({ private: this.privateRepo });
        if (init?.method === 'PUT' || init?.method === 'POST') {
            const body = JSON.parse(init.body as string), sha = body.sha ?? null;
            try { await this.store(token).write(path, Buffer.from(body.content, 'base64').toString('utf8'), sha); return Response.json({}, { status: sha ? 200 : 201 }); }
            catch (e) { return Response.json({}, { status: (e as GitError).status || 500 }); }
        }
        if (path === 'vam' || path === 'vam/requests') return Response.json([...this.files.entries()].filter(([p]) => p.startsWith(path + '/') && !p.slice(path.length + 1).includes('/')).map(([p, file]) => ({ name: p.split('/').at(-1), type: 'file', sha: file.sha })));
        const file = this.files.get(path); return file ? this.rawFiles ? new Response(file.text, { headers: { 'content-type': 'application/json' } }) : Response.json({ sha: file.sha, encoding: 'base64', content: Buffer.from(file.text).toString('base64') }) : Response.json({}, { status: 404 });
    };
}
