import type {Plugin} from 'obsidian';
// A second Plugin object opening the same fixture sees the same vault file.
const files = new Map<string, unknown>();
export function attachVaultFile(plugin: Plugin, key: string) {
    const initial = plugin.loadData.bind(plugin);
    plugin.loadData = async () => files.has(key) ? structuredClone(files.get(key)) : initial();
    plugin.saveData = async value => { files.set(key, structuredClone(value)); };
}
