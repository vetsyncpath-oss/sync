import { generateIdentity, signJws } from '../../manager/src/auth-v2/crypto';
import { AccessService, type Store, type Connection } from '../../manager/src/auth-v2/service';
import type { TenantGrant } from '../../manager/src/auth-v2/model';
import { GitConflict, type VersionedFile } from '../../manager/src/auth-v2/git-store';

export class MemoryStore implements Store {
    files = new Map<string, VersionedFile>();
    writes = 0;
    fail = false;
    async read(path: string) { if (this.fail) throw new Error('HTTP 401'); return structuredClone(this.files.get(path) ?? null); }
    async write(path: string, text: string, sha: string | null) {
        if ((this.files.get(path)?.sha ?? null) !== sha) throw new GitConflict();
        this.files.set(path, { sha: String(++this.writes), text });
    }
    async listRequests() { return [...this.files.keys()]; }
}
export async function fixture() {
    const publisher = await generateIdentity(), owner = await generateIdentity(), user = await generateIdentity();
    let now = Date.now();
    const repo = (name: string) => ({ baseUrl: 'https://api.github.com', owner: 'company', repo: name });
    const tenant: TenantGrant = { v: 2, type: 'tenant', tenantId: 'org-a', publisherId: 'publisher', ownerKey: owner.publicKey,
        products: ['product-a', 'cloud-vault-sync'], authority: repo('authority'), access: repo('access'), requests: repo('requests'), issuedAt: now, expiresAt: now + 365 * 86400_000 };
    const roots = { publisher: publisher.publicKey };
    const certificate = await signJws(tenant, publisher);
    const connection: Connection = { certificate, credentials: { authority: '', access: '', requests: '' } };
    const stores = { authority: new MemoryStore(), access: new MemoryStore(), requests: new MemoryStore() };
    const connect = (identity = user, changed?: () => void) => AccessService.connect(connection, identity, roots, { stores, now: () => now, changed });
    const admin = await connect(owner);
    await admin.initialize();
    const member = await connect();
    const request = await member.createRequest('member', 'Alice');
    const query = { tenantId: 'org-a', productId: 'product-a', capability: 'use' };
    return { publisher, owner, user, tenant, roots, connection, stores, connect, admin, member, request, query, get now() { return now; }, advance(ms: number) { now += ms; } };
}
