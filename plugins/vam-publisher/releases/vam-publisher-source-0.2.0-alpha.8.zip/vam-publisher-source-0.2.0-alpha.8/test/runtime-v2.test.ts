import { afterEach, describe, expect, it, vi } from 'vitest';
import { Plugin } from 'obsidian';
import { AccessRuntime } from '../manager/src/auth-v2/runtime';
import ManagerPlugin from '../manager/main.ts';
import { fixture } from './helpers/v2';
import { vamGuard } from '../manager/src/sdk/vam-guard';
import { installVamBridge } from '../manager/src/sdk/vam-bridge';
import { signJws } from '../manager/src/auth-v2/crypto';

const active: Array<{ dispose(): void }> = [];
afterEach(() => { for (const item of active.splice(0)) item.dispose(); vi.useRealTimers(); delete (globalThis as any).__VAM__; delete (globalThis as any).__VAM_PENDING__; delete (globalThis as any).vaultSyncAuth; });
function host() {
    const files = new Map<string, string>();
    const app: any = { vault: { adapter: {
        exists: async (p: string) => files.has(p), read: async (p: string) => { if (!files.has(p)) throw new Error('missing'); return files.get(p)!; },
        write: async (p: string, text: string) => { files.set(p, text); }, remove: async (p: string) => { files.delete(p); }, mkdir: async () => undefined,
    } }, plugins: { plugins: {} } };
    const plugin = new (Plugin as any)(app, { id: 'vault-access-manager', version: 'test' });
    return { files, app, plugin };
}
describe('profile recovery and runtime wiring', () => {
    it('ignores legacy local owner/cache and leaves data.json intact on startup', async () => {
        const h = host(); h.app.initialSettings = { version: 1, role: 'owner', cache: { publicStatus: 'ok' } };
        const plugin = new ManagerPlugin(h.app, { id: 'vault-access-manager', version: 'test' });
        await plugin.onload(); active.push({ dispose: () => plugin.onunload() });
        const api = (globalThis as any).__VAM__;
        expect(api.getStatus()).toBe('blocked'); expect(api.isOwner('org-a')).toBe(false);
        expect(() => plugin.applyRole('owner')).toThrow('Локальная роль');
        expect(h.app.savedSettings).toBeUndefined();
        expect((globalThis as any).vaultSyncAuth.getState().status).toBe('blocked');
    });
    it('recovers the same device and signed connection after data.json is deleted', async () => {
        const h = host(), f = await fixture();
        const fetcher = vi.fn(async () => new Response('', { status: 404 }));
        const first = new AccessRuntime(h.plugin, f.roots, fetcher); active.push(first); await first.start();
        await first.createProfile('correct horse battery');
        const subject = first.identity!.keyId;
        await first.connect({ ...f.connection, credentials: { authority: 'secret-a', access: 'secret-b', requests: 'secret-c' } });
        const stored = await first.exportProfile();
        expect(stored).not.toContain('secret-a'); expect(stored).not.toContain('privateKey');
        h.files.delete('.obsidian/plugins/vault-access-manager/data.json'); first.dispose();
        const restored = new AccessRuntime(h.plugin, f.roots, fetcher); active.push(restored); await restored.start();
        expect(restored.hasProfile).toBe(true);
        expect(restored.identity).toBeNull();
        await restored.unlock('correct horse battery');
        expect(restored.identity!.keyId).toBe(subject);
        expect(restored.service!.tenant.tenantId).toBe('org-a');
        // Downloading the owner's public certificate cannot make this different device an owner.
        expect(restored.service!.isOwner()).toBe(false);
    });
    it('rejects an untrusted connection before sending tokens or replacing a good profile', async () => {
        const h = host(), f = await fixture();
        const fetcher = vi.fn(async () => new Response('', { status: 404 }));
        const runtime = new AccessRuntime(h.plugin, {}, fetcher); active.push(runtime); await runtime.start();
        await runtime.createProfile('correct horse battery');
        const before = await runtime.exportProfile();
        await expect(runtime.connect(f.connection)).rejects.toThrow('Unknown publisher');
        expect(fetcher).not.toHaveBeenCalled(); expect(await runtime.exportProfile()).toBe(before);
    });
    it('restores an encrypted backup on another installation and refuses accidental overwrite', async () => {
        const h = host(), other = host();
        const one = new AccessRuntime(h.plugin); const two = new AccessRuntime(other.plugin); active.push(one, two);
        await one.start(); await one.createProfile('correct horse battery');
        const backup = await one.exportProfile();
        await two.start(); await two.restoreProfile(backup, 'correct horse battery');
        expect(two.identity!.keyId).toBe(one.identity!.keyId);
        await expect(two.createProfile('new passphrase here')).rejects.toThrow('уже существует');
        await expect(two.restoreProfile(backup, 'correct horse battery')).rejects.toThrow('пустом профиле');
    });
    it('a retired publisher/expired connection does not prevent recovering the identity', async () => {
        const h = host(), f = await fixture();
        const first = new AccessRuntime(h.plugin, f.roots, async () => new Response('', { status: 404 })); active.push(first);
        await first.start(); await first.createProfile('correct horse battery'); await first.connect(f.connection);
        const subject = first.identity!.keyId; first.dispose();
        const restored = new AccessRuntime(h.plugin, {}); active.push(restored);
        await restored.start(); await restored.unlock('correct horse battery');
        expect(restored.identity!.keyId).toBe(subject);
        expect(restored.service).toBeNull(); expect(restored.connectionError).toContain('Unknown publisher');
        expect(await restored.request('org-a', 'admin', 'Recovery')).toContain('.');
    });
    it('issues identical product decisions through scoped SDK, legacy sync API and probes', async () => {
        const h = host(), f = await fixture();
        const probes: any[] = [];
        h.app.plugins.plugins['cloud-vault-sync'] = { applyManagerProbe: async (p: any) => { probes.push(p); } };
        const runtime = new AccessRuntime(h.plugin, f.roots); active.push(runtime); await runtime.start();
        runtime.identity = f.user; runtime.service = await f.connect(f.user, runtime.changed);
        const guard = vamGuard({ tenantId: 'org-a', pluginId: 'cloud-vault-sync' }); active.push(guard);
        await f.admin.grantMember(f.request, ['cloud-vault-sync'], ['use'], f.now + 10000);
        await runtime.service.refresh(); await Promise.resolve(); await Promise.resolve();
        expect(guard.isGranted()).toBe(true); expect(h.plugin.auth.getState().status).toBe('ok');
        await f.admin.revokeMember(f.user.keyId); await runtime.service.refresh();
        await new Promise(resolve => setTimeout(resolve, 0));
        expect(guard.isGranted()).toBe(false); expect(h.plugin.auth.getState().status).toBe('blocked');
        expect(probes.some(p => p.authOk === true)).toBe(true);
        expect(probes.at(-1).authOk).toBe(false);
    });
});

describe('scoped SDK protocol v5', () => {
    it('requires tenant/product scope; mutable returned snapshots cannot set owner', () => {
        const bridge = installVamBridge(() => ({ status: 'blocked', reason: 'scoped-access-required' }), undefined, undefined,
            q => ({ status: q.tenantId === 'org-a' && q.productId === 'product-a' ? 'granted' : 'blocked', reason: null, validUntil: Date.now() + 1000 }), t => t === 'org-a');
        active.push(bridge);
        const api = (globalThis as any).__VAM__;
        api.getAuthState().role = 'owner';
        expect(api.getAuthState().role).toBe('unknown');
        expect(api.isOwner()).toBe(false); expect(api.isOwner('org-b')).toBe(false);
        const good = vamGuard({ tenantId: 'org-a', pluginId: 'product-a' });
        const foreign = vamGuard({ tenantId: 'org-b', pluginId: 'product-a' });
        const unscoped = vamGuard({ pluginId: 'product-a' }); active.push(good, foreign, unscoped);
        expect(good.isGranted()).toBe(true); expect(foreign.isGranted()).toBe(false); expect(unscoped.isGranted()).toBe(false);
        expect(good.getAuthState()?.authenticated).toBe(true);
        bridge.dispose(); expect(good.isGranted()).toBe(false); expect(api.isOwner('org-a')).toBe(false);
    });
    it('does not downgrade a scoped guard to the old global owner grant', () => {
        (globalThis as any).__VAM__ = { version: '4', getStatus: () => 'granted', getReason: () => null, subscribe: (cb: any) => { cb('granted', null); return () => undefined; } };
        const guard = vamGuard({ tenantId: 'org-a', pluginId: 'product-a' }); active.push(guard);
        expect(guard.isGranted()).toBe(false);
    });
    it('reattaches after manager reload and receives revocation', async () => {
        vi.useFakeTimers();
        let granted = true;
        const make = () => installVamBridge(() => ({ status: 'blocked', reason: 'scoped-access-required', policySignature: String(granted) }), undefined, undefined,
            () => ({ status: granted ? 'granted' : 'blocked', reason: null, validUntil: null }));
        const first = make(); active.push(first);
        const guard = vamGuard({ tenantId: 'org-a', pluginId: 'product-a', pollMs: 10 }); active.push(guard);
        expect(guard.isGranted()).toBe(true);
        first.dispose(); expect(guard.isGranted()).toBe(false);
        const second = make(); active.push(second);
        await vi.advanceTimersByTimeAsync(11); expect(guard.isGranted()).toBe(true);
        granted = false; second.refresh(); expect(guard.isGranted()).toBe(false);
    });
    it('a revocation callback is delivered once per transition, not on every poll', async () => {
        vi.useFakeTimers();
        let allowed = true;
        const onRevoked = vi.fn();
        const bridge = installVamBridge(() => ({ status: 'blocked', reason: null, policySignature: String(allowed) }), undefined, undefined,
            () => ({ status: allowed ? 'granted' : 'blocked', reason: null, validUntil: null })); active.push(bridge);
        const guard = vamGuard({ tenantId: 'org-a', pluginId: 'product-a', pollMs: 10, onRevoked }); active.push(guard);
        allowed = false; bridge.refresh(); await vi.advanceTimersByTimeAsync(50);
        expect(onRevoked).toHaveBeenCalledTimes(1);
    });
});
