import { afterEach, describe, expect, it, vi } from 'vitest';
import { createHash } from 'node:crypto';
import { ChannelClient } from '../manager/src/core/channel';
import { GitStore } from '../manager/src/auth-v3/git-store';
import { CONFIG_PATH, LAYOUT } from '../manager/src/auth-v4/model';
const repo = { baseUrl: 'https://api.github.com', owner: 'org', repo: 'private' };
const metadata = (text = 'document') => Response.json({ sha: 'sha-original', encoding: 'base64', content: Buffer.from(text).toString('base64') });
const oid = (text: string, algorithm = 'sha1') => createHash(algorithm).update(`blob ${Buffer.byteLength(text)}\0`).update(text).digest('hex');
afterEach(() => { vi.unstubAllGlobals(); vi.useRealTimers(); });
describe('transport compatibility with the original Obsidian client', () => {
    it('calls browser fetch with the same global receiver as the original client', async () => {
        const receiverSensitiveFetch = vi.fn(function(this: unknown) {
            if (this !== globalThis) throw new TypeError("Failed to execute 'fetch' on 'Window': Illegal invocation");
            return Promise.resolve(metadata());
        }) as unknown as typeof fetch;
        const original = new ChannelClient({ ...repo, token: 'fixture-token' }, { fetchImpl: receiverSensitiveFetch });
        expect(new TextDecoder().decode((await original.getFile('vam/config.json') as any).bytes)).toBe('document');
        const current = new GitStore(repo, 'fixture-token', receiverSensitiveFetch, async () => {});
        expect(await current.read('state.jws')).toEqual({ sha: 'sha-original', text: 'document' });
    });
    it('binds the default global fetch too, without relying on a test-injected fetcher', async () => {
        vi.stubGlobal('fetch', function(this: unknown) { if (this !== globalThis) throw new TypeError('Illegal invocation'); return Promise.resolve(metadata()); });
        expect(await new GitStore(repo, 'fixture-token').read('state.jws')).toEqual({ sha: 'sha-original', text: 'document' });
    });
    it('preserves legacy headers and follows the original same-origin metadata redirect before writes', async () => {
        const methods: string[] = [], urls: string[] = [], redirects: Array<RequestRedirect | undefined> = [];
        const fetcher = vi.fn(async (input: any, init: RequestInit = {}) => {
            const url = String(input); urls.push(url); methods.push(init.method!); redirects.push(init.redirect);
            expect((init.headers as any).Authorization).toBe('Bearer fixture-token'); expect((init.headers as any).Accept).toBe('application/json');
            if (!url.includes('/contents/')) {
                if (init.redirect === 'error') throw new TypeError('Failed to fetch');
                const response = Response.json({ private: true }); Object.defineProperty(response, 'url', { value: 'https://api.github.com/repos/org/renamed' }); return response;
            }
            return init.method === 'PUT' ? Response.json({}, { status: 200 }) : metadata();
        });
        const git = new GitStore(repo, 'fixture-token', fetcher); await git.checkPrivate(); await git.read('state.jws'); await git.write('state.jws', 'new bytes', 'sha-original');
        expect(urls).toEqual(['https://api.github.com/repos/org/private', 'https://api.github.com/repos/org/renamed/contents/state.jws', 'https://api.github.com/repos/org/renamed/contents/state.jws']);
        expect(methods).toEqual(['GET', 'GET', 'PUT']); expect(redirects).toEqual(['follow', 'follow', 'error']);
    });
    it('rejects cross-origin API responses and never follows credential-bearing writes', async () => {
        const fetcher = vi.fn(async () => { const response = metadata(); Object.defineProperty(response, 'url', { value: 'https://other.example/repos/org/private/contents/state.jws' }); return response; });
        await expect(new GitStore(repo, 'fixture-token', fetcher).read('state.jws')).rejects.toMatchObject({ kind: 'redirect' }); expect(fetcher).toHaveBeenCalledTimes(1);
        const writer = vi.fn(async (_input: any, init: RequestInit) => { expect(init.redirect).toBe('error'); return Response.json({}, { status: 201 }); }); await new GitStore(repo, 'fixture-token', writer).write('state.jws', 'private config', null);
    });
    it.each(['https://api.github.com', 'https://gitea.example/api/v1'])('reads legacy raw Contents replies from %s and verifies the matching Git blob SHA', async baseUrl => {
        const text = '{\r\n  "message": "Привет", "version": 4\r\n}\r\n', sha = oid(text);
        const fetcher = vi.fn(async (input: any) => String(input).endsWith('/contents/vam') ? Response.json([{ name: 'config.json', type: 'file', sha }]) : new Response(text));
        const original = new ChannelClient({ ...repo, baseUrl, token: 'fixture-token' }, { fetchImpl: fetcher }); expect(new TextDecoder().decode((await original.getFile(CONFIG_PATH) as any).bytes)).toBe(text);
        const current = new GitStore({ ...repo, baseUrl }, 'fixture-token', fetcher, async () => {}, LAYOUT); expect(await current.read(CONFIG_PATH)).toEqual({ sha, text: text.trim() });
    });
    it('rereads a raw body when the parent SHA changed, instead of pairing stale bytes with a fresh SHA', async () => {
        const older = '{"revision":1}', newer = '{"revision":2}', sha = oid(newer); let reads = 0;
        const fetcher = vi.fn(async (input: any) => String(input).endsWith('/contents/vam') ? Response.json([{ name: 'config.json', sha }]) : new Response(reads++ === 0 ? older : newer));
        expect(await new GitStore(repo, 'fixture-token', fetcher, async () => {}, LAYOUT).read(CONFIG_PATH)).toEqual({ sha, text: newer }); expect(reads).toBe(2);
    });
    it('fails on a persistent raw-body/SHA mismatch without writing anything', async () => {
        const fetcher = vi.fn(async (input: any) => String(input).endsWith('/contents/vam') ? Response.json([{ name: 'config.json', sha: oid('newer bytes') }]) : new Response('older bytes'));
        await expect(new GitStore(repo, 'fixture-token', fetcher, async () => {}, LAYOUT).read(CONFIG_PATH)).rejects.toMatchObject({ kind: 'conflict' }); expect(fetcher.mock.calls.every((call: any) => call[1].method === 'GET')).toBe(true);
    });
    it('recognizes a SHA-256 Git repository and preserves metadata Base64 compatibility', async () => {
        const text = '{"v":4}', sha = oid(text, 'sha256'), fetcher = vi.fn(async (input: any) => String(input).endsWith('/contents/vam') ? Response.json([{ name: 'config.json', sha }]) : new Response(text));
        expect(await new GitStore(repo, 'fixture-token', fetcher, async () => {}, LAYOUT).read(CONFIG_PATH)).toEqual({ sha, text });
        const original = new ChannelClient({ ...repo, token: 'fixture-token' }, { fetchImpl: async () => metadata(text) }); expect(new TextDecoder().decode((await original.getFile(CONFIG_PATH) as any).bytes)).toBe(text);
    });
    it('reports an empty GitHub repository and an HTML API response without calling them network failures', async () => {
        await expect(new GitStore(repo, 'fixture-token', async () => Response.json({ message: 'Git Repository is empty.' }, { status: 409 })).read('state.jws')).rejects.toMatchObject({ kind: 'empty-repository' });
        await expect(new GitStore(repo, 'fixture-token', async () => new Response('<html>login</html>')).checkPrivate()).rejects.toMatchObject({ kind: 'invalid-response' });
    });
    it('separates a programming error from a network error and hides exception secrets', async () => {
        const fetcher = vi.fn(async () => { throw new TypeError('Illegal invocation fixture-secret https://private.example/'); });
        const error = await new GitStore(repo, 'fixture-token', fetcher, async () => {}).read('state.jws').catch(e => e);
        expect(error.kind).toBe('transport'); expect(error.message).not.toContain('fixture-secret'); expect(error.message).not.toContain('private.example'); expect(fetcher).toHaveBeenCalledTimes(1);
    });
    it('classifies abort timeouts explicitly and keeps bounded GET retries', async () => {
        vi.useFakeTimers();
        const fetcher = vi.fn((_input: any, init: RequestInit) => new Promise<Response>((_resolve, reject) => { init.signal!.addEventListener('abort', () => reject(new DOMException('aborted', 'AbortError'))); }));
        const promise = new GitStore(repo, 'fixture-token', fetcher, async () => {}).checkPrivate().catch(e => e); await vi.advanceTimersByTimeAsync(45000); const error = await promise;
        expect(error.kind).toBe('timeout'); expect(fetcher).toHaveBeenCalledTimes(3);
    });
});
