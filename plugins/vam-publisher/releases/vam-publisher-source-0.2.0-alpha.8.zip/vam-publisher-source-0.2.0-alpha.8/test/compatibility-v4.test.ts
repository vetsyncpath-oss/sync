import 'fake-indexeddb/auto';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { Plugin } from 'obsidian';
import { Runtime } from '../manager/src/auth-v4/runtime';
import { LocalStore } from '../manager/src/auth-v3/local';
import { encryptUserRecord, type UserPayload } from '../manager/src/core/crypto';
import { vamGuard as originalGuard } from './fixtures/vam-guard-original';
import { build, Repository } from './helpers/v4';
import { decodeCode } from '../manager/src/auth-v4/model';
const active: Array<{ dispose(): void }> = [];
afterEach(() => { active.splice(0).reverse().forEach(x => x.dispose()); delete (globalThis as any).__VAM__; delete (globalThis as any).__VAM_PENDING__; delete (globalThis as any).vaultSyncAuth; });
function memory(files = new Map<string, string>()) {
    return { files, async read(path: string) { if (!this.files.has(path)) throw new Error('missing'); return this.files.get(path)!; }, async write(path: string, value: string) { this.files.set(path, value); }, async exists(path: string) { return this.files.has(path) || [...this.files.keys()].some(p => p.startsWith(path + '/')); }, async remove(path: string) { this.files.delete(path); }, async mkdir(_path: string) {}, async list(path: string) { const all = [...this.files.keys()].filter(p => p.startsWith(path + '/')); return { files: all.filter(p => !p.slice(path.length + 1).includes('/')), folders: [...new Set(all.filter(p => p.slice(path.length + 1).includes('/')).map(p => path + '/' + p.slice(path.length + 1).split('/')[0]))] }; }, async rename(from: string, to: string) { await this.write(to, await this.read(from)); await this.remove(from); } };
}
function setup(repo = new Repository(), app: any = {}) {
    const plugin = new Plugin({ vault: {}, ...app }, { id: 'vault-access-manager', version: 'test' });
    const r = new Runtime(plugin, build, { fetcher: repo.fetcher }, new LocalStore(crypto.randomUUID())); active.push(r); return { r, plugin, repo };
}
async function legacyRepo(payload: UserPayload) {
    const repo = new Repository(), records = new Map<string, Uint8Array>();
    records.set(payload.userId, await encryptUserRecord('old-user-password', payload.userId, payload, { iterations: 1000 }));
    const base = repo.fetcher;
    repo.fetcher = async (url, init) => {
        const path = String(url).split('/contents/')[1];
        if (path === 'users') return Response.json([...records.keys()].map(id => ({ name: id + '.enc', sha: 'old-sha', type: 'file' })));
        if (path?.startsWith('users/')) { const bytes = records.get(path.slice(6, -4)); return bytes ? Response.json({ content: Buffer.from(bytes).toString('base64'), encoding: 'base64' }) : Response.json({}, { status: 404 }); }
        return base(url, init);
    };
    return { repo, records };
}
const oldUser: UserPayload = { v: 2, userId: 'abcdef1', note: 'Прежний пользователь', issuedAt: 1, expiresAt: null, permissions: [], maxDevices: 2, devices: [{ id: 'old-hardware-id', name: 'Laptop', addedAt: 1 }] };

describe('original plugin contracts with verified v4 sessions', () => {
    it('unblocks the unchanged original SDK after login and revokes it on logout and unload', async () => {
        const forbidden = vi.fn(), guard = originalGuard({ pluginId: 'old-reader', onForbidden: forbidden }); active.push(guard);
        const sync = { applyManagerProbe: vi.fn(async () => {}) };
        const { r, plugin } = setup(undefined, { initialSettings: { role: 'owner' }, plugins: { plugins: { 'cloud-vault-sync': sync } } });
        await r.start(); expect(guard.status).toBe('blocked'); expect(guard.isOwner()).toBe(false); expect(forbidden).not.toHaveBeenCalled();
        const api = (globalThis as any).__VAM__, legacy = (plugin as any).auth, states: string[] = [];
        legacy.onChanged((s: any) => states.push(s.status));
        await r.loginAdministrator(build.defaultPassword, 'old-token');
        expect(guard.status).toBe('granted'); expect(guard.isOwner()).toBe(true); expect(legacy.getState().status).toBe('ok');
        expect(api.getPermission('old-reader').permission).toBe('regulated');
        expect(api.access({ tenantId: 'foreign', bundleId: build.bundleId }).status).toBe('blocked'); expect(api.isOwner('foreign')).toBe(false); expect(api.access(null).status).toBe('blocked');
        expect(sync.applyManagerProbe.mock.calls.some(([p]: any) => p.authOk === true)).toBe(true);
        await r.logout(); expect(guard.status).toBe('blocked'); expect(guard.isOwner()).toBe(false); expect(states.at(-1)).toBe('blocked');
        await r.loginAdministrator(build.defaultPassword); r.dispose(); expect(guard.status).toBe('blocked'); expect(api.isOwner()).toBe(false);
    });
    it('restores only previously enabled locks and leaves unrelated disabled plugins alone', async () => {
        const folder = '.obsidian/plugins', adapter = memory(new Map([
            [folder + '/old-reader/manifest.json', '{"id":"old-reader"}'], [folder + '/manual-off/manifest.json', '{"id":"manual-off"}'],
            [folder + '/vault-access-manager/lock-registry.json', JSON.stringify({ version: 1, entries: ['old-reader', 'manual-off'].map(id => ({ manifestId: id, folder: id, policyId: id, wasEnabled: id === 'old-reader', lockedAt: 1, epochPolicy: 'old' })) })],
        ]));
        const plugins: any = { plugins: {}, manifests: { 'old-reader': { id: 'old-reader' }, 'manual-off': { id: 'manual-off' }, 'unrelated': { id: 'unrelated' } }, async enablePluginAndSave(id: string) { this.plugins[id] = {}; } };
        const enable = vi.spyOn(plugins, 'enablePluginAndSave');
        const { r } = setup(undefined, { vault: { adapter }, plugins }); await r.start(); await r.loginAdministrator(build.defaultPassword, 'old-token');
        expect(enable.mock.calls).toEqual([['old-reader']]); expect(JSON.parse(await adapter.read(folder + '/vault-access-manager/lock-registry.json')).entries).toEqual([]);
        await r.plugins.restore(); expect(enable).toHaveBeenCalledTimes(1); await r.logout(); await expect(r.plugins.enable('old-reader')).rejects.toThrow('действующим доступом');
    });
    it('keeps a failed old lock for retry and restores a neutralized manifest without overwriting a live file', async () => {
        const folder = '.obsidian/plugins', adapter = memory(new Map([
            [folder + '/old-reader/.vam-manifest', '{"id":"old-reader"}'],
            [folder + '/vault-access-manager/lock-registry.json', JSON.stringify({ version: 1, entries: [{ manifestId: 'old-reader', folder: 'old-reader', policyId: 'old-reader', wasEnabled: true, lockedAt: 1, epochPolicy: 'old' }] })],
        ]));
        const plugins: any = { plugins: {}, manifests: {}, async loadManifests() { this.manifests['old-reader'] = JSON.parse(await adapter.read(folder + '/old-reader/manifest.json')); }, enablePluginAndSave: vi.fn(async () => { throw new Error('plugin failure'); }) };
        const { r } = setup(undefined, { vault: { adapter }, plugins }); await r.start(); await r.loginAdministrator(build.defaultPassword, 'old-token');
        expect(r.plugins.error).toContain('Не удалось'); expect(await adapter.exists(folder + '/old-reader/manifest.json')).toBe(true);
        expect(JSON.parse(await adapter.read(folder + '/vault-access-manager/lock-registry.json')).entries).toHaveLength(1);
        plugins.enablePluginAndSave = async (id: string) => { plugins.plugins[id] = {}; }; await r.plugins.restore(); expect(r.plugins.error).toBe('');
    });
});
describe('read and migrate the original encrypted users registry', () => {
    it('loads repository users after administrator login and imports verified credentials without touching the old file', async () => {
        const { repo, records } = await legacyRepo(oldUser), original = records.get(oldUser.userId), { r } = setup(repo); await r.start(); await r.loginAdministrator(build.defaultPassword, 'old-token');
        expect(r.legacyUsers.map(u => u.accountId)).toEqual([oldUser.userId]);
        await expect(r.importLegacy(oldUser.userId, 'wrong')).rejects.toThrow('прежний пароль'); expect(repo.document().members).toHaveLength(0);
        const key = await r.importLegacy(oldUser.userId, 'old-user-password');
        expect(decodeCode(key, build).accountId).toBe(oldUser.userId);
        expect(repo.document().members[0]).toMatchObject({ accountId: oldUser.userId, label: oldUser.note, password: 'old-user-password', maxDevices: 2, expiresAt: null, devices: [] });
        expect(records.get(oldUser.userId)).toEqual(original);
        await r.service!.change('revoke-member', oldUser.userId); await expect(r.importLegacy(oldUser.userId, 'old-user-password')).rejects.toThrow('уже перенесён'); expect(repo.document().members[0].active).toBe(false);
    });
    it.each(['expired', 'removed'])('does not turn an %s legacy record into a new active account', async mode => {
        const { repo, records } = await legacyRepo({ ...oldUser, expiresAt: mode === 'expired' ? 1 : null }); const { r } = setup(repo); await r.start(); await r.loginAdministrator(build.defaultPassword, 'old-token');
        if (mode === 'removed') records.clear();
        await expect(r.importLegacy(oldUser.userId, 'old-user-password')).rejects.toThrow('Не удалось проверить'); expect(repo.document().members).toHaveLength(0);
    });
    it('imports a valid expiry unchanged and completes new-device enrollment with the issued key', async () => {
        const expiresAt = Date.now() + 86400000, { repo } = await legacyRepo({ ...oldUser, expiresAt }), { r: admin } = setup(repo); await admin.start(); await admin.loginAdministrator(build.defaultPassword, 'old-token');
        const code = await admin.importLegacy(oldUser.userId, 'old-user-password'), { r: user } = setup(repo); await user.start(); await user.applyCode(code); await admin.tick(); await user.tick();
        const guard = originalGuard({ pluginId: 'old-reader' }); active.push(guard); expect(guard.isGranted()).toBe(true); expect(guard.isOwner()).toBe(false);
        expect(user.decision.status).toBe('granted'); expect(repo.document().members[0].expiresAt).toBe(expiresAt); expect(repo.document().members[0].devices).toHaveLength(1);
        await admin.service!.change('revoke-member', oldUser.userId); await user.tick(); expect(guard.isGranted()).toBe(false);
    });
});

describe('administrator editing without rebuilding the profile', () => {
    it('changes expiry and password, invalidates old invitations and preserves registered devices', async () => {
        const { r, repo } = setup(); await r.start(); await r.loginAdministrator(build.defaultPassword, 'old-token');
        const invitation = await r.service!.invite('Alice', { accountId: 'alice', password: 'before' });
        const unused = await r.service!.invite('Alice', { accountId: 'alice' });
        const existingUser = setup(repo).r; await existingUser.start(); await existingUser.applyCode(invitation.code); await r.tick(); await existingUser.tick(); const deviceId = existingUser.device.keyId;
        const expiry = Date.now() + 86400000;
        await r.service!.updateMember('alice', { label: 'Alice updated', active: true, expiresAt: expiry, password: 'after' });
        expect(repo.document().members[0]).toMatchObject({ password: 'after', expiresAt: expiry, label: 'Alice updated' });
        expect(repo.document().invitations).toHaveLength(0); expect(repo.document().members[0].devices.map(d => d.deviceId)).toEqual([deviceId]);
        await existingUser.logout(); await existingUser.loginUser('alice', 'after'); expect(existingUser.decision.status).toBe('granted');
        const { r: user } = setup(repo); await user.start(); await expect(user.applyCode(unused.code)).rejects.toThrow('недействителен');
        repo.edit(d => { d.adminPassword = 'changed'; }); await expect(r.service!.updateMember('alice', { label: 'Stale writer', active: true, expiresAt: null })).rejects.toThrow('актуальным паролем');
        expect(repo.document().members[0].expiresAt).toBe(expiry);
    });
});
