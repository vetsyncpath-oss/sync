import { describe, it, expect, vi } from 'vitest';
import { GitStore, GitConflict } from '../manager/src/auth-v2/git-store';

describe('GitHub/Gitea conditional writes', () => {
    const github = { baseUrl: 'https://api.github.com', owner: 'company', repo: 'access' };
    it('reads signed text and its SHA from the same metadata response', async () => {
        const fetcher = vi.fn(async () => new Response(JSON.stringify({ sha: 'original', encoding: 'base64', content: btoa('signed-document') }), { status: 200 }));
        expect(await new GitStore(github, 'read-token', fetcher).read('access.jws')).toEqual({ sha: 'original', text: 'signed-document' });
        expect(fetcher).toHaveBeenCalledTimes(1);
    });
    it.each(['https://api.github.com', 'https://gitea.example/api/v1'])('sends exact expected SHA and never retries conflicts: %s', async baseUrl => {
        const fetcher = vi.fn(async () => new Response('{}', { status: 409 }));
        const store = new GitStore({ ...github, baseUrl }, 'write-token', fetcher);
        await expect(store.write('access.jws', 'new', 'previous-sha')).rejects.toBeInstanceOf(GitConflict);
        expect(fetcher).toHaveBeenCalledTimes(1);
        const init = (fetcher.mock.calls[0] as unknown as [string, RequestInit])[1];
        expect(init.method).toBe('PUT');
        expect(init.redirect).toBe('error');
        expect(JSON.parse(init.body as string).sha).toBe('previous-sha');
    });
    it.each([['https://api.github.com', 'PUT'], ['https://gitea.example/api/v1', 'POST']])('uses host-specific create method: %s', async (baseUrl, method) => {
        const fetcher = vi.fn(async () => new Response('{}', { status: 201 }));
        await new GitStore({ ...github, baseUrl }, '', fetcher).write('authority.jws', 'initial', null);
        const init = (fetcher.mock.calls[0] as unknown as [string, RequestInit])[1];
        expect(init.method).toBe(method);
        expect(JSON.parse(init.body as string).sha).toBeUndefined();
        expect((init.headers as Record<string, string>).Authorization).toBeUndefined();
    });
    it('rejects missing metadata, HTTP errors and paths outside the protocol', async () => {
        const fetcher = vi.fn(async () => new Response(JSON.stringify({ content: 'bad' }), { status: 200 }));
        const store = new GitStore(github, 'token', fetcher);
        await expect(store.read('access.jws')).rejects.toThrow('metadata');
        await expect(store.write('../authority.jws', 'text', null)).rejects.toThrow('path');
        await expect(new GitStore(github, 'token', async () => new Response('', { status: 401 })).read('access.jws')).rejects.toThrow('401');
    });
});
