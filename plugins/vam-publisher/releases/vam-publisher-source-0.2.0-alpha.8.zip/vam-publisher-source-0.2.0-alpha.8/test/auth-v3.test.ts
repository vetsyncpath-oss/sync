import { describe, expect, it } from 'vitest';
import { generateIdentity, inspectJws, signJws } from '../manager/src/auth-v2/crypto';
import { enrollment, open, verifyEnrollment } from '../manager/src/auth-v3/enrollment';
import { DAY, verifyPackage, verifyState } from '../manager/src/auth-v3/model';
import { Service } from '../manager/src/auth-v3/service';
import { GitError } from '../manager/src/auth-v3/git-store';
import { fixture } from './helpers/v3';

describe('bundle authority, enrollment and device lifecycle', () => {
    it('separates owner appointment, bundle access, user identity and device possession', async () => {
        const f = await fixture(), user = await f.connect(); await user.refresh();
        expect(user.isOwner()).toBe(false); expect(f.admin.access(f.query).status).not.toBe('granted');
        await expect(user.unlockOwner(f.user, f.inbox.privateKey)).rejects.toThrow('не принадлежит');
        await user.submit(f.request); await f.admin.inboxRequests(); await user.refresh();
        expect(user.access(f.query).status).toBe('granted');
        expect(user.access({ ...f.query, bundleId: 'foreign' }).status).toBe('blocked');
        expect(user.access({ ...f.query, capability: 'admin' }).status).toBe('blocked');
        const copied = await f.connect(f.user, await generateIdentity()); await copied.refresh();
        expect(copied.access(f.query).status).toBe('pending');
        const wrongUser = await f.connect(await generateIdentity(), f.device); await wrongUser.refresh();
        expect(wrongUser.access(f.query).status).toBe('pending');
    });
    it('encrypts invitations and transport secrets; rejects a swapped device possession proof', async () => {
        const f = await fixture();
        expect(f.request.ciphertext).not.toContain(f.invite); expect(f.request.ciphertext).not.toContain('user-access');
        const code = await open(f.request.ciphertext, f.inbox.privateKey);
        const raw = inspectJws(code) as any; raw.deviceKey = (await generateIdentity()).publicKey;
        await expect(verifyEnrollment(await signJws(raw, f.user), f.tenant, f.roots, f.now)).rejects.toThrow();
        expect(f.stores.access.files.get('state.jws')!.text).not.toContain(f.invite);
    });
    it('consumes one invitation atomically under two concurrent owner clients', async () => {
        const f = await fixture();
        const other = await Service.connect(f.ownerConnection, f.user, f.device, f.roots, { stores: f.stores, now: () => f.now });
        await other.unlockOwner(f.owner, f.inbox.privateKey);
        const second = await enrollment(f.invite, f.p, f.tenant, await generateIdentity(), await generateIdentity(), f.now);
        const results = await Promise.allSettled([f.admin.approve(await open(f.request.ciphertext, f.inbox.privateKey)), other.approve(await open(second.ciphertext, f.inbox.privateKey))]);
        expect(results.filter(r => r.status === 'fulfilled')).toHaveLength(1);
        await f.admin.refresh(); expect(f.admin.state!.members[0].devices).toHaveLength(1);
        expect(f.admin.state!.invitations[0].consumedBy).toBeTruthy();
    });
    it('enforces the device limit even with two different valid invitations', async () => {
        const f = await fixture();
        const secondCode = await f.admin.invite('', f.credentials, 1, { accountId: f.p.accountId });
        const secondP = (await verifyPackage(secondCode, f.roots, f.now)).package;
        const second = await enrollment(secondCode, secondP, f.tenant, await generateIdentity(), await generateIdentity(), f.now);
        await f.admin.approve(await open(f.request.ciphertext, f.inbox.privateKey));
        await expect(f.admin.approve(await open(second.ciphertext, f.inbox.privateKey))).rejects.toThrow('Лимит');
        expect(f.admin.state!.members[0].maxDevices).toBe(1);
    });
    it('requires explicit replacement approval and removes old device in the same commit', async () => {
        const f = await fixture(); await f.admin.approve(await open(f.request.ciphertext, f.inbox.privateKey));
        const replacement = await f.admin.invite('', f.credentials, 1, { accountId: f.p.accountId, replaceDeviceId: f.device.keyId });
        const newUser = await generateIdentity(), newDevice = await generateIdentity(), p = (await verifyPackage(replacement, f.roots, f.now)).package;
        const request = await enrollment(replacement, p, f.tenant, newUser, newDevice, f.now), code = await open(request.ciphertext, f.inbox.privateKey);
        await expect(f.admin.approve(code)).rejects.toThrow('подтверждения');
        await f.admin.approve(code, true);
        const old = await f.connect(), next = await f.connect(newUser, newDevice); await old.refresh(); await next.refresh();
        expect(old.access(f.query).status).not.toBe('granted'); expect(next.access(f.query).status).toBe('granted');
    });
    it('replaying a consumed request after revocation cannot restore access', async () => {
        const f = await fixture(), code = await open(f.request.ciphertext, f.inbox.privateKey);
        await f.admin.approve(code); await f.admin.change({ kind: 'revoke-member', accountId: f.p.accountId });
        await f.admin.approve(code); expect(f.admin.state!.members).toHaveLength(0);
    });
    it('recomputes a mutation after conflict without resurrecting a concurrent revocation', async () => {
        const f = await fixture();
        const other = await Service.connect(f.ownerConnection, f.user, f.device, f.roots, { stores: f.stores, now: () => f.now }); await other.unlockOwner(f.owner, f.inbox.privateKey);
        const write = f.stores.access.write.bind(f.stores.access); let conflict = true;
        f.stores.access.write = async (path, text, sha) => { if (conflict) { conflict = false; await other.change({ kind: 'revoke-member', accountId: f.p.accountId }); } return write(path, text, sha); };
        await expect(f.admin.approve(await open(f.request.ciphertext, f.inbox.privateKey))).rejects.toThrow('Приглашение');
        expect(f.admin.state!.members).toHaveLength(0);
    });
    it('temporary admin expiry or revocation does not invalidate existing owner-signed grants', async () => {
        const f = await fixture(); await f.admin.approve(await open(f.request.ciphertext, f.inbox.privateKey));
        await f.admin.setAdmin(f.user.publicKey, f.now + 1000); f.advance(1001);
        const user = await f.connect(); await user.refresh(); expect(user.access(f.query).status).toBe('granted');
        await f.admin.setAdmin(f.user.publicKey, 0); await user.refresh(); expect(user.access(f.query).status).toBe('granted');
    });
    it('revalidates queued administrator commands against current authority', async () => {
        const f = await fixture(); await f.admin.setAdmin(f.user.publicKey, f.now + DAY);
        const user = await f.connect(); await user.propose({ kind: 'revoke-member', accountId: f.p.accountId });
        await f.admin.setAdmin(f.user.publicKey, 0);
        const result = await f.admin.inboxRequests(); expect(result.rejected).toBe(1); expect(f.admin.state!.members).toHaveLength(1);
        await expect(user.propose({ kind: 'set-limit', accountId: f.p.accountId, limit: 10 })).rejects.toThrow('полномочий');
    });
    it('processes active admin commands but cannot grant owner or rewrite the state directly', async () => {
        const f = await fixture(); await f.admin.setAdmin(f.user.publicKey, f.now + DAY);
        const user = await f.connect(); await user.propose({ kind: 'set-limit', accountId: f.p.accountId, limit: 2 });
        await f.admin.inboxRequests(); expect(f.admin.state!.members[0].maxDevices).toBe(2);
        await expect(verifyState(await signJws(f.admin.state, f.user), f.tenant, f.now)).rejects.toThrow();
        expect(user.isOwner()).toBe(false);
    });
    it('keeps a bounded signed cache for transient errors, never extends it, and honors fresh revocation', async () => {
        const f = await fixture(); await f.admin.approve(await open(f.request.ciphertext, f.inbox.privateKey));
        const user = await f.connect(); await user.refresh(); const original = user.cache!.verifiedAt;
        f.stores.access.failure = new GitError('network'); f.advance(DAY - 1); await user.refresh();
        expect(user.access(f.query).status).toBe('granted'); expect(user.cache!.verifiedAt).toBe(original);
        f.advance(1); expect(user.access(f.query).status).toBe('blocked');
        f.stores.access.failure = null; await user.refresh();
        await f.admin.change({ kind: 'remove-device', accountId: f.p.accountId, deviceId: f.device.keyId }); await user.refresh();
        expect(user.access(f.query).status).not.toBe('granted');
    });
    it('invalid signatures, authentication errors and rollback cannot use the old cached grant', async () => {
        const f = await fixture(); await f.admin.approve(await open(f.request.ciphertext, f.inbox.privateKey));
        const user = await f.connect(); await user.refresh(); const old = structuredClone(f.stores.access.files.get('state.jws')!);
        await f.admin.change({ kind: 'set-limit', accountId: f.p.accountId, limit: 2 }); await user.refresh();
        f.stores.access.files.set('state.jws', old); await user.refresh(); expect(user.access(f.query).status).toBe('blocked');
        f.stores.access.failure = new GitError('authentication'); await user.refresh(); expect(user.cache).toBeNull();
    });
    it('refuses owner credentials in distributed packages and unknown trust roots', async () => {
        const f = await fixture();
        await expect(f.admin.invite('x', f.ownerConnection.credentials, 1)).rejects.toThrow('PAT хозяина');
        await expect(verifyPackage(f.invite, {}, f.now)).rejects.toThrow('Unknown publisher');
        const untrusted = await generateIdentity();
        const forged = await signJws({ ...f.tenant, ownerKey: untrusted.publicKey }, untrusted);
        await expect(Service.connect({ ...f.connection, certificate: forged }, untrusted, f.device, f.roots, { stores: f.stores })).rejects.toThrow();
    });
});
