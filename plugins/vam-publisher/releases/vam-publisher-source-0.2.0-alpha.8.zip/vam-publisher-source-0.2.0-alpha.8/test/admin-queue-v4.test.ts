import 'fake-indexeddb/auto';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { parseHTML } from 'linkedom';
import { Modal, Plugin } from 'obsidian';
import { SettingsTab } from '../manager/src/auth-v4/settings-tab';
import { Runtime } from '../manager/src/auth-v4/runtime';
import { LocalStore } from '../manager/src/auth-v3/local';
import { build, Repository } from './helpers/v4';

const runtimes: Runtime[] = [];
beforeEach(() => { const { window } = parseHTML('<!doctype html><html><body></body></html>'); for (const name of ['document', 'HTMLElement', 'HTMLInputElement', 'HTMLTextAreaElement', 'Event']) vi.stubGlobal(name, (window as any)[name]); });
afterEach(() => { runtimes.splice(0).forEach(r => r.dispose()); delete (globalThis as any).__VAM__; delete (globalThis as any).vaultSyncAuth; vi.unstubAllGlobals(); });
function node(repo: Repository, id = crypto.randomUUID()) {
    const plugin = new Plugin({ appId: id, vault: { adapter: { getBasePath: () => '/' + id } }, workspace: { onLayoutReady() {} } } as any, { id: 'vault-access-manager', version: 'test' });
    const runtime = new Runtime(plugin, { ...build, bootstrapToken: 'old-token' }, { fetcher: repo.fetcher }, new LocalStore(id)); runtimes.push(runtime); return runtime;
}
async function admin(repo: Repository) { const r = node(repo); await r.start(); await r.loginAdministrator(build.defaultPassword); return r; }
async function join(repo: Repository, a: Runtime, key: string) { const d = node(repo); await d.start(); await d.applyCode(key); await a.tick(); await d.tick(); return d; }

describe('Administrator decisions on waiting requests', () => {
    it('describes a waiting request: who, what kind, how old, which devices', async () => {
        const repo = new Repository(), a = await admin(repo), added = await a.service!.addUser('Alice', { accountId: 'alice' }); const one = await join(repo, a, added.code);
        const two = node(repo); await two.start(); await two.applyCode(added.code); await a.tick();
        const [p] = a.service!.pending; expect([p.kind, p.accountId, p.label, p.replaceDeviceId]).toEqual(['extra', 'alice', 'Alice', undefined]); expect(Date.now() - p.issuedAt).toBeLessThan(60000);
        const old = repo.document().members[0].devices[0].deviceId; const swap = await a.service!.invite('Alice', { accountId: 'alice', replaceDeviceId: old });
        const three = node(repo); await three.start(); await three.applyCode(swap.code); await a.tick();
        expect(a.service!.pending.map(x => x.kind).sort()).toEqual(['extra', 'replace']); expect(a.service!.pending.find(x => x.kind === 'replace')!.replaceDeviceId).toBe(old); void one;
    });
    it('approving an extra device adds exactly one place; the key keeps working for the same limit afterwards', async () => {
        const repo = new Repository(), a = await admin(repo), added = await a.service!.addUser('Bob', { accountId: 'bob' }); await join(repo, a, added.code);
        const two = node(repo); await two.start(); await two.applyCode(added.code); await a.tick(); await a.service!.approve(a.service!.pending[0].code); await a.tick(); await two.tick();
        expect([repo.document().members[0].maxDevices, repo.document().members[0].devices.length, two.decision.status]).toEqual([2, 2, 'granted']); expect(a.service!.pending).toEqual([]);
        const three = node(repo); await three.start(); await three.applyCode(added.code); await a.tick(); expect(a.service!.pending).toHaveLength(1); // full again: needs a new decision
    });
    it('rejecting records a receipt, empties the queue, tells the device and does not touch access', async () => {
        const repo = new Repository(), a = await admin(repo), added = await a.service!.addUser('Cy', { accountId: 'cy' }); const first = await join(repo, a, added.code);
        const second = node(repo); await second.start(); await second.applyCode(added.code); await a.tick();
        expect(second.status).toContain('ожидаем решения'); await a.service!.reject(a.service!.pending[0].code); await a.tick(); await second.tick();
        expect(a.service!.pending).toEqual([]); expect(repo.document().receipts.filter(r => r.rejected)).toHaveLength(1); expect(repo.document().members[0].devices).toHaveLength(1);
        expect(second.status).toContain('отклонил'); expect(second.decision.status).not.toBe('granted'); expect(first.decision.status).toBe('granted');
        expect(a.service!.rejectedList.map(x => [x.accountId, x.reason])).toEqual([['cy', 'Отклонена Администратором']]);
        await a.tick(); await a.tick(); expect(a.service!.pending).toEqual([]); // stays declined on every later check
    });
    it('lets a user ask again after a refusal: the declined request is never reused', async () => {
        const repo = new Repository(), a = await admin(repo), added = await a.service!.addUser('Flo', { accountId: 'flo' }); await join(repo, a, added.code);
        const second = node(repo); await second.start(); await second.applyCode(added.code); await a.tick(); await a.service!.reject(a.service!.pending[0].code); await a.tick(); await second.tick();
        expect(second.status).toContain('отклонил'); const declinedId = (second as any).profile.outbox.id;
        await a.service!.updateUser('flo', { label: 'Flo', expiresAt: null, maxDevices: 2, restrictions: [] }); // the Administrator makes room and says "try again"
        await second.applyCode(added.code); expect((second as any).profile.outbox.id).not.toBe(declinedId); await a.tick(); await second.tick();
        expect(second.decision.status).toBe('granted'); expect(repo.document().members[0].devices).toHaveLength(2);
    });
    it('turns a waiting request into an ordinary approval when the Administrator raises the limit instead', async () => {
        const repo = new Repository(), a = await admin(repo), added = await a.service!.addUser('Gus', { accountId: 'gus' }); await join(repo, a, added.code);
        const second = node(repo); await second.start(); await second.applyCode(added.code); await a.tick(); expect(a.service!.pending).toHaveLength(1);
        await a.service!.updateUser('gus', { label: 'Gus', expiresAt: null, maxDevices: 2, restrictions: [] }); await a.tick(); await second.tick();
        expect(a.service!.pending).toEqual([]); expect(second.decision.status).toBe('granted');
    });
    it('rejecting a replacement spends its one-time key and leaves the old device in place', async () => {
        const repo = new Repository(), a = await admin(repo), added = await a.service!.addUser('Di', { accountId: 'di' }); await join(repo, a, added.code);
        const old = repo.document().members[0].devices[0].deviceId, swap = await a.service!.invite('Di', { accountId: 'di', replaceDeviceId: old });
        const fresh = node(repo); await fresh.start(); await fresh.applyCode(swap.code); await a.tick(); expect(a.service!.pending[0].kind).toBe('replace');
        await a.service!.reject(a.service!.pending[0].code); await a.tick();
        expect(repo.document().members[0].devices.map(d => d.deviceId)).toEqual([old]); expect(repo.document().invitations.find(i => i.purpose === 'replace')!.consumedBy).not.toBeNull();
        const again = node(repo); await again.start(); await expect(again.applyCode(swap.code)).rejects.toThrow('уже использован');
    });
    it('keeps the reason for declined requests and does not reread them every minute', async () => {
        const repo = new Repository(), original = repo.fetcher; let reads = 0;
        repo.fetcher = async (input, init) => { if (/\/contents\/vam\/requests\/[^/]+$/.test(new URL(String(input)).pathname) && (init?.method ?? 'GET') === 'GET') reads++; return original(input, init); };
        const a = await admin(repo), added = await a.service!.addUser('Ed', { accountId: 'ed' }); repo.files.set('vam/requests/garbage.json', { sha: 'g1', text: '{"v":4,"deviceProof":"nope"}' });
        const d = node(repo); await d.start(); await d.applyCode(added.code); await a.service!.change('revoke-member', 'ed'); await a.tick();
        expect(a.service!.rejectedList.map(x => x.reason).sort()).toEqual(['Доступ отозван', 'Некорректная или просроченная заявка']); const after = reads;
        await a.tick(); await a.tick(); expect(reads).toBe(after); expect(a.service!.rejected).toBe(2);
    });
});

describe('one save for a user, restoring access, last sync', () => {
    it('saves name, expiry, limit, password and restrictions in one commit and keeps the key and unknown restriction names', async () => {
        const repo = new Repository(), a = await admin(repo), added = await a.service!.addUser('Fi', { accountId: 'fi' }); await join(repo, a, added.code);
        repo.edit(d => { d.members[0].restrictions = ['future.feature']; }); await a.tick(); const before = repo.document().revision;
        await a.service!.updateUser('fi', { label: 'Fiona', password: 'new-password-1', expiresAt: Date.now() + 86400000 * 30, maxDevices: 3, restrictions: ['note.delete'] });
        const m = repo.document().members[0]; expect(repo.document().revision).toBe(before + 1);
        expect([m.label, m.password, m.maxDevices, m.restrictions]).toEqual(['Fiona', 'new-password-1', 3, ['note.delete', 'future.feature']]); expect(a.service!.userKey('fi')).toBe(added.code);
        await expect(a.service!.updateUser('fi', { label: 'x', expiresAt: null, maxDevices: 0, restrictions: [] })).rejects.toThrow('Лимит'); await expect(a.service!.updateUser('ghost', { label: 'x', expiresAt: null, maxDevices: 1, restrictions: [] })).rejects.toThrow('не найден');
        await a.service!.updateUser('fi', { label: 'Fiona', expiresAt: null, maxDevices: 3, restrictions: [] }); expect(repo.document().members[0].restrictions).toEqual(['future.feature']);
    });
    it('restores a revoked user together with the connected devices and a new key, clearing a lapsed expiry', async () => {
        const repo = new Repository(), a = await admin(repo), added = await a.service!.addUser('Gi', { accountId: 'gi' }), d = await join(repo, a, added.code);
        await a.service!.change('revoke-member', 'gi'); await d.tick(); expect(d.decision.status).not.toBe('granted'); expect(a.service!.userKey('gi')).toBeNull();
        repo.edit(m => { m.members[0].expiresAt = 1; }); await a.tick(); await a.service!.restoreMember('gi'); await d.tick();
        expect(repo.document().members[0].expiresAt).toBeNull(); expect(d.decision.status).toBe('granted'); const key = a.service!.userKey('gi'); expect(key).toContain('VAM4.'); expect(key).not.toBe(added.code);
        await expect(a.service!.restoreMember('ghost')).rejects.toThrow('не найден');
    });
    it('reports when the configuration was last fetched', async () => {
        const repo = new Repository(), a = await admin(repo); expect(a.service!.lastSyncAt).not.toBeNull(); expect(Date.now() - a.service!.lastSyncAt!).toBeLessThan(60000);
    });
});

describe('administrator panel', () => {
    const buttons = (root: ParentNode, title: string) => Array.from(root.querySelectorAll('button')).filter(b => b.textContent === title) as HTMLButtonElement[];
    const press = async (b: HTMLButtonElement | undefined) => { if (!b) throw new Error('Missing button'); await (b.onclick as any)({ preventDefault() {} }); };
    const field = (root: ParentNode, title: string, index = 0) => Array.from(root.querySelectorAll('label')).filter(l => l.firstChild?.textContent === title).map(l => l.querySelector('input,textarea') as HTMLInputElement)[index];
    const open = async (repo = new Repository()) => {
        const a = await admin(repo); const view = new SettingsTab((a as any).plugin.app, (a as any).plugin, a); document.body.append(view.containerEl); view.display(); (Modal as any).opened = [];
        return { repo, a, view, s: a.service! };
    };
    const card = (id: string) => document.querySelector(`details[data-key="user:${id}"]`) as HTMLDetailsElement;
    const confirmWith = async (work: Promise<void>, label: string) => { const modal = (Modal as any).opened.at(-1); await press(buttons(modal.contentEl, label)[0]); await work; };

    it('shows waiting requests at the top, opened, and lets the Administrator approve or reject each in place', async () => {
        const { repo, a, s, view } = await open(); const added = await s.addUser('Alice', { accountId: 'alice' }); await join(repo, a, added.code);
        const old = repo.document().members[0].devices[0].deviceId, swap = await s.invite('Alice', { accountId: 'alice', replaceDeviceId: old });
        const extra = node(repo); await extra.start(); await extra.applyCode(added.code); const fresh = node(repo); await fresh.start(); await fresh.applyCode(swap.code); await a.tick(); view.display();
        const queue = document.querySelector('details[data-key="queue"]') as HTMLDetailsElement; expect(queue.open).toBe(true); expect(queue.querySelector('summary')!.textContent).toBe('Заявки на рассмотрении: 2');
        const items = Array.from(queue.querySelectorAll('.vam-request')); expect(items).toHaveLength(2); const text = queue.textContent!;
        expect(text).toContain('Alice (alice)'); expect(text).toContain('дополнительное устройство'); expect(text).toContain('замена устройства'); expect(text).toContain('только что'); expect(text).toContain('лимит станет 2');
        const overview = document.querySelector('.vam-overview')!; expect(overview.textContent).toContain('Заявок на рассмотрении: 2');
        const extraItem = items.find(i => i.textContent!.includes('дополнительное устройство'))!, replaceItem = items.find(i => i.textContent!.includes('замена устройства'))!;
        await press(buttons(extraItem, 'Отклонить')[0]);
        expect(s.pending.map(p => p.kind)).toEqual(['replace']); expect(document.querySelector('details[data-key="declined"]')!.textContent).toContain('Отклонена Администратором'); expect(document.querySelector('.vam-overview')!.textContent).toContain('Заявок на рассмотрении: 1');
        await press(buttons(document.querySelector('details[data-key="queue"]')!, 'Подтвердить')[0]); void replaceItem;
        expect(s.pending).toEqual([]); expect(document.querySelector('details[data-key="queue"]')!.textContent).toContain('Новых заявок нет'); expect(repo.document().members[0].devices.map(d => d.deviceId)).not.toContain(old);
        view.hide();
    });
    it('saves a card in one step and refreshes in place: nothing collapses and the page is not rebuilt', async () => {
        const { s, view } = await open(); await s.addUser('Alice', { accountId: 'alice', maxDevices: 1 }); await s.addUser('Bob', { accountId: 'bob' }); (view as any).display();
        const alice = card('alice'), edit = alice.querySelector('details[data-key="user:alice:edit"]') as HTMLDetailsElement; alice.open = true; edit.open = true;
        const heading = document.querySelector('h2'), overview = document.querySelector('.vam-overview');
        field(edit, 'Лимит устройств').value = '3'; field(edit, 'Имя пользователя').value = 'Alice A.'; (field(edit, 'Запретить удаление заметок и папок') as HTMLInputElement).checked = true;
        await press(buttons(edit, 'Сохранить изменения')[0]);
        const m = s.document!.members.find(x => x.accountId === 'alice')!; expect([m.maxDevices, m.label, m.restrictions]).toEqual([3, 'Alice A.', ['note.delete']]);
        expect(document.querySelector('h2')).toBe(heading); expect(document.querySelector('.vam-overview')).toBe(overview); // not a full redraw
        expect(card('alice').open).toBe(true); expect((card('alice').querySelector('details[data-key="user:alice:edit"]') as HTMLDetailsElement).open).toBe(true); expect(card('bob').open).toBe(false);
        expect(card('alice').querySelector('summary')!.textContent).toContain('Alice A.'); expect(card('alice').querySelector('summary')!.textContent).toContain('ограничения');
        view.hide();
    });
    it('shows a revoked user as a compact card with one way back, and restores with a clearly named dialog', async () => {
        const { s, view } = await open(); await s.addUser('Bob', { accountId: 'bob' }); await s.change('revoke-member', 'bob'); (view as any).display();
        const bob = card('bob'); expect(bob.textContent).toContain('Доступ отозван'); expect(buttons(bob, 'Восстановить доступ')).toHaveLength(1);
        for (const gone of ['Перевыпустить ключ', 'Отозвать пользователя', 'Скопировать приглашение']) expect(buttons(bob, gone)).toHaveLength(0); expect(bob.querySelector('textarea[data-standing]')).toBeNull();
        const pending = press(buttons(bob, 'Восстановить доступ')[0]); await Promise.resolve(); const modal = (Modal as any).opened.at(-1);
        expect(modal.contentEl.querySelector('h3').textContent).toBe('Подтвердите восстановление доступа'); expect(buttons(modal.contentEl, 'Отозвать доступ')).toHaveLength(0);
        await confirmWith(pending, 'Восстановить доступ'); expect(s.document!.members[0].active).toBe(true); expect(card('bob').querySelector('textarea[data-standing]')).toBeNull();await press(buttons(card('bob'),'Показать ключ пользователя')[0]);expect(card('bob').querySelector('textarea[data-standing]')).not.toBeNull(); expect(buttons(card('bob'), 'Восстановить доступ')).toHaveLength(0);
        view.hide();
    });
    it('names reissue and device removal for what they are', async () => {
        const { repo, a, s, view } = await open(); const added = await s.addUser('Cy', { accountId: 'cy' }); await join(repo, a, added.code); (view as any).display();
        let pending = press(buttons(card('cy'), 'Перевыпустить ключ')[0]); await Promise.resolve(); let modal = (Modal as any).opened.at(-1);
        expect([modal.contentEl.querySelector('h3').textContent, buttons(modal.contentEl, 'Перевыпустить ключ').length, buttons(modal.contentEl, 'Отозвать доступ').length]).toEqual(['Перевыпуск ключа', 1, 0]); await confirmWith(pending, 'Отмена');
        expect(s.userKey('cy')).toBe(added.code); // cancelled: nothing changed
        const device = repo.document().members[0].devices[0].deviceId; pending = press(buttons(card('cy'), 'Отозвать устройство')[0]); await Promise.resolve(); modal = (Modal as any).opened.at(-1);
        expect(modal.contentEl.querySelector('h3').textContent).toBe('Подтвердите отзыв устройства'); expect(modal.contentEl.textContent).toContain('Cy'); expect(modal.contentEl.textContent).toContain(device.slice(-8)); await confirmWith(pending, 'Отозвать устройство');
        expect(repo.document().members[0].devices).toEqual([]); view.hide();
    });
    it('filters users by state and search together, and shows device age and a short id', async () => {
        const { repo, a, s, view } = await open(); const one = await s.addUser('Ann', { accountId: 'ann', maxDevices: 1 }); await s.addUser('Ben', { accountId: 'ben' }); await s.addUser('Cat', { accountId: 'cat' }); await s.change('revoke-member', 'ben');
        await join(repo, a, one.code); (view as any).display();
        const visible = () => Array.from(document.querySelectorAll<HTMLElement>('[data-user-key], details[data-key^="user:"]')).filter(d => !d.dataset.key!.includes(':edit') && !d.dataset.key!.includes(':devices') && !d.hidden).map(d => d.dataset.key!.slice(5)).sort();
        const select = document.querySelector('.vam-filters select') as HTMLSelectElement, search = field(document, 'Найти пользователя по ID или имени');
        expect(visible()).toEqual(['ann', 'ben', 'cat']);
        for (const [value, expected] of [['revoked', ['ben']], ['full', ['ann']], ['empty', ['ben', 'cat']], ['active', ['ann', 'cat']], ['guarded', []]] as const) { Object.defineProperty(select, 'value', { value, configurable: true }); select.dispatchEvent(new (document.defaultView as any).Event('change')); expect(visible()).toEqual(expected); }
        Object.defineProperty(select, 'value', { value: 'empty', configurable: true }); select.dispatchEvent(new (document.defaultView as any).Event('change')); search.value = 'cat'; search.dispatchEvent(new (document.defaultView as any).Event('input')); expect(visible()).toEqual(['cat']);
        search.value=''; Object.defineProperty(select,'value',{value:'all',configurable:true}); select.dispatchEvent(new (document.defaultView as any).Event('change'));
        const devices = card('ann').querySelector('details[data-key="user:ann:devices"]')!; expect(devices.textContent).toContain('Устройство …' + repo.document().members.find(m => m.accountId === 'ann')!.devices[0].deviceId.slice(-8) + ' · добавлено '); view.hide();
    });
    it('summarises states, PAT expiry and the last sync, and warns when the PAT is close to expiry', async () => {
        const { s, a, view } = await open(); await s.addUser('Ann', { accountId: 'ann' }); await s.addUser('Ben', { accountId: 'ben' }); await s.change('revoke-member', 'ben'); (view as any).display();
        const line = () => document.querySelectorAll('.vam-overview p'); expect(line()[0].textContent).toContain('1 действующих'); expect(line()[0].textContent).toContain('1 отозвано'); expect(line()[1].textContent).toContain('срок PAT: не задан'); expect(line()[1].textContent).toContain('данные получены только что'); expect((line()[1] as HTMLElement).dataset.warn).toBe('');
        const soon = new Date(Date.now() + 5 * 86400000).toISOString().slice(0, 10); await a.rotateToken('new-token', soon); (view as any).display();
        expect(line()[1].textContent).toMatch(/осталось [4-6] дн\./); expect((line()[1] as HTMLElement).dataset.warn).toBe('1'); view.hide();
    });
    it('copies a ready invitation text with the ID, the key and the steps', async () => {
        const writes: string[] = []; vi.stubGlobal('navigator', { clipboard: { writeText: async (v: string) => { writes.push(v); } } });
        const { s, view } = await open(); const added = await s.addUser('Dee', { accountId: 'dee' }); (view as any).display();
        await press(buttons(card('dee'), 'Скопировать приглашение')[0]);
        expect(writes).toHaveLength(1); expect(writes[0]).toContain('ID: dee'); expect(writes[0]).toContain(added.code); expect(writes[0]).toContain('Установите плагин'); expect(writes[0]).not.toContain('Пароль'); view.hide();
    });
});

