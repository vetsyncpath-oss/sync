import {attachVaultFile} from './helpers/vault-file';
import 'fake-indexeddb/auto';
import { parseHTML } from 'linkedom';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { Modal, Plugin } from 'obsidian';
import { Runtime } from '../manager/src/auth-v4/runtime';
import { LocalStore } from '../manager/src/auth-v3/local';
import { vamGuard, type VamGate, type VamGuardOptions } from '../manager/vam-guard';
import { build, Repository } from './helpers/v4';

/**
 * What a protected plugin experiences: these tests drive the real SDK guard (manager/vam-guard.ts, the file plugins embed)
 * against the real manager runtime through every public hook: __VAM__, vaultSyncAuth, __VAM_PENDING__ and applyManagerProbe.
 */
const runtimes: Runtime[] = [], guards: VamGate[] = [];
beforeEach(() => { const { window } = parseHTML('<!doctype html><html><body></body></html>'); for (const name of ['document', 'HTMLElement', 'HTMLInputElement', 'HTMLTextAreaElement', 'Event']) vi.stubGlobal(name, (window as any)[name]); });
afterEach(() => { guards.splice(0).forEach(g => g.dispose()); runtimes.splice(0).forEach(r => r.dispose()); for (const key of ['__VAM__', 'vaultSyncAuth', '__VAM_PENDING__']) delete (globalThis as any)[key]; vi.useRealTimers(); vi.unstubAllGlobals(); });

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));
async function until(condition: () => boolean, what = 'condition'): Promise<void> { for (let i = 0; i < 400; i++) { if (condition()) return; await sleep(5); } throw new Error('Timed out waiting for ' + what); }
const fresh = () => { for (const key of ['__VAM__', 'vaultSyncAuth', '__VAM_PENDING__']) delete (globalThis as any)[key]; }; // a new Obsidian start: no stale bridge

function node(repo: Repository, installation: string, options: { fetcher?: typeof fetch; app?: Record<string, unknown> } = {}) {
    const plugin = new Plugin({ appId: installation, vault: { adapter: { getBasePath: () => '/' + installation } }, workspace: { onLayoutReady() {} }, ...(options.app ?? {}) } as any, { id: 'vault-access-manager', version: 'test' });
    attachVaultFile(plugin,installation); const runtime = new Runtime(plugin, { ...build, bootstrapToken: 'old-token' }, { fetcher: options.fetcher ?? repo.fetcher }, new LocalStore(installation)); runtimes.push(runtime); return runtime;
}
/** A protected plugin: every callback of the SDK is recorded in order. */
function watch(log: string[], extra: Partial<VamGuardOptions> = {}): VamGate {
    const gate = vamGuard({ tenantId: build.tenantId, bundleId: build.bundleId, pluginId: 'my-plugin', pollMs: 5, timeoutMs: 15000,
        onChange: (status, reason) => log.push(`change:${status}/${reason}`), onBlocked: reason => log.push(`blocked:${reason}`), onRevoked: reason => log.push(`REVOKED:${reason}`),
        onForbidden: info => log.push(`FORBIDDEN:${info.note}`), onPermissionChange: permission => log.push(`perm:${permission}`), ...extra });
    guards.push(gate); return gate;
}
async function administrator(repo: Repository, installation: string = crypto.randomUUID()) { const r = node(repo, installation); await r.start(); await r.loginAdministrator(build.defaultPassword); return r; }
/** An approved user device; returns the runtimes and the user's key. */
async function enrolled(repo: Repository, fetcher?: typeof fetch, app?: Record<string, unknown>, installation: string = crypto.randomUUID()) {
    const a = await administrator(repo), added = await a.service!.addUser('Alice', { accountId: 'alice' });
    const u = node(repo, installation, { fetcher, app }); await u.start(); await u.applyCode(added.code); await a.tick(); await u.tick(); expect(u.decision.status).toBe('granted'); return { a, u, added, installation };
}
const takeLog = (log: string[]) => log.splice(0);

describe('a protected plugin follows the whole life of access', () => {
    it('gets every transition, in both directions, exactly once and in order', async () => {
        const repo = new Repository(), log: string[] = [], a = await administrator(repo), added = await a.service!.addUser('Alice', { accountId: 'alice' });
        const u = node(repo, crypto.randomUUID()); await u.start(); const gate = watch(log);
        expect(takeLog(log)).toEqual(['perm:regulated', 'change:blocked/signed-out', 'blocked:signed-out']); expect(gate.isGranted()).toBe(false);
        await u.applyCode(added.code); expect(takeLog(log)).toEqual(['change:pending/device-not-approved']); // waiting is not a refusal
        await a.tick(); await u.tick(); expect(takeLog(log)).toEqual(['perm:allowed', 'change:granted/null']); expect(gate.isGranted()).toBe(true);
        await a.service!.change('revoke-member', 'alice'); await u.tick();
        expect(takeLog(log)).toEqual(['perm:forbidden', 'FORBIDDEN:access-revoked-or-expired', 'change:blocked/access-revoked-or-expired', 'blocked:access-revoked-or-expired', 'REVOKED:access-revoked-or-expired']); expect(gate.isGranted()).toBe(false);
        await a.service!.restoreMember('alice'); await u.tick(); expect(takeLog(log)).toEqual(['perm:allowed', 'change:granted/null']);
        u.logout(); expect(takeLog(log)).toEqual(['perm:regulated', 'change:blocked/signed-out', 'blocked:signed-out', 'REVOKED:signed-out']); // signing out is not a policy denial
    });
    it('is not spammed by the manager\'s periodic refresh', async () => {
        const repo = new Repository(), log: string[] = [], { u } = await enrolled(repo); watch(log); takeLog(log);
        for (let i = 0; i < 5; i++) u.changed(); await u.tick(); await u.tick(); expect(log).toEqual([]);
    });
    it('treats the removal of its device as an explicit denial', async () => {
        const repo = new Repository(), log: string[] = [], { a, u } = await enrolled(repo); watch(log); takeLog(log);
        await a.service!.change('remove-device', 'alice', repo.document().members[0].devices[0].deviceId); await u.tick();
        expect(takeLog(log)).toEqual(['perm:forbidden', 'FORBIDDEN:device-revoked', 'change:blocked/device-revoked', 'blocked:device-revoked', 'REVOKED:device-revoked']);
    });
    it('sees the end of a dated access without any Administrator action', async () => {
        vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date('2026-10-20T10:00:00Z'));
        const repo = new Repository(), log: string[] = [], { a, u } = await enrolled(repo); await a.service!.updateUser('alice', { label: 'Alice', expiresAt: Date.now() + 3600000, maxDevices: 1, restrictions: [] }); await u.tick();
        watch(log); takeLog(log); vi.setSystemTime(new Date('2026-10-20T12:00:00Z')); u.changed();
        expect(takeLog(log)).toEqual(['perm:forbidden', 'FORBIDDEN:access-revoked-or-expired', 'change:blocked/access-revoked-or-expired', 'blocked:access-revoked-or-expired', 'REVOKED:access-revoked-or-expired']);
    });
    it('blocks after a day without a check, calls it a connection problem rather than a denial, and recovers on its own', async () => {
        vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date('2026-10-20T10:00:00Z'));
        const repo = new Repository(); let down = false; const flaky: typeof fetch = async (input, init) => { if (down) throw new TypeError('offline'); return repo.fetcher(input, init); };
        const log: string[] = [], { u } = await enrolled(repo, flaky); watch(log); takeLog(log);
        down = true; vi.setSystemTime(new Date('2026-10-20T20:00:00Z')); await u.tick(); u.changed(); expect(log).toEqual([]); // still within 24 hours: offline use is fine
        vi.setSystemTime(new Date('2026-10-21T11:00:00Z')); u.changed();
        expect(takeLog(log)).toEqual(['perm:regulated', 'change:blocked/connection-unavailable', 'blocked:connection-unavailable', 'REVOKED:connection-unavailable']); // no FORBIDDEN: nothing was denied
        down = false; await u.tick(); expect(takeLog(log)).toEqual(['perm:allowed', 'change:granted/null']);
    });
    it('keeps working for a user with interface restrictions, and the restrictions do not leak into the status', async () => {
        const repo = new Repository(), log: string[] = [], { a, u } = await enrolled(repo, undefined, { vault: { trash: async () => {} }, setting: { open() {}, openTabById() {} } }); const gate = watch(log); takeLog(log);
        await a.service!.updateUser('alice', { label: 'Alice', expiresAt: null, maxDevices: 1, restrictions: ['note.delete', 'settings.open'] }); await u.tick();
        expect(gate.isGranted()).toBe(true); expect(log).toEqual([]); expect((globalThis as any).__VAM__.access({ tenantId: build.tenantId, bundleId: build.bundleId, capability: 'use' }).status).toBe('granted');
    });
});

describe('start-up order and manager reloads', () => {
    it('a guard that loads before the manager is served through the pending queue, and registers its plugin', async () => {
        const repo = new Repository(), log: string[] = []; fresh(); const gate = watch(log);
        expect(gate.status).toBe('pending'); expect(log).toEqual([]); // the starting state is not an event
        const a = node(repo, crypto.randomUUID()); await a.start(); await until(() => gate.status === 'blocked', 'the manager to be adopted');
        expect(gate.reason).toBe('signed-out'); expect(log).not.toContain('blocked:not-configured'); expect(log.some(l => l.startsWith('FORBIDDEN'))).toBe(false);
        await a.loginAdministrator(build.defaultPassword); await until(() => gate.isGranted(), 'the administrator grant'); expect(gate.isAdministrator()).toBe(true);
        expect((a as any).plugins.known).toContain('my-plugin');
    });
    it('during the first check after a restart other plugins see "checking", never a refusal', async () => {
        vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date('2026-10-20T10:00:00Z'));
        const repo = new Repository(), { u, installation } = await enrolled(repo); u.dispose(); await sleep(30); vi.setSystemTime(new Date('2026-10-22T10:00:00Z')); // the 24-hour cache has lapsed
        let release!: () => void; const gateOpen = new Promise<void>(resolve => { release = resolve; }); const slow: typeof fetch = async (input, init) => { await gateOpen; return repo.fetcher(input, init); };
        fresh(); const log: string[] = [], gate = watch(log); const again = node(repo, installation, { fetcher: slow }); await again.start({ awaitRefresh: false }); await sleep(40);
        expect([gate.status, gate.reason]).toEqual(['pending', 'checking']); expect(log.filter(l => /^(blocked|FORBIDDEN|REVOKED)/.test(l))).toEqual([]); expect(again.status).toBe('Проверяем доступ…');
        release(); await again.ready; await until(() => gate.isGranted(), 'the grant after the check'); expect(log.filter(l => /^(blocked|FORBIDDEN|REVOKED)/.test(l))).toEqual([]); // it never flickered through a refusal
    });
    it('if that first check finds no connection, the plugin is told it is a connection problem, not a denial', async () => {
        vi.useFakeTimers({ toFake: ['Date'] }); vi.setSystemTime(new Date('2026-10-20T10:00:00Z'));
        const repo = new Repository(), { u, installation } = await enrolled(repo); u.dispose(); await sleep(30); vi.setSystemTime(new Date('2026-10-22T10:00:00Z'));
        const offline: typeof fetch = async () => { throw new TypeError('network down'); }; fresh(); const log: string[] = [], gate = watch(log); const again = node(repo, installation, { fetcher: offline }); await again.start({ awaitRefresh: false }); await again.ready;
        await until(() => gate.status === 'blocked', 'the verdict'); expect(gate.reason).toBe('connection-unavailable'); expect(log.some(l => l.startsWith('FORBIDDEN'))).toBe(false); expect(log).toContain('blocked:connection-unavailable');
    });
    it('a saved grant is in force at once on a cold start, before any network answer', async () => {
        const repo = new Repository(), { u, installation } = await enrolled(repo); u.dispose(); await sleep(30);
        const offline: typeof fetch = async () => { throw new TypeError('network down'); }; fresh(); const log: string[] = [], gate = watch(log); const again = node(repo, installation, { fetcher: offline }); await again.start({ awaitRefresh: false });
        await until(() => gate.isGranted(), 'the cached grant'); expect(log.filter(l => /^(blocked|FORBIDDEN|REVOKED)/.test(l))).toEqual([]);
    });
    it('unloading the manager is reported as such, not as a denial; a reloaded manager is adopted again', async () => {
        const repo = new Repository(), log: string[] = [], { u, installation } = await enrolled(repo); const gate = watch(log); takeLog(log);
        u.dispose(); expect(takeLog(log)).toEqual(['perm:regulated', 'change:blocked/vam-unloaded', 'blocked:vam-unloaded', 'REVOKED:vam-unloaded']); expect(gate.isGranted()).toBe(false);
        await sleep(30); const offline: typeof fetch = async () => { throw new TypeError('network down'); }; const again = node(repo, installation, { fetcher: offline }); await again.start({ awaitRefresh: false });
        await until(() => gate.isGranted(), 'the reloaded manager'); expect(log.some(l => l.startsWith('FORBIDDEN'))).toBe(false); expect(log.filter(l => l.startsWith('blocked:'))).toEqual([]); // the blocked event came once, at unload
    });
    it('without any manager the guard fails closed after its timeout', async () => {
        fresh(); const log: string[] = [], gate = watch(log, { timeoutMs: 40 }); await until(() => gate.status === 'blocked', 'the timeout');
        expect(gate.reason).toBe('vam-missing'); expect(gate.isGranted()).toBe(false); expect(log).toContain('blocked:vam-missing');
    });
});

describe('who may ask, and how strictly', () => {
    it('answers "is this the administrator" only for the configured organization and only while signed in', async () => {
        const repo = new Repository(), a = await administrator(repo), api = (globalThis as any).__VAM__, gate = watch([]);
        await until(() => gate.isGranted()); expect([gate.isAdministrator(), api.isAdministrator(build.tenantId), api.isOwner(build.tenantId), api.isAdministrator('another-organization')]).toEqual([true, true, true, false]);
        expect(gate.getAuthState()).toMatchObject({ role: 'administrator', authenticated: true, gate: 'granted', managerVersion: 'test' }); a.logout(); expect(gate.isAdministrator()).toBe(false);
    });
    it('a user is never an administrator', async () => {
        const repo = new Repository(), { u } = await enrolled(repo), gate = watch([]); await until(() => gate.isGranted()); expect(gate.isAdministrator()).toBe(false); expect(gate.getAuthState()).toMatchObject({ role: 'user', authenticated: true }); void u;
    });
    it('is strict about scope: another bundle, no tenant, or a malformed query never reads as access', async () => {
        const repo = new Repository(); await administrator(repo); const api = (globalThis as any).__VAM__;
        const wrongBundle = watch([], { bundleId: 'another-bundle' }), noTenant = watch([], { tenantId: undefined });
        await until(() => wrongBundle.status === 'blocked' && noTenant.status === 'blocked'); expect([wrongBundle.reason, noTenant.reason]).toEqual(['bundle-scope-required', 'scope-required']);
        expect(api.access(null)).toMatchObject({ status: 'blocked', reason: 'invalid-scope' }); expect(api.access({ tenantId: 'x', bundleId: build.bundleId, capability: 'use' })).toMatchObject({ status: 'blocked' });
    });
    it('keeps plugin policy separate from access: every plugin id is "regulated" and bad ids are not registered', async () => {
        const repo = new Repository(), a = await administrator(repo), api = (globalThis as any).__VAM__;
        expect(api.getPermission('anything')).toEqual({ permission: 'regulated', source: 'builtin', note: null });
        const before = [...(a as any).plugins.known]; for (const bad of ['bad id!', 'x'.repeat(201), 5, null, '']) api.register(bad); expect([...(a as any).plugins.known]).toEqual(before); api.register('good.plugin-1'); expect([...(a as any).plugins.known]).toEqual([...before, 'good.plugin-1']);
    });
    it('survives a plugin whose callbacks throw', async () => {
        const repo = new Repository(), api = (): any => (globalThis as any).__VAM__; const a = await administrator(repo); a.logout(); const seen: string[] = [];
        api().subscribe(() => { throw new Error('bad consumer'); }); api().subscribeAuth(() => { throw new Error('bad consumer'); }); (globalThis as any).vaultSyncAuth.onChanged(() => { throw new Error('bad consumer'); });
        const gate = watch([], { onChange: () => { throw new Error('bad plugin'); } }); gate.onChange(status => seen.push(status));
        await a.loginAdministrator(build.defaultPassword); await until(() => gate.isGranted()); expect(seen).toContain('granted');
    });
});

describe('the other public surfaces', () => {
    it('exposes the bridge of protocol 6 with live status, reason, auth state and unsubscribe', async () => {
        const repo = new Repository(), api = () => (globalThis as any).__VAM__, a = node(repo, crypto.randomUUID()); await a.start(); const statuses: string[] = [], auths: any[] = [];
        expect(api().version).toBe('6'); expect([api().getStatus(), api().getReason()]).toEqual(['blocked', 'signed-out']);
        const off = api().subscribe((status: string, reason: string | null) => statuses.push(`${status}/${reason}`)); const offAuth = api().subscribeAuth((state: any) => auths.push(state));
        expect(statuses).toEqual(['blocked/signed-out']); // current state at once
        await a.loginAdministrator(build.defaultPassword); expect(statuses).toEqual(['blocked/signed-out', 'granted/null']); expect(api().getAuthState()).toMatchObject({ role: 'owner', authenticated: true, gate: 'granted' }); expect(auths.at(-1)).toMatchObject({ role: 'owner', authenticated: true });
        off(); offAuth(); const before = [statuses.length, auths.length]; a.logout(); expect([statuses.length, auths.length]).toEqual(before); // unsubscribed
    });
    it('keeps the earlier vaultSyncAuth API working: state, change events, prompt and a refresh that does not pile up', async () => {
        const repo = new Repository(), a = await administrator(repo), added = await a.service!.addUser('Alice', { accountId: 'alice' }), u = node(repo, crypto.randomUUID()); await u.start();
        const legacy = (globalThis as any).vaultSyncAuth, states: any[] = []; legacy.onChanged((state: any) => states.push(state.status));
        expect(legacy.getState()).toMatchObject({ status: 'blocked', reason: 'signed-out' }); expect((u as any).plugin.auth).toBe(legacy);
        await u.applyCode(added.code); expect(legacy.getState().status).toBe('checking'); await a.tick(); await u.tick();
        expect(legacy.getState()).toMatchObject({ status: 'ok', userId: 'alice' }); expect(typeof legacy.getState().checkedAt).toBe('number'); expect(states).toEqual(['blocked', 'checking', 'ok']);
        const spy = vi.spyOn(u, 'tick'); await Promise.all([legacy.beforeSession(), legacy.beforeSession(), legacy.beforeSession()]); expect(spy).toHaveBeenCalledTimes(1);
        (Modal as any).opened = []; legacy.prompt(); expect((Modal as any).opened).toHaveLength(1);
    });
    it('tells a cloud-sync plugin about every change in order, including the unload', async () => {
        const probes: any[] = [], sync = { applyManagerProbe: async (probe: any) => { await sleep(Math.random() * 5); probes.push(probe); } };
        const repo = new Repository(), { a, u } = await enrolled(repo, undefined, { plugins: { plugins: { 'cloud-vault-sync': sync } } });
        await a.service!.change('revoke-member', 'alice'); await u.tick(); await sleep(60); u.dispose(); await sleep(60);
        const grant = probes.findIndex(p => p.authOk), denied = probes.findIndex((p, i) => i > grant && !p.authOk && p.reason === 'access-revoked-or-expired'), unloaded = probes.findIndex(p => p.present === false);
        expect(grant).toBeGreaterThanOrEqual(0); expect(denied).toBeGreaterThan(grant); expect(unloaded).toBeGreaterThan(denied); expect(probes[unloaded]).toMatchObject({ present: false, authOk: false, reason: 'vam-unloaded' });
        expect(probes.every((p, i) => i === 0 || JSON.stringify(p) !== JSON.stringify(probes[i - 1]))).toBe(true); // never the same probe twice in a row
    });
});
