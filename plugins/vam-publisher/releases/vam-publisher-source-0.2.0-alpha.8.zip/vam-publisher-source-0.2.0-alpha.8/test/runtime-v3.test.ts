import 'fake-indexeddb/auto';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { Notice, Plugin } from 'obsidian';
import { Runtime } from '../manager/src/auth-v3/runtime';
import { GitError } from '../manager/src/auth-v3/git-store';
import { LocalStore } from '../manager/src/auth-v3/local';
import { patWarning } from '../manager/src/auth-v3/pat';
import { installBridge } from '../manager/src/auth-v3/bridge';
import { vamGuard } from '../manager/src/sdk/vam-guard';
import { fixture } from './helpers/v3';
import { encryptSecret, inspectJws, signJws } from '../manager/src/auth-v2/crypto';
const active: Array<{ dispose(): void }> = [];
afterEach(() => { active.splice(0).forEach(x => x.dispose()); vi.useRealTimers(); delete (globalThis as any).__VAM__; });
function plugin() { return new Plugin({ vault: {}, initialSettings: { role: 'owner' } } as any, { id: 'manager', version: 'test' }); }
function runtime(f: Awaited<ReturnType<typeof fixture>>, name = crypto.randomUUID()) { const r = new Runtime(plugin(), f.roots, f.fetcher, new LocalStore(name)); active.push(r); return r; }

describe('installation storage and seamless runtime', () => {
    it('stores separate non-exportable keys outside the vault, with atomic concurrent initialization', async () => {
        const name = crypto.randomUUID(), a = new LocalStore(name), b = new LocalStore(name);
        try {
            const [one, two] = await Promise.all([a.identity('device'), b.identity('device')]);
            expect(one.keyId).toBe(two.keyId); expect(one.privateKey.extractable).toBe(false);
            await expect(crypto.subtle.exportKey('jwk', one.privateKey)).rejects.toThrow();
            expect((await a.identity('user')).keyId).not.toBe(one.keyId);
            await a.saveSecret('profile', { token: 'test-private-token' });
            expect(JSON.stringify(await a.get('profile'))).not.toContain('test-private-token');
            expect(await b.secret('profile')).toEqual({ token: 'test-private-token' });
        } finally { await a.close(); await b.close(); }
    });
    it('does not accept another device fingerprint without its private key', async () => {
        const f = await fixture(), local = new LocalStore(crypto.randomUUID());
        try {
            const device = await local.identity('device');
            await local.set('device', { ...device, keyId: f.device.keyId, publicKey: f.device.publicKey });
            await expect(local.identity('device')).rejects.toThrow();
        } finally { await local.close(); }
    });
    it('an in-progress password unlock cannot override a subsequent lock command', async () => {
        const f = await fixture(), r = runtime(f); await r.start();
        const password = 'a long owner passphrase';
        const box = await encryptSecret({ key: await crypto.subtle.exportKey('jwk', f.owner.privateKey), inbox: f.inbox.privateKey }, password);
        await r.restoreOwner(JSON.stringify({ v: 3, ownerBox: box }), password); r.lockOwner();
        const unlocking = r.unlockOwner(password); r.lockOwner();
        await expect(unlocking).rejects.toThrow('отменена'); expect(r.ownerUnlocked).toBe(false);
    });
    it('activates with one code, restores without password or data.json, and requires approval on a new installation', async () => {
        const f = await fixture(), name = crypto.randomUUID(), one = runtime(f, name); await one.start();
        await one.applyCode(f.invite); expect(one.profile.submitted).toBe(true); expect(one.status).toContain('Ожидаем');
        await f.admin.inboxRequests(); await one.tick(); expect(one.decision.status).toBe('granted');
        const device = one.device.keyId; one.dispose();
        const restored = runtime(f, name); await restored.start();
        expect(restored.device.keyId).toBe(device); expect(restored.decision.status).toBe('granted'); expect(restored.ownerUnlocked).toBe(false);
        const copied = runtime(f); await copied.start(); await expect(copied.applyCode(f.invite)).rejects.toThrow('уже использован');
        await f.admin.inboxRequests(); await copied.tick(); expect(copied.decision.status).not.toBe('granted');
    });
    it('does not leave a losing or revoked enrollment indefinitely in the waiting state', async () => {
        const f = await fixture(), one = runtime(f), two = runtime(f); await one.start(); await two.start();
        await one.applyCode(f.invite); await two.applyCode(f.invite); await f.admin.inboxRequests(); await two.tick();
        expect(two.status).toContain('уже использован'); expect(two.status).not.toContain('Ожидаем');
        await f.admin.change({ kind: 'revoke-member', accountId: f.p.accountId }); await one.tick();
        expect(one.status).toContain('отозван');
    });
    it('manual PAT update keeps the device, account, rights and request count', async () => {
        const f = await fixture(), r = runtime(f); await r.start(); await r.applyCode(f.invite); await f.admin.inboxRequests(); await r.tick();
        const device = r.device.keyId, writes = f.stores.requests.writes;
        const update = await f.admin.connectionUpdate(f.p.accountId, { access: 'new-user-access', requests: 'new-user-requests' }, 2);
        await r.applyCode(update); expect(r.device.keyId).toBe(device); expect(r.decision.status).toBe('granted');
        expect(f.stores.requests.writes).toBe(writes); expect(r.profile.connection!.version).toBe(2);
        await expect(r.applyCode(update)).rejects.toThrow('более новой');
        await f.admin.change({ kind: 'revoke-member', accountId: f.p.accountId }); await r.tick(); expect(r.decision.status).toBe('blocked');
    });
    it('rejects a tampered package without network calls or replacing a working profile', async () => {
        const f = await fixture(), r = runtime(f); await r.start(); await r.applyCode(f.invite);
        const before = structuredClone(r.profile.connection), forged = await signJws({ ...(inspectJws(f.invite) as any), accountId: 'attacker' }, f.user);
        const writes = f.stores.requests.writes;
        await expect(r.applyCode(forged)).rejects.toThrow(); expect(r.profile.connection).toEqual(before); expect(f.stores.requests.writes).toBe(writes);
    });
    it('password protects owner keys, and locking owner management leaves bundle access active', async () => {
        const f = await fixture(), r = runtime(f); await r.start(); await r.applyCode(f.invite); await f.admin.inboxRequests(); await r.tick();
        const password = 'a long owner passphrase';
        const box = await encryptSecret({ key: await crypto.subtle.exportKey('jwk', f.owner.privateKey), inbox: f.inbox.privateKey }, password);
        await r.restoreOwner(JSON.stringify({ v: 3, ownerBox: box }), password);
        await r.configureOwner(f.certificate, f.ownerConnection.credentials, { access: '2027-01-01', requests: null });
        expect(r.ownerService!.isOwner()).toBe(true); r.lockOwner();
        expect(r.ownerService!.isOwner()).toBe(false); expect(r.decision.status).toBe('granted');
        await expect(r.unlockOwner('wrong password')).rejects.toThrow();
        const backup = r.exportOwner(); expect(backup).not.toContain(r.device.keyId); expect(backup).not.toContain('owner-access');
        await r.unlockOwner(password); expect(r.ownerService!.isOwner()).toBe(true);
    });
    it('warns once at owner startup about distributed PATs and clears dates when replacing them', async () => {
        const f = await fixture(), name = crypto.randomUUID(), r = runtime(f, name); await r.start();
        const password = 'a long owner passphrase';
        const box = await encryptSecret({ key: await crypto.subtle.exportKey('jwk', f.owner.privateKey), inbox: f.inbox.privateKey }, password);
        await r.restoreOwner(JSON.stringify({ v: 3, ownerBox: box }), password);
        await r.configureOwner(f.certificate, f.ownerConnection.credentials, { access: null, requests: null });
        const seven = new Date(Date.now() + 7 * 86400_000).toISOString().slice(0, 10);
        await r.configureDistribution(f.credentials, 1, { access: seven, requests: null }); r.dispose();
        (Notice as any).messages = [];
        const restored = runtime(f, name); await restored.start(); await restored.tick(); await restored.tick();
        expect((Notice as any).messages).toHaveLength(1); expect((Notice as any).messages[0][0]).toContain('PAT пользователей'); expect((Notice as any).messages[0][0]).toContain('7 дней');
        await restored.unlockOwner(password);
        await restored.configureDistribution({ access: 'new-user-access', requests: 'new-user-requests' }, 2, { access: null, requests: null });
        expect(restored.profile.distribution!.expiry.access).toBeNull();
    });
    it('persists rollback protection across restart even after an authentication failure clears the cache', async () => {
        const f = await fixture(), name = crypto.randomUUID(), r = runtime(f, name); await r.start(); await r.applyCode(f.invite); await f.admin.inboxRequests(); await r.tick();
        const old = structuredClone(f.stores.access.files.get('state.jws')!);
        await f.admin.change({ kind: 'revoke-member', accountId: f.p.accountId }); await r.tick();
        f.stores.access.failure = new GitError('authentication'); await r.tick(); expect(r.profile.cache).toBeNull(); r.dispose();
        f.stores.access.failure = null;
        f.stores.access.files.set('state.jws', old);
        const restarted = runtime(f, name); await restarted.start(); expect(restarted.decision.status).toBe('blocked'); expect(restarted.service!.error).toContain('откат');
    });
    it('distinguishes an unconfirmed send from waiting for approval and retries the same request', async () => {
        const f = await fixture(); let fail = true;
        const fetcher: typeof fetch = async (url, init) => { if (fail && init?.method === 'PUT' && String(url).includes('/requests/')) return Response.json({}, { status: 403 }); return f.fetcher(url, init); };
        const r = new Runtime(plugin(), f.roots, fetcher, new LocalStore(crypto.randomUUID())); active.push(r); await r.start();
        await expect(r.applyCode(f.invite)).rejects.toThrow('Недостаточно'); expect(r.profile.submitted).toBe(false); expect(r.status).not.toContain('Ожидаем');
        const id = r.profile.outbox!.requestId; fail = false; await r.sendPending();
        expect(r.profile.outbox!.requestId).toBe(id); expect(r.status).toContain('Ожидаем'); expect(f.stores.requests.files.size).toBe(1);
    });
});

describe('PAT startup warning calendar', () => {
    const now = Date.parse('2026-10-09T23:59:59Z');
    it.each([['2026-10-17', null], ['2026-10-16', 'Через 7 дней'], ['2026-10-10', 'Через 1 день'], ['2026-10-09', 'Сегодня'], ['2026-10-08', 'уже истёк'], [null, null]] as const)('handles %s', (date, expected) => { const warning = patWarning(date, now); if (expected === null) expect(warning).toBeNull(); else expect(warning).toContain(expected); });
    it('rejects normalized invalid dates', () => { expect(() => patWarning('2026-02-30', now)).toThrow(); });
});

describe('SDK 6 bundle integration', () => {
    it('ignores product ID as entitlement and never accepts missing/foreign bundle scope', () => {
        const bridge = installBridge(q => ({ status: q.tenantId === 't' && q.bundleId === 'b' ? 'granted' : 'blocked', reason: null, validUntil: Date.now() + 1000 }), () => false); active.push(bridge);
        const a = vamGuard({ tenantId: 't', bundleId: 'b', pluginId: 'first' }), b = vamGuard({ tenantId: 't', bundleId: 'b', pluginId: 'second' }), wrong = vamGuard({ tenantId: 't', bundleId: 'other', pluginId: 'first' }), old = vamGuard({ tenantId: 't', pluginId: 'first' }); active.push(a, b, wrong, old);
        expect(a.isGranted()).toBe(true); expect(b.isGranted()).toBe(true); expect(wrong.isGranted()).toBe(false); expect(old.isGranted()).toBe(false);
        bridge.dispose(); expect(a.isGranted()).toBe(false);
    });
    it('reconnects after reload and blocks downgrade to a legacy owner gate', async () => {
        vi.useFakeTimers();
        const make = () => installBridge(() => ({ status: 'granted', reason: null, validUntil: Date.now() + 1000 }), () => true);
        const bridge = make(); active.push(bridge); const guard = vamGuard({ tenantId: 't', bundleId: 'b', pluginId: 'x', pollMs: 10 }); active.push(guard);
        expect(guard.isGranted()).toBe(true); bridge.dispose(); expect(guard.isGranted()).toBe(false);
        const next = make(); active.push(next); await vi.advanceTimersByTimeAsync(11); expect(guard.isGranted()).toBe(true);
        (globalThis as any).__VAM__ = { version: '4', getStatus: () => 'granted', getReason: () => null, subscribe: () => () => {} };
        await vi.advanceTimersByTimeAsync(11); expect(guard.isGranted()).toBe(false);
    });
});
