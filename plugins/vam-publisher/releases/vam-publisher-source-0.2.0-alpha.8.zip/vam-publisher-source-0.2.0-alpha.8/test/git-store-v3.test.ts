import { describe, expect, it, vi } from 'vitest';
import { GitStore } from '../manager/src/auth-v3/git-store';
const repo = { baseUrl: 'https://api.github.com', owner: 'org', repo: 'private' };
const file = (text = 'signed', sha = 'sha-a') => Response.json({ sha, encoding: 'base64', content: Buffer.from(text).toString('base64') });
describe('private Git transport', () => {
    it.each([[401, {}, 'authentication'], [403, {}, 'permission'], [403, { 'x-github-sso': 'required' }, 'sso'], [403, { 'x-ratelimit-remaining': '0' }, 'rate-limit'], [429, {}, 'rate-limit'], [422, {}, 'validation']] as const)('classifies HTTP %s without guessing PAT expiry', async (status, headers, kind) => {
        const fetcher = vi.fn(async () => new Response('server secret text', { status, headers }));
        await expect(new GitStore(repo, 'secret', fetcher, async () => {}).read('state.jws')).rejects.toMatchObject({ kind });
        expect(fetcher.mock.calls.length).toBe(kind === 'rate-limit' ? 3 : 1);
    });
    it('distinguishes a missing file from a hidden repository', async () => {
        const hidden = vi.fn(async () => Response.json({}, { status: 404 }));
        await expect(new GitStore(repo, 'x', hidden).read('state.jws')).rejects.toMatchObject({ kind: 'repository-unavailable' });
        const missing = vi.fn().mockResolvedValueOnce(Response.json({}, { status: 404 })).mockResolvedValueOnce(Response.json({ private: true }));
        expect(await new GitStore(repo, 'x', missing).read('state.jws')).toBeNull();
    });
    it('reconciles a committed write after a lost response without a second PUT', async () => {
        const fetcher = vi.fn().mockRejectedValueOnce(new TypeError('lost response')).mockResolvedValueOnce(file());
        await new GitStore(repo, 'secret', fetcher).write('state.jws', 'signed', 'sha-before');
        expect(fetcher).toHaveBeenCalledTimes(2);
        expect(fetcher.mock.calls[0][1].method).toBe('PUT'); expect(fetcher.mock.calls[1][1].method).toBe('GET');
        expect(JSON.parse(fetcher.mock.calls[0][1].body).sha).toBe('sha-before');
    });
    it('reports unknown write outcome and never replaces state using a freshly read SHA', async () => {
        const fetcher = vi.fn().mockRejectedValueOnce(new TypeError('timeout')).mockResolvedValueOnce(file('another state', 'new-sha'));
        await expect(new GitStore(repo, 'secret', fetcher).write('state.jws', 'signed', 'old-sha')).rejects.toMatchObject({ kind: 'unknown-write' });
        expect(fetcher.mock.calls.filter(c => c[1].method === 'PUT')).toHaveLength(1);
    });
    it('Gitea uses POST only for create and PUT with expected SHA for update', async () => {
        const fetcher = vi.fn(async () => Response.json({}, { status: 201 }));
        const git = new GitStore({ ...repo, baseUrl: 'https://gitea.example/api/v1' }, 'secret', fetcher);
        await git.write('requests/abc.jwe', 'sealed', null); await git.write('state.jws', 'signed', 'sha');
        expect(fetcher.mock.calls.map(c => (c as any)[1].method)).toEqual(['POST', 'PUT']);
    });
    it('honors Retry-After without issuing requests during the cooldown', async () => {
        const fetcher = vi.fn(async () => Response.json({}, { status: 429, headers: { 'retry-after': '120' } }));
        const git = new GitStore(repo, 'secret', fetcher, async () => {});
        await expect(git.read('state.jws')).rejects.toMatchObject({ kind: 'rate-limit' });
        await expect(git.read('state.jws')).rejects.toMatchObject({ kind: 'rate-limit' });
        expect(fetcher).toHaveBeenCalledTimes(1);
    });
    it('rejects a public repository and a paginated directory even below the GitHub cap', async () => {
        await expect(new GitStore(repo, 'secret', async () => Response.json({ private: false })).checkPrivate()).rejects.toThrow('приватным');
        const git = new GitStore(repo, 'secret', async () => Response.json([{ name: 'a.jwe' }], { headers: { link: '<https://api.github.com/next>; rel="next"' } }));
        await expect(git.listRequests()).rejects.toThrow('лимита');
    });
    it('fails explicitly for a potentially truncated requests queue', async () => {
        const git = new GitStore(repo, 'secret', async () => Response.json(Array.from({ length: 1000 }, (_, i) => ({ name: `${i}.jwe` }))));
        await expect(git.listRequests()).rejects.toThrow('лимита');
    });
});
