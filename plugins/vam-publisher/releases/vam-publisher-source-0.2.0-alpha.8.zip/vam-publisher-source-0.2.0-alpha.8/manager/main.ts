import { Plugin } from 'obsidian';
import {LocalStore} from './src/auth-v3/local';
import {bakedProfile} from './src/auth-v4/baked-profile';
import {UpdateSlots} from './src/auth-v4/update-slots';
import type {ClientBuild} from './src/auth-v4/model';
import { Runtime } from './src/auth-v4/runtime';
import type { ChannelDeps } from './src/core/channel';
import type { VaultSyncAuth } from './src/api/vault-sync-auth';

export async function startManagerCore(plugin:Plugin,profile?:ClientBuild) {
    const runtime=new Runtime(plugin,profile, {fetcher:(plugin as any).deps?.fetchImpl});
    try {await runtime.start({awaitRefresh:false});return runtime;}catch(e){runtime.dispose();throw e;}
}
/** Repository-bound v4 entry. Old local roles and publisher appointments are never authority. */
export default class ManagerPlugin extends Plugin {
    accessV4: Runtime | null = null;
    auth?: VaultSyncAuth;
    constructor(app: ConstructorParameters<typeof Plugin>[0], manifest: ConstructorParameters<typeof Plugin>[1], private deps: ChannelDeps = {}) {
        super(app, manifest);
    }
    async onload(): Promise<void> {
        const profile=bakedProfile();
        if(!profile){this.accessV4=await startManagerCore(this);return;}
        const local=new LocalStore('vam-installation-v4');
        try {
            const slots=await UpdateSlots.open(this,profile,local);
            this.accessV4=await slots.boot(this,p=>startManagerCore(p,profile));
            await this.accessV4.enableUpdates(slots);
            this.register?.(()=>{void local.close();});
        }catch(e){await local.close();throw e;}
    }
    onunload(): void { this.accessV4?.dispose(); this.accessV4 = null; }
    /** Explicit rejection for integrations still trying to select a local role. */
    applyRole(_role: 'user' | 'owner'): never {
        throw new Error('Локальная роль больше не выдаёт права. Войдите как Администратор или активируйте ключ доступа.');
    }
}
