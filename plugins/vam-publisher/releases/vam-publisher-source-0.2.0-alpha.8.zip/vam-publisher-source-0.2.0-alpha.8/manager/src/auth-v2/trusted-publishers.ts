/** Release-time trust anchors. Never load these from an invitation or data.json.
 * Run the issuer tool, review the public key, then add it here and rebuild.
 * The empty development registry deliberately grants nobody access. */
export const TRUSTED_PUBLISHERS: Readonly<Record<string, JsonWebKey>> = Object.freeze({});
