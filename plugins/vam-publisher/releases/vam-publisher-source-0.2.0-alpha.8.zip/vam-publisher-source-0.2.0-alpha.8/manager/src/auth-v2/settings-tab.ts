import { PluginSettingTab, Notice, type App, type Plugin } from 'obsidian';
import type { AccessRuntime } from './runtime';
import { verifyJoin } from './model';
import { keyId } from './crypto';

/** Trial UI: public signed requests are portable; private profiles are always encrypted. */
export class AccessSettingsTab extends PluginSettingTab {
    constructor(app: App, plugin: Plugin, private runtime: AccessRuntime) { super(app, plugin); }
    private field(parent: HTMLElement, title: string, value = '', options: { secret?: boolean; multiline?: boolean; readonly?: boolean } = {}): HTMLInputElement | HTMLTextAreaElement {
        const label = document.createElement('label');
        label.style.display = 'block'; label.style.margin = '12px 0'; label.textContent = title;
        const input = document.createElement(options.multiline ? 'textarea' : 'input');
        input.value = value; input.style.width = '100%';
        if (input instanceof HTMLInputElement) { input.type = options.secret ? 'password' : 'text'; input.autocomplete = 'off'; }
        if (input instanceof HTMLTextAreaElement) input.rows = 4;
        input.readOnly = options.readonly ?? false;
        label.append(input); parent.append(label); return input;
    }
    private text(parent: HTMLElement, text: string): void { const p = document.createElement('p'); p.textContent = text; parent.append(p); }
    private button(parent: HTMLElement, title: string, work: () => Promise<void> | void, redraw = true): void {
        const b = document.createElement('button'); b.textContent = title; b.style.margin = '4px';
        b.onclick = async () => {
            b.disabled = true;
            try { await work(); if (redraw) this.display(); }
            catch (error) { new Notice(error instanceof Error ? error.message : 'Операция не выполнена'); }
            finally { b.disabled = false; }
        };
        parent.append(b);
    }
    display(): void {
        const root = this.containerEl;
        root.empty();
        const r = this.runtime;
        this.text(root, 'Доступ v2 — пробная версия. Права подтверждаются подписью издателя и назначениями в GitHub/Gitea.');
        const phrase = this.field(root, 'Парольная фраза профиля (от 12 символов)', '', { secret: true });
        if (!r.identity) {
            this.button(root, r.hasProfile ? 'Разблокировать профиль' : 'Создать профиль устройства', async () => {
                if (r.hasProfile) await r.unlock(phrase.value); else await r.createProfile(phrase.value);
            });
            if (!r.hasProfile) {
                const backup = this.field(root, 'Зашифрованная резервная копия профиля', '', { multiline: true });
                this.button(root, 'Восстановить профиль', () => r.restoreProfile(backup.value, phrase.value));
            }
            this.text(root, 'Удаление data.json не удаляет профиль. Потеря файла access-profile-v2.json требует резервной копии либо нового назначения прав.');
            return;
        }
        phrase.parentElement?.remove();
        this.field(root, 'Отпечаток ключа устройства — сверяйте при назначении прав', r.identity.keyId, { readonly: true });
        this.button(root, 'Заблокировать профиль', () => r.lock());
        this.button(root, 'Показать зашифрованную резервную копию', async () => {
            this.field(root, 'Сохраните копию отдельно от хранилища и парольной фразы', await r.exportProfile(), { multiline: true, readonly: true });
        }, false);

        const service = r.service;
        if (r.connectionError) this.text(root, `Профиль разблокирован; подключение требует обновления: ${r.connectionError}`);
        const tenant = service?.tenant;
        if (tenant) {
            this.text(root, `Организация: ${tenant.tenantId}. ${service!.isOwner() ? 'Владелец подтверждён.' : 'Локальная роль не используется.'}`);
            this.text(root, service!.error ? `Состояние: ${service!.error}` : 'Подписи и состояние Git проверены.');
            this.button(root, 'Обновить права', () => service!.refresh());
            for (const product of tenant.products) {
                const result = service!.access({ tenantId: tenant.tenantId, productId: product, capability: 'use' });
                this.text(root, `${product}: ${result.status === 'granted' ? 'доступ разрешён' : result.reason}`);
            }
            if (service!.isOwner()) this.button(root, 'Создать authority в новом репозитории', () => service!.initialize());
        }

        const setup = document.createElement('details');
        const summary = document.createElement('summary'); summary.textContent = tenant ? 'Подключение и Git-токены' : 'Подключить организацию'; setup.append(summary); root.append(setup);
        this.text(setup, 'Вставьте подписанное назначение организации от издателя. Все три токена задаются явно для этого подключения; старые токены не переносятся. Для обычного пользователя authority и access — только чтение.');
        const certificate = this.field(setup, 'Назначение организации (tenant JWS)', '', { multiline: true });
        const authority = this.field(setup, 'Токен authority', '', { secret: true });
        const access = this.field(setup, 'Токен access', '', { secret: true });
        const requests = this.field(setup, 'Токен requests', '', { secret: true });
        this.button(setup, 'Проверить и сохранить подключение', () => r.connect({ certificate: certificate.value.trim(), credentials: { authority: authority.value.trim(), access: access.value.trim(), requests: requests.value.trim() } }));

        const tenantId = this.field(root, 'Организация для запроса', tenant?.tenantId ?? '');
        const label = this.field(root, 'Имя / описание устройства');
        const request = this.field(root, 'Подписанный запрос — передайте владельцу', '', { multiline: true, readonly: true });
        this.button(root, 'Запросить доступ к продуктам', async () => { request.value = await r.request(tenantId.value.trim(), 'member', label.value); }, false);
        this.button(root, 'Запросить административные права', async () => { request.value = await r.request(tenantId.value.trim(), 'admin', label.value); }, false);
        if (service) this.button(root, 'Отправить запрос в Git', async () => { await service.submitRequest(request.value); new Notice('Запрос отправлен. Он ожидает подтверждения администратора.'); }, false);
        if (!service || !service.isAdmin()) return;

        const management = document.createElement('details');
        const managementTitle = document.createElement('summary'); managementTitle.textContent = 'Назначение и отзыв прав'; management.append(managementTitle); root.append(management);
        this.text(management, 'Операции проверяют полномочия перед записью. Администратор пробной версии управляет всеми пользовательскими правами организации; назначать администраторов может только владелец.');
        const incoming = this.field(management, 'Запрос получателя', '', { multiline: true });
        this.button(management, 'Проверить запрос и показать получателя', async () => {
            const decoded = await verifyJoin(incoming.value.trim(), tenant!.tenantId, Date.now());
            this.text(management, `Получатель: ${decoded.label}; запрос: ${decoded.purpose}; отпечаток: ${await keyId(decoded.key)}. Сверьте отпечаток с получателем перед назначением.`);
        }, false);
        this.button(management, 'Загрузить последние запросы', async () => {
            const list = await service.requests();
            this.text(management, `Получено запросов: ${list.length} (до 100 за один просмотр). Перед подтверждением сверьте отпечаток с получателем.`);
            for (const item of list) this.button(management, `${item.request.label} / ${item.request.purpose} / ${item.subject}`, () => { incoming.value = item.code; }, false);
        }, false);
        const products = this.field(management, 'Продукты через запятую', tenant!.products.join(', '));
        const capabilities = this.field(management, 'Разрешённые действия через запятую', 'use');
        const expiry = this.field(management, 'Срок действия (ISO, UTC)', new Date(Math.min(tenant!.expiresAt, Date.now() + 30 * 86400_000)).toISOString());
        const expiresAt = () => { const value = Date.parse(expiry.value); if (!Number.isSafeInteger(value)) throw new Error('Некорректный срок действия'); return value; };
        const split = (s: string) => s.split(',').map(x => x.trim()).filter(Boolean);
        this.button(management, 'Подтвердить пользовательский доступ', () => service.grantMember(incoming.value.trim(), split(products.value), split(capabilities.value), expiresAt()));
        if (service.isOwner()) this.button(management, 'Назначить администратором', () => service.grantAdmin(incoming.value.trim(), expiresAt()));
        for (const member of service.members) {
            this.text(management, `${member.label} · ${member.subject} · ${member.products.join(', ')} · до ${new Date(member.expiresAt).toISOString()}`);
            this.button(management, 'Отозвать пользовательский доступ', () => service.revokeMember(member.subject));
        }
        if (service.isOwner()) this.button(management, 'Показать администраторов', async () => {
            for (const admin of await service.admins()) {
                this.text(management, `${admin.subject} · до ${new Date(admin.expiresAt).toISOString()}`);
                this.button(management, 'Отозвать администратора', () => service.revokeAdmin(admin.subject));
            }
        }, false);
        if (service.isOwner()) {
            const recovery = document.createElement('details');
            const title = document.createElement('summary'); title.textContent = 'Восстановление повреждённого состояния доступа'; recovery.append(title); management.append(recovery);
            this.text(recovery, 'Сброс удалит все пользовательские назначения. Ключ владельца и назначения администраторов сохранятся. Затем потребуется заново выдать пользовательские права.');
            const confirmation = this.field(recovery, `Для подтверждения введите ${tenant!.tenantId}`);
            this.button(recovery, 'Сбросить все пользовательские назначения', () => service.resetMemberAccess(confirmation.value));
        }
    }
}
