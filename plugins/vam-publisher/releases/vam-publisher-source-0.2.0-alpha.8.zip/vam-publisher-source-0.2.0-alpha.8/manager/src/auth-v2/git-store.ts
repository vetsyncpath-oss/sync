import { validateRepo, type Repo } from './model';

export class GitConflict extends Error {
    constructor() { super('Данные изменились в Git. Обновите состояние и повторите действие.'); }
}
export interface VersionedFile { sha: string; text: string }
/** Read body + SHA from the SAME Contents API response. Never retry writes with a fresh SHA. */
export class GitStore {
    private repo: Repo;
    constructor(repo: Repo, private token: string, private fetcher: typeof fetch = fetch) { this.repo = validateRepo(repo); }
    private async request(path: string, method = 'GET', body?: unknown): Promise<Response> {
        if (!/^(authority|access)\.jws$|^requests(?:\/[a-zA-Z0-9-]+\.jws)?$/.test(path)) throw new Error('Invalid authority path');
        const { baseUrl, owner, repo } = this.repo;
        const headers: Record<string, string> = { Accept: 'application/json' };
        if (this.token) headers.Authorization = `Bearer ${this.token}`;
        if (body !== undefined) headers['Content-Type'] = 'application/json';
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), 15000);
        try {
            const response = await this.fetcher(`${baseUrl}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${path}`, {
                method, headers, body: body === undefined ? undefined : JSON.stringify(body), redirect: 'error', signal: ctrl.signal,
            });
            if (response.status === 409 || response.status === 422) throw new GitConflict();
            if (!response.ok && response.status !== 404) throw new Error(`Git: HTTP ${response.status}`);
            return response;
        } finally { clearTimeout(timer); }
    }
    async read(path: string): Promise<VersionedFile | null> {
        const response = await this.request(path);
        if (response.status === 404) return null;
        const file = await response.json();
        if (!file || typeof file.sha !== 'string' || !file.sha || typeof file.content !== 'string'
            || file.encoding !== 'base64' || file.content.length > 3_000_000) throw new Error('Git returned invalid file metadata');
        const bytes = Uint8Array.from(atob(file.content.replace(/\s/g, '')), c => c.charCodeAt(0));
        return { sha: file.sha, text: new TextDecoder('utf-8', { fatal: true }).decode(bytes).trim() };
    }
    async write(path: string, text: string, expectedSha: string | null): Promise<void> {
        const bytes = new TextEncoder().encode(text);
        let binary = '';
        for (const byte of bytes) binary += String.fromCharCode(byte);
        const method = expectedSha === null && this.repo.baseUrl.endsWith('/api/v1') ? 'POST' : 'PUT';
        const response = await this.request(path, method, {
            message: `VAM v2: update ${path}`, content: btoa(binary), ...(expectedSha === null ? {} : { sha: expectedSha }),
        });
        if (response.status !== 200 && response.status !== 201) throw new Error(`Git write failed: HTTP ${response.status}`);
    }
    async listRequests(): Promise<string[]> {
        const response = await this.request('requests');
        if (response.status === 404) return [];
        const entries = await response.json();
        if (!Array.isArray(entries)) throw new Error('Invalid requests directory');
        return entries.filter(e => typeof e?.name === 'string' && /^[a-zA-Z0-9-]+\.jws$/.test(e.name)).map(e => `requests/${e.name}`);
    }
}
