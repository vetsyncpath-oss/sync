import { inspectJws, keyId, publicKey, verifyJws } from './crypto';

export interface Repo { baseUrl: string; owner: string; repo: string }
export interface TenantGrant {
    v: 2; type: 'tenant'; publisherId: string; tenantId: string; ownerKey: JsonWebKey;
    products: string[]; authority: Repo; access: Repo; requests: Repo; issuedAt: number; expiresAt: number;
}
export interface Admin { key: JsonWebKey; expiresAt: number }
export interface Authority {
    v: 2; type: 'authority'; tenantId: string; revision: number; signer: string;
    admins: Admin[]; issuedAt: number; expiresAt: number;
}
export interface Member {
    subject: string; products: string[]; capabilities: string[]; expiresAt: number; label: string;
}
export interface AccessState {
    v: 2; type: 'access'; tenantId: string; revision: number; signer: string;
    members: Member[]; issuedAt: number; expiresAt: number;
}
export interface JoinRequest {
    v: 2; type: 'join'; tenantId: string; requestId: string; key: JsonWebKey;
    purpose: 'member' | 'admin'; label: string; issuedAt: number; expiresAt: number;
}
export interface AccessQuery { tenantId: string; productId: string; capability: string }
export interface AccessDecision { status: 'granted' | 'blocked' | 'pending'; reason: string | null; validUntil: number | null }
export type TrustRoots = Readonly<Record<string, JsonWebKey>>;
export function record(value: unknown): Record<string, any> {
    if (value === null || typeof value !== 'object' || Array.isArray(value)) throw new Error('Expected object');
    return value as Record<string, any>;
}
function id(value: unknown): asserts value is string {
    if (typeof value !== 'string' || !/^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,127}$/.test(value)) throw new Error('Invalid identifier');
}
function ids(value: unknown): asserts value is string[] {
    if (!Array.isArray(value) || value.length < 1 || value.length > 100 || new Set(value).size !== value.length) throw new Error('Invalid scope');
    value.forEach(id);
}
function time(value: unknown): asserts value is number {
    if (!Number.isSafeInteger(value) || (value as number) < 0) throw new Error('Invalid timestamp');
}
function lifetime(value: Record<string, any>, now: number): void {
    time(value.issuedAt); time(value.expiresAt);
    if (value.issuedAt > now + 60_000 || value.expiresAt <= now || value.expiresAt <= value.issuedAt) throw new Error('Document expired or not yet valid');
}
function base(raw: unknown, type: string, now: number): Record<string, any> {
    const r = record(raw);
    if (r.v !== 2 || r.type !== type) throw new Error('Unexpected document type');
    id(r.tenantId); lifetime(r, now);
    return r;
}
export function validateRepo(raw: unknown): Repo {
    const r = record(raw);
    id(r.owner); id(r.repo);
    const url = new URL(r.baseUrl);
    if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash
        || !(/^\/api\/v[13]$/.test(url.pathname) || (url.hostname === 'api.github.com' && url.pathname === '/')))
        throw new Error('Expected HTTPS GitHub/Gitea API endpoint');
    return { baseUrl: url.origin + (url.pathname === '/' ? '' : url.pathname), owner: r.owner, repo: r.repo };
}
function sameRepo(a: Repo, b: Repo): boolean { return a.baseUrl.toLowerCase() === b.baseUrl.toLowerCase() && a.owner.toLowerCase() === b.owner.toLowerCase() && a.repo.toLowerCase() === b.repo.toLowerCase(); }
export async function verifyTenant(jws: string, roots: TrustRoots, now: number): Promise<TenantGrant> {
    const hint = record(inspectJws(jws));
    if (typeof hint.publisherId !== 'string' || !Object.prototype.hasOwnProperty.call(roots, hint.publisherId)) throw new Error('Unknown publisher; invitation cannot add trust roots');
    const r = base(await verifyJws(jws, roots[hint.publisherId]), 'tenant', now);
    id(r.publisherId); publicKey(r.ownerKey); ids(r.products);
    r.authority = validateRepo(r.authority); r.access = validateRepo(r.access); r.requests = validateRepo(r.requests);
    if (sameRepo(r.requests, r.authority) || sameRepo(r.requests, r.access)) throw new Error('Requests must use a separate repository');
    return r as TenantGrant;
}
export async function verifyAuthority(jws: string, tenant: TenantGrant, now: number): Promise<Authority> {
    const r = base(await verifyJws(jws, tenant.ownerKey), 'authority', now);
    if (r.tenantId !== tenant.tenantId || r.signer !== await keyId(tenant.ownerKey) || r.expiresAt > tenant.expiresAt) throw new Error('Authority context mismatch');
    if (!Number.isSafeInteger(r.revision) || r.revision < 1 || !Array.isArray(r.admins) || r.admins.length > 100) throw new Error('Invalid authority');
    if (r.admins.length && sameRepo(tenant.authority, tenant.access)) throw new Error('Delegated admins require separate authority and access repositories');
    const seen = new Set<string>();
    for (const admin of r.admins) {
        record(admin); publicKey(admin.key); time(admin.expiresAt);
        const subject = await keyId(admin.key);
        if (seen.has(subject) || subject === r.signer || admin.expiresAt > r.expiresAt) throw new Error('Invalid admin assignment');
        seen.add(subject);
    }
    return r as Authority;
}
export async function verifyAccess(jws: string, tenant: TenantGrant, authority: Authority, now: number): Promise<AccessState> {
    const hint = record(inspectJws(jws));
    let signerKey = tenant.ownerKey;
    if (hint.signer !== await keyId(signerKey)) {
        let found = false;
        for (const admin of authority.admins) {
            if (await keyId(admin.key) === hint.signer && admin.expiresAt > now) {
                signerKey = admin.key; found = true; break;
            }
        }
        if (!found) throw new Error('Access signer is not an active administrator');
    }
    const r = base(await verifyJws(jws, signerKey), 'access', now);
    if (r.tenantId !== tenant.tenantId || r.expiresAt > tenant.expiresAt
        || !Number.isSafeInteger(r.revision) || r.revision < 1 || !Array.isArray(r.members) || r.members.length > 10000) throw new Error('Invalid access state');
    const seen = new Set<string>();
    for (const member of r.members) {
        record(member); ids(member.products); ids(member.capabilities); time(member.expiresAt);
        if (!/^[A-Za-z0-9_-]{43}$/.test(member.subject) || typeof member.label !== 'string' || member.label.length > 200
            || member.products.some((p: string) => !tenant.products.includes(p)) || member.expiresAt > r.expiresAt
            || seen.has(member.subject)) throw new Error('Invalid member grant');
        seen.add(member.subject);
    }
    return r as AccessState;
}
export async function verifyJoin(jws: string, tenantId: string, now: number): Promise<JoinRequest> {
    const hint = record(inspectJws(jws));
    const r = base(await verifyJws(jws, publicKey(hint.key)), 'join', now);
    id(r.requestId);
    if (r.tenantId !== tenantId || !['member', 'admin'].includes(r.purpose) || typeof r.label !== 'string' || r.label.length > 200
        || r.expiresAt - r.issuedAt > 7 * 86400_000) throw new Error('Invalid join request');
    return r as JoinRequest;
}
