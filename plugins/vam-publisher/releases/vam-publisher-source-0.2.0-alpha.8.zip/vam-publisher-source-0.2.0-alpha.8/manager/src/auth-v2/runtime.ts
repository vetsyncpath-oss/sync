import { Plugin, Notice } from 'obsidian';
import { scopeAdapter, type DataAdapter } from '../core/store';
import { installVamBridge } from '../sdk/vam-bridge';
import { decryptSecret, encryptSecret, generateIdentity, importIdentity, signJws, type Identity } from './crypto';
import { AccessService, type Connection } from './service';
import { TRUSTED_PUBLISHERS } from './trusted-publishers';
import { type AccessQuery, type AccessDecision, type TrustRoots } from './model';
import { AccessSettingsTab } from './settings-tab';
import type { VaultSyncAuth, PublicAuthState } from '../api/vault-sync-auth';

const PROFILE = 'access-profile-v2.json';
/** Encrypted portable fallback. OS keychain integration is intentionally not assumed. */
export class AccessRuntime {
    service: AccessService | null = null;
    identity: Identity | null = null;
    hasProfile = false;
    connectionError = '';
    private connection: Connection | null = null;
    private passphrase: string | null = null;
    private adapter: DataAdapter;
    private bridge?: ReturnType<typeof installVamBridge>;
    private listeners = new Set<(state: PublicAuthState) => void>();
    private timer: ReturnType<typeof setInterval> | null = null;
    private expiryTimer: ReturnType<typeof setInterval> | null = null;
    private disposed = false;
    private epoch = 0;
    private profileBusy = false;
    private lastProbe = '';
    private probeQueue: Promise<unknown> = Promise.resolve();
    private api?: VaultSyncAuth;
    constructor(private plugin: Plugin & { auth?: VaultSyncAuth }, private roots: TrustRoots = TRUSTED_PUBLISHERS, private fetcher?: typeof fetch) {
        const dir = plugin.app.vault.configDir ?? '.obsidian';
        this.adapter = scopeAdapter(plugin.app.vault.adapter as DataAdapter, `${dir}/plugins/${plugin.manifest.id}`);
    }
    async start(): Promise<void> {
        this.hasProfile = await this.adapter.exists(PROFILE);
        if (this.disposed) return;
        this.bridge = installVamBridge(() => ({
            status: 'blocked', reason: this.disposed ? 'vam-unloaded' : 'scoped-access-required',
            auth: { role: this.service?.isOwner() ? 'owner' : this.identity ? 'user' : 'unconfigured', authenticated: false,
                gate: 'blocked', reason: 'scoped-access-required', managerVersion: this.plugin.manifest.version },
            policySignature: String(this.epoch),
        }), undefined, id => {
            const decision = this.accessForProduct(id);
            return { permission: decision.status === 'granted' ? 'allowed' : 'forbidden', source: 'channel', note: decision.reason };
        }, query => this.access(query), tenantId => this.service?.tenant.tenantId === tenantId && this.service.isOwner());
        const state = (): PublicAuthState => this.legacyState();
        this.api = {
            version: 1, getState: state,
            onChanged: cb => { this.listeners.add(cb); return () => { this.listeners.delete(cb); }; },
            prompt: () => this.openSettings(), beforeSession: async () => { await this.service?.refresh(); this.changed(); },
        };
        (globalThis as any).vaultSyncAuth = this.api;
        this.plugin.auth = this.api;
        this.plugin.addSettingTab(new AccessSettingsTab(this.plugin.app, this.plugin, this));
        this.plugin.addCommand({ id: 'vam-access-v2', name: 'Доступ: профиль и права', callback: () => this.openSettings() });
        this.plugin.addCommand({ id: 'vam-access-v2-lock', name: 'Доступ: заблокировать профиль', callback: () => this.lock() });
        this.timer = setInterval(() => { void this.service?.refresh(); }, 300_000);
        this.expiryTimer = setInterval(() => this.changed(), 10_000);
        this.changed();
    }
    openSettings(): void { this.plugin.app.setting?.open(); this.plugin.app.setting?.openTabById(this.plugin.manifest.id); }
    access(query: AccessQuery): AccessDecision {
        if (this.disposed || !this.service) return { status: 'blocked', reason: this.disposed ? 'vam-unloaded' : 'profile-locked-or-unconfigured', validUntil: null };
        return this.service.access(query);
    }
    private accessForProduct(productId: string): AccessDecision {
        return this.access({ tenantId: this.service?.tenant.tenantId ?? '', productId, capability: 'use' });
    }
    private legacyState(): PublicAuthState {
        const granted = this.accessForProduct('cloud-vault-sync').status === 'granted';
        return { status: granted ? 'ok' : 'blocked', ...(this.identity ? { userId: this.identity.keyId } : {}), ...(granted ? {} : { reason: 'channel-error' as const }) };
    }
    changed = (): void => {
        this.epoch++;
        this.bridge?.refresh();
        const state = this.legacyState();
        for (const listener of this.listeners) { try { listener({ ...state }); } catch { /* consumer isolation */ } }
        const sync = this.plugin.app.plugins?.plugins?.['cloud-vault-sync'];
        const decision = this.accessForProduct('cloud-vault-sync');
        const probe = this.disposed ? { present: false, reason: 'manager unloaded' }
            : decision.status === 'granted' ? { present: true, authOk: true } : { present: true, authOk: false, reason: decision.reason ?? 'blocked' };
        const signature = JSON.stringify(probe);
        if (typeof sync?.applyManagerProbe === 'function' && signature !== this.lastProbe) {
            this.lastProbe = signature;
            this.probeQueue = this.probeQueue.catch(() => undefined).then(() => sync.applyManagerProbe(probe)).catch(() => { this.lastProbe = ''; });
        }
    };
    private async profileOperation(work: () => Promise<void>): Promise<void> {
        if (this.disposed || this.profileBusy) throw new Error('Операция с профилем уже выполняется');
        this.profileBusy = true;
        try { await work(); } finally { this.profileBusy = false; }
    }
    private async saveProfile(identity: Identity, connection: Connection | null, passphrase: string): Promise<void> {
        const encrypted = await encryptSecret({ privateKey: await crypto.subtle.exportKey('jwk', identity.privateKey), connection }, passphrase);
        if (this.disposed) throw new Error('Manager unloaded');
        await this.adapter.write(PROFILE, JSON.stringify(encrypted));
    }
    async createProfile(passphrase: string): Promise<void> {
        await this.profileOperation(async () => {
            if (await this.adapter.exists(PROFILE)) throw new Error('Профиль уже существует. Разблокируйте его или восстановите резервную копию.');
            const identity = await generateIdentity();
            await this.saveProfile(identity, null, passphrase);
            if (this.disposed) return;
            this.identity = identity; this.passphrase = passphrase; this.hasProfile = true; this.changed();
        });
    }
    async unlock(passphrase: string): Promise<void> {
        await this.profileOperation(async () => {
            const payload = await decryptSecret(JSON.parse(await this.adapter.read(PROFILE)), passphrase) as any;
            const identity = await importIdentity(payload.privateKey);
            const connection: Connection | null = payload.connection ?? null;
            let next: AccessService | null = null;
            this.connectionError = '';
            // An expired/retired connection must not make a recoverable private key inaccessible.
            if (connection) {
                try { next = await AccessService.connect(connection, identity, this.roots, { fetcher: this.fetcher, changed: this.changed }); }
                catch (error) { this.connectionError = error instanceof Error ? error.message : 'Подключение требует обновления'; }
            }
            if (this.disposed) { next?.dispose(); return; }
            this.service?.dispose(); this.identity = identity; this.connection = connection; this.passphrase = passphrase; this.service = next;
            await next?.refresh(); this.changed();
        });
    }
    async connect(connection: Connection): Promise<void> {
        await this.profileOperation(async () => {
            if (!this.identity || !this.passphrase) throw new Error('Сначала разблокируйте профиль');
            // Validate publisher/tenant/locators before persisting or sending any credential.
            const next = await AccessService.connect(connection, this.identity, this.roots, { fetcher: this.fetcher, changed: this.changed });
            await this.saveProfile(this.identity, connection, this.passphrase);
            if (this.disposed) { next.dispose(); return; }
            this.connectionError = '';
            this.service?.dispose(); this.connection = connection; this.service = next;
            await next.refresh(); this.changed();
        });
    }
    async exportProfile(): Promise<string> { return this.adapter.read(PROFILE); }
    async restoreProfile(encrypted: string, passphrase: string): Promise<void> {
        await this.profileOperation(async () => {
            if (await this.adapter.exists(PROFILE)) throw new Error('Восстановление доступно в пустом профиле. Сначала сохраните существующий профиль отдельно.');
            const payload = await decryptSecret(JSON.parse(encrypted), passphrase) as any;
            const identity = await importIdentity(payload.privateKey);
            await this.saveProfile(identity, payload.connection ?? null, passphrase);
            this.hasProfile = true;
        });
        await this.unlock(passphrase);
    }
    async request(tenantId: string, purpose: 'member' | 'admin', label: string): Promise<string> {
        if (!this.identity) throw new Error('Профиль заблокирован');
        if (this.service && tenantId === this.service.tenant.tenantId) return this.service.createRequest(purpose, label);
        const now = Date.now();
        return signJws({ v: 2, type: 'join', tenantId, requestId: crypto.randomUUID(), key: this.identity.publicKey,
            purpose, label, issuedAt: now, expiresAt: now + 7 * 86400_000 }, this.identity);
    }
    lock(): void {
        if (this.profileBusy) { new Notice('Дождитесь окончания операции с профилем'); return; }
        this.clearIdentity(); this.changed();
    }
    private clearIdentity(): void {
        this.service?.dispose(); this.service = null; this.identity = null; this.passphrase = null; this.connection = null;
        this.connectionError = '';
    }
    dispose(): void {
        this.disposed = true;
        if (this.timer) clearInterval(this.timer);
        if (this.expiryTimer) clearInterval(this.expiryTimer);
        this.clearIdentity(); this.changed(); this.bridge?.dispose(); this.listeners.clear();
        if ((globalThis as any).vaultSyncAuth === this.api) delete (globalThis as any).vaultSyncAuth;
        this.plugin.auth = undefined;
    }
}
