/** Compact JWS (RFC 7515), ES256; all signatures are over the encoded payload. */
const utf8 = new TextEncoder();
export function encode64(bytes: Uint8Array): string {
    let s = '';
    for (const byte of bytes) s += String.fromCharCode(byte);
    return btoa(s).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}
export function decode64(value: string): Uint8Array<ArrayBuffer> {
    if (!/^[A-Za-z0-9_-]+$/.test(value)) throw new Error('Invalid base64url');
    const bytes = Uint8Array.from(atob(value.replace(/-/g, '+').replace(/_/g, '/')), c => c.charCodeAt(0));
    if (encode64(bytes) !== value) throw new Error('Non-canonical base64url');
    return bytes;
}
export function publicKey(key: JsonWebKey): JsonWebKey {
    if (!key || key.kty !== 'EC' || key.crv !== 'P-256' || typeof key.x !== 'string' || typeof key.y !== 'string'
        || decode64(key.x).length !== 32 || decode64(key.y).length !== 32) throw new Error('Expected P-256 public key');
    return { kty: 'EC', crv: 'P-256', x: key.x, y: key.y };
}
export async function keyId(key: JsonWebKey): Promise<string> {
    const p = publicKey(key);
    // RFC 7638 member order.
    return encode64(new Uint8Array(await crypto.subtle.digest('SHA-256', utf8.encode(JSON.stringify({ crv: p.crv, kty: p.kty, x: p.x, y: p.y })))));
}
export interface Identity { publicKey: JsonWebKey; privateKey: CryptoKey; keyId: string }
export async function generateIdentity(): Promise<Identity> {
    const pair = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign', 'verify']);
    const pub = publicKey(await crypto.subtle.exportKey('jwk', pair.publicKey));
    return { publicKey: pub, privateKey: pair.privateKey, keyId: await keyId(pub) };
}
export async function importIdentity(jwk: JsonWebKey): Promise<Identity> {
    if (!jwk.d) throw new Error('Private key required');
    const pub = publicKey(jwk);
    const privateKey = await crypto.subtle.importKey('jwk', { ...pub, d: jwk.d }, { name: 'ECDSA', namedCurve: 'P-256' }, true, ['sign']);
    const identity = { publicKey: pub, privateKey, keyId: await keyId(pub) };
    await verifyJws(await signJws({ challenge: crypto.randomUUID() }, identity), pub);
    return identity;
}
export async function signJws(payload: unknown, identity: Identity): Promise<string> {
    const data = `${encode64(utf8.encode(JSON.stringify({ alg: 'ES256', typ: 'vam+jws' })))}.${encode64(utf8.encode(JSON.stringify(payload)))}`;
    const signature = await crypto.subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, identity.privateKey, utf8.encode(data));
    return `${data}.${encode64(new Uint8Array(signature))}`;
}
export function inspectJws(jws: string): unknown {
    if (typeof jws !== 'string' || jws.length > 2_000_000) throw new Error('Invalid or oversized signed document');
    const parts = jws.split('.');
    if (parts.length !== 3) throw new Error('Expected compact JWS');
    const header = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(decode64(parts[0])));
    if (header.alg !== 'ES256' || header.typ !== 'vam+jws' || Object.keys(header).length !== 2) throw new Error('Unsupported JWS header');
    return JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(decode64(parts[1])));
}
export async function verifyJws(jws: string, pub: JsonWebKey): Promise<unknown> {
    const payload = inspectJws(jws);
    const parts = jws.split('.');
    const signature = decode64(parts[2]);
    if (signature.length !== 64) throw new Error('Invalid ES256 signature');
    const key = await crypto.subtle.importKey('jwk', publicKey(pub), { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify']);
    if (!await crypto.subtle.verify({ name: 'ECDSA', hash: 'SHA-256' }, key, signature, utf8.encode(`${parts[0]}.${parts[1]}`))) throw new Error('Signature verification failed');
    return payload;
}

export interface EncryptedIdentity { v: 2; salt: string; iv: string; ciphertext: string }
const ITERATIONS = 600_000;
async function wrappingKey(passphrase: string, salt: Uint8Array<ArrayBuffer>): Promise<CryptoKey> {
    const base = await crypto.subtle.importKey('raw', utf8.encode(passphrase), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations: ITERATIONS }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
}
export async function encryptIdentity(identity: Identity, passphrase: string): Promise<EncryptedIdentity> {
    return encryptSecret(await crypto.subtle.exportKey('jwk', identity.privateKey), passphrase);
}
export async function encryptSecret(value: unknown, passphrase: string): Promise<EncryptedIdentity> {
    if (passphrase.length < 12) throw new Error('Используйте парольную фразу длиной не менее 12 символов');
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const key = await wrappingKey(passphrase, salt);
    const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: utf8.encode('VAM identity v2') }, key,
        utf8.encode(JSON.stringify(value)));
    return { v: 2, salt: encode64(salt), iv: encode64(iv), ciphertext: encode64(new Uint8Array(ciphertext)) };
}
export async function decryptIdentity(raw: EncryptedIdentity, passphrase: string): Promise<Identity> {
    return importIdentity(await decryptSecret(raw, passphrase) as JsonWebKey);
}
export async function decryptSecret(raw: EncryptedIdentity, passphrase: string): Promise<unknown> {
    if (!raw || raw.v !== 2 || typeof raw.ciphertext !== 'string' || raw.ciphertext.length > 100_000) throw new Error('Invalid encrypted profile');
    const salt = decode64(raw.salt), iv = decode64(raw.iv);
    if (salt.length !== 16 || iv.length !== 12) throw new Error('Invalid encrypted identity parameters');
    const plaintext = await crypto.subtle.decrypt({ name: 'AES-GCM', iv, additionalData: utf8.encode('VAM identity v2') }, await wrappingKey(passphrase, salt), decode64(raw.ciphertext));
    return JSON.parse(new TextDecoder().decode(plaintext));
}
