import { inspectJws, keyId, signJws, type Identity } from './crypto';
import { GitStore, type VersionedFile } from './git-store';
import { verifyAccess, verifyAuthority, verifyJoin, verifyTenant, type AccessDecision, type AccessQuery, type AccessState, type Authority, type JoinRequest, type TenantGrant, type TrustRoots } from './model';

export interface Credentials { authority: string; access: string; requests: string }
export interface Connection { certificate: string; credentials: Credentials }
export interface Store {
    read(path: string): Promise<VersionedFile | null>;
    write(path: string, text: string, sha: string | null): Promise<void>;
    listRequests(): Promise<string[]>;
}
interface Snapshot { authority: Authority; access: AccessState | null; authoritySha: string; accessSha: string | null; verifiedAt: number; adminExpiresAt: number | null; signerExpiresAt: number; accessError: string | null; accessRevision: number }
const blocked = (reason: string): AccessDecision => ({ status: 'blocked', reason, validUntil: null });

/** One unlocked device identity, one tenant. No legacy password/role/cache is trusted. */
export class AccessService {
    private snapshot: Snapshot | null = null;
    private generation = 0;
    private disposed = false;
    private busy = false;
    private refreshTask: Promise<void> | null = null;
    private lastError = 'not-verified';
    private highestAuthority = 0;
    private highestAccess = 0;
    private authorityDocument: string | null = null;
    private accessDocument: string | null = null;
    private constructor(
        readonly tenant: TenantGrant,
        private identity: Identity,
        private stores: { authority: Store; access: Store; requests: Store },
        private now: () => number,
        private changed: () => void,
        private ownerId: string,
    ) {}
    static async connect(connection: Connection, identity: Identity, roots: TrustRoots, options: {
        now?: () => number; changed?: () => void; fetcher?: typeof fetch;
        stores?: { authority: Store; access: Store; requests: Store };
    } = {}): Promise<AccessService> {
        const now = options.now ?? Date.now;
        const tenant = await verifyTenant(connection.certificate, roots, now());
        const credentials = connection.credentials;
        if (!credentials || ['authority', 'access', 'requests'].some(k => typeof credentials[k as keyof Credentials] !== 'string')) throw new Error('Invalid credentials');
        const stores = options.stores ?? {
            authority: new GitStore(tenant.authority, credentials.authority, options.fetcher),
            access: new GitStore(tenant.access, credentials.access, options.fetcher),
            requests: new GitStore(tenant.requests, credentials.requests, options.fetcher),
        };
        return new AccessService(tenant, identity, stores, now, options.changed ?? (() => undefined), await keyId(tenant.ownerKey));
    }
    get subject(): string { return this.identity.keyId; }
    get error(): string { return this.lastError; }
    get members() { return structuredClone(this.snapshot?.access?.members ?? []); }
    async admins(): Promise<Array<{ subject: string; expiresAt: number }>> {
        return Promise.all((this.snapshot?.authority.admins ?? []).map(async a => ({ subject: await keyId(a.key), expiresAt: a.expiresAt })));
    }
    /** Local key possession + publisher-signed owner appointment. Bootstrap may use this before authority exists. */
    isOwner(): boolean { return !this.disposed && this.tenant.expiresAt > this.now() && this.subject === this.ownerId; }
    isAdmin(): boolean {
        if (this.isOwner()) return true;
        if (!this.current()) return false;
        return (this.snapshot!.adminExpiresAt ?? 0) > this.now();
    }
    private current(): boolean {
        return !this.disposed && this.snapshot !== null && this.tenant.expiresAt > this.now()
            && this.snapshot.authority.expiresAt > this.now() && this.now() - this.snapshot.verifiedAt <= 24 * 3600_000;
    }
    access(query: AccessQuery): AccessDecision {
        if (!query || query.tenantId !== this.tenant.tenantId || !this.tenant.products.includes(query.productId)) return blocked('scope-mismatch');
        if (!this.current()) return blocked(this.lastError || 'not-verified');
        const s = this.snapshot!;
        const state = s.access;
        if (!state || state.expiresAt <= this.now() || s.signerExpiresAt <= this.now()) return blocked('access-missing-or-expired');
        const member = state.members.find(m => m.subject === this.subject);
        if (!member || member.expiresAt <= this.now() || !member.products.includes(query.productId) || !member.capabilities.includes(query.capability)) return blocked('no-product-grant');
        return { status: 'granted', reason: null, validUntil: Math.min(this.tenant.expiresAt, s.authority.expiresAt, state.expiresAt, s.signerExpiresAt, member.expiresAt, s.verifiedAt + 24 * 3600_000) };
    }
    refresh(): Promise<void> {
        if (this.disposed) return Promise.resolve();
        if (!this.refreshTask) this.refreshTask = this.load().finally(() => { this.refreshTask = null; });
        return this.refreshTask;
    }
    private async load(): Promise<void> {
        const generation = this.generation;
        try {
            const a = await this.stores.authority.read('authority.jws');
            if (!a) throw new Error('authority-missing');
            const authority = await verifyAuthority(a.text, this.tenant, this.now());
            const b = await this.stores.access.read('access.jws');
            let access: AccessState | null = null;
            let accessError: string | null = null;
            let accessRevision = this.highestAccess;
            if (b) {
                try { access = await verifyAccess(b.text, this.tenant, authority, this.now()); }
                catch (error) { accessError = error instanceof Error ? error.message : 'Invalid access snapshot'; }
                // A counter from an invalid document can only raise the replacement revision.
                // No subject/scope/grant is ever recovered from unverified contents.
                try {
                    const hint = inspectJws(b.text) as Partial<AccessState>;
                    if (Number.isSafeInteger(hint.revision) && hint.revision! > 0 && hint.revision! < Number.MAX_SAFE_INTEGER) accessRevision = Math.max(accessRevision, hint.revision!);
                } catch { /* explicit owner reset may replace corrupt bytes */ }
            }
            let adminExpiresAt: number | null = null;
            let signerExpiresAt = this.tenant.expiresAt;
            for (const admin of authority.admins) {
                const id = await keyId(admin.key);
                if (id === this.subject) adminExpiresAt = admin.expiresAt;
                if (id === access?.signer) signerExpiresAt = admin.expiresAt;
            }
            if (authority.revision < this.highestAuthority || (authority.revision === this.highestAuthority && this.authorityDocument !== null && a.text !== this.authorityDocument)
                || (access && (access.revision < this.highestAccess || (access.revision === this.highestAccess && this.accessDocument !== null && b!.text !== this.accessDocument)))) throw new Error('State rollback detected');
            if (generation !== this.generation || this.disposed) return;
            this.highestAuthority = authority.revision; this.authorityDocument = a.text;
            if (access) { this.highestAccess = access.revision; this.accessDocument = b!.text; }
            this.snapshot = { authority, access, authoritySha: a.sha, accessSha: b?.sha ?? null, verifiedAt: this.now(), adminExpiresAt, signerExpiresAt, accessError, accessRevision };
            this.lastError = accessError ?? '';
        } catch (e) {
            if (generation !== this.generation || this.disposed) return;
            // Trial is deliberately online-first. No error creates or extends access.
            this.snapshot = null;
            this.lastError = e instanceof Error ? e.message : 'verification-failed';
        }
        this.changed();
    }
    private async operation(work: () => Promise<void>): Promise<void> {
        if (this.disposed || this.busy) throw new Error('Операция уже выполняется или профиль закрыт');
        this.busy = true;
        try { await work(); } finally { this.busy = false; await this.refresh(); }
    }
    private async freshAdmin(ownerOnly = false): Promise<Snapshot> {
        await this.refresh();
        if (this.disposed || !this.snapshot || !(ownerOnly ? this.isOwner() : await this.isAdmin())) throw new Error('Нет подтверждённых административных прав');
        if (this.snapshot.accessError && !ownerOnly) throw new Error('Некорректное состояние доступа: требуется восстановление владельцем');
        return this.snapshot;
    }
    async initialize(): Promise<void> {
        await this.operation(async () => {
            if (!this.isOwner()) throw new Error('Только назначенный издателем владелец может создать authority');
            if (await this.stores.authority.read('authority.jws')) throw new Error('Authority already exists');
            const authority: Authority = { v: 2, type: 'authority', tenantId: this.tenant.tenantId, revision: 1, signer: this.subject,
                admins: [], issuedAt: this.now(), expiresAt: this.tenant.expiresAt };
            if (this.disposed) throw new Error('Profile locked');
            await this.stores.authority.write('authority.jws', await signJws(authority, this.identity), null);
        });
    }
    async createRequest(purpose: 'member' | 'admin', label: string): Promise<string> {
        if (this.disposed || !['member', 'admin'].includes(purpose) || label.length > 200) throw new Error('Invalid request');
        const request: JoinRequest = { v: 2, type: 'join', tenantId: this.tenant.tenantId, requestId: crypto.randomUUID(),
            key: this.identity.publicKey, purpose, label, issuedAt: this.now(), expiresAt: this.now() + 7 * 86400_000 };
        return signJws(request, this.identity);
    }
    async submitRequest(jws: string): Promise<void> {
        if (this.disposed) throw new Error('Profile locked');
        const request = await verifyJoin(jws, this.tenant.tenantId, this.now());
        if (await keyId(request.key) !== this.subject) throw new Error('Request belongs to another device');
        await this.stores.requests.write(`requests/${request.requestId}.jws`, jws, null);
    }
    async requests(): Promise<Array<{ code: string; request: JoinRequest; subject: string }>> {
        await this.freshAdmin();
        const result: Array<{ code: string; request: JoinRequest; subject: string }> = [];
        for (const path of (await this.stores.requests.listRequests()).slice(0, 100)) {
            try {
                const file = await this.stores.requests.read(path);
                if (!file) continue;
                const request = await verifyJoin(file.text, this.tenant.tenantId, this.now());
                result.push({ code: file.text, request, subject: await keyId(request.key) });
            } catch { /* Untrusted, invalid requests do not break the queue. */ }
        }
        return result;
    }
    private async publishAccess(snapshot: Snapshot, members: AccessState['members']): Promise<void> {
        const expiresAt = this.tenant.expiresAt;
        const state: AccessState = { v: 2, type: 'access', tenantId: this.tenant.tenantId,
            revision: Math.max(snapshot.access?.revision ?? 0, snapshot.accessRevision, this.highestAccess) + 1, signer: this.subject, members,
            issuedAt: this.now(), expiresAt };
        const jws = await signJws(state, this.identity);
        await verifyAccess(jws, this.tenant, snapshot.authority, this.now());
        if (this.disposed) throw new Error('Profile locked');
        await this.stores.access.write('access.jws', jws, snapshot.accessSha);
    }
    async grantMember(requestCode: string, products: string[], capabilities: string[], expiresAt: number): Promise<void> {
        await this.operation(async () => {
            const s = await this.freshAdmin();
            const request = await verifyJoin(requestCode, this.tenant.tenantId, this.now());
            if (request.purpose !== 'member') throw new Error('Expected member request');
            if (expiresAt <= this.now()) throw new Error('Срок доступа уже истёк');
            const subject = await keyId(request.key);
            const members = (s.access?.members ?? []).filter(m => m.subject !== subject);
            members.push({ subject, products, capabilities, expiresAt, label: request.label });
            await this.publishAccess(s, members);
        });
    }
    async revokeMember(subject: string): Promise<void> {
        await this.operation(async () => {
            const s = await this.freshAdmin();
            await this.publishAccess(s, (s.access?.members ?? []).filter(m => m.subject !== subject));
        });
    }
    async grantAdmin(requestCode: string, expiresAt: number): Promise<void> {
        await this.operation(async () => {
            const s = await this.freshAdmin(true);
            const request = await verifyJoin(requestCode, this.tenant.tenantId, this.now());
            if (request.purpose !== 'admin' || expiresAt <= this.now()) throw new Error('Invalid admin request/expiry');
            const subject = await keyId(request.key);
            const admins: Authority['admins'] = [];
            for (const admin of s.authority.admins) if (await keyId(admin.key) !== subject) admins.push(admin);
            admins.push({ key: request.key, expiresAt });
            const next: Authority = { ...s.authority, revision: s.authority.revision + 1, issuedAt: this.now(), admins };
            const jws = await signJws(next, this.identity);
            await verifyAuthority(jws, this.tenant, this.now());
            if (this.disposed) throw new Error('Profile locked');
            await this.stores.authority.write('authority.jws', jws, s.authoritySha);
        });
    }
    async revokeAdmin(subject: string): Promise<void> {
        await this.operation(async () => {
            const s = await this.freshAdmin(true);
            // Keep existing member grants valid after removing their former signer.
            if (!s.accessError) await this.publishAccess(s, s.access?.members ?? []);
            const admins: Authority['admins'] = [];
            for (const admin of s.authority.admins) if (await keyId(admin.key) !== subject) admins.push(admin);
            const next: Authority = { ...s.authority, revision: s.authority.revision + 1, issuedAt: this.now(), admins };
            if (this.disposed) throw new Error('Profile locked');
            await this.stores.authority.write('authority.jws', await signJws(next, this.identity), s.authoritySha);
        });
    }
    /** Explicit recovery after corrupt data or an expired signer. Never salvage unverified grants. */
    async resetMemberAccess(confirmationTenantId: string): Promise<void> {
        await this.operation(async () => {
            const s = await this.freshAdmin(true);
            if (confirmationTenantId !== this.tenant.tenantId) throw new Error('Для сброса введите точный идентификатор организации');
            await this.publishAccess(s, []);
        });
    }
    dispose(): void { this.disposed = true; this.generation++; this.snapshot = null; this.changed(); }
}
