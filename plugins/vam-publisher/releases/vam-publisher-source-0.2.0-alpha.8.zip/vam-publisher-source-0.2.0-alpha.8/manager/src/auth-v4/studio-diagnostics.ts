import type { App, Plugin } from 'obsidian';

interface Consumer {
    getDispatchStatus?: (manager: Plugin) => unknown;
}
const phases: Record<string,string> = {
    idle: 'Ожидание', scan: 'Сравнение', apply: 'Применение', recover: 'Восстановление',
    done: 'Завершено', partial: 'Завершено частично', error: 'Ошибка',
};
const gates: Record<string,string> = {
    vamGranted: 'Разрешено', vamPending: 'Идёт проверка', vamDevice: 'Ожидается подтверждение устройства',
    vamBlocked: 'Заблокировано', vamLogin: 'Требуется вход', vamMissing: 'Manager недоступен',
    vamExpired: 'Срок допуска истёк', vamScope: 'Организация или бандл недоступны',
    vamOffline: 'Нет действующего подтверждения', vamProtocol: 'Несовместимый SDK',
};
const events: Record<string,string> = {
    started: 'Начато применение', completed: 'Завершено', partial: 'Завершено частично', failed: 'Ошибка применения',
};
// Only render known diagnostic fields. An incompatible plugin may return arbitrary text.
const errors = new Set(['stopped','busy','invalid','invalidConfig','overlap','readonly','cloudRecovery','incomplete','collision','referenceChanged','vamSessionChanged','failed',...Object.keys(gates)]);
function mapped(table: Record<string,string>, value: unknown) {
    return typeof value === 'string' && Object.hasOwn(table,value) ? table[value] : 'Неизвестно';
}
function moment(value: unknown) {
    if (typeof value !== 'number' || !Number.isSafeInteger(value) || value <= 0 || value > 8640000000000000) return undefined;
    return new Date(value).toLocaleString();
}
function errorLabel(value: unknown) {
    return typeof value === 'string' && errors.has(value) ? value : 'failed';
}
export function studioLines(app: App, manager: Plugin): string[] {
    const studio = (app as App & {plugins?: {plugins?: {refsync?: Consumer}}}).plugins?.plugins?.refsync;
    if (!studio) return ['Sync Studio выключен или не установлен.'];
    if (typeof studio.getDispatchStatus !== 'function') return ['Установите Sync Studio 0.8.1 или новее для отчётов.'];
    try {
        const report = studio.getDispatchStatus(manager);
        if (report === null) return ['Обмен выключен. Привязка для отчётов доступна в настройках Sync Studio.'];
        if (!report || typeof report !== 'object') return ['Сводка недоступна.'];
        const r = report as Record<string,unknown>;
        if (r.protocol !== 1 || (r.pluginId !== undefined && r.pluginId !== 'refsync')) return ['Несовместимая версия протокола отчётов.'];
        const lines = ['Допуск: ' + mapped(gates, r.access), 'Состояние: ' + mapped(phases,r.phase)];
        if (typeof r.version === 'string' && r.version.length <= 80 && /^\d+\.\d+\.\d+(?:[-+][a-zA-Z0-9.-]+)*$/.test(r.version)) lines.unshift('Sync Studio ' + r.version);
        if (typeof r.recoveryPending === 'boolean') lines.push('Требуется восстановление: ' + (r.recoveryPending ? 'да' : 'нет'));
        if (typeof r.failedProfiles === 'number' && Number.isSafeInteger(r.failedProfiles) && r.failedProfiles >= 0) lines.push('Профилей с ошибкой: ' + r.failedProfiles);
        for (const [key,title] of [['lastAttemptAt','Последняя попытка'],['lastSuccessAt','Последнее успешное применение']]) {
            const time = moment(r[key]); if (time) lines.push(title + ': ' + time);
        }
        if (r.lastErrorCode !== undefined) lines.push('Последняя ошибка: ' + errorLabel(r.lastErrorCode));
        if (Array.isArray(r.events)) {
            if (!r.events.length) lines.push('В этом сеансе ещё не было применений при включённой привязке.');
            else for (const ev of r.events.slice(-32).reverse()) {
                if (!ev || typeof ev !== 'object' || !Object.hasOwn(events,ev.code) || !moment(ev.at)) continue;
                lines.push(moment(ev.at) + ' · ' + mapped(events, ev.code) + (ev.code === 'failed' ? ' · ' + errorLabel(ev.errorCode) : ''));
            }
        }
        return lines;
    } catch { return ['Сводка временно недоступна.']; }
}

// Exchange runs only while the local settings panel is open.
export function studioPanel(root: HTMLElement, app: App, manager: Plugin) {
    const doc = root.ownerDocument, details = doc.createElement('details'), title = doc.createElement('summary');
    title.textContent = 'Диагностика Sync Studio';
    const body = doc.createElement('div'); details.append(title,body); root.append(details);
    let tick: ReturnType<typeof setInterval> | undefined;
    let previous = '';
    const refresh = () => {
        const lines = studioLines(app,manager), next = JSON.stringify(lines);
        if (previous === next) return;
        previous = next;
        body.replaceChildren(...lines.map(line => {const p=doc.createElement('p'); p.textContent=line; return p;}));
    };
    const stop = () => {clearInterval(tick); tick=undefined; previous=''; body.replaceChildren();};
    details.ontoggle = () => { stop(); if(details.open){refresh(); tick=setInterval(refresh,2000);} };
    return () => { details.ontoggle=null; stop(); };
}
