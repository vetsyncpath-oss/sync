import {verifyJws} from '../auth-v2/crypto';
import type {ClientBuild} from './model';
export type Component='refsync'|'vault-access-manager';
export const filenames=['manifest.json','styles.css','main.js'] as const;
type Asset=typeof filenames[number];
export type Files=Record<Asset,string>;
export interface Release {
    kind:'vam-release-1'; component:Component; version:string; tenant?:string; bundle?:string;
    files:Record<Asset,{sha256:string;size:number}>;
}
export interface Campaign {
    id:string; created:number; expires:number; targets:string[]; recipients:Record<string,{account:string;device:string;owner:boolean}>; component:Component; version:string;
    manifest:string; base:string; reason:string; author:string;
}
export interface Package { signature:string; files:Files }
export async function digest(bytes:Uint8Array<ArrayBuffer>) {
    return Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',bytes)),n=>n.toString(16).padStart(2,'0')).join('');
}
const semver=/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*))?$/;
export function newer(a:string,b:string) {
    const x=semver.exec(a),y=semver.exec(b);if(!x||!y)return false;
    for(let i=1;i<=3;i++){if(+x[i]!==+y[i])return BigInt(x[i])>BigInt(y[i]);}
    if(!x[4]||!y[4])return !x[4]&&!!y[4];
    const aa=x[4].split('.'),bb=y[4].split('.');
    for(let i=0;i<Math.max(aa.length,bb.length);i++){
        if(i===aa.length||i===bb.length)return i===bb.length;
        if(aa[i]===bb[i])continue;
        const n=/^\d+$/.test(aa[i]),m=/^\d+$/.test(bb[i]);
        return n&&m ? BigInt(aa[i])>BigInt(bb[i]) : n!==m ? !n : aa[i]>bb[i];
    }
    return false;
}
export function releaseBase(raw:string){
    const url=new URL(raw);
    if(url.protocol!=='https:'||url.username||url.password||url.search||url.hash)throw Error('Нужен HTTPS-адрес папки релиза');
    return url.href.replace(/\/?$/,'/');
}
export async function verifyRelease(signature:string,component:Component,build:ClientBuild){
    const key=component==='refsync'?build.studioIssuer:build.managerIssuer;
    if(!key)throw Error('Не задан доверенный ключ источника релизов');
    const rel=await verifyJws(signature,key) as Release;
    if(rel.kind!=='vam-release-1'||rel.component!==component||typeof rel.version!=='string'||rel.version.length>64||!semver.test(rel.version)||
        (component==='vault-access-manager'&&(rel.tenant!==build.tenantId||rel.bundle!==build.bundleId))||
        !rel.files||Object.keys(rel.files).length!==3)throw Error('Неверное назначение релиза');
    for(const name of filenames){const a=rel.files[name]; if(!a||!Number.isSafeInteger(a.size)||a.size<0||a.size>12_000_000||!/^[0-9a-f]{64}$/.test(a.sha256))throw Error('Некорректное описание файла');}
    return rel;
}
export async function checkPackage(pkg:Package,component:Component,build:ClientBuild) {
    const rel=await verifyRelease(pkg.signature,component,build);
    for(const name of filenames){const bytes=new TextEncoder().encode(pkg.files[name]);if(bytes.length!==rel.files[name].size||await digest(bytes)!==rel.files[name].sha256)throw Error('Файл релиза повреждён');}
    const manifest=JSON.parse(pkg.files['manifest.json']);
    if(manifest.id!==component||manifest.version!==rel.version)throw Error('Манифест не совпадает с подписанным релизом');
    return rel;
}
export async function fetchPackage(c:Campaign,build:ClientBuild,fetcher=globalThis.fetch.bind(globalThis)) {
    const rel=await verifyRelease(c.manifest,c.component,build),base=releaseBase(c.base);
    if(rel.version!==c.version)throw Error('Версия кампании изменилась');
    const files={} as Files;
    for(const name of filenames) {
        const expected=rel.files[name],response=await fetcher(new URL(name,base).href,{credentials:'omit',referrerPolicy:'no-referrer',redirect:'error',signal:AbortSignal.timeout(45000)});
        if(!response.ok||!response.body)throw Error('Файл релиза недоступен');
        const r=response.body.getReader(),bytes=new Uint8Array(expected.size);let at=0;
        try {while(true){const {value,done}=await r.read();if(done)break;if(at+value.length>expected.size)throw Error('Превышен размер файла');bytes.set(value,at);at+=value.length;}}
        finally{await r.cancel();}
        if(at!==expected.size||await digest(bytes)!==expected.sha256)throw Error('Контрольная сумма файла отличается');
        files[name]=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(bytes);
    }
    const pkg={signature:c.manifest,files};await checkPackage(pkg,c.component,build);return pkg;
}
