export const permissions = ['sync.run','sync.publish','sync.manual','sync.automatic','sync.diagnostics.share','obsidian.settings.open','obsidian.note.delete','obsidian.note.edit','obsidian.note.create','obsidian.note.rename','obsidian.folder.create','obsidian.attachment.add','obsidian.attachment.delete','obsidian.folder.delete','obsidian.note.move'] as const;
export type Permission = typeof permissions[number];
export const permissionLabels: Record<Permission,string> = {
    'sync.run':'Синхронизация разрешена', 'sync.publish':'Публикация разрешена',
    'sync.manual':'Ручной запуск', 'sync.automatic':'Автосинхронизация',
    'sync.diagnostics.share':'Передача диагностики', 'obsidian.settings.open':'Открытие настроек',
    'obsidian.note.delete':'Удаление заметок', 'obsidian.note.edit':'Редактирование заметок',
    'obsidian.note.create':'Создание заметок', 'obsidian.note.rename':'Переименование заметок',
    'obsidian.note.move':'Перемещение заметок', 'obsidian.folder.create':'Создание папок',
    'obsidian.folder.delete':'Удаление папок', 'obsidian.attachment.add':'Добавление вложений',
    'obsidian.attachment.delete':'Удаление вложений'
};
export type Rules = Partial<Record<Permission,'allow'|'deny'>>;
export interface Group { id: string; name: string; rules: Rules }
export interface Policy {
    mandatory?: Permission[];
    defaults?: Rules;
    roles?: Partial<Record<'user'|'operator',Rules>>;
    groups?: Group[];
}
export interface Assignment { accountId: string; groups?: string[]; role?: 'user'|'operator'; rules?: Rules }
export function effective(policy: Policy = {}, member: Assignment, id: Permission) {
    const decide = (allowed: boolean, source: string) => ({allowed,source});
    if (policy.mandatory?.includes(id)) return decide(false,'Обязательный запрет организации');
    if (member.rules?.[id]) return decide(member.rules[id]==='allow','Индивидуальное правило');
    const groups = (policy.groups ?? []).filter(g=>member.groups?.includes(g.id) && g.rules[id]);
    const group = groups.find(g=>g.rules[id]==='deny') ?? groups[0];
    if (group) return decide(group.rules[id]==='allow','Группа «'+group.name+'»');
    const role = member.role ?? 'user', rule = policy.roles?.[role]?.[id];
    if (rule) return decide(rule==='allow',role==='user'?'Роль пользователя':'Роль оператора');
    return decide(policy.defaults?.[id] ? policy.defaults[id]==='allow' : id!=='sync.diagnostics.share','По умолчанию в организации');
}
export function validateRules(rules: unknown): asserts rules is Rules {
    if (!rules || typeof rules !== 'object' || Array.isArray(rules) || Object.entries(rules).some(([key,v])=>!permissions.includes(key as Permission) || !['allow','deny'].includes(v))) throw Error('Некорректное правило доступа');
}
