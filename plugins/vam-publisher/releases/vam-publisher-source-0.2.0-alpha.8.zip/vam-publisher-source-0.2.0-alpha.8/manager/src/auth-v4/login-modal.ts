import { Modal, type App, type Plugin } from 'obsidian';
import type { Runtime } from './runtime';
import { SettingsTab } from './settings-tab';
/** One shared login view for startup, commands and partner-plugin prompts. */
export class LoginModal extends Modal {
    private view?: SettingsTab;
    private unsubscribe?: () => void;
    constructor(app: App, private plugin: Plugin, private runtime: Runtime, private closed: () => void, private keepOpen = false) { super(app); }
    onOpen(): void {
        this.modalEl.classList.add('vam-login-modal');
        this.view = new SettingsTab(this.app, this.plugin, this.runtime);
        this.view.containerEl = this.contentEl;
        this.view.display();
        this.unsubscribe = this.runtime.subscribe(() => { if (!this.keepOpen && this.runtime.decision.status === 'granted') this.close(); });
    }
    onClose(): void { this.unsubscribe?.(); this.view?.hide(); this.contentEl.replaceChildren(); this.closed(); }
}
