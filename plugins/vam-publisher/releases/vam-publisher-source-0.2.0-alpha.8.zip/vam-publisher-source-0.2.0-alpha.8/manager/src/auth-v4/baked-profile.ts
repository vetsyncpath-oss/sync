import { clientBuild, type ClientBuild } from './model';
// The publisher replaces this one JS string literal in the compiled manager template.
const PROFILE_JSON = '__VAM_PROFILE_V4_JSON__';
export function bakedProfile(): ClientBuild | null { return PROFILE_JSON.startsWith('__') ? null : clientBuild(JSON.parse(PROFILE_JSON)); }
