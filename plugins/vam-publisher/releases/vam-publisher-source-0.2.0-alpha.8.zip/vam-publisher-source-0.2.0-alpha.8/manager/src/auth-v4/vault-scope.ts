import type { App } from 'obsidian';
const ephemeral = new WeakMap<object, string>();
export interface VaultScope { id: string; persistent: boolean }
/** A copied data.json or a shared vault display name must never carry an authenticated session. */
export async function vaultScope(app: App): Promise<VaultScope> {
    let source = '';
    try {
        const adapter = app.vault.adapter as any;
        const raw = typeof adapter?.getBasePath === 'function' ? adapter.getBasePath() : null;
        if (typeof raw === 'string' && raw.trim()) {
            let path = raw.replace(/\\/g, '/').replace(/\/+$/, '') || '/';
            if (/^[a-z]:\//i.test(path)) path = path.toLowerCase();
            source = `path:${path}`;
        }
    } catch { /* Use Obsidian's vault identifier when the adapter does not expose a path. */ }
    if (!source && typeof app.appId === 'string' && app.appId.trim()) source = `obsidian-vault:${app.appId}`;
    const persistent = !!source;
    if (!source) {
        let id = ephemeral.get(app.vault); if (!id) { id = crypto.randomUUID(); ephemeral.set(app.vault, id); }
        source = `session-only:${id}`;
    }
    const bytes = new TextEncoder().encode(JSON.stringify([source, app.vault.configDir ?? '.obsidian']));
    const hash = await crypto.subtle.digest('SHA-256', bytes);
    return { id: Array.from(new Uint8Array(hash), b => b.toString(16).padStart(2, '0')).join(''), persistent };
}

// The marker travels with the vault. The installation registry detects a copied
// marker at another location without sharing an authenticated storage key.
export async function vaultInstance(plugin: import('obsidian').Plugin, local: import('../auth-v3/local').LocalStore, data: any) {
    const location = await vaultScope(plugin.app);
    const original = data?.vaultInstanceId;
    const uuid = typeof original === 'string' && /^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i.test(original);
    let id: string = uuid ? original : crypto.randomUUID();
    if (!location.persistent) return { id: crypto.randomUUID(), persistent: false, location };
    const claim = async (candidate: string) => {
        const key = 'vault-instance:' + candidate;
        return await local.create(key, location.id) || await local.get(key) === location.id;
    };
    if (!await claim(id)) {
        id = crypto.randomUUID();
        if (!await claim(id)) throw new Error('Не удалось зарегистрировать экземпляр хранилища');
    }
    if (id !== original) await plugin.saveData({ ...data, vaultInstanceId: id });
    return { id, persistent: true, location };
}
