import * as obsidian from 'obsidian';
import type { Plugin } from 'obsidian';
import {LocalStore} from '../auth-v3/local';
import {keyId} from '../auth-v2/crypto';
import {vaultInstance} from './vault-scope';
import {checkPackage,filenames,newer,type Campaign,type Package,type Files} from './updates';
import type {ClientBuild} from './model';
import type {Runtime} from './runtime';

type Start=(plugin:Plugin)=>Promise<Runtime>;
type Slot={id:string;version:string;expires:number};
type State={active?:Slot;previous?:Slot;pending?:Slot;trial?:Slot;failed?:string};
export class UpdateSlots {
    private checkStudioOnBoot = true;
    constructor(readonly local:LocalStore,private key:string,private build:ClientBuild){}
    static async open(plugin:Plugin,build:ClientBuild,local:LocalStore) {
        const scope=await vaultInstance(plugin,local,await plugin.loadData());
        return new UpdateSlots(local,'updates:'+scope.id+':'+build.tenantId+':'+build.bundleId+':'+await keyId(build.authority.signing),build);
    }
    private state() {return this.local.get<State>(this.key).then(s=>s ?? {});}
    async stageManager(c:Campaign,pkg:Package,current:string) {
        const release=await checkPackage(pkg,'vault-access-manager',this.build),s=await this.state();
        if(!newer(release.version,current)||s.pending && !newer(release.version,s.pending.version) && s.pending.id!==c.id)throw Error('Откат версии запрещён');
        await this.local.saveSecret(this.key+':'+c.id,pkg);
        await this.local.set(this.key,{...s,pending:{id:c.id,version:release.version,expires:c.expires}});
    }
    private async startSlot(slot:Slot,plugin:Plugin):Promise<Runtime> {
        const pkg=await this.local.secret<Package>(this.key+':'+slot.id);
        if(!pkg)throw Error('Отсутствует слот обновления');
        const rel=await checkPackage(pkg,'vault-access-manager',this.build);
        if(rel.version!==slot.version)throw Error('Версия слота отличается');
        const module:{exports:any}={exports:{}};
        // Execute only an installed, hash-checked module signed by this organization's pinned Publisher release key.
        new Function('module','exports','require',pkg.files['main.js'])(module,module.exports,(name:string)=>{
            if(name!=='obsidian')throw Error('Недопустимая зависимость Manager'); return obsidian;
        });
        if(typeof module.exports.startManagerCore!=='function')throw Error('Отсутствует точка входа обновления');
        const runtime:Runtime=await module.exports.startManagerCore(plugin,this.build);
        if(!runtime?.device || !runtime.instanceId) {runtime?.dispose?.();throw Error('Manager не открыл локальный профиль');}
        if(typeof document!=='undefined' && pkg.files['styles.css']) {
            const style=document.createElement('style');style.textContent=pkg.files['styles.css'];document.head.append(style);plugin.register(()=>style.remove());
        }
        return runtime;
    }
    async boot(plugin:Plugin,base:Start) {
        const state=await this.state(), factoryVersion=plugin.manifest.version;
        if(state.trial){state.failed=state.trial.id;if(state.active?.id===state.trial.id)state.active=state.previous;delete state.pending;delete state.trial;await this.local.set(this.key,state);}
        if(state.pending && state.pending.expires<=Date.now()){state.failed=state.pending.id;delete state.pending;await this.local.set(this.key,state);}
        const slots=[state.pending,state.active,state.previous].filter((v,i,a):v is Slot=>!!v && newer(v.version,factoryVersion) && a.findIndex(x=>x?.id===v.id)===i);
        for(const slot of slots) {
            if(slot.id===state.failed)continue;
            // A process crash before the health marker makes the next launch try the previous slot.
            state.trial=slot;await this.local.set(this.key,state);
            try {
                plugin.manifest.version=slot.version; const runtime=await this.startSlot(slot,plugin);
                if(state.active?.id!==slot.id){state.previous=state.active;state.active=slot;}
                delete state.pending;delete state.trial;await this.local.set(this.key,state);return runtime;
            }catch{plugin.manifest.version=factoryVersion;state.failed=slot.id;delete state.trial;delete state.pending;await this.local.set(this.key,state);}
        }
        return base(plugin);
    }
    async managerResult(id:string){const s=await this.state();return s.failed===id?'failed':s.active?.id===id?'applied':s.pending?.id===id?'staged':null;}
    private studioDir(plugin:Plugin){
        const root=plugin.app.vault.configDir+'/plugins/', raw=(plugin.app.plugins as any)?.manifests?.refsync?.dir ?? root+'refsync';
        if(!raw.startsWith(root)||!/^[-\w. ]+$/.test(raw.slice(root.length))||['.','..'].includes(raw.slice(root.length)))throw Error('Некорректная папка Sync Studio');
        return raw;
    }
    async installStudio(plugin:Plugin,c:Campaign,pkg:Package,guard:()=>void) {
        const release=await checkPackage(pkg,'refsync',this.build);
        const studio=(plugin.app.plugins?.plugins as any)?.refsync;
        if(!studio?.withUpdateWindow || !studio.receiveUpdateSignal?.(plugin,{protocol:1,component:'refsync',version:release.version}))return 'waiting' as const;
        const adapter=plugin.app.vault.adapter as any,dir=this.studioDir(plugin),key=this.key+':studio';
        if(await this.local.secret(key))return 'waiting' as const;
        await studio.withUpdateWindow(plugin,async()=>{
            guard();
            const before={} as Files; for(const name of filenames)before[name]=await adapter.read(dir+'/'+name);
            const manifest=JSON.parse(before['manifest.json']);
            if(manifest.id!=='refsync'||!newer(release.version,manifest.version))throw Error('Откат версии запрещён');
            const backup={before,id:c.id,version:c.version,dir,writing:true};
            await this.local.saveSecret(key,backup);
            try{
                for(const name of ['styles.css','main.js','manifest.json'] as const){guard();await adapter.write(dir+'/'+name,pkg.files[name]);}
                for(const name of filenames)if(await adapter.read(dir+'/'+name)!==pkg.files[name])throw Error('Неполная запись обновления');
                await this.local.saveSecret(key,{...backup,writing:false});
            }catch(e){for(const name of filenames)await adapter.write(dir+'/'+name,before[name]);await this.local.set(key,null);throw e;}
        });
        // These bytes take effect on the next load, while this instance is still running the old code.
        this.checkStudioOnBoot = false;
        return 'staged' as const;
    }
    // Called on the next application layout, with an independent working Manager.
    async verifyStudio(plugin:Plugin, active = () => true) {
        if (!this.checkStudioOnBoot) return;
        const key = this.key + ':studio';
        const backup = await this.local.secret<{before: Files; id: string; version: string; dir: string; writing: boolean}>(key);
        if (!backup) { this.checkStudioOnBoot = false; return; }
        const plugins = plugin.app.plugins as any;
        const dir = this.studioDir(plugin);
        if (dir !== backup.dir) throw Error('Изменилась папка Sync Studio');
        let studio = plugins?.plugins?.refsync;
        if (!backup.writing && !studio) {
            // Obsidian may start Manager first. Its layout callback can run before
            // the plugin registry contains Studio, including on a normal cold boot.
            const deadline = Date.now() + 15000;
            while (active() && !studio && Date.now() < deadline) {
                await new Promise(resolve => setTimeout(resolve, 200));
                studio = plugins?.plugins?.refsync;
            }
        }
        if (!active()) return;
        let enabled = plugins?.enabledPlugins?.has('refsync') === true;
        if (!studio && !enabled) {
            try {
                const ids = JSON.parse(await (plugin.app.vault.adapter as any).read(plugin.app.vault.configDir+'/community-plugins.json'));
                enabled = Array.isArray(ids) && ids.includes('refsync');
            } catch { /* Disabled plugins stay disabled, including on adapters without a persisted list. */ }
        }
        if (!backup.writing && !studio && !enabled) return;
        let healthy=false;
        if(!backup.writing && studio?.manifest.version===backup.version) {
            let timer:ReturnType<typeof setTimeout>|undefined;
            try{healthy=await Promise.race([Promise.resolve(studio.ready).then(()=>!!studio.gate),new Promise<false>(r=>{timer=setTimeout(()=>r(false),45000);})]);}catch{}finally{clearTimeout(timer);}
        }
        if (!active()) return;
        if(!healthy){
            await plugins.disablePlugin?.('refsync');
            for(const name of filenames)await (plugin.app.vault.adapter as any).write(dir+'/'+name,backup.before[name]);
            await plugins.loadManifests?.(); if(enabled || studio)await plugins.enablePlugin?.('refsync');
        }
        await this.local.set(key,null);this.checkStudioOnBoot=false;return {id:backup.id,status:healthy?'applied' as const:'failed' as const,at:Date.now()};
    }
}
