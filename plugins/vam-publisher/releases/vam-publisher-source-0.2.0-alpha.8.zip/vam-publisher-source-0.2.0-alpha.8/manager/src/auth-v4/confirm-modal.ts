import { Modal, type App } from 'obsidian';
/** Cancel on Escape/outside click as well as on the explicit Cancel button. */
export class ConfirmModal extends Modal {
    private confirmed = false;
    private completed = false;
    /** Defaults describe the original use (revoking access); other actions name themselves. */
    constructor(app: App, private message: string, private done: (confirmed: boolean) => void, private labels: { title?: string; action?: string; danger?: boolean } = {}) { super(app); }
    onOpen(): void {
        const title = document.createElement('h3'); title.textContent = this.labels.title ?? 'Подтвердите отзыв доступа';
        const text = document.createElement('p'); text.className = this.labels.danger === false ? 'vam-confirm' : 'vam-confirm-danger'; text.textContent = this.message;
        const actions = document.createElement('div'); actions.className = 'vam-row-actions';
        const cancel = document.createElement('button'); cancel.textContent = 'Отмена'; cancel.onclick = () => this.close();
        const confirm = document.createElement('button'); confirm.textContent = this.labels.action ?? 'Отозвать доступ'; confirm.className = this.labels.danger === false ? 'mod-cta' : 'mod-warning'; confirm.onclick = () => { this.confirmed = true; this.close(); };
        actions.append(cancel, confirm); this.contentEl.replaceChildren(title, text, actions);
    }
    onClose(): void { if (!this.completed) { this.completed = true; this.done(this.confirmed); } }
}
