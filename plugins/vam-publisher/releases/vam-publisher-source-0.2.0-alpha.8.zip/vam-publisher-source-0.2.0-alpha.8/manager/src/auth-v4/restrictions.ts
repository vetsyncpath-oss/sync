import { Notice } from 'obsidian';
import type { Restriction } from './model';

/**
 * Soft interface guards for a signed-in user (decision D1: protection from accidental actions, not a security boundary).
 *
 * Mechanism (decision D4): wrap Obsidian API methods, so that every entry point — menu, command palette, hotkey, drag and drop,
 * another plugin — meets the same guard on desktop and mobile. CSS classes on <body> only hide the matching controls.
 *
 * Known gaps, by design: direct `vault.adapter` calls, other programs changing the vault folder, disabling or deleting this plugin.
 * Each wrapper is reversible and passes calls straight through once disabled, so it never breaks a wrapper that another plugin
 * installed on top of ours afterwards.
 */
type Method = (...args: any[]) => any;
interface Spec { key: string; target: (app: any) => any; method: string; block: (args: any[]) => boolean; result: () => unknown }
interface Installed { remove(): void }

const NOTE_EXTENSIONS = ['md', 'canvas'];
/** A note is a Markdown or canvas file; any folder counts, because deleting it deletes the notes inside. Attachments stay deletable. */
export function isNoteOrFolder(entry: any): boolean {
    if (!entry || typeof entry !== 'object') return false;
    if (typeof entry.extension === 'string') return NOTE_EXTENSIONS.includes(entry.extension.toLowerCase());
    return Array.isArray(entry.children);
}
const first = (args: any[]) => isNoteOrFolder(args[0]);
const always = () => true;
const done = () => Promise.resolve();
const nothing = () => undefined;

const folder = (args:any[]) => Array.isArray(args[0]?.children);
const note = (args:any[]) => !folder(args) && first(args);
const attachment = (args:any[]) => typeof args[0]?.extension==='string' && !first(args);
const notePath = (args:any[]) => /\.(md|canvas)$/i.test(args[0]);
const parent = (p:string) => p.slice(0,p.lastIndexOf('/')+1);
function api(target:'vault'|'fileManager',method:string,block:Spec['block']):Spec {
    return {key:target+'.'+method,target:app=>app[target],method,block,result:()=>Promise.reject(Error('Действие ограничено политикой организации'))};
}
const SPECS: Record<Restriction, Spec[]> = {
    'note.create':[api('vault','create',notePath)],
    'note.edit':['modify','modifyBinary','process','append'].map(m=>api('vault',m,note)),
    'note.rename':[api('fileManager','renameFile',a=>note(a) && a[0].path.split('/').pop()!==String(a[1]).split('/').pop()),api('vault','rename',a=>note(a) && a[0].path.split('/').pop()!==String(a[1]).split('/').pop())],
    'note.move':[api('fileManager','renameFile',a=>note(a) && parent(a[0].path)!==parent(a[1])),api('vault','rename',a=>note(a) && parent(a[0].path)!==parent(a[1]))],
    'folder.create':[api('vault','createFolder',always)],
    'folder.delete':[api('vault','trash',folder),api('vault','delete',folder),api('fileManager','trashFile',folder)],
    'attachment.add':[api('vault','createBinary',a=>!notePath(a)),api('vault','create',a=>!notePath(a))],
    'attachment.delete':[api('vault','trash',attachment),api('vault','delete',attachment),api('fileManager','trashFile',attachment)],
    'note.delete': [
        { key: 'vault.trash', target: app => app.vault, method: 'trash', block: first, result: done },
        { key: 'vault.delete', target: app => app.vault, method: 'delete', block: first, result: done },
        { key: 'fileManager.trashFile', target: app => app.fileManager, method: 'trashFile', block: first, result: done },
        // Internal prompts: stop at the question instead of letting the user confirm something that will then be refused.
        { key: 'fileManager.promptForDeletion', target: app => app.fileManager, method: 'promptForDeletion', block: first, result: nothing },
        { key: 'fileManager.promptForFolderDeletion', target: app => app.fileManager, method: 'promptForFolderDeletion', block: first, result: nothing },
    ],
    'settings.open': [
        { key: 'setting.open', target: app => app.setting, method: 'open', block: always, result: nothing },
        { key: 'setting.openTabById', target: app => app.setting, method: 'openTabById', block: always, result: nothing },
    ],
};
const MESSAGES: Record<Restriction, string> = {'note.create':'Создание заметок ограничено политикой','note.edit':'Редактирование заметок ограничено политикой','note.rename':'Переименование заметок ограничено политикой','note.move':'Перемещение заметок ограничено политикой','folder.create':'Создание папок ограничено политикой','folder.delete':'Удаление папок ограничено политикой','attachment.add':'Добавление вложений ограничено политикой','attachment.delete':'Удаление вложений ограничено политикой', 'note.delete': 'Удаление заметок отключено Администратором.', 'settings.open': 'Вход в настройки отключён Администратором.' };
const BODY_CLASS: Record<Restriction, string> = {'note.create':'vam-restrict-note-create','note.edit':'vam-restrict-note-edit','note.rename':'vam-restrict-note-rename','note.move':'vam-restrict-note-move','folder.create':'vam-restrict-folder-create','folder.delete':'vam-restrict-folder-delete','attachment.add':'vam-restrict-attachment-add','attachment.delete':'vam-restrict-attachment-delete', 'note.delete': 'vam-restrict-delete', 'settings.open': 'vam-restrict-settings' };

export class UiRestrictions {
    private systemCall?: {method:string; first:unknown};
    invokeSystem<T>(method:string, args:unknown[], work:()=>T):T {
        const previous=this.systemCall; this.systemCall={method,first:args[0]};
        try{return work();}finally{this.systemCall=previous;}
    }
    private installed = new Map<string, Installed>();
    private active = new Set<Restriction>();
    private lastNotice = new Map<Restriction, number>();
    constructor(private app: any, private notify: (message: string) => void = message => { new Notice(message); }, private now: () => number = Date.now) {}
    get enabled(): Restriction[] { return [...this.active]; }
    isActive(restriction: Restriction): boolean { return this.active.has(restriction); }
    /** Idempotent: call on every state change. Installs what is newly required, retries what could not be found yet and removes the rest. */
    update(next: Restriction[]): void {
        const wanted = new Set(next);
        for (const restriction of [...this.active]) if (!wanted.has(restriction)) this.release(restriction);
        for (const restriction of wanted) { this.active.add(restriction); this.install(restriction); }
        this.classes();
    }
    dispose(): void { this.update([]); }
    private install(restriction: Restriction): void {
        for (const spec of SPECS[restriction]) {
            const id = `${restriction}:${spec.key}`; if (this.installed.has(id)) continue;
            const target = spec.target(this.app), original = target?.[spec.method];
            if (typeof original !== 'function') continue; // Absent in this Obsidian version, or not created yet: retried on the next update.
            const hadOwn = Object.prototype.hasOwnProperty.call(target, spec.method), state = { on: true }, guard = this;
            const wrapper: Method = function (this: unknown, ...args: any[]) {
                if (state.on && !(guard.systemCall?.method===spec.method && guard.systemCall.first===args[0]) && spec.block(args)) { guard.refuse(restriction); return spec.result(); }
                return original.apply(this, args);
            };
            try { target[spec.method] = wrapper; } catch { continue; }
            this.installed.set(id, { remove: () => {
                state.on = false;
                if (target[spec.method] !== wrapper) return; // Someone wrapped us later: stay as a harmless pass-through.
                try { if (hadOwn) target[spec.method] = original; else delete target[spec.method]; } catch {}
            } });
        }
    }
    private release(restriction: Restriction): void {
        this.active.delete(restriction);
        for (const [id, patch] of [...this.installed]) if (id.startsWith(restriction + ':')) { patch.remove(); this.installed.delete(id); }
    }
    private refuse(restriction: Restriction): void {
        const at = this.now(), last = this.lastNotice.get(restriction) ?? -Infinity;
        if (at - last < 3000) return; this.lastNotice.set(restriction, at);
        try { this.notify(MESSAGES[restriction]); } catch {}
    }
    private classes(): void {
        if (typeof document === 'undefined' || !document.body) return;
        for (const restriction of Object.keys(BODY_CLASS) as Restriction[]) document.body.classList.toggle(BODY_CLASS[restriction], this.active.has(restriction));
    }
}
