import type { Plugin } from 'obsidian';
import { getManagedPluginIds } from '../core/plugin-policy';
import { PluginLock } from '../core/plugin-lock';
import { sweepNeutralizedManifests, sweepQuarantine } from '../core/quarantine-sweeper';
export interface ConnectedPlugin { id: string; name: string; enabled: boolean }
export class ConnectedPlugins {
    readonly known = new Set<string>([...getManagedPluginIds(), 'cloud-vault-sync']);
    error = '';
    private restoring = false;
    constructor(private plugin: Plugin, private allowed: () => boolean, private changed: () => void) {}
    register(id: string): void { if (/^[\w.-]{1,200}$/.test(id) && id !== this.plugin.manifest.id) this.known.add(id); }
    list(): ConnectedPlugin[] {
        const api = this.plugin.app.plugins as any, manifests = api?.manifests ?? {};
        const known = new Set([...this.known].map(id => id.toLowerCase()));
        return Object.entries(manifests).filter(([id, m]: any) => id !== this.plugin.manifest.id && (known.has(id.toLowerCase()) || known.has(String(m.id).toLowerCase()))).map(([id, m]: any) => ({ id, name: m.name || m.id || id, enabled: !!api.plugins?.[id] })).sort((a, b) => a.name.localeCompare(b.name));
    }
    async enable(id: string): Promise<void> {
        if (!this.allowed()) throw new Error('Сначала войдите в профиль с действующим доступом');
        if (!this.list().some(p => p.id === id)) throw new Error('Подключённый плагин не найден');
        const api = this.plugin.app.plugins as any;
        if (typeof api?.enablePluginAndSave !== 'function') throw new Error('Включите плагин в настройках Obsidian → Сторонние плагины');
        await api.enablePluginAndSave(id);
        if (!this.allowed()) { if (typeof api.disablePlugin === 'function') await api.disablePlugin(id); throw new Error('Доступ изменился во время включения плагина'); }
        this.changed();
    }
    /** Only the old lock registry's wasEnabled entries are restored automatically. */
    async restore(): Promise<void> {
        if (this.restoring || !this.allowed()) return;
        const adapter = this.plugin.app.vault.adapter;
        if (!adapter?.exists) return;
        this.restoring = true; this.error = '';
        try {
            const api = this.plugin.app.plugins as any, configDir = this.plugin.app.vault.configDir ?? '.obsidian';
            const pluginsDir = typeof api?.getPluginFolder === 'function' ? api.getPluginFolder() : `${configDir}/plugins`;
            const deps = { adapter, configDir, pluginsDir };
            const quarantine = await sweepQuarantine(deps), manifests = await sweepNeutralizedManifests(deps);
            if (quarantine.failed.length || manifests.failed.length || quarantine.degraded || manifests.degraded || quarantine.conflicts.length) this.error = 'Часть прежних файлов плагинов не восстановлена. Проверьте карантин и конфликты файлов.';
            if ((quarantine.ran || manifests.ran) && typeof api?.loadManifests === 'function') await api.loadManifests();
            const lock = new PluginLock({ ...deps, selfPluginId: this.plugin.manifest.id });
            for (const entry of await lock.listLocked()) {
                if (!this.allowed()) break;
                this.register(entry.manifestId); this.register(entry.folder);
                if (entry.wasEnabled) {
                    const item = this.list().find(p => p.id === entry.manifestId || p.id === entry.folder);
                    if (!item) { this.error = 'Прежний заблокированный плагин не найден. Проверьте его установку.'; continue; }
                    if (!item.enabled) await this.enable(item.id);
                }
                if (this.allowed()) await lock.unlockFolder(entry.folder);
            }
        } catch { this.error = 'Не удалось восстановить прежнее состояние плагинов. Повторите восстановление в настройках менеджера.'; }
        finally { this.restoring = false; this.changed(); }
    }
}
