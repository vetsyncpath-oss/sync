import { decode64, encode64, decryptSecret, importIdentity, keyId, publicKey, signJws, verifyJws, type Identity, type EncryptedIdentity } from '../auth-v2/crypto';
import type { Document, ManagerBuild } from './model';
import { validateDocument } from './model';

const utf8 = new TextEncoder();
export interface AuthorityKit { signing: JsonWebKey; inbox: JsonWebKey }
export interface AuthorityKeys { signing: Identity; inbox: JsonWebKey }
export interface AuthorityPin { signing: JsonWebKey; inbox: JsonWebKey }
export interface SignedState {
    kind: 'vam-policy-1'; view: Document; transportDigest: string; delivery: Record<string,string>; privateState: string; wrapped: EncryptedIdentity;
}
export const passphrase = (tenant: string, password: string) => JSON.stringify(['vam-owner',tenant,password]);

export async function unlock(wrapped: EncryptedIdentity, password: string, tenant: string, pin: AuthorityPin): Promise<AuthorityKeys> {
    try {
        const kit = await decryptSecret(wrapped, passphrase(tenant,password)) as AuthorityKit;
        const signing = await importIdentity(kit.signing);
        if (signing.keyId !== await keyId(pin.signing) || await keyId(kit.inbox) !== await keyId(pin.inbox)) throw Error();
        return { signing, inbox: kit.inbox };
    } catch { throw Error('Не удалось открыть ключ владельца. Проверьте пароль и код первичной настройки.'); }
}

// A fresh ephemeral ECDH key per message; the signing key is never used for encryption.
async function aes(privateJwk: JsonWebKey | CryptoKey, peer: JsonWebKey) {
    const algorithm = {name:'ECDH',namedCurve:'P-256'};
    const privateKey = 'kty' in privateJwk ? await crypto.subtle.importKey('jwk', privateJwk, algorithm, false,['deriveKey']) : privateJwk as CryptoKey;
    const other = await crypto.subtle.importKey('jwk',publicKey(peer),algorithm,false,[]);
    return crypto.subtle.deriveKey({name:'ECDH',public:other},privateKey,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);
}
export async function seal(peer: JsonWebKey, value: unknown, context: string) {
    const pair = await crypto.subtle.generateKey({name:'ECDH',namedCurve:'P-256'},true,['deriveKey']);
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const cipher = await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:utf8.encode(context)},await aes(pair.privateKey,peer),utf8.encode(JSON.stringify(value)));
    return JSON.stringify([publicKey(await crypto.subtle.exportKey('jwk',pair.publicKey)),encode64(iv),encode64(new Uint8Array(cipher))]);
}
export async function unseal(privateKey: JsonWebKey | CryptoKey, sealed: string, context: string) {
    const [peer,iv,cipher] = JSON.parse(sealed);
    const raw = await crypto.subtle.decrypt({name:'AES-GCM',iv:decode64(iv),additionalData:utf8.encode(context)},await aes(privateKey,peer),decode64(cipher));
    return JSON.parse(new TextDecoder().decode(raw));
}
export async function credential(value: string, salt: string): Promise<string> {
    const key = await crypto.subtle.importKey('raw',utf8.encode(value),'PBKDF2',false,['deriveBits']);
    return encode64(new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:decode64(salt),iterations:600000},key,256)));
}
export async function invitationDigest(value: string) { return encode64(new Uint8Array(await crypto.subtle.digest('SHA-256',utf8.encode(value)))); }

export async function encodeState(doc: Document, keys: AuthorityKeys, wrapped: EncryptedIdentity, previous?: {view: Document; full: Document}) {
    const view = structuredClone(doc);
    view.adminPassword = '[private]';
    for (const member of view.members) {
        const prior = previous?.full.members.find(m=>m.accountId===member.accountId);
        const cached = previous?.view.members.find(m=>m.accountId===member.accountId);
        if (cached && prior?.password === member.password) member.password = cached.password;
        else {
            const salt = encode64(crypto.getRandomValues(new Uint8Array(16)));
            member.password = salt + '.' + await credential(member.password,salt);
        }
    }
    for (const invite of view.invitations) invite.secret = await invitationDigest(invite.secret);
    const delivery: Record<string,string> = {};
    const context = JSON.stringify([doc.tenantId,doc.bundleId,'transport',doc.transport.version]);
    for (const member of doc.members) {
        if (!member.active || (member.expiresAt !== null && member.expiresAt <= Date.now())) continue;
        for (const device of member.devices) if (device.inbox) delivery[device.deviceId] = await seal(device.inbox,doc.transport.token,context);
    }
    const transportDigest = await invitationDigest(doc.transport.token);
    view.transport.token = '[private]';
    const state: SignedState = {delivery,transportDigest,kind:'vam-policy-1',view,wrapped,privateState:await seal(keys.inbox,doc,'vam-private-policy')};
    return JSON.stringify({signature:await signJws(state,keys.signing)});
}
export async function decodeState(raw: unknown, build: ManagerBuild, pin: AuthorityPin): Promise<SignedState> {
    if (!raw || typeof raw !== 'object' || !('signature' in raw) || typeof raw.signature !== 'string') throw Error('Требуется подписанный реестр организации');
    const state = await verifyJws(raw.signature,pin.signing) as SignedState;
    if (state.kind !== 'vam-policy-1') throw Error('Некорректное назначение подписи');
    validateDocument(state.view,build);
    return state;
}
