import type { Plugin } from 'obsidian';
import type { Runtime } from './runtime';
import type { Query, Decision } from '../auth-v3/model';

/** Legacy callers refer to this installed, repository-bound bundle. Explicit scopes remain strict. */
export function installCompatibilityBridge(runtime: Runtime, plugin: Plugin, register: (id: string) => void) {
    const listeners = new Set<(status: string, reason: string | null) => void>();
    const authListeners = new Set<(state: any) => void>(), publicListeners = new Set<(state: any) => void>();
    let disposed = false, previous = '', refreshInFlight: Promise<void> | null = null;
    const decision = (): Decision => disposed ? { status: 'blocked', reason: 'vam-unloaded', validUntil: null } : runtime.decision;
    const administrator = (tenant?: string) => !disposed && (!tenant || tenant === runtime.build?.tenantId) && !!runtime.service?.isAdministrator();
    const auth = () => ({ role: administrator() ? 'owner' : runtime.session?.kind === 'user' ? 'user' : 'unconfigured', authenticated: decision().status === 'granted', gate: decision().status, reason: decision().reason, managerVersion: plugin.manifest.version });
    const publicState = () => ({ status: decision().status === 'granted' ? 'ok' : decision().status === 'pending' ? 'checking' : 'blocked', userId: runtime.session?.kind === 'user' ? runtime.session.accountId : undefined, checkedAt: runtime.service?.cache?.fetchedAt, reason: decision().reason });
    const safe = (cb: (...args: any[]) => void, ...args: any[]) => { try { cb(...args); } catch {} };
    const api = {
        version: '6', getStatus: () => decision().status, getReason: () => decision().reason, getAuthState: auth,
        isOwner: administrator, isAdministrator: administrator,
        access: (query: Query): Decision => { try { return disposed ? decision() : runtime.access(query); } catch { return { status: 'blocked', reason: 'invalid-scope', validUntil: null }; } },
        // Access and plugin policy are separate in the original SDK. A signed-out user is not a forbidden plugin.
        getPermission: (_id: string) => ({ permission: 'regulated', source: 'builtin', note: null }),
        register: (id: string) => { if (!disposed && typeof id === 'string' && /^[\w.-]{1,200}$/.test(id)) register(id); },
        subscribe: (cb: (status: string, reason: string | null) => void) => { listeners.add(cb); safe(cb, decision().status, decision().reason); return () => listeners.delete(cb); },
        subscribeAuth: (cb: (state: any) => void) => { authListeners.add(cb); safe(cb, auth()); return () => authListeners.delete(cb); },
    };
    const legacy = {
        version: 1 as const, getState: publicState,
        onChanged: (cb: (state: any) => void) => { publicListeners.add(cb); safe(cb, publicState()); return () => publicListeners.delete(cb); },
        prompt: () => { if (!disposed) runtime.openLogin(); },
        beforeSession: () => { if (!refreshInFlight && !disposed) refreshInFlight = runtime.tick().catch(() => {}).finally(() => { refreshInFlight = null; }); return refreshInFlight ?? Promise.resolve(); },
    };
    const host = globalThis as any;
    host.__VAM__ = api; host.vaultSyncAuth = legacy; (plugin as any).auth = legacy;
    const pending = Array.isArray(host.__VAM_PENDING__) ? host.__VAM_PENDING__.splice(0) : [];
    for (const cb of pending) safe(cb, decision().status, decision().reason);
    let syncInstance: any, syncKey = '';
    const refresh = () => {
        const signature = JSON.stringify([decision(), auth(), publicState()]);
        if (signature !== previous) {
            previous = signature;
            for (const cb of [...listeners]) safe(cb, decision().status, decision().reason);
            for (const cb of [...authListeners]) safe(cb, auth());
            for (const cb of [...publicListeners]) safe(cb, publicState());
        }
        const sync = plugin.app.plugins?.plugins?.['cloud-vault-sync'];
        const probe = { present: !disposed, authOk: decision().status === 'granted', ...(decision().reason ? { reason: decision().reason } : {}) };
        const key = JSON.stringify(probe);
        if (typeof sync?.applyManagerProbe === 'function' && (sync !== syncInstance || key !== syncKey)) {
            syncInstance = sync; syncKey = key;
            // Preserve transition order even when a plugin applies a probe asynchronously.
            probeQueue = probeQueue.then(() => sync.applyManagerProbe(probe)).catch(() => { if (syncInstance === sync && syncKey === key) syncKey = ''; });
        }
    };
    let probeQueue: Promise<unknown> = Promise.resolve();
    return { refresh, dispose: () => { disposed = true; refresh(); listeners.clear(); authListeners.clear(); publicListeners.clear(); } };
}
