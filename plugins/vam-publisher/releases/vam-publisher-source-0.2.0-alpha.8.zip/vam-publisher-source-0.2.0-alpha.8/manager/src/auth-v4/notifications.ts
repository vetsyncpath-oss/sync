import { Notice } from 'obsidian';
import type { Decision } from '../auth-v3/model';
export interface NotificationState {
    decision: Decision;
    role: 'administrator' | 'user' | null;
    requestSubmitted: boolean;
    requestFailed: boolean;
    requestRejected?: boolean;
    pending: string[];
    pluginError: string;
}
/** Notify about episodes, never about every polling attempt; all messages are static and secret-free. */
export class Notifications {
    private previous?: NotificationState;
    private seenRequests = new Set<string>();
    constructor(private show = (message: string) => { new Notice(message, 10000); }) {}
    reset(): void { this.previous = undefined; this.seenRequests.clear(); }
    update(state: NotificationState): void {
        const previous = this.previous; this.previous = structuredClone(state);
        if (previous?.decision.status === 'granted' && state.decision.status !== 'granted') {
            const reason = state.decision.reason;
            this.show(previous.role === 'administrator'
                ? 'Вход Администратора больше не подтверждён. Откройте менеджер и проверьте пароль и подключение Git.'
                : reason === 'access-revoked-or-expired' || reason === 'device-revoked'
                    ? 'Доступ к бандлу отозван или срок доступа истёк. Обратитесь к Администратору.'
                    : 'Доступ к бандлу приостановлен. Откройте менеджер; при проблеме подключения запросите код восстановления у Администратора.');
        }
        if (previous?.decision.status === 'pending' && state.decision.status === 'granted' && state.role === 'user') this.show('Устройство подтверждено. Доступ к бандлу открыт.');
        if (previous && state.requestSubmitted && !previous.requestSubmitted) this.show('Заявка устройства отправлена Администратору. Подтверждение будет получено автоматически.');
        if (state.requestRejected && !previous?.requestRejected) this.show('Администратор отклонил заявку на подключение устройства. Обратитесь к нему.');
        if (state.requestFailed && !previous?.requestFailed) this.show('Заявка устройства не отправлена. Откройте менеджер и повторите отправку.');
        if (state.role === 'administrator') {
            const fresh = state.pending.filter(id => !this.seenRequests.has(id));
            state.pending.forEach(id => this.seenRequests.add(id));
            if (fresh.length) this.show(`Новые заявки на устройства ждут вашего решения: ${fresh.length}. Откройте менеджер.`);
        }
        if (state.role === 'administrator' && state.pluginError && state.pluginError !== previous?.pluginError) this.show('Не удалось полностью восстановить подключённые плагины. Подробности — в настройках менеджера.');
    }
}
