import { verifyJws, type Identity, signJws } from '../auth-v2/crypto';
import type { Document } from './model';
import type { Store } from '../auth-v3/git-store';

const uuid = /^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;
const version = /^[0-9A-Za-z][0-9A-Za-z.-]{0,47}$/;
const issues = ['failed','busy','invalid','stopped','cloudRecovery','referenceChanged','readonly','incomplete','collision'];
export type Receipt = {id:string; status:'applied'|'waiting'|'failed'|'staged'|'expired'; at:number};
export interface Installation {
    kind:'installation-1'; tenant:string; bundle:string; instance:string; device:string; account:string; owner:boolean;
    manager:string; studio:string|null; seen:number; revision:number; transport:number;
    lastSuccess:number|null; error:string|null; receipts:Receipt[];
}
export function diagnostics(raw: any) {
    return {lastSuccess:Number.isSafeInteger(raw?.lastSuccessAt) && raw.lastSuccessAt>0 && raw.lastSuccessAt<=Date.now()+60000 ? raw.lastSuccessAt as number:null,
        error:typeof raw?.lastErrorCode === 'string' ? issues.includes(raw.lastErrorCode) ? raw.lastErrorCode as string : 'failed' : null};
}
export function cleanVersion(v: unknown) { return typeof v==='string' && version.test(v) ? v : null; }
export const installationPath = (id: string) => 'vam/installations/'+id+'.json';
export async function writeInstallation(store:Store, data:Installation, identity: Identity) {
    if (!uuid.test(data.instance)) throw Error('Неизвестная установка');
    const path=installationPath(data.instance), prior=await store.read(path);
    await store.write(path,JSON.stringify({signature:await signJws(data,identity)}),prior?.sha ?? null);
}
export async function readInstallations(store:Store, doc:Document, ownerKey:JsonWebKey) {
    const paths=await store.listInstallations?.() ?? [], result:Installation[]=[];
    // Contents requests are sequential within small batches so a large fleet does not flood the provider.
    for (let i=0;i<paths.length;i+=6) {
        const rows=await Promise.all(paths.slice(i,i+6).map(async path=>{
            const file=await store.read(path); if(!file) return;
            try {
                const signed=JSON.parse(file.text).signature;
                const {inspectJws}=await import('../auth-v2/crypto');
                const hint=inspectJws(signed) as Installation;
                const member=doc.members.find(m=>m.accountId===hint.account);
                const key=hint.owner===true && hint.account===doc.adminId ? ownerKey : member?.devices.find(d=>d.deviceId===hint.device)?.key;
                if(!key)return;
                const r=await verifyJws(signed,key) as Installation;
                if(r.kind!=='installation-1'||r.tenant!==doc.tenantId||r.bundle!==doc.bundleId||!uuid.test(r.instance)||path!==installationPath(r.instance)||typeof r.owner!=='boolean'||!cleanVersion(r.manager)||(r.studio!==null&&!cleanVersion(r.studio))||!Number.isSafeInteger(r.seen)||r.seen>Date.now()+60000||!Number.isSafeInteger(r.revision)||!Number.isSafeInteger(r.transport))return;
                if(!/^[\w-]{43}$/.test(r.device)) return;
                // Whitelist fields even for signatures from enrolled devices.
                return {kind:r.kind,tenant:doc.tenantId,bundle:doc.bundleId,instance:r.instance,device:r.device,account:r.account,owner:r.owner,manager:r.manager,studio:r.studio,seen:r.seen,revision:r.revision,transport:r.transport,
                  ...diagnostics({lastSuccessAt:r.lastSuccess,lastErrorCode:r.error}),receipts:(Array.isArray(r.receipts)?r.receipts:[]).slice(-32).filter(x=>x && uuid.test(x.id) && ['applied','waiting','failed','staged','expired'].includes(x.status) && Number.isSafeInteger(x.at)).map(x=>({id:x.id,status:x.status,at:x.at}))};
            } catch {return;}
        }));
        for(const row of rows)if(row)result.push(row);
    }
    return result;
}
