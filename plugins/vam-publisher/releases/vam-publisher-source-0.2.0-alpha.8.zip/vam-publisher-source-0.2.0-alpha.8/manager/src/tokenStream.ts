import type { Filters, SectionEntry, SectionIndex, Token, TokenSource } from "./types";
import { isLetterCode, pivotIndex } from "./pivot";

/**
 * Фаза B: ленивая токенизация читаемых зон в поток токенов RSVP-движка.
 *
 * Память: токены хранятся массивами офсетов (starts/ends/…), слова
 * материализуются (и кэшируются) при первом get(i). Чистка инлайн-markdown
 * выполняется построчно внутри читаемых интервалов; все офсеты токенов —
 * индексы ИСХОДНОГО текста (как и в фазе A).
 *
 * Доготовка: pumpAhead разбирает текст юнитами (юнит = раздел фазы A;
 * зона до первого заголовка — свой юнит, «секция» без заголовков обходится
 * порциями ≥500 слов) кооперативными порциями ≤14 мс с await yieldFn().
 *
 * Отклонения/решения (полный список — в worklog):
 *  - заголовки фазы A токенизуются (маркер `##` срезается): totalReadableChars
 *    фазы A считает текст заголовка читаемым, а маркер — шумом;
 *  - текст до первого заголовка получает sectionIdx = −1 (нет раздела с
 *    charStart ≤ позиции); getSection(−1) бросает RangeError;
 *  - при seek вперёд синхронно добирается и пропуск до раздела: токены
 *    добавляются строго в порядке документа, фон разбирает остаток;
 *  - изолированные инлайн-конструкции не найдя пары деградируют в литерал
 *    («$5 без пары» не формула); инлайн-`$…$` дополнительно требует, чтобы
 *    содержимое не начиналось/кончалось пробелом (иначе «5$ и 10$»
 *    съедало бы текст между долларами).
 */

/* ── коды символов ── */
const CH_TAB = 0x09;
const CH_CR = 0x0d;
const CH_SPACE = 0x20;
const CH_BANG = 0x21; // !
const CH_HASH = 0x23; // #
const CH_DOLLAR = 0x24; // $
const CH_LPAREN = 0x28; // (
const CH_RPAREN = 0x29; // )
const CH_STAR = 0x2a; // *
const CH_PLUS = 0x2b; // +
const CH_COMMA = 0x2c; // ,
const CH_HYPHEN = 0x2d; // -
const CH_DOT = 0x2e; // .
const CH_SLASH = 0x2f; // /
const CH_COLON = 0x3a; // :
const CH_SEMI = 0x3b; // ;
const CH_LT = 0x3c; // <
const CH_EQ = 0x3d; // =
const CH_GT = 0x3e; // >
const CH_QUESTION = 0x3f; // ?
const CH_LBRACKET = 0x5b; // [
const CH_BACKSLASH = 0x5c; // \
const CH_RBRACKET = 0x5d; // ]
const CH_CARET = 0x5e; // ^
const CH_UNDERSCORE = 0x5f; // _
const CH_BACKTICK = 0x60; // `
const CH_PIPE = 0x7c; // |
const CH_TILDE = 0x7e; // ~
const CH_QUOTE_OPEN1 = 0x00ab; // «
const CH_QUOTE_CLOSE1 = 0x00bb; // »
const CH_QUOTE_OPEN2 = 0x201c; // “
const CH_QUOTE_CLOSE2 = 0x201d; // ”
const CH_QUOTE_OPEN3 = 0x2018; // ‘
const CH_QUOTE_CLOSE3 = 0x2019; // ’
const NBSP = 0x00a0;
const NNBSP = 0x202f; // узкий неразрывный пробел
const ELLIPSIS = 0x2026; // …
const EM_DASH = 0x2014; // —
const EN_DASH = 0x2013; // –

/** Порция фоновой доготовки: не дольше 14 мс. */
const PORTION_MS = 14;
/** …и не меньше 500 токенов (для гигантских зон без заголовков). */
const PORTION_TOKENS = 500;

/** Краевые кавычки, срезаемые из текста токена. */
function isQuoteEdge(code: number): boolean {
  return (
    code === CH_QUOTE_OPEN1 || code === CH_QUOTE_CLOSE1 ||
    code === CH_QUOTE_OPEN2 || code === CH_QUOTE_CLOSE2 ||
    code === CH_QUOTE_OPEN3 || code === CH_QUOTE_CLOSE3
  );
}

function isDigitCode(code: number): boolean {
  return code >= 0x30 && code <= 0x39;
}

/** Пробелы-разделители слов (обычный, таб, \r, nbsp, узкий nbsp). */
function isWsCode(code: number): boolean {
  return code === CH_SPACE || code === CH_TAB || code === CH_CR || code === NBSP || code === NNBSP;
}

/** Разделители числовых групп «12 345»: пробел/nbsp/узкий nbsp. */
function isMergeGapCode(code: number): boolean {
  return code === CH_SPACE || code === NBSP || code === NNBSP;
}

const NBSP_RE = /[\u00a0\u202f]/g;

/** Срез краевых кавычек « » “ ” ‘ ’. */
function trimEdgeQuotes(s: string): string {
  let a = 0;
  let b = s.length;
  while (a < b && isQuoteEdge(s.charCodeAt(a))) a++;
  while (b > a && isQuoteEdge(s.charCodeAt(b - 1))) b--;
  return a === 0 && b === s.length ? s : s.slice(a, b);
}

/**
 * Множитель экспозиции — МАКСИМУМ применимых (не перемножаются):
 * хвост [.!?…] → 2; хвост [,;:] → 1.5; цифры без букв → 1.6;
 * буквы-дефис-буквы → 1.2; одиночное — / – → 2.
 */
function computeFactor(t: string): number {
  const n = t.length;
  if (n === 0) return 1;
  if (n === 1) {
    const c = t.charCodeAt(0);
    if (c === EM_DASH || c === EN_DASH) return 2;
  }
  let f = 1;
  const last = t.charCodeAt(n - 1);
  if (last === CH_DOT || last === CH_BANG || last === CH_QUESTION || last === ELLIPSIS) f = 2;
  else if (last === CH_COMMA || last === CH_SEMI || last === CH_COLON) f = 1.5;
  let hasDigit = false;
  let hasLetter = false;
  let hyphenWord = false;
  let prevLetter = false;
  for (let i = 0; i < n; i++) {
    const c = t.charCodeAt(i);
    const letter = isLetterCode(c);
    if (letter) hasLetter = true;
    else if (isDigitCode(c)) hasDigit = true;
    if (c === CH_HYPHEN && prevLetter && i + 1 < n && isLetterCode(t.charCodeAt(i + 1))) {
      hyphenWord = true;
    }
    prevLetter = letter;
  }
  if (hasDigit && !hasLetter && f < 1.6) f = 1.6;
  if (hyphenWord && f < 1.2) f = 1.2;
  return f;
}

/** Служебные слова для чанкинга (В9-2). */
const FUNCTION_WORDS: ReadonlySet<string> = new Set([
  "в", "на", "с", "к", "у", "о", "и", "а", "но", "не", "ли", "же", "бы",
  "из", "от", "до", "по", "за", "для", "при", "что", "как", "это", "так",
  "то", "мы", "вы", "он", "она", "они",
]);

/** Очищенное от пунктуации слово (буквы, нижний регистр). */
function stripToLetters(s: string): string {
  let out = "";
  for (let i = 0; i < s.length; i++) {
    if (isLetterCode(s.charCodeAt(i))) out += s[i];
  }
  return out.toLowerCase();
}

/* ── локальные типы ── */

interface ReadInterval {
  from: number;
  to: number;
}

interface Unit {
  from: number;
  to: number;
  sectionIdx: number;
}

/** Фрагмент чистки: text = исходник.slice(ts, te) (замены всегда сырые подстроки). */
interface Fragment {
  ts: number;
  te: number;
}

/** Слово до числового слияния: text задан только для «склеек из чистки». */
interface Word {
  start: number;
  end: number;
  text?: string;
}

type LineKind = "blank" | "noise" | "heading" | "quote" | "plain" | "eoi";

/* ═══════════════════════ TokenStream ═══════════════════════ */

export class TokenStream implements TokenSource {
  private readonly text: string;
  private readonly index: SectionIndex;
  private readonly filters: Filters;
  private readonly yieldFn: () => Promise<void>;

  /** Читаемые интервалы (текст − skip-зоны), упорядочены и не пересекаются. */
  private readonly intervals: ReadInterval[];
  /** Юниты разбора: по разделам; до первого заголовка — юнит с sectionIdx −1. */
  private readonly units: Unit[];
  /** Число юнитов перед первым разделом (0 или 1). */
  private readonly preUnits: number;
  private readonly unitIv0: number[];
  private readonly unitParsed: boolean[];
  private parsedUnitCount = 0;

  /** Офсеты токенов (материализация — в get). */
  private readonly starts: number[] = [];
  private readonly ends: number[] = [];
  private readonly secs: number[] = [];
  private readonly flags: number[] = []; // 1 = isParaEnd
  private readonly cums: number[] = []; // charsBefore
  private charsTotal = 0;
  /** Текст «склеек из чистки» и числовых групп (≠ сырой срез). */
  private readonly complexText = new Map<number, string>();
  private readonly cache: (Token | undefined)[] = [];

  private _length = -1;
  private pumpUnit = 0;
  private pumpChar = 0;
  private pumpGen = 0;
  private curSectionIdx = -1;

  /** Скретч-буферы разбора строки (переиспользуются). */
  private readonly frags: Fragment[] = [];
  private readonly words: Word[] = [];

  constructor(
    text: string,
    index: SectionIndex,
    filters: Filters,
    /** Инжектируется тестами; прод-дефолт — setTimeout(0). */
    yieldFn: () => Promise<void> = (): Promise<void> =>
      new Promise<void>((resolve) => {
        setTimeout(resolve, 0);
      }),
  ) {
    this.text = text;
    this.index = index;
    this.filters = filters;
    this.yieldFn = yieldFn;

    const n = text.length;

    // Читаемые интервалы: весь текст минус skip-зоны с mode === "skip".
    // mode "read" читается как текст; TODO (этап 3): mode "pause" —
    // показывать блок целиком с отдельным фактором паузы.
    const skips = index.skips
      .filter((s) => s.mode === "skip")
      .sort((a, b) => a.from - b.from);
    const intervals: ReadInterval[] = [];
    let pos = 0;
    for (const sk of skips) {
      const from = Math.max(0, sk.from);
      const to = Math.min(n, sk.to);
      if (to <= from) continue;
      if (from > pos) intervals.push({ from: pos, to: from });
      if (to > pos) pos = to;
    }
    if (pos < n) intervals.push({ from: pos, to: n });
    this.intervals = intervals;

    // Юниты: границы — начала разделов (charStart строго возрастают).
    const units: Unit[] = [];
    const sections = index.sections;
    if (sections.length === 0) {
      if (n > 0) units.push({ from: 0, to: n, sectionIdx: -1 });
    } else {
      if (sections[0].charStart > 0) units.push({ from: 0, to: sections[0].charStart, sectionIdx: -1 });
      for (let k = 0; k < sections.length; k++) {
        const from = sections[k].charStart;
        const to = k + 1 < sections.length ? sections[k + 1].charStart : n;
        units.push({ from, to, sectionIdx: k });
      }
    }
    this.units = units;
    this.preUnits = units.length > 0 && units[0].sectionIdx === -1 ? 1 : 0;
    this.unitParsed = units.map(() => false);

    // Первый пересекающийся интервал для каждого юнита (два указателя).
    const iv0 = units.map(() => 0);
    let p = 0;
    for (let u = 0; u < units.length; u++) {
      while (p < this.intervals.length && this.intervals[p].to <= units[u].from) p++;
      iv0[u] = p;
    }
    this.unitIv0 = iv0;
    this.pumpChar = this.units.length > 0 ? this.units[0].from : 0;

    this._length = units.length === 0 ? 0 : -1;
  }

  /* ── контракт TokenSource ── */

  get length(): number {
    return this._length;
  }

  get totalReadableChars(): number {
    return this.index.totalReadableChars;
  }

  /** Последний готовый индекс (−1, пока ничего не разобрано). */
  get maxReadyIndex(): number {
    return this.starts.length - 1;
  }

  isReady(i: number): boolean {
    return i >= 0 && i < this.starts.length;
  }

  /** Материализация токена: pivot/factor на лету, результат кэшируется. */
  get(i: number): Token {
    if (i < 0 || i >= this.starts.length) {
      throw new Error(`TokenStream.get: токен ${i} не готов (готово: ${this.starts.length})`);
    }
    const cached = this.cache[i];
    if (cached !== undefined) return cached;
    const start = this.starts[i];
    const end = this.ends[i];
    const override = this.complexText.get(i);
    const raw = override !== undefined ? override : this.text.slice(start, end);
    const text = trimEdgeQuotes(raw);
    const token: Token = {
      text,
      pivot: pivotIndex(text),
      factor: computeFactor(text),
      isParaEnd: this.flags[i] === 1,
      sectionIdx: this.secs[i],
      charStart: start,
      charEnd: end,
      // chunkId/isChunkTail — не задаём: раскладкой займётся рендер.
    };
    this.cache[i] = token;
    return token;
  }

  /** Прогресс: читаемые символы (сумма спанов) до токена i. */
  charsBefore(i: number): number {
    if (i <= 0) return 0;
    if (i >= this.cums.length) return this.charsTotal;
    return this.cums[i];
  }

  getSection(idx: number): SectionEntry {
    const sections = this.index.sections;
    if (idx < 0 || idx >= sections.length) {
      throw new RangeError(`TokenStream.getSection: нет раздела ${idx}`);
    }
    return sections[idx];
  }

  /**
   * Чанкинг (В9-2): при wpm > 500 склеивает пару «служебное + короткое»
   * слово в один показ. Инвариант для движка: результат ≠ token.text и
   * содержит пробел → показ пары, потребление 2 токенов.
   */
  getChunk(i: number, wpm: number): string {
    const cur = this.get(i);
    if (wpm <= 500) return cur.text;
    const bare = stripToLetters(cur.text);
    if (FUNCTION_WORDS.has(bare)) {
      const nextIdx = i + 1;
      if (nextIdx < this.starts.length) {
        const next = this.get(nextIdx);
        if (
          !cur.isParaEnd &&
          !next.isParaEnd &&
          next.sectionIdx === cur.sectionIdx &&
          next.text.length <= 4
        ) {
          return cur.text + " " + next.text;
        }
      }
    }
    return cur.text;
  }

  /**
   * Синхронный разбор раздела + перезапуск фоновой доготовки от него.
   * Синхронная часть (валидация, разбор пропуска и самого раздела,
   * первая порция) выполняется сразу при вызове — до первого await,
   * поэтому раздел готов к get() ещё до await возвращённого промиса.
   */
  async seek(sectionIdx: number): Promise<void> {
    await this.pumpAhead(sectionIdx);
  }

  /* ── фоновая доготовка ── */

  /**
   * Кооперативная доготовка порциями ≤14 мс / ≥500 токенов.
   * fromSectionIdx — разобрать раздел (и пропуск до него) синхронно
   * и продолжить фон с фронтира разбора.
   */
  async pumpAhead(fromSectionIdx?: number): Promise<void> {
    if (fromSectionIdx !== undefined) {
      const sections = this.index.sections;
      if (fromSectionIdx < 0 || fromSectionIdx >= sections.length) {
        throw new RangeError(`TokenStream.pumpAhead: нет раздела ${fromSectionIdx}`);
      }
      this.syncParseUpTo(fromSectionIdx + this.preUnits);
    }
    if (this.units.length === 0) return;
    const gen = ++this.pumpGen;
    for (;;) {
      this.skipParsedUnits();
      if (this.pumpUnit >= this.units.length) return;
      const t0 = performance.now();
      const limit = this.starts.length + PORTION_TOKENS;
      for (;;) {
        this.skipParsedUnits();
        if (this.pumpUnit >= this.units.length) break;
        const complete = this.parseUnitFrom(this.pumpUnit, this.pumpChar, limit);
        if (gen !== this.pumpGen) return; // перезапущен более новым вызовом
        if (!complete) break; // лимит порции внутри юнита
        if (this.pumpUnit >= this.units.length) break;
        if (this.starts.length >= limit) break;
        if (performance.now() - t0 >= PORTION_MS) break;
      }
      this.skipParsedUnits();
      if (this.pumpUnit >= this.units.length) return;
      await this.yieldFn();
      if (gen !== this.pumpGen) return;
    }
  }

  /** Первый неразобранный юнит (−1 — всё готово); неразобранные — суффикс. */
  private firstUnparsedUnit(): number {
    for (let v = 0; v < this.units.length; v++) {
      if (!this.unitParsed[v]) return v;
    }
    return -1;
  }

  /**
   * Синхронно добрать юниты от первого неразобранного до u включительно.
   * Инвариант порядка: токены добавляются только в порядке документа,
   * поэтому пропуск до раздела разбирается здесь же (насос честно
   * доигрывает остаток в фоне, и length финализируется).
   */
  private syncParseUpTo(u: number): void {
    for (;;) {
      const v = this.firstUnparsedUnit();
      if (v === -1 || v > u) return;
      const from =
        v === this.pumpUnit && this.pumpChar > this.units[v].from
          ? this.pumpChar
          : this.units[v].from;
      this.parseUnitFrom(v, from, -1);
    }
  }

  private skipParsedUnits(): void {
    while (this.pumpUnit < this.units.length && this.unitParsed[this.pumpUnit]) {
      this.pumpUnit++;
      this.pumpChar =
        this.pumpUnit < this.units.length ? this.units[this.pumpUnit].from : this.text.length;
    }
  }

  /* ── разбор ── */

  /**
   * Разбор юнита u с позиции from до unit.to.
   * tokenLimit ≥ 0 — остановиться ПОСЛЕ строки, где число токенов достигло
   * лимита (порция доготовки); −1 — целиком (seek).
   * Возвращает true, если юнит разобран полностью; курсор обновляет сам.
   */
  private parseUnitFrom(u: number, from: number, tokenLimit: number): boolean {
    const unit = this.units[u];
    const to = unit.to;
    this.curSectionIdx = unit.sectionIdx;
    let pos = from;
    let complete = true;
    for (let p = this.unitIv0[u]; p < this.intervals.length; p++) {
      const iv = this.intervals[p];
      if (iv.from >= to) break;
      const a = iv.from > from ? iv.from : from;
      const b = iv.to < to ? iv.to : to;
      if (b <= a) continue;
      let lineStart = a;
      while (lineStart < b) {
        let nl = this.text.indexOf("\n", lineStart);
        if (nl === -1 || nl >= b) nl = b;
        const kind = this.classifyLine(lineStart, nl);
        if (kind !== "blank" && kind !== "noise") {
          const nextKind: LineKind =
            nl < b
              ? this.classifyLine(nl + 1, this.nextLineEnd(nl + 1, b))
              : "eoi"; // конец читаемого интервала
          this.tokenizeLine(lineStart, nl, kind, nextKind);
        }
        lineStart = nl < b ? nl + 1 : b;
        if (tokenLimit >= 0 && this.starts.length >= tokenLimit && lineStart < b) {
          pos = lineStart;
          complete = false;
          break;
        }
      }
      if (!complete) break;
    }
    if (complete) {
      this.unitParsed[u] = true;
      this.parsedUnitCount++;
      this.pumpUnit = u + 1;
      this.pumpChar =
        this.pumpUnit < this.units.length ? this.units[this.pumpUnit].from : this.text.length;
      if (this.parsedUnitCount === this.units.length) this._length = this.starts.length;
    } else {
      this.pumpUnit = u;
      this.pumpChar = pos;
    }
    return complete;
  }

  private nextLineEnd(from: number, b: number): number {
    let nl = this.text.indexOf("\n", from);
    if (nl === -1 || nl >= b) nl = b;
    return nl;
  }

  /** Быстрая классификация строки: blank/noise/heading/quote/plain. */
  private classifyLine(ls: number, le: number): LineKind {
    const T = this.text;
    let i = ls;
    while (i < le && (T.charCodeAt(i) === CH_SPACE || T.charCodeAt(i) === CH_TAB || T.charCodeAt(i) === CH_CR)) i++;
    if (i >= le) return "blank";
    // заголовок: ≤3 ведущих пробелов + #{1..6} + пробел/конец строки
    let k = ls;
    let lead = 0;
    while (k < le && T.charCodeAt(k) === CH_SPACE && lead < 3) {
      k++;
      lead++;
    }
    if (k < le && T.charCodeAt(k) === CH_HASH) {
      let q = k;
      let h = 0;
      while (q < le && T.charCodeAt(q) === CH_HASH && h < 7) {
        q++;
        h++;
      }
      if (h >= 1 && h <= 6 && (q >= le || T.charCodeAt(q) === CH_SPACE || T.charCodeAt(q) === CH_TAB || T.charCodeAt(q) === CH_CR)) {
        return "heading";
      }
    }
    // шум: HR / setext-подчёркивание / маркеры код-блоков и $$ в read-зонах
    let e = le;
    while (e > i && (T.charCodeAt(e - 1) === CH_SPACE || T.charCodeAt(e - 1) === CH_TAB || T.charCodeAt(e - 1) === CH_CR)) e--;
    if (e > i) {
      let allNoise = true;
      for (let j = i; j < e; j++) {
        const c = T.charCodeAt(j);
        if (
          c !== CH_EQ && c !== CH_HYPHEN && c !== CH_STAR && c !== CH_UNDERSCORE &&
          c !== CH_BACKTICK && c !== CH_TILDE && c !== CH_DOLLAR
        ) {
          allNoise = false;
          break;
        }
      }
      if (allNoise) return "noise";
    }
    if (lead <= 3 && T.charCodeAt(i) === CH_GT) return "quote";
    return "plain";
  }

  /** Граница абзаца после текущей строки. */
  private isParaBreaker(next: LineKind, cur: LineKind): boolean {
    return (
      next === "eoi" ||
      next === "blank" ||
      next === "heading" ||
      next === "noise" ||
      (next === "quote" && cur !== "quote")
    );
  }

  /** Разбор одной строки: префиксы → инлайн-чистка → слова → токены. */
  private tokenizeLine(ls: number, le: number, kind: LineKind, nextKind: LineKind): void {
    const T = this.text;
    let cs = ls;
    let ce = le;
    let paraEndLast: boolean;

    if (kind === "heading") {
      // маркер {0,3} пробелов + #{1..6} + пробелы; хвостовые закрывающие ###
      while (cs < ce && T.charCodeAt(cs) === CH_SPACE) cs++;
      while (cs < ce && T.charCodeAt(cs) === CH_HASH) cs++;
      while (cs < ce && isWsCode(T.charCodeAt(cs))) cs++;
      let te = ce;
      while (te > cs && isWsCode(T.charCodeAt(te - 1))) te--;
      let q = te;
      while (q > cs && T.charCodeAt(q - 1) === CH_HASH) q--;
      if (q < te && q > cs && isWsCode(T.charCodeAt(q - 1))) {
        te = q;
        while (te > cs && isWsCode(T.charCodeAt(te - 1))) te--;
      }
      ce = te;
      paraEndLast = true; // заголовок — самостоятельный блок
    } else {
      if (kind === "quote") {
        // маркеры цитаты: {0,3} пробелов + (>[ \t]?)+
        let k = cs;
        let lead = 0;
        while (k < ce && T.charCodeAt(k) === CH_SPACE && lead < 3) {
          k++;
          lead++;
        }
        if (k < ce && T.charCodeAt(k) === CH_GT) {
          cs = k;
          while (cs < ce && T.charCodeAt(cs) === CH_GT) {
            cs++;
            if (cs < ce && (T.charCodeAt(cs) === CH_SPACE || T.charCodeAt(cs) === CH_TAB)) cs++;
          }
        }
      }
      // маркер списка: {0,3} пробелов + (-|*|+|\d{1,9}.) + пробел
      {
        let k = cs;
        let lead = 0;
        while (k < ce && T.charCodeAt(k) === CH_SPACE && lead < 3) {
          k++;
          lead++;
        }
        const c = k < ce ? T.charCodeAt(k) : 0;
        if (c === CH_HYPHEN || c === CH_STAR || c === CH_PLUS) {
          if (k + 1 < ce && (T.charCodeAt(k + 1) === CH_SPACE || T.charCodeAt(k + 1) === CH_TAB)) {
            cs = k + 2;
          }
        } else if (isDigitCode(c)) {
          let d = k;
          let cnt = 0;
          while (d < ce && isDigitCode(T.charCodeAt(d)) && cnt < 9) {
            d++;
            cnt++;
          }
          if (d < ce && T.charCodeAt(d) === CH_DOT && d + 1 < ce &&
              (T.charCodeAt(d + 1) === CH_SPACE || T.charCodeAt(d + 1) === CH_TAB)) {
            cs = d + 2;
          }
        }
      }
      // определение сноски [^N]: в начале строки
      if (cs + 1 < ce && T.charCodeAt(cs) === CH_LBRACKET && T.charCodeAt(cs + 1) === CH_CARET) {
        let close = cs + 2;
        while (close < ce && T.charCodeAt(close) !== CH_RBRACKET) close++;
        if (close < ce && close + 1 < ce && T.charCodeAt(close + 1) === CH_COLON) {
          cs = close + 2;
        }
      }
      paraEndLast = this.isParaBreaker(nextKind, kind);
    }

    if (cs >= ce) return;

    this.frags.length = 0;
    this.scanRange(cs, ce, 0);
    this.words.length = 0;
    this.buildWords();
    this.pushWords(paraEndLast);
  }

  /* ── инлайн-чистка (построчно, в границах [from, to)) ── */

  /** Найти символ в [from, to). */
  private findChar(c: number, from: number, to: number): number {
    const T = this.text;
    for (let i = from; i < to; i++) {
      if (T.charCodeAt(i) === c) return i;
    }
    return -1;
  }

  /** Найти пару символов ab в [from, to). */
  private findSeq(a: number, b: number, from: number, to: number): number {
    const T = this.text;
    let i = from;
    while (i + 1 < to) {
      if (T.charCodeAt(i) === a && T.charCodeAt(i + 1) === b) return i;
      i++;
    }
    return -1;
  }

  /** Найти строку в [from, to). */
  private findStr(seq: string, from: number, to: number): number {
    const idx = this.text.indexOf(seq, from);
    return idx === -1 || idx + seq.length > to ? -1 : idx;
  }

  /** Экранирование нечётным числом бэкслэшей внутри [from, i). */
  private isEscapedAt(i: number, from: number): boolean {
    const T = this.text;
    let k = i - 1;
    let cnt = 0;
    while (k >= from && T.charCodeAt(k) === CH_BACKSLASH) {
      cnt++;
      k--;
    }
    return (cnt & 1) === 1;
  }

  /** Тело callout-префикса [!note]: буквы/цифры/дефис/подчёркивание. */
  private isCalloutBody(a: number, b: number): boolean {
    if (b <= a) return false;
    const T = this.text;
    for (let i = a; i < b; i++) {
      const c = T.charCodeAt(i);
      if (!isLetterCode(c) && !isDigitCode(c) && c !== CH_HYPHEN && c !== CH_UNDERSCORE) return false;
    }
    return true;
  }

  /** [текст](url) → конец конструкции и границы текста. */
  private tryLink(i: number, to: number): { end: number; ts: number; te: number } | null {
    const T = this.text;
    const closeBr = this.findChar(CH_RBRACKET, i + 1, to);
    if (closeBr === -1 || closeBr <= i + 1) return null;
    if (closeBr + 1 >= to || T.charCodeAt(closeBr + 1) !== CH_LPAREN) return null;
    const closeParen = this.findChar(CH_RPAREN, closeBr + 2, to);
    if (closeParen === -1) return null;
    return { end: closeParen + 1, ts: i + 1, te: closeBr };
  }

  /** HTML-тег/комментарий <…>: конец тега или −1 (тогда «<» — литерал). */
  private tryHtml(i: number, to: number): number {
    const T = this.text;
    if (i + 3 < to && T.charCodeAt(i + 1) === CH_BANG && T.charCodeAt(i + 2) === CH_HYPHEN && T.charCodeAt(i + 3) === CH_HYPHEN) {
      const close = this.findStr("-->", i + 4, to);
      if (close !== -1) return close + 3;
      const gt = this.findChar(CH_GT, i + 4, to);
      if (gt !== -1) return gt + 1;
      return -1;
    }
    let j = i + 1;
    if (j < to && T.charCodeAt(j) === CH_SLASH) j++;
    if (j >= to || !isLetterCode(T.charCodeAt(j))) return -1;
    j++;
    while (j < to) {
      const c = T.charCodeAt(j);
      if (isLetterCode(c) || isDigitCode(c) || c === CH_HYPHEN || c === CH_UNDERSCORE || c === CH_COLON) j++;
      else break;
    }
    if (j >= to) return -1;
    const c = T.charCodeAt(j);
    if (c === CH_GT) return j + 1;
    if (c === CH_SLASH && j + 1 < to && T.charCodeAt(j + 1) === CH_GT) return j + 2;
    if (c === CH_SPACE || c === CH_TAB) {
      // атрибуты: до '>' должен быть '=' (имя="значение") или только пробелы/'/'
      let k = j;
      let hasEq = false;
      let onlyWsSlash = true;
      while (k < to && T.charCodeAt(k) !== CH_GT) {
        const a = T.charCodeAt(k);
        if (a === CH_EQ) hasEq = true;
        if (!(a === CH_SPACE || a === CH_TAB || a === CH_SLASH)) onlyWsSlash = false;
        k++;
      }
      if (k < to && (hasEq || onlyWsSlash)) return k + 1;
    }
    return -1;
  }

  /** Внутренность [[цель|алиас]]: алиас после первого неэкранированного |. */
  private wikilinkTarget(innerFrom: number, innerTo: number): { ts: number; te: number } {
    const T = this.text;
    let pipe = -1;
    for (let p = innerFrom; p < innerTo; p++) {
      if (T.charCodeAt(p) === CH_PIPE && (p === innerFrom || T.charCodeAt(p - 1) !== CH_BACKSLASH)) {
        pipe = p;
        break;
      }
    }
    return pipe === -1 ? { ts: innerFrom, te: innerTo } : { ts: pipe + 1, te: innerTo };
  }

  /**
   * Сканер инлайн-конструкций: наполняет this.frags кусочками ЧИСТОГО текста
   * (замены всегда являются сырыми подстроками). depth ограничивает вложенную
   * чистку (жирный внутри текста ссылки и т.п.); код-спаны и вики-ссылки
   * проходят дословно.
   */
  private scanRange(from: number, to: number, depth: number): void {
    const T = this.text;
    const frags = this.frags;
    let runStart = -1;
    let i = from;

    const flushRun = (runEnd: number): void => {
      if (runStart !== -1 && runEnd > runStart) frags.push({ ts: runStart, te: runEnd });
      runStart = -1;
    };
    // flush литерального прогона ДО конструкции, затем пуш/рекурсия тела
    const pushBody = (constructStart: number, ts: number, te: number, verbatim: boolean): void => {
      flushRun(constructStart);
      if (te > ts) {
        if (verbatim || depth >= 2) frags.push({ ts, te });
        else this.scanRange(ts, te, depth + 1);
      }
    };

    while (i < to) {
      const c = T.charCodeAt(i);
      const isMarker =
        c === CH_BANG || c === CH_LBRACKET || c === CH_DOLLAR || c === CH_BACKTICK ||
        c === CH_STAR || c === CH_EQ || c === CH_TILDE || c === CH_LT || c === CH_HASH;
      if (isMarker && this.isEscapedAt(i, from)) {
        if (runStart === -1) runStart = i;
        i++;
        continue;
      }

      if (c === CH_BACKTICK) {
        // `код` / ``код`` — дословно
        let len = 1;
        while (i + len < to && T.charCodeAt(i + len) === CH_BACKTICK) len++;
        let close = -1;
        let j = i + len;
        while (j < to) {
          if (T.charCodeAt(j) === CH_BACKTICK) {
            let l = 1;
            while (j + l < to && T.charCodeAt(j + l) === CH_BACKTICK) l++;
            if (l === len) {
              close = j;
              break;
            }
            j += l;
          } else j++;
        }
        if (close !== -1) {
          pushBody(i, i + len, close, true);
          i = close + len;
          continue;
        }
      } else if (c === CH_STAR) {
        // **жирный** / *курсив*
        if (i + 1 < to && T.charCodeAt(i + 1) === CH_STAR) {
          const close = this.findSeq(CH_STAR, CH_STAR, i + 2, to);
          if (close !== -1) {
            pushBody(i, i + 2, close, false);
            i = close + 2;
            continue;
          }
        } else {
          const close = this.findChar(CH_STAR, i + 1, to);
          if (close !== -1) {
            pushBody(i, i + 1, close, false);
            i = close + 1;
            continue;
          }
        }
      } else if (c === CH_EQ) {
        if (i + 1 < to && T.charCodeAt(i + 1) === CH_EQ) {
          const close = this.findSeq(CH_EQ, CH_EQ, i + 2, to);
          if (close !== -1) {
            pushBody(i, i + 2, close, false);
            i = close + 2;
            continue;
          }
        }
      } else if (c === CH_TILDE) {
        if (i + 1 < to && T.charCodeAt(i + 1) === CH_TILDE) {
          const close = this.findSeq(CH_TILDE, CH_TILDE, i + 2, to);
          if (close !== -1) {
            pushBody(i, i + 2, close, false);
            i = close + 2;
            continue;
          }
        }
      } else if (c === CH_DOLLAR) {
        // инлайн-формула $…$ / $$…$$ — выкинуть; содержимое не должно
        // начинаться/кончаться пробелом (защита от «5$ и 10$»)
        const dbl = i + 1 < to && T.charCodeAt(i + 1) === CH_DOLLAR;
        const openEnd = i + (dbl ? 2 : 1);
        const close = dbl
          ? this.findSeq(CH_DOLLAR, CH_DOLLAR, openEnd, to)
          : this.findChar(CH_DOLLAR, openEnd, to);
        if (close !== -1 && close > openEnd &&
            !isWsCode(T.charCodeAt(openEnd)) && !isWsCode(T.charCodeAt(close - 1))) {
          flushRun(i);
          i = close + (dbl ? 2 : 1);
          continue;
        }
      } else if (c === CH_BANG) {
        // эмбеды ![[…]] / ![…](…)
        if (i + 1 < to && T.charCodeAt(i + 1) === CH_LBRACKET) {
          if (i + 2 < to && T.charCodeAt(i + 2) === CH_LBRACKET) {
            const close = this.findSeq(CH_RBRACKET, CH_RBRACKET, i + 3, to);
            if (close !== -1) {
              if (this.filters.embeds === "skip") {
                flushRun(i);
                i = close + 2;
                continue;
              }
              // TODO (этап 3): разворачивание эмбедов; пока — как вики-ссылка
              const inner = this.wikilinkTarget(i + 2, close);
              pushBody(i, inner.ts, inner.te, true);
              i = close + 2;
              continue;
            }
          } else {
            const closeBr = this.findChar(CH_RBRACKET, i + 2, to);
            if (closeBr !== -1 && closeBr + 1 < to && T.charCodeAt(closeBr + 1) === CH_LPAREN) {
              const closeParen = this.findChar(CH_RPAREN, closeBr + 2, to);
              if (closeParen !== -1) {
                if (this.filters.embeds === "skip") {
                  flushRun(i);
                  i = closeParen + 1;
                  continue;
                }
                pushBody(i, i + 2, closeBr, true);
                i = closeParen + 1;
                continue;
              }
            }
          }
        }
      } else if (c === CH_LBRACKET) {
        if (i + 1 < to) {
          const c1 = T.charCodeAt(i + 1);
          if (c1 === CH_LBRACKET) {
            // [[Заметка]] / [[Заметка|Алиас]] — алиас дословно
            const close = this.findSeq(CH_RBRACKET, CH_RBRACKET, i + 2, to);
            if (close !== -1) {
              const inner = this.wikilinkTarget(i + 2, close);
              pushBody(i, inner.ts, inner.te, true);
              i = close + 2;
              continue;
            }
          } else if (c1 === CH_CARET) {
            // сноска [^N] — выкинуть
            const close = this.findChar(CH_RBRACKET, i + 2, to);
            if (close !== -1) {
              flushRun(i);
              i = close + 1;
              continue;
            }
          } else {
            // [!note] callout — выкинуть; иначе [текст](url)
            if (c1 === CH_BANG) {
              const close = this.findChar(CH_RBRACKET, i + 2, to);
              if (close !== -1 && this.isCalloutBody(i + 2, close)) {
                flushRun(i);
                i = close + 1;
                continue;
              }
            }
            const link = this.tryLink(i, to);
            if (link !== null) {
              pushBody(i, link.ts, link.te, false);
              i = link.end;
              continue;
            }
          }
        }
      } else if (c === CH_LT) {
        // HTML-теги <…> — выкинуть, текст между остаётся
        const tagEnd = this.tryHtml(i, to);
        if (tagEnd !== -1) {
          flushRun(i);
          i = tagEnd;
          continue;
        }
      } else if (c === CH_HASH) {
        // инлайн-тег #тег (после начала содержимого/пробела, не заголовок)
        const atStart = i === from || T.charCodeAt(i - 1) === CH_SPACE || T.charCodeAt(i - 1) === CH_TAB;
        const nextOk = i + 1 < to && !isWsCode(T.charCodeAt(i + 1)) && T.charCodeAt(i + 1) !== CH_HASH;
        if (atStart && nextOk && this.filters.tags === false) {
          flushRun(i);
          let j = i + 1;
          while (j < to && !isWsCode(T.charCodeAt(j))) j++;
          i = j;
          continue;
        }
      }

      // литеральный символ
      if (runStart === -1) runStart = i;
      i++;
    }
    flushRun(to);
  }

  /* ── слова → токены ── */

  /**
   * Сборка слов из фрагментов: слова режутся по пробелам конкатенации
   * чистого текста; куски одного слова могут лежать в разных фрагментах
   * (склейки из чистки). Слово «простое», если его куски подряд идут и в
   * исходнике — тогда text = срез; иначе текст собирается явно.
   */
  private buildWords(): void {
    const T = this.text;
    const words = this.words;
    let wordStart = -1;
    let wordEnd = -1;
    let simple = true;
    let parts: string[] | null = null;

    const flush = (): void => {
      if (wordStart === -1) return;
      if (simple) words.push({ start: wordStart, end: wordEnd });
      else words.push({ start: wordStart, end: wordEnd, text: (parts ?? []).join("") });
      wordStart = -1;
      wordEnd = -1;
      simple = true;
      parts = null;
    };

    for (const frag of this.frags) {
      let i = frag.ts;
      const te = frag.te;
      while (i < te) {
        if (isWsCode(T.charCodeAt(i))) {
          flush();
          i++;
          continue;
        }
        let j = i + 1;
        while (j < te && !isWsCode(T.charCodeAt(j))) j++;
        if (wordStart === -1) {
          wordStart = i;
          wordEnd = j;
          simple = true;
        } else if (simple && i === wordEnd) {
          wordEnd = j;
        } else {
          if (parts === null) parts = [T.slice(wordStart, wordEnd)];
          parts.push(T.slice(i, j));
          wordEnd = j;
          simple = false;
        }
        i = j;
      }
    }
    flush();
  }

  private isDigitRun(a: number, b: number): boolean {
    if (b <= a) return false;
    const T = this.text;
    for (let i = a; i < b; i++) {
      if (!isDigitCode(T.charCodeAt(i))) return false;
    }
    return true;
  }

  /** Слова → токены: числовые группы «12 345» склеиваются в один токен. */
  private pushWords(paraEndLast: boolean): void {
    const T = this.text;
    const words = this.words;
    const n = words.length;
    for (let j = 0; j < n; j++) {
      const w = words[j];
      let start = w.start;
      let end = w.end;
      let text: string | undefined = w.text;
      let last = j;
      if (w.text === undefined && this.isDigitRun(w.start, w.end) && w.end - w.start <= 3) {
        // первая группа 1–3 цифры, далее — строго трёхзначные группы
        let k = j;
        let lastEnd = w.end;
        while (k + 1 < n) {
          const nx = words[k + 1];
          if (
            nx.text === undefined &&
            this.isDigitRun(nx.start, nx.end) &&
            nx.end - nx.start === 3 &&
            nx.start === lastEnd + 1 &&
            isMergeGapCode(T.charCodeAt(lastEnd))
          ) {
            lastEnd = nx.end;
            k++;
          } else break;
        }
        if (k > j) {
          end = lastEnd;
          text = T.slice(start, end).replace(NBSP_RE, " ");
          last = k;
          j = k;
        }
      }
      const isLast = last === n - 1;
      this.pushToken(start, end, text, isLast && paraEndLast);
    }
  }

  private pushToken(start: number, end: number, text: string | undefined, paraEnd: boolean): void {
    const T = this.text;
    // пустой результат чистки (только краевые кавычки) — не токен
    if (text === undefined) {
      let allQuotes = true;
      for (let i = start; i < end; i++) {
        if (!isQuoteEdge(T.charCodeAt(i))) {
          allQuotes = false;
          break;
        }
      }
      if (allQuotes) return;
    } else {
      let allQuotes = true;
      for (let i = 0; i < text.length; i++) {
        if (!isQuoteEdge(text.charCodeAt(i))) {
          allQuotes = false;
          break;
        }
      }
      if (allQuotes) return;
    }
    const idx = this.starts.length;
    this.starts.push(start);
    this.ends.push(end);
    this.secs.push(this.curSectionIdx);
    this.flags.push(paraEnd ? 1 : 0);
    this.cums.push(this.charsTotal);
    this.charsTotal += end - start;
    if (text !== undefined) this.complexText.set(idx, text);
    if (this.curSectionIdx >= 0) {
      const sec = this.index.sections[this.curSectionIdx];
      if (sec.firstTokenIdx === -1) sec.firstTokenIdx = idx;
    }
  }
}
