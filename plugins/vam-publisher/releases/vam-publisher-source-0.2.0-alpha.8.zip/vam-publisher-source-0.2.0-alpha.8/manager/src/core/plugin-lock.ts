// src/core/plugin-lock.ts — реестр блокировок запрещённых плагинов (v0.5.1, H-1).
//
// v0.5.1 РЕШЛИНИЕ (полевая обратная связь с реального Obsidian): манипуляции
// manifest.json (rename → .vam-manifest → обратно) УДАЛЕНЫ. Причины:
//   • бут-скан Obsidian не видит папку без manifest.json — плагин исчезает из
//     настроек; восстановление требует loadManifest/рестарта, которого публично нет;
//   • бут-цикл: до входа пользователя замок перезапирал папку на каждом старте —
//     «manifest не восстанавливается» (реальный репорт пользователя);
//   • атомарность rename на реальных адаптерах не гарантирована.
// ЗАМОК ТЕПЕРЬ = штатные слои Obsidian: disablePluginAndSave (S3+S2) + скраб
// community-plugins.json — оба переживают рестарт без всяких манипуляций файлами
// плагина. Папка и манифест НЕ трогаются вовсе.
//
// НАЗНАЧЕНИЕ ЭТОГО МОДУЛЯ — lock-registry.json (учёт замка):
//   .obsidian/plugins/<self>/lock-registry.json, { version: 1, entries: [...] }.
//   • запись = «этот плагин заперт политикой»: folder, manifestId (первичный ключ
//     матчинга, M-3), wasEnabled (до-блокировочное состояние для smooth unlock, C-4),
//     policyId, lockedAt, epochPolicy (анти-откат-метка);
//   • идемпотентность: повторный lock того же плагина = 'already-locked', no-op;
//     wasEnabled фиксируется при ПЕРВОЙ блокировке и не перезаписывается;
//   • запись удаляется unlock'ом (реестр обязан отражать только живые замки);
//   • syncRegistry — самовосстановление СТРУКТУРЫ (исчезнувшие/переименованные
//     папки), состояние доступа меняют только lock/unlock.
//
// СЛОЙНОСТЬ: модуль — только учёт. Порядок lock по слоям (disable → скраб →
// registry-запись) — ответственность main.ts.
//
// ПОТОКОБЕЗОПАСНОСТЬ: все операции над реестром сериализуются внутренней очередью
// (параллельные lock/unlock не теряют записи). Рестарт посреди записи лечится
// валидацией при загрузке: мусорные записи выбрасываются, файл-не-JSON
// пересоздаётся пустым.
//
// ЛЕГАСИ .vam-manIFEST (застрявшие от v0.5-beta): сам модуль их не создаёт и не
// читает, КРОМЕ readFolderManifestId (проба id для матчинга). Одноразовая
// автопочинка застрявших файлов — quarantine-sweeper.ts (sweepNeutralizedManifests),
// порядок гарантирует main.ts (sweep ДО enforcement).

import type { DataAdapter } from './store';

/**
 * Имя, под которым v0.5-beta прятал manifest.json. Механизм удалён (H-1);
 * константа остаётся для: (а) автопочинки застрявших файлов (sweeper),
 * (б) legacy-пробы id в readFolderManifestId.
 */
export const NEUTRALIZED_MANIFEST = '.vam-manifest';
/** Файл реестра блокировок (в собственной папке менеджера). */
export const LOCK_REGISTRY_FILE = 'lock-registry.json';

export interface LockRegistryEntry {
        policyId: string;      // id из политики (канонический)
        folder: string;        // фактическая папка в plugins/ (может ≠ id)
        manifestId: string;    // id из manifest.json — первичный ключ матчинга (M-3)
        wasEnabled: boolean;   // БЫЛ ли включён до блокировки → smooth unlock (C-4)
        lockedAt: number;
        epochPolicy: string;   // digest политики на момент блокировки (анти-откат-метка)
}

export interface LockTarget {
        policyId: string;
        folder: string;
        manifestId: string;
        wasEnabled: boolean;
        epochPolicy: string;
}

/** Результат registry-записи. 'locked' — новая запись (действие, журнал);
 *  'already-locked' — идемпотентный no-op; 'missing' — папки нет (нечего
 *  запирать — sync принесёт папку позже, D-3 поймает); 'degraded' — реестр
 *  не записался (честный провал, журнал через onEvent). */
export type LockOutcome =
        | { kind: 'locked'; folder: string; manifestId: string }
        | { kind: 'already-locked'; folder: string }
        | { kind: 'missing'; folder: string }
        | { kind: 'degraded'; folder: string; reason: string };

export type UnlockOutcome =
        | { kind: 'unlocked'; folder: string; manifestId: string }
        | { kind: 'not-locked'; folder: string }
        | { kind: 'missing-folder'; folder: string };

export interface PluginLockDeps {
        /** ПОЛНЫЙ vault.adapter (НЕ scoped): все пути — vault-относительные. */
        adapter: DataAdapter;
        configDir: string;
        /** Переопределение pluginsDir (например, из app.plugins.getPluginFolder());
         *  дефолт — `${configDir}/plugins`. */
        pluginsDir?: string;
        selfPluginId: string;
        now?: () => number;
        /** Канал наблюдаемости (zero-silent): эпизоды самовосстановления и провалы
         *  уходят сюда строкой — main.ts кладёт их в журнал. */
        onEvent?: (detail: string) => void;
}

interface RegistryFile {
        version: 1;
        entries: LockRegistryEntry[];
}

function safeFolderName(folder: string): boolean {
        // защита от мусора из манифестов/политик: имя папки — простой сегмент без '/'
        return typeof folder === 'string' && folder.length > 0 && !folder.startsWith('.') && !folder.includes('/');
}

function safeId(id: string): boolean {
        return typeof id === 'string' && id.length > 0 && !id.includes('/');
}

/** Digest политики для epochPolicy. SHA-256 (WebCrypto), FNV-1a как fallback
 *  (окружения без crypto.subtle). Значение — сравнимая метка, не секрет. */
export async function digestPolicy(policy: unknown): Promise<string> {
        const json = JSON.stringify(policy) ?? 'null';
        const subtle = (globalThis as { crypto?: { subtle?: { digest?: (alg: string, data: ArrayBufferView) => Promise<ArrayBuffer> } } }).crypto?.subtle;
        if (subtle?.digest) {
                try {
                        const buf = await subtle.digest('SHA-256', new TextEncoder().encode(json));
                        return `sha256:${[...new Uint8Array(buf)].map(b => b.toString(16).padStart(2, '0')).join('')}`;
                } catch {
                        // падаем в fnv — метка всё равно детерминированная
                }
        }
        let h = 0x811c9dc5;
        for (let i = 0; i < json.length; i++) {
                h ^= json.charCodeAt(i);
                h = Math.imul(h, 0x01000193);
        }
        return `fnv1a:${(h >>> 0).toString(16)}`;
}

export class PluginLock {
        private readonly pluginsDir: string;
        private readonly registryPath: string;
        private readonly now: () => number;
        private readonly events: (detail: string) => void;
        /** Сериализация операций над реестром (см. шапку файла). */
        private queue: Promise<unknown> = Promise.resolve();

        constructor(private readonly deps: PluginLockDeps) {
                this.pluginsDir = deps.pluginsDir ?? `${deps.configDir}/plugins`;
                this.registryPath = `${this.pluginsDir}/${deps.selfPluginId}/${LOCK_REGISTRY_FILE}`;
                this.now = deps.now ?? (() => Date.now());
                this.events = deps.onEvent ?? (() => undefined);
        }

        private enqueue<T>(op: () => Promise<T>): Promise<T> {
                const run = this.queue.then(op, op);
                this.queue = run.then(() => undefined, () => undefined);
                return run;
        }

        private event(detail: string): void {
                try {
                        this.events(detail);
                } catch {
                        // наблюдаемость не должна ронять механизм
                }
        }

        private folderPath(folder: string): string {
                return `${this.pluginsDir}/${folder}`;
        }

        private async existsSafe(path: string): Promise<boolean> {
                try {
                        return await this.deps.adapter.exists(path);
                } catch {
                        return false;
                }
        }

        // --- реестр ---

        private async loadRegistry(): Promise<RegistryFile> {
                if (!(await this.existsSafe(this.registryPath))) {
                        // нет файла — нормальное состояние первого старта
                        return { version: 1, entries: [] };
                }
                try {
                        const raw = JSON.parse(await this.deps.adapter.read(this.registryPath));
                        if (typeof raw === 'object' && raw !== null && (raw as RegistryFile).version === 1 && Array.isArray((raw as RegistryFile).entries)) {
                                const file = raw as RegistryFile;
                                // валидация записей: мусор выбрасываем, остальное держим
                                const entries = file.entries.filter(e => safeId(e?.policyId) && safeFolderName(e?.folder) && safeId(e?.manifestId) && typeof e?.wasEnabled === 'boolean' && typeof e?.lockedAt === 'number' && typeof e?.epochPolicy === 'string');
                                if (entries.length !== file.entries.length) {
                                        this.event('lock-registry: invalid entries dropped on load');
                                }
                                return { version: 1, entries };
                        }
                        this.event('lock-registry: malformed file — rebuilt empty');
                        return { version: 1, entries: [] };
                } catch {
                        this.event('lock-registry: malformed file — rebuilt empty');
                        return { version: 1, entries: [] };
                }
        }

        private async saveRegistry(entries: LockRegistryEntry[]): Promise<void> {
                await this.deps.adapter.write(this.registryPath, JSON.stringify({ version: 1, entries } as RegistryFile, null, 2));
        }

        /** Список заблокированных (для UI/diagnostics). Читает реестр с диска. */
        listLocked(): Promise<LockRegistryEntry[]> {
                return this.enqueue(async () => (await this.loadRegistry()).entries);
        }

        /** Поиск записи по любому из ключей (policyId / manifestId / folder),
         *  case-insensitive — как весь матчинг политик. */
        async findEntryFor(idOrFolder: string): Promise<LockRegistryEntry | undefined> {
                const entries = await this.listLocked();
                const key = idOrFolder.toLowerCase();
                return entries.find(e => e.policyId.toLowerCase() === key || e.manifestId.toLowerCase() === key || e.folder.toLowerCase() === key);
        }

        // --- пробы (для main.ts: резолв цели блокировки) ---

        /** id из manifest.json папки (fallback — легаси .vam-manIFEST застрявшего
         *  от v0.5-beta, до автопочинки). null — папки нет / манифестов нет / битый. */
        async readFolderManifestId(folder: string): Promise<string | null> {
                if (!safeFolderName(folder) || folder === this.deps.selfPluginId) return null;
                const dir = this.folderPath(folder);
                for (const name of ['manifest.json', NEUTRALIZED_MANIFEST]) {
                        try {
                                const raw = JSON.parse(await this.deps.adapter.read(`${dir}/${name}`));
                                const id = (raw as { id?: unknown }).id;
                                if (typeof id === 'string' && safeId(id)) return id;
                        } catch {
                                // нет файла или битый JSON — пробуем следующий
                        }
                }
                return null;
        }

        /** Папки в plugins/ (без dot-префикса; dot-папки невидимы для Obsidian). */
        async listPluginFolders(): Promise<string[]> {
                // v0.5.2 (полевой репорт №2): bound-вызов. Отрыв list от adapter'а
                // (const list = adapter.list; list(...)) в реальном Obsidian валится
                // TypeError'ом по внутреннему this — моки харнесса этого не ловили,
                // метод молча возвращал [] и S1-скан замка не видел папки.
                const adapter = this.deps.adapter;
                const list = typeof adapter.list === 'function'
                        ? (adapter.list as unknown as (p: string) => Promise<{ files: string[]; folders: string[] }>).bind(adapter)
                        : undefined;
                if (list === undefined) return [];
                try {
                        const entries = await list(this.pluginsDir);
                        return entries.folders.map(f => f.split('/').pop() ?? f).filter(n => !n.startsWith('.'));
                } catch {
                        return [];
                }
        }

        // --- блокировка (учёт; само запирание — disable+scrub в main.ts) ---

        /**
         * Зарегистрировать замок папки. ФС плагина НЕ трогается (v0.5.1, H-1):
         * замок живут в disable+scrub — это переживает рестарт штатно.
         *   папки нет                       → 'missing' (sync принесёт — D-3 поймает)
         *   запись уже есть                 → обновить метки → 'already-locked' (no-op)
         *   записи нет                      → write → 'locked' (действие, журнал вызывающего)
         *   реестр не записался             → 'degraded' (провал не молчит)
         */
        lockFolder(target: LockTarget): Promise<LockOutcome> {
                return this.enqueue(() => this.lockFolderInner(target));
        }

        private async lockFolderInner(target: LockTarget): Promise<LockOutcome> {
                if (!safeFolderName(target.folder) || !safeId(target.manifestId)) {
                        return { kind: 'missing', folder: target.folder };
                }
                // менеджер себя не блокирует (soft-контроль §2/U3)
                if (target.folder === this.deps.selfPluginId || target.manifestId === this.deps.selfPluginId) {
                        return { kind: 'missing', folder: target.folder };
                }

                if (!(await this.existsSafe(this.folderPath(target.folder)))) {
                        return { kind: 'missing', folder: target.folder };
                }
                // «похоже на плагин»: манифест (живой или легаси-маркер застрявшего v0.5-beta)
                const dir = this.folderPath(target.folder);
                const hasManifest = (await this.existsSafe(`${dir}/manifest.json`))
                        || (await this.existsSafe(`${dir}/${NEUTRALIZED_MANIFEST}`));
                if (!hasManifest) {
                        return { kind: 'missing', folder: target.folder };
                }

                const entries = (await this.loadRegistry()).entries;
                const existing = entries.find(e => e.folder.toLowerCase() === target.folder.toLowerCase());
                if (existing) {
                        // идемпотентность: wasEnabled первой блокировки не перезаписываем,
                        // метки политики освежаем (папку могло переименовать — sync heal'ит).
                        existing.policyId = target.policyId;
                        existing.manifestId = target.manifestId;
                        existing.epochPolicy = target.epochPolicy;
                        try {
                                await this.saveRegistry(entries);
                        } catch (err) {
                                this.event(`lock-registry save failed for '${target.manifestId}' (${errText(err)})`);
                        }
                        return { kind: 'already-locked', folder: target.folder };
                }

                entries.push({ ...target, lockedAt: this.now() });
                try {
                        await this.saveRegistry(entries);
                } catch (err) {
                        this.event(`lock failed: cannot write registry for '${target.manifestId}' (${errText(err)})`);
                        return { kind: 'degraded', folder: target.folder, reason: 'registry-write-failed' };
                }
                return { kind: 'locked', folder: target.folder, manifestId: target.manifestId };
        }

        // --- разблокировка (C-4) ---

        /**
         * Снять запись замка. ФС плагина НЕ трогается — включение (если wasEnabled)
         * делает вызывающий через enablePluginAndSave (штатный живой цикл).
         *   записи нет        → 'not-locked' (no-op)
         *   папки нет на диске → 'missing-folder' (запись СОХРАНЕНА: папка может
         *                       вернуться через sync; вызывающий честно сообщает)
         *   иначе             → запись удалена → 'unlocked'
         */
        unlockFolder(folder: string): Promise<UnlockOutcome> {
                return this.enqueue(() => this.unlockFolderInner(folder));
        }

        private async unlockFolderInner(folder: string): Promise<UnlockOutcome> {
                if (!safeFolderName(folder)) {
                        return { kind: 'missing-folder', folder };
                }
                const entries = (await this.loadRegistry()).entries;
                const entry = entries.find(e => e.folder.toLowerCase() === folder.toLowerCase());
                if (entry === undefined) {
                        return { kind: 'not-locked', folder };
                }
                if (!(await this.existsSafe(this.folderPath(folder))) && entry.folder === folder) {
                        return { kind: 'missing-folder', folder };
                }
                const next = entries.filter(e => e !== entry);
                try {
                        await this.saveRegistry(next);
                } catch (err) {
                        this.event(`unlock failed: cannot write registry for '${entry.manifestId}' (${errText(err)})`);
                        return { kind: 'not-locked', folder };
                }
                return { kind: 'unlocked', folder, manifestId: entry.manifestId };
        }

        // --- самовосстановление СТРУКТУРЫ реестра (C-2) ---

        /**
         * Сверка на каждом такте/запуске — ТОЛЬКО структура (v0.5.1: политика
         * больше не участвует — unlock по политике делает reconcileLocksWithPolicy,
         * единый путь с wasEnabled-включением). Действия:
         *   (a) запись → папки нет: перенос в переименованную папку (по manifestId,
         *       проба по всем папкам) или удаление записи (плагин исчез) — эпизод
         *       в onEvent;
         *   (b) self-запись (повреждённый реестр) — удалить.
         */
        syncRegistry(): Promise<void> {
                return this.enqueue(() => this.syncRegistryInner());
        }

        private async syncRegistryInner(): Promise<void> {
                const folders = await this.listPluginFolders();
                const folderSet = new Set(folders);
                let entries = (await this.loadRegistry()).entries;
                let changed = false;

                for (const entry of [...entries]) {
                        // self-запись — всегда повреждение (себя не запираем), чистим
                        // независимо от того, существует ли папка менеджера
                        if (entry.folder === this.deps.selfPluginId || entry.manifestId === this.deps.selfPluginId) {
                                entries = entries.filter(e => e !== entry);
                                changed = true;
                                this.event('lock-registry: self-entry dropped (corrupted registry)');
                                continue;
                        }
                        if (folderSet.has(entry.folder)) continue;
                        // переименование папки? ищем manifestId по всем папкам
                        let relocated: string | null = null;
                        for (const f of folders) {
                                const probe = await this.readFolderManifestId(f);
                                if (probe !== null && probe.toLowerCase() === entry.manifestId.toLowerCase()) {
                                        relocated = f;
                                        break;
                                }
                        }
                        if (relocated !== null) {
                                this.event(`lock-registry healed: '${entry.manifestId}' moved '${entry.folder}' → '${relocated}'`);
                                entry.folder = relocated;
                        } else {
                                this.event(`lock-registry healed: stale entry for '${entry.manifestId}' removed (plugin gone)`);
                                entries = entries.filter(e => e !== entry);
                        }
                        changed = true;
                }

                if (changed) {
                        try {
                                await this.saveRegistry(entries);
                        } catch (err) {
                                this.event(`lock-registry save failed after heal (${errText(err)})`);
                        }
                }
        }
}

function errText(err: unknown): string {
        return err instanceof Error ? err.message : String(err);
}
