// src/core/device.ts — привязка доступа к устройству (v0.6, M4 «device binding light»).
// Директива владельца: запись доступа должна работать только на ограниченном
// количестве компьютеров; вход с нового девайса виден администратору как заявка.
//
// МОДЕЛЬ (камерная, без противодействия хакерам):
//   deviceId = SHA-256( deviceSecret[16B случайный] ‖ fingerprint )[0..16]
//   • deviceSecret  — «VAMD1\n» + base64(16 байт), живёт ВНЕ хранилища на desktop
//     (app-root Obsidian, fallback — папка плагина): копия vault без секрета мертва;
//   • fingerprint   — каноничная строка из Node-сигналов (hostname/platform/arch/
//     cpu/mem/mac — собирает main.ts): копия папки плагина на другой ПК не сходится.
//   Пара даёт два свойства; подделка отпечатка патчем кода — вне модели угроз.
//
// ЗАПИСЬ (UserPayload v2, аддитивно): devices?: [{id, name, addedAt}], maxDevices?.
//   • devices === undefined (v1 или не активирована) → проверки НЕТ (legacy-режим);
//   • devices === [] (реестр активен, пуст) → любой desktop получает mismatch →
//     заявку («сброс устройств» хозяином); mobile (deviceId null) — проходит;
//   • deviceId ∈ devices → ок.
//
// ЗАЯВКА (requests/<uuid>.json v2): + deviceId, deviceName — «вход с нового девайса»
// виден хозяину в общей очереди заявок; одобрение = переиздание записи с устройством.
//
// Модуль ЧИСТЫЙ (NFR-1): Node/os/obsidian НЕ импортируются — сигналы собирает main.ts
// и передаёт сюда; файловые операции — через структурный DataAdapter (как remember.bin).

import type { UserPayload } from './crypto';
import type { DataAdapter } from './store';

// --- сигналы отпечатка (десктоп; сбор — в main.ts, здесь только канонизация) ---

export interface DeviceSignals {
	hostname: string;
	platform: string;
	arch: string;
	cpuModel?: string;
	memTotalBytes?: number;
	mac?: string;
}

const FP_FIELD_SEP = '‖';

export function fingerprintString(signals: DeviceSignals): string {
	// Каноничный порядок полей; опциональные отсутствующие → пустая строка.
	// Единственная обязанность — детерминизм на одной машине (не криптостойкость).
	const parts = [
		signals.hostname,
		signals.platform,
		signals.arch,
		signals.cpuModel ?? '',
		signals.memTotalBytes !== undefined ? String(Math.round(signals.memTotalBytes / (1 << 20))) : '', // МБ — переживает мелкие BIOS-дрейфы
		signals.mac ?? '',
	];
	return parts.join(FP_FIELD_SEP);
}

export async function computeDeviceId(secret: Uint8Array, fingerprint: string): Promise<string> {
	// sha256(secret ‖ fingerprint) → первые 16 hex (64 бита — коллизии на масштабе
	// «десятки машин» пренебрежимы, запись остаётся компактной).
	const encoder = new TextEncoder();
	const fpBytes = encoder.encode(fingerprint);
	const merged = new Uint8Array(secret.length + fpBytes.length);
	merged.set(secret, 0);
	merged.set(fpBytes, secret.length);
	const digest = await crypto.subtle.digest('SHA-256', merged as BufferSource);
	const hex = bytesToHex(new Uint8Array(digest));
	return hex.slice(0, 16);
}

function bytesToHex(bytes: Uint8Array): string {
	let hex = '';
	for (const b of bytes) hex += b.toString(16).padStart(2, '0');
	return hex;
}

function hexToBytes(hex: string): Uint8Array {
	const out = new Uint8Array(hex.length / 2);
	for (let i = 0; i < out.length; i++) out[i] = Number.parseInt(hex.slice(i * 2, i * 2 + 2), 16);
	return out;
}

// --- device.bin: секрет устройства (обфускация как remember.bin, БЕЗ шифрования) ---

const DEVICE_SECRET_PREFIX = 'VAMD1\n';
const DEVICE_SECRET_LEN = 16;

export type DeviceSecretScope = 'app-root' | 'plugin-folder';

export interface DeviceIdentity {
	deviceId: string;
	deviceName: string;          // hostname — человекочитаемо для хозяина
	scope: DeviceSecretScope;    // где лежит секрет (app-root = сильнее, папка = fallback)
}

export async function readDeviceSecret(adapter: DataAdapter): Promise<Uint8Array | null> {
	// Нет файла / битый префикс / битый base64 / неверная длина → null (молча;
	// выше создадим новый — deviceId сменится, канал честно увидит «новое устройство»).
	try {
		const text = await adapter.read('device.bin');
		if (!text.startsWith(DEVICE_SECRET_PREFIX)) return null;
		const clean = text.slice(DEVICE_SECRET_PREFIX.length).replace(/\s+/g, '');
		const bin = atob(clean);
		const bytes = new Uint8Array(bin.length);
		for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
		if (bytes.length !== DEVICE_SECRET_LEN) return null;
		return bytes;
	} catch {
		return null;
	}
}

export async function writeDeviceSecret(adapter: DataAdapter, secret: Uint8Array): Promise<void> {
	let bin = '';
	for (const b of secret) bin += String.fromCharCode(b);
	await adapter.write('device.bin', DEVICE_SECRET_PREFIX + btoa(bin));
}

export async function ensureDeviceSecret(adapter: DataAdapter): Promise<Uint8Array> {
	const existing = await readDeviceSecret(adapter);
	if (existing !== null) return existing;
	const fresh = crypto.getRandomValues(new Uint8Array(DEVICE_SECRET_LEN));
	await writeDeviceSecret(adapter, fresh);
	return fresh;
}

export function deviceSecretHex(secret: Uint8Array): string {
	return bytesToHex(secret);
}

export function deviceSecretFromHex(hex: string): Uint8Array {
	return hexToBytes(hex);
}

// --- проверка привязки по расшифрованной записи ---

export interface DeviceBindingEntry {
	id: string;
	name: string;
	addedAt: number;
}

export const DEFAULT_MAX_DEVICES = 2;

export function hasDeviceRegistry(payload: UserPayload): boolean {
	// Реестр «активен», если поле определено — включая ПУСТОЙ список (сброс
	// хозяином: все desktop'ы получают mismatch, mobile проходит).
	return payload.devices !== undefined;
}

export function isDeviceAllowed(payload: UserPayload, deviceId: string): boolean {
	const devices = payload.devices;
	if (devices === undefined) return true; // реестра нет — legacy, проверка выключена
	return devices.some((d) => d.id === deviceId);
}
