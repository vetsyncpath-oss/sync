// src/core/startup-strategy.ts — НОВАЯ стратегия раннего блокирования запрещённых плагинов.
//
// ПРОБЛЕМА: Obsidian загружает плагины в порядке их ID в community-plugins.json.
// Если "vault-access-manager" идёт ПОСЛЕ "evil-plugin", то evil-plugin уже загружен
// к моменту, когда менеджер получает контроль. Менеджер выключит его, но onload
// evil-plugin уже успеет выполниться (с вредоносным кодом).
//
// СТАРЫЙ подход (v0.3.6): installEnableInterceptor + enforcePluginPolicyNow.
// НЕДОСТАТОК: работает только ПОСЛЕ onload менеджера. evil-plugin уже работает.
//
// НОВЫЙ подход (v0.4.1): registerVaultEventListener на событие загрузки плагина.
// Если такое событие есть в Obsidian — слушаем и блокируем немедленно.
// Фоллбэк: раннее чтение pluginPolicyCache в onload (до любых async-операций)
//           + сканирование app.plugins.plugins на наличие уже-загруженных forbidden.
//
// ВАЖНО: даже при идеальной реализации, между чтением community-plugins.json
// и onload менеджера есть окно (порядка миллисекунд). Полная блокировка
// требует, чтобы менеджер загружался ПЕРВЫМ. Это можно достичь через:
//   1. Убедить пользователя установить менеджер первым (через документацию).
//   2. Использовать onLayoutReady для проверки уже-загруженных плагинов.
//   3. Карантин на FS-уровне — плагин не загрузится, даже если менеджер не успел.

import type { PluginPolicy } from './plugin-policy';

export interface StartupStrategyResult {
    /** Плагины, которые были загружены до менеджера и должны быть немедленно выключены */
    alreadyLoadedForbidden: string[];
    /** Плагины, в файле community-plugins.json, но ещё не загрузились */
    pendingForbidden: string[];
    /** Все forbidden-плагины (объединение loaded + pending) */
    allForbidden: string[];
}

/**
 * Сравнивает список включённых плагинов с политикой и возвращает forbidden,
 * разделённые на «уже загружены» и «в файле, но не загружены».
 *
 * @param enabledIds — список id включённых плагинов (из getEnabledPluginIds)
 * @param loadedIds — список id уже загруженных в рантайм (из app.plugins.plugins)
 * @param policy — политика плагинов
 * @param selfId — id менеджера (исключается)
 */
export function analyzeStartupState(
    enabledIds: string[],
    loadedIds: Set<string>,
    policy: PluginPolicy,
    selfId: string,
): StartupStrategyResult {
    const forbiddenIds = new Set<string>();
    for (const entry of policy.plugins) {
        if (entry.action === 'forbidden') {
            forbiddenIds.add(entry.id);
        }
    }

    const alreadyLoadedForbidden: string[] = [];
    const pendingForbidden: string[] = [];

    for (const id of enabledIds) {
        if (id === selfId) continue;
        if (!forbiddenIds.has(id)) continue;
        if (loadedIds.has(id)) {
            alreadyLoadedForbidden.push(id);
        } else {
            pendingForbidden.push(id);
        }
    }

    return {
        alreadyLoadedForbidden,
        pendingForbidden,
        allForbidden: [...alreadyLoadedForbidden, ...pendingForbidden],
    };
}
