// src/core/plugin-quarantine.ts — Физический карантин запрещённых плагинов (Level 2 защиты).
//
// Контекст: API-перехват (Level 1) не покрывает все сценарии — правка community-plugins.json
// напрямую, новая установка плагина, sync с другого устройства. Level 2 — физическое
// перемещение папки плагина в .obsidian/plugins/.vam-quarantine/<id>/, что делает её
// невидимой для Obsidian (папки с '.'-префиксом скрыты при сканировании плагинов).
//
// Свойства:
//   • Идемпотентно: quarantine/restore можно вызывать многократно
//   • Self-protection: менеджер себя не блокирует (по selfPluginId)
//   • Sentinel: внутри quarantined папки создаётся .vam-blocked файл-маркер
//     (отличает «мы заблокировали» от «плагин повреждён другим процессом»)
//   • Cross-platform: через DataAdapter (без прямого fs доступа, без rename — copy+remove)
//   • Graceful: все ошибки ловятся, не роняют вызывающий код
//
// Контракт:
//   - Adapter — полный vault.adapter (НЕ scoped). Пути — полные от корня vault.
//   - configDir — обычно '.obsidian' (читается из app.vault.configDir).
//   - pluginsDir = `${configDir}/plugins`, quarantineDir = `${pluginsDir}/.vam-quarantine`.

import type { DataAdapter } from './store';

export interface QuarantineDeps {
    adapter: DataAdapter;
    configDir: string;
    selfPluginId: string;
}

export const QUARANTINE_DIR_NAME = '.vam-quarantine';
export const SENTINEL_FILE = '.vam-blocked';

// Стандартные файлы плагина, которые пробуем скопировать, если adapter.list недоступен
const KNOWN_PLUGIN_FILES = ['manifest.json', 'main.js', 'styles.css', 'data.json'];

/**
 * PluginQuarantine — менеджер физического карантина запрещённых плагинов.
 *
 * Жизненный цикл:
 *   1. quarantine(id) — переместить plugins/<id>/ в plugins/.vam-quarantine/<id>/
 *   2. restore(id) — переместить обратно (если id больше не forbidden)
 *   3. restoreAll() — восстановить ВСЕ плагины (при выгрузке менеджера)
 *   4. listQuarantined() — список id в карантине (для UI/диагностики)
 *   5. isQuarantined(id) — проверка, находится ли id в карантине
 *
 * Потоковый безопасный через самих вызовов (нет shared mutable state, кроме adapter).
 */
export class PluginQuarantine {
    private readonly pluginsDir: string;
    private readonly quarantineDir: string;

    constructor(private deps: QuarantineDeps) {
        this.pluginsDir = `${deps.configDir}/plugins`;
        this.quarantineDir = `${this.pluginsDir}/${QUARANTINE_DIR_NAME}`;
    }

    /**
     * Переместить плагин в карантин. Идемпотентно.
     *
     * Логика:
     *   • dst exists + src doesn't exist → touch sentinel (already in quarantine, no-op)
     *   • dst exists + src exists → CONFLICT (attacker copied back) → удалить src, оставить dst
     *     (мы доверяем тому, что уже в карантине, а не новой копии)
     *   • dst doesn't exist + src exists → нормальный quarantine (copy+remove)
     *   • dst doesn't exist + src doesn't exist → return false (nothing to do)
     *
     * @returns true если действие выполнено (или уже было в карантине), false если нечего блокировать
     */
    async quarantine(policyId: string): Promise<boolean> {
        // Защита от само-блокировки: никогда не блокируем сам менеджер
        if (policyId === this.deps.selfPluginId) return false;

        const src = `${this.pluginsDir}/${policyId}`;
        const dst = `${this.quarantineDir}/${policyId}`;
        const srcExists = await this.existsSafe(src);
        const dstExists = await this.existsSafe(dst);

        // Case 4: nothing to do
        if (!srcExists && !dstExists) return false;

        // Case 1: already in quarantine, no live copy → touch sentinel + return true
        if (dstExists && !srcExists) {
            await this.touchSentinel(dst);
            return true;
        }

        // Case 2: dst exists AND src exists → CONFLICT (attacker put copy back)
        // We trust the quarantined version (dst) and delete the live copy (src).
        if (dstExists && srcExists) {
            try {
                await this.removeFolder(src);
                await this.touchSentinel(dst);
                console.warn('[VAM] quarantine conflict resolved for', policyId, '(live copy removed, kept quarantined)');
                return true;
            } catch (err) {
                console.warn('[VAM] quarantine conflict resolution failed for', policyId, err instanceof Error ? err.message : String(err));
                return false;
            }
        }

        // Case 3: dst doesn't exist + src exists → normal quarantine (copy + remove)
        // Создать карантин (ignore if exists)
        try {
            await this.deps.adapter.mkdir(this.quarantineDir);
        } catch {
            // уже существует или недоступно — продолжаем, write ниже покажет реальную ошибку
        }

        try {
            await this.moveFolder(src, dst);
            await this.touchSentinel(dst);
            return true;
        } catch (err) {
            console.warn('[VAM] quarantine failed for', policyId, err instanceof Error ? err.message : String(err));
            return false;
        }
    }

    /**
     * Восстановить плагин из карантина.
     * @returns true если восстановлено, false если в карантине нет
     */
    async restore(policyId: string): Promise<boolean> {
        const src = `${this.quarantineDir}/${policyId}`;
        const dst = `${this.pluginsDir}/${policyId}`;

        if (!(await this.existsSafe(src))) return false;

        // Конфликт: в plugins/<id>/ уже есть папка (кто-то переустановил, пока был в карантине)
        // В этом случае удаляем карантин, оставляем «живую» версию
        if (await this.existsSafe(dst)) {
            await this.removeFolder(src);
            return true;
        }

        try {
            await this.moveFolder(src, dst);
            return true;
        } catch (err) {
            console.warn('[VAM] restore failed for', policyId, err instanceof Error ? err.message : String(err));
            return false;
        }
    }

    /**
     * Восстановить ВСЕ плагины из карантина.
     * Используется при real-unload менеджера (когда enabledPlugins.has(self) === false).
     */
    async restoreAll(): Promise<void> {
        if (!(await this.existsSafe(this.quarantineDir))) return;

        const entries = await this.listSafe(this.quarantineDir);
        if (!entries) return;

        for (const folder of entries.folders) {
            // folder — БЕЗ префикса quarantineDir (имя подпапки)
            await this.restore(folder);
        }

        // Удалить пустой карантин (best-effort)
        try {
            const remaining = await this.listSafe(this.quarantineDir);
            if (remaining && remaining.folders.length === 0 && remaining.files.length === 0) {
                await this.deps.adapter.remove(this.quarantineDir);
            }
        } catch {
            // не критично — пустой карантин не мешает
        }
    }

    /**
     * Список всех quarantined id (для UI/диагностики).
     */
    async listQuarantined(): Promise<string[]> {
        if (!(await this.existsSafe(this.quarantineDir))) return [];
        const entries = await this.listSafe(this.quarantineDir);
        if (!entries) return [];
        return [...entries.folders];
    }

    /**
     * Проверить, что конкретный id в карантине.
     */
    async isQuarantined(policyId: string): Promise<boolean> {
        const dst = `${this.quarantineDir}/${policyId}`;
        return this.existsSafe(dst);
    }

    // --- Внутренние helper-методы ---

    /**
     * Создать sentinel-файл .vam-blocked внутри quarantined папки.
     * Маркер: distinguishes «мы заблокировали» от «плагин повреждён».
     */
    private async touchSentinel(quarantinedFolder: string): Promise<void> {
        const sentinel = `${quarantinedFolder}/${SENTINEL_FILE}`;
        try {
            await this.deps.adapter.write(sentinel, `${Date.now()}\n`);
        } catch {
            // не критично — sentinel опционален
        }
    }

    /**
     * Переместить папку (через copy + remove, т.к. DataAdapter не имеет rename).
     */
    private async moveFolder(src: string, dst: string): Promise<void> {
        await this.copyRecursive(src, dst);
        await this.removeFolder(src);
    }

    /**
     * Рекурсивное копирование. Использует adapter.list если доступен, иначе
     * fallback на чтение известных имён файлов плагина.
     *
     * БЕЗОПАСНОСТЬ: если ЛЮБОЙ файл не удалось скопировать, кидает ошибку.
     * Вызывающий (moveFolder) НЕ удалит источник — данные не теряются.
     */
    private async copyRecursive(src: string, dst: string): Promise<void> {
        await this.deps.adapter.mkdir(dst);

        const entries = await this.listSafe(src);
        if (entries) {
            // Полный путь через adapter.list
            for (const file of entries.files) {
                let content: string;
                try {
                    content = await this.deps.adapter.read(`${src}/${file}`);
                } catch (err) {
                    throw new Error(`copyRecursive: read failed for ${file}: ${err instanceof Error ? err.message : String(err)}`);
                }
                try {
                    await this.deps.adapter.write(`${dst}/${file}`, content);
                } catch (err) {
                    throw new Error(`copyRecursive: write failed for ${file}: ${err instanceof Error ? err.message : String(err)}`);
                }
            }
            for (const folder of entries.folders) {
                await this.copyRecursive(`${src}/${folder}`, `${dst}/${folder}`);
            }
            return;
        }

        // Fallback: adapter.list не поддерживается — пробуем известные имена
        let copied = 0;
        for (const fname of KNOWN_PLUGIN_FILES) {
            try {
                const content = await this.deps.adapter.read(`${src}/${fname}`);
                await this.deps.adapter.write(`${dst}/${fname}`, content);
                copied++;
            } catch {
                // файла нет — нормально, не считаем ошибкой
            }
        }
        if (copied === 0) {
            throw new Error(`copyRecursive: no files copied from ${src} (fallback mode)`);
        }
    }

    /**
     * Рекурсивное удаление папки.
     */
    private async removeFolder(folder: string): Promise<void> {
        const entries = await this.listSafe(folder);
        if (entries) {
            for (const file of entries.files) {
                try {
                    await this.deps.adapter.remove(`${folder}/${file}`);
                } catch {
                    // продолжаем
                }
            }
            for (const sub of entries.folders) {
                await this.removeFolder(`${folder}/${sub}`);
            }
        } else {
            // Fallback: пробуем известные имена
            for (const fname of [...KNOWN_PLUGIN_FILES, SENTINEL_FILE]) {
                try {
                    await this.deps.adapter.remove(`${folder}/${fname}`);
                } catch {
                    // продолжаем
                }
            }
        }
        try {
            await this.deps.adapter.remove(folder);
        } catch {
            // папка может быть уже пустой или недоступной — не критично
        }
    }

    /**
     * Безопасный exists — ловит ошибки (например, нет прав).
     */
    private async existsSafe(path: string): Promise<boolean> {
        try {
            return await this.deps.adapter.exists(path);
        } catch {
            return false;
        }
    }

    /**
     * Безопасный list — ловит ошибки. Возвращает null если list недоступен.
     */
    private async listSafe(path: string): Promise<{ files: string[]; folders: string[] } | null> {
        if (typeof this.deps.adapter.list !== 'function') return null;
        try {
            return await this.deps.adapter.list(path);
        } catch {
            return null;
        }
    }
}
