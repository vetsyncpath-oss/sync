// src/core/hook-registry.ts — реестр замеченных hook-плагинов (v0.5.5).
//
// НАЗНАЧЕНИЕ (требование владельца): менеджер «замечает» кастомные плагины
// со встроенным VAM-hook (src/sdk/vam-guard.ts), чтобы хозяин видел в
// настройках, кто именно цепляется к системе. Основную блокировку такие
// плагины выполняют САМИ (fail-closed гвард: нет менеджера/нет доступа →
// плагин инертен); реестр — observability, не enforcement.
//
// ДВА ИСТОЧНИКА ДАННЫХ:
//   • runtime (active): гвард зарегистрировался ЧЕРЕЗ window.__VAM__.register()
//     в текущей сессии менеджера — плагин загружен прямо сейчас;
//   • persisted (known): записи в ManagerSettings.knownHookPlugins — переживают
//     перезапуск Obsidian; показываются как «замечен ранее».
//
// Регистрация дешёвая и доверчивая: id не верифицируется (любой код может
// зарегистрировать любой id) — это ЧЕСТНО заявлено в UI (аудит v0.5.4: гвард
// кооперативный механизм). Журнал: первая встреча с id пишет запись kind:'plugins'.

export interface HookPluginRecord {
        id: string;
        firstSeen: number;  // epoch ms
        lastSeen: number;   // epoch ms
}

/** Запись для UI: persisted-поля + флаг «зарегистрирован в этой сессии». */
export interface HookRegistrySnapshot extends HookPluginRecord {
        active: boolean;
}

const MAX_ID_LEN = 200;
const MAX_RECORDS = 500;

/** Санитизация массива из data.json (нормализация настроек, fail-soft). */
export function normalizeHookRecords(raw: unknown): HookPluginRecord[] {
        if (!Array.isArray(raw)) return [];
        const out: HookPluginRecord[] = [];
        const seen = new Set<string>();
        for (const item of raw) {
                if (typeof item !== 'object' || item === null) continue;
                const r = item as Record<string, unknown>;
                if (typeof r.id !== 'string' || r.id.trim() === '' || r.id.length > MAX_ID_LEN) continue;
                const id = r.id.trim();
                if (seen.has(id)) continue;
                seen.add(id);
                const firstSeen = typeof r.firstSeen === 'number' && Number.isFinite(r.firstSeen) ? r.firstSeen : 0;
                const lastSeen = typeof r.lastSeen === 'number' && Number.isFinite(r.lastSeen) ? r.lastSeen : firstSeen;
                out.push({ id, firstSeen, lastSeen: Math.max(firstSeen, lastSeen) });
        }
        return out.slice(0, MAX_RECORDS);
}

export interface HookRegistryIO {
        load(): HookPluginRecord[];
        persist(records: HookPluginRecord[]): Promise<void>;
        now(): number;
        /** Журнал: вызывается при ПЕРВОЙ встрече id (не на каждом touch). */
        onFirstSeen(id: string): void;
}

export class HookRegistry {
        private io: HookRegistryIO;
        private active = new Set<string>();
        private records: HookPluginRecord[] | null = null; // lazy: load при первом обращении

        constructor(io: HookRegistryIO) {
                this.io = io;
        }

        private ensureRecords(): HookPluginRecord[] {
                if (this.records === null) {
                        this.records = normalizeHookRecords(this.io.load());
                }
                return this.records;
        }

        /** Регистрация от window.__VAM__.register(id). Идемпотентна: повторный
         *  вызов обновляет lastSeen и active. Персистенция — fire-and-forget. */
        register(rawId: string): void {
                if (typeof rawId !== 'string') return;
                const id = rawId.trim();
                if (id === '' || id.length > MAX_ID_LEN) return;

                const recs = this.ensureRecords();
                const now = this.io.now();
                this.active.add(id);

                const existing = recs.find(r => r.id === id);
                if (existing) {
                        existing.lastSeen = Math.max(existing.lastSeen, now);
                } else {
                        recs.push({ id, firstSeen: now, lastSeen: now });
                        recs.sort((a, b) => a.id.localeCompare(b.id));
                        this.io.onFirstSeen(id);
                }
                if (recs.length > MAX_RECORDS) {
                        // защита от раздувания: режем хвост по lastSeen
                    recs.sort((a, b) => b.lastSeen - a.lastSeen);
                    this.records = recs.slice(0, MAX_RECORDS).sort((a, b) => a.id.localeCompare(b.id));
                }
                void this.io.persist(this.ensureRecords()).catch(() => undefined);
        }

        /** Снимок для UI: все известные id + флаг active (регистрация в этой сессии). */
        list(): HookRegistrySnapshot[] {
                const recs = this.ensureRecords();
                return recs.map(r => ({ ...r, active: this.active.has(r.id) }));
        }

        /** Сколько плагинов зарегистрировано сейчас (runtime-счётчик). */
        activeCount(): number {
                return this.active.size;
        }
}
