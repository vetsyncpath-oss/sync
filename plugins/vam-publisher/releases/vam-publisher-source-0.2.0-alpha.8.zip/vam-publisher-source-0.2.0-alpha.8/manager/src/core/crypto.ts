// src/core/crypto.ts — конверты AES-256-GCM + PBKDF2, shortHash (FR-2,3; §7.1, §8.1).
// Только crypto.subtle (NFR-5); модуль чистый — без импортов obsidian/node:* (NFR-1).
// Раскладка файла-конверта (§8.1):
//   [0..3] magic 'VSAM' · [4] version=1 · [5..8] kdfIterations BE u32
//   [9..24] salt 16B · [25..36] nonce 12B · [37..] ciphertext || GCM-tag(16B)
// AAD в файл не пишется; пароль пользователя НИКОГДА не логируется (FR-29).

export interface DeviceBinding {
        id: string;          // deviceId (hex16) — SHA-256(секрет ‖ отпечаток)
        name: string;        // hostname — человекочитаемо для хозяина
        addedAt: number;     // ms epoch зачисления
}

export interface UserPayload {
        v: 1 | 2;
        userId: string;              // 7 hex, = shortHashIdentifier(identifier)
        issuedAt: number;            // ms epoch
        expiresAt: number | null;    // null = бессрочно
        permissions: string[];       // задел под M3 (в v1 всегда [])
        note: string;                // справочно хозяину (identifier/имя)
        // v2 (M4 «device binding light»): реестр устройств записи. undefined/v1 —
        // legacy, проверка выключена; [] — реестр активен и пуст (сброс хозяином);
        // [ {id, name, addedAt} ] — допущенные устройства. maxDevices — лимит зачислений
        // (default 2).
        // v0.6.1: autoEnroll === false — ручной режим (ставится сбросом устройств):
        // новые устройства НЕ зачисляются сами, только заявкой + одобрением. Поле
        // отсутствует/true — под капом новое устройство с верным паролем зачисляется
        // автоматически (директива владельца: приглашение уже выдано вместе с ключом).
        devices?: DeviceBinding[];
        maxDevices?: number;
        autoEnroll?: boolean;
}

export const PROD_KDF_ITERATIONS = 600_000;

export class MalformedRecordError extends Error {
        constructor(message = 'malformed record') {
                super(message);
                this.name = 'MalformedRecordError';
        }
}

export class DecryptError extends Error {
        constructor(message = 'decrypt failed') {
                super(message);
                this.name = 'DecryptError';
        }
}

// --- базовые хелперы ---

const encoder = new TextEncoder();
const decoder = new TextDecoder();

export function normalizeIdentifier(raw: string): string {
        return raw.trim().toLowerCase();
}

export async function shortHashIdentifier(identifier: string): Promise<string> {
        // sha256(нормализованный identifier) → первые 7 hex. Нормализация ОБЯЗАТЕЛЬНА до хэша (вектор A.0).
        const digest = await crypto.subtle.digest('SHA-256', encoder.encode(normalizeIdentifier(identifier)) as BufferSource);
        return bytesToHex(new Uint8Array(digest)).slice(0, 7);
}

export function bytesToHex(bytes: Uint8Array): string {
        let hex = '';
        for (const b of bytes) hex += b.toString(16).padStart(2, '0');
        return hex;
}

export function bytesToB64(bytes: Uint8Array): string {
        let bin = '';
        const CHUNK = 0x8000;
        for (let i = 0; i < bytes.length; i += CHUNK) {
                bin += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
        }
        return btoa(bin);
}

export function b64ToBytes(b64: string): Uint8Array {
        // GitHub переносит строки внутри base64 — whitespace вычищаем (§7.3-4, TC-11/23).
        const clean = b64.replace(/\s+/g, '');
        const bin = atob(clean);
        const out = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
        return out;
}

// --- конверт (§8.1) ---

const MAGIC = new Uint8Array([0x56, 0x53, 0x41, 0x4d]); // 'VSAM'
const VERSION = 1;
const SALT_LEN = 16;
const NONCE_LEN = 12;
const HEADER_LEN = 4 + 1 + 4 + SALT_LEN + NONCE_LEN; // 37
export const MIN_ENVELOPE_LEN = HEADER_LEN + 16;      // 53: минимальный файл (пустой plaintext + tag)

export interface EnvelopeOpts {
        iterations?: number;
        salt?: Uint8Array;
        nonce?: Uint8Array;
}

async function deriveAesKey(password: string, salt: Uint8Array, iterations: number): Promise<CryptoKey> {
        const baseKey = await crypto.subtle.importKey('raw', encoder.encode(password) as BufferSource, 'PBKDF2', false, ['deriveKey']);
        return crypto.subtle.deriveKey(
                { name: 'PBKDF2', salt: salt as BufferSource, iterations, hash: 'SHA-256' },
                baseKey,
                { name: 'AES-GCM', length: 256 },
                false,
                ['encrypt', 'decrypt'],
        );
}

export async function encryptEnvelope(password: string, aad: string, payloadJson: string, opts?: EnvelopeOpts): Promise<Uint8Array> {
        const iterations = opts?.iterations ?? PROD_KDF_ITERATIONS;
        const salt = opts?.salt ?? crypto.getRandomValues(new Uint8Array(SALT_LEN));
        const nonce = opts?.nonce ?? crypto.getRandomValues(new Uint8Array(NONCE_LEN));
        if (salt.length !== SALT_LEN) throw new MalformedRecordError('bad salt length');
        if (nonce.length !== NONCE_LEN) throw new MalformedRecordError('bad nonce length');
        const key = await deriveAesKey(password, salt, iterations);
        const ciphertext = new Uint8Array(await crypto.subtle.encrypt(
                {
                        name: 'AES-GCM',
                        iv: nonce as BufferSource,
                        additionalData: encoder.encode(aad) as BufferSource,
                        tagLength: 128,
                },
                key,
                encoder.encode(payloadJson) as BufferSource,
        ));
        const out = new Uint8Array(HEADER_LEN + ciphertext.length);
        out.set(MAGIC, 0);
        out[4] = VERSION;
        new DataView(out.buffer, out.byteOffset, out.byteLength).setUint32(5, iterations, false); // BE
        out.set(salt, 9);
        out.set(nonce, 25);
        out.set(ciphertext, HEADER_LEN);
        return out;
}

export async function decryptEnvelope(password: string, aad: string, bytes: Uint8Array, opts?: { iterations?: number }): Promise<string> {
        if (bytes.length < MIN_ENVELOPE_LEN) throw new MalformedRecordError('record too short');
        if (bytes[0] !== MAGIC[0] || bytes[1] !== MAGIC[1] || bytes[2] !== MAGIC[2] || bytes[3] !== MAGIC[3]) {
                throw new MalformedRecordError('bad magic');
        }
        if (bytes[4] !== VERSION) throw new MalformedRecordError('bad version');
        const fileIterations = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength).getUint32(5, false);
        const iterations = opts?.iterations ?? fileIterations; // по умолчанию kdfIter читается из файла (TC-7)
        const salt = bytes.slice(9, 9 + SALT_LEN);
        const nonce = bytes.slice(25, 25 + NONCE_LEN);
        const ciphertext = bytes.slice(HEADER_LEN);
        const key = await deriveAesKey(password, salt, iterations);
        try {
                const plaintext = await crypto.subtle.decrypt(
                        {
                                name: 'AES-GCM',
                                iv: nonce as BufferSource,
                                additionalData: encoder.encode(aad) as BufferSource,
                                tagLength: 128,
                        },
                        key,
                        ciphertext as BufferSource,
                );
                return decoder.decode(plaintext);
        } catch {
                // Неверный пароль, порча или подмена AAD — наружу не отдаём ничего (§7.1).
                throw new DecryptError();
        }
}

// --- записи пользователей (aad = vsam:users:<userId>:v1) ---

export function userRecordAad(userId: string): string {
        return `vsam:users:${userId}:v1`;
}

export async function encryptUserRecord(password: string, userId: string, payload: UserPayload, opts?: EnvelopeOpts): Promise<Uint8Array> {
        return encryptEnvelope(password, userRecordAad(userId), JSON.stringify(payload), opts);
}

export async function decryptUserRecord(password: string, userId: string, bytes: Uint8Array, opts?: { iterations?: number }): Promise<UserPayload> {
        const json = await decryptEnvelope(password, userRecordAad(userId), bytes, opts);
        return parseUserPayload(json);
}

function isDeviceBinding(v: unknown): v is DeviceBinding {
        return typeof v === 'object' && v !== null
                && typeof (v as DeviceBinding).id === 'string'
                && typeof (v as DeviceBinding).name === 'string'
                && typeof (v as DeviceBinding).addedAt === 'number';
}

function parseUserPayload(json: string): UserPayload {
        let raw: unknown;
        try {
                raw = JSON.parse(json);
        } catch {
                throw new DecryptError('payload is not JSON');
        }
        if (raw === null || typeof raw !== 'object') throw new DecryptError('payload is not an object');
        const r = raw as Record<string, unknown>;
        const baseOk = (r.v === 1 || r.v === 2)
                && typeof r.userId === 'string'
                && typeof r.issuedAt === 'number'
                && (r.expiresAt === null || typeof r.expiresAt === 'number')
                && Array.isArray(r.permissions)
                && r.permissions.every((p) => typeof p === 'string')
                && typeof r.note === 'string';
        if (!baseOk) throw new DecryptError('payload schema mismatch');
        // v2: devices/maxDevices/autoEnroll опциональны, но если заявлены — строго
        // типизированы (битая форма = порча записи, а не «тихий legacy»: fail-closed).
        // v1: посторонние поля devices/maxDevices/autoEnroll СРЕЗАЮТСЯ — иначе мусорная
        // форма активировала бы проверку реестра на легаси-записи (salvage, не отказ).
        const devicesOk = r.devices === undefined || (Array.isArray(r.devices) && r.devices.every(isDeviceBinding));
        const maxOk = r.maxDevices === undefined
                || (typeof r.maxDevices === 'number' && Number.isFinite(r.maxDevices) && r.maxDevices >= 1);
        const autoOk = r.autoEnroll === undefined || typeof r.autoEnroll === 'boolean';
        if (r.v === 2) {
                if (!devicesOk) throw new DecryptError('payload schema mismatch (devices)');
                if (!maxOk) throw new DecryptError('payload schema mismatch (maxDevices)');
                if (!autoOk) throw new DecryptError('payload schema mismatch (autoEnroll)');
        } else if (!devicesOk || !maxOk || !autoOk) {
                delete (raw as Record<string, unknown>).devices;
                delete (raw as Record<string, unknown>).maxDevices;
                delete (raw as Record<string, unknown>).autoEnroll;
        }
        return raw as UserPayload;
}

// --- proof-конверт заявок (aad = vsam:proof:v1, БЕЗ userId — §7.1) ---

export interface ProofPayload {
        v: 1;
        userId: string;
        identifier: string;
        ts: number;
}

export const PROOF_AAD = 'vsam:proof:v1';

export async function encryptProof(defaultPassword: string, payload: ProofPayload, opts?: EnvelopeOpts): Promise<Uint8Array> {
        return encryptEnvelope(defaultPassword, PROOF_AAD, JSON.stringify(payload), opts);
}

export async function decryptProof(defaultPassword: string, bytes: Uint8Array, opts?: { iterations?: number }): Promise<ProofPayload> {
        const json = await decryptEnvelope(defaultPassword, PROOF_AAD, bytes, opts);
        let raw: unknown;
        try {
                raw = JSON.parse(json);
        } catch {
                throw new DecryptError('proof is not JSON');
        }
        const r = raw as Record<string, unknown> | null;
        if (!r || typeof r !== 'object' || r.v !== 1 || typeof r.userId !== 'string' || typeof r.identifier !== 'string' || typeof r.ts !== 'number') {
                throw new DecryptError('proof schema mismatch');
        }
        return raw as ProofPayload;
}
