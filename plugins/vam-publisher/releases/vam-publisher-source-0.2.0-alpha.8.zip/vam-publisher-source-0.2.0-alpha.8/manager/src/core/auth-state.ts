// src/core/auth-state.ts — конечный автомат вердиктов доступа (§7.4, FR-3..13).
// ЧИСТАЯ функция reduce(state, event) → { next, probe, effects }: таблица переходов §7.4.
// Расширения к таблице (описаны в комментариях у кейсов) закрыты требованиями FR-11/FR-12
// (истечение/kill-switch проверяются при каждом контакте) и сценариями S7 (восстановление
// после TTL-блокировки): blocked+DECRYPT_OK → ok, KILL_SWITCH/TTL из checking/awaiting.

import type { UserPayload } from './crypto';
import type { ManagerProbe } from './probe';
import type { AuthCache } from './store';

export type { UserPayload } from './crypto';

export type AuthBlockReason =
        | 'revoked'
        | 'expired'
        | 'wrong-password'
        | 'kill-switch'
        | 'ttl'
        | 'channel-error'
        | 'no-password'
        // v0.5 (M2 §4.3): честность вместо «rotated»-лжи: фоновая расшифровка провалилась —
        // мы НЕ знаем, была ли ротация; знает только хозяин. Подсказка — попросить переиздать.
        | 'key-mismatch';

export type InternalStatus = 'unconfigured' | 'awaiting-approval' | 'checking' | 'ok' | 'blocked' | 'degraded-channel';

/** M-15 (план §4.2): валиден ли reason из персистентного кэша (обрезает мусор). */
export function isAuthBlockReason(v: unknown): v is AuthBlockReason {
        return typeof v === 'string' && [
                'revoked', 'expired', 'wrong-password', 'kill-switch', 'ttl', 'channel-error', 'no-password', 'key-mismatch',
        ].includes(v);
}

export interface AuthStateDetail {
        status: InternalStatus;
        reason?: AuthBlockReason;          // только для blocked
        userId?: string;
        checkedAt: number | null;          // последний УСПЕШНЫЙ контакт (расшифровка ok)
        staleAt: number | null;            // последняя сетевая попытка (любой исход)
        channelHead: string | null;        // etag/sha последнего users/<id>.enc
        awaitingSince: number | null;      // с какого момента ждём подтверждения заявки
}

export type AuthEvent =
        | { type: 'CONFIGURED' }
        | { type: 'PULL_START' }
        | { type: 'DECRYPT_OK'; payload: UserPayload; channelHead: string; now: number }
        | { type: 'DECRYPT_FAIL'; context: 'typed' | 'background' }
        | { type: 'USER_NOT_FOUND'; everOk: boolean; channelGone?: boolean }
        // v0.6 (M4): запись расшифрована (пароль верен), но устройство не в реестре
        // записи — расшифровка прошла в main, сюда приходит только факт нарушения.
        | { type: 'DEVICE_MISMATCH' }
        | { type: 'NET_ERROR'; now: number; grace?: boolean }
        | { type: 'CHANNEL_AUTH_ERROR' }
        | { type: 'REQUEST_PUSHED'; now: number }
        | { type: 'KILL_SWITCH' }
        | { type: 'TTL_EXPIRED' }
        | { type: 'ACCESS_EXPIRED' } // v0.5 (M2 §4.2, M-4): локальная проверка expiresAt на тике — без сети
        | { type: 'PASSWORD_TYPED' }
        | { type: 'PASSWORD_FORGOTTEN' };

export type Effect =
        | 'pull-cycle'
        | 'open-rotation-modal'
        | 'open-retry-modal'
        | 'push-request'
        | 'start-approval-polling'
        | 'stop-approval-polling'
        | 'persist-cache'
        | 'notify-subscribers'
        | 'clear-remember';

export interface Transition {
        next: AuthStateDetail;
        probe: ManagerProbe | null;
        effects: Effect[];
}

export function initialAuthState(cache: AuthCache | null): AuthStateDetail {
        // cache.publicStatus 'ok' → ok (checkedAt из кэша); 'blocked' → blocked; 'checking' →
        // awaiting-approval (рестарт во время заявки — поллинг перезапускает main); иначе
        // unconfigured.
        // v0.5 (M2 §4.2, M-15): причина блокировки регидрируется из снапшота — рестарт
        // больше не превращает blocked в «безымянный» до первого pull. 'degraded' →
        // degraded-channel (грейс канала, §4.3).
        if (cache && cache.publicStatus === 'ok') {
                return {
                        status: 'ok',
                        reason: undefined,
                        checkedAt: cache.checkedAt ?? null,
                        staleAt: cache.checkedAt ?? null,
                        channelHead: cache.channelHead ?? null,
                        awaitingSince: null,
                };
        }
        if (cache && (cache.publicStatus === 'blocked' || cache.publicStatus === 'degraded')) {
                const status: InternalStatus = cache.publicStatus === 'degraded' ? 'degraded-channel' : 'blocked';
                return {
                        status,
                        reason: status === 'blocked' && isAuthBlockReason(cache.reason) ? cache.reason : undefined,
                        checkedAt: cache.checkedAt ?? null,
                        staleAt: cache.checkedAt ?? null,
                        channelHead: cache.channelHead ?? null,
                        awaitingSince: null,
                };
        }
        if (cache && cache.publicStatus === 'checking') {
                return {
                        status: 'awaiting-approval',
                        checkedAt: cache.checkedAt ?? null,
                        staleAt: cache.checkedAt ?? null,
                        channelHead: cache.channelHead ?? null,
                        awaitingSince: null,
                };
        }
        return { status: 'unconfigured', checkedAt: null, staleAt: null, channelHead: null, awaitingSince: null };
}

function withStatus(state: AuthStateDetail, patch: Partial<AuthStateDetail>): AuthStateDetail {
        return { ...state, ...patch };
}

function clearVerdict(state: AuthStateDetail): AuthStateDetail {
        // переход в checking: причина блокировки снимается
        return { ...state, status: 'checking', awaitingSince: null, reason: undefined };
}

export function reduce(state: AuthStateDetail, event: AuthEvent): Transition {
        switch (event.type) {
                case 'CONFIGURED': {
                        // unconfigured → checking, probe null (FR-17), pull-cycle.
                        if (state.status === 'unconfigured') {
                                return { next: clearVerdict(state), probe: null, effects: ['pull-cycle'] };
                        }
                        return noChange(state);
                }

                case 'PASSWORD_TYPED': {
                        // unconfigured/awaiting/blocked → checking + pull-cycle (контекст typed задаёт main).
                        if (state.status === 'unconfigured' || state.status === 'awaiting-approval' || state.status === 'blocked') {
                                return { next: clearVerdict(state), probe: null, effects: ['pull-cycle'] };
                        }
                        return noChange(state);
                }

                case 'PULL_START': {
                        // * → checking (кроме awaiting-approval: поллинг продолжается), probe null.
                        if (state.status !== 'awaiting-approval' && state.status !== 'unconfigured') {
                                return { next: clearVerdict(state), probe: null, effects: [] };
                        }
                        if (state.status === 'unconfigured') {
                                // PULL_START без идентичности — внешняя аномалия, состояние не меняем
                                return noChange(state);
                        }
                        return noChange(state);
                }

                case 'DECRYPT_OK': {
                        const expired = event.payload.expiresAt !== null && event.payload.expiresAt < event.now;
                        const next: AuthStateDetail = withStatus(state, {
                                status: expired ? 'blocked' : 'ok',
                                reason: expired ? 'expired' : undefined,
                                userId: event.payload.userId,
                                checkedAt: event.now,
                                channelHead: event.channelHead,
                                awaitingSince: null,
                        });
                        if (state.status === 'awaiting-approval') {
                                return {
                                        next,
                                        probe: expired
                                                ? { present: true, authOk: false, reason: 'access expired' }
                                                : { present: true, authOk: true },
                                        effects: ['stop-approval-polling', 'persist-cache', 'notify-subscribers'],
                                };
                        }
                        if (state.status === 'ok') {
                                // ok → ok: обновление checkedAt/channelHead, probe null (без изменений)
                                return {
                                        next,
                                        probe: null,
                                        effects: expired ? ['persist-cache', 'notify-subscribers'] : ['persist-cache'],
                                };
                        }
                        // checking → ok/blocked(expired); blocked → ok (расширение: восстановление после
                        // TTL/иной блокировки при живом пароле — S7-3 «pull ok → разблокировано»).
                        return {
                                next,
                                probe: expired ? { present: true, authOk: false, reason: 'access expired' } : { present: true, authOk: true },
                                effects: ['persist-cache', 'notify-subscribers'],
                        };
                }

                case 'DECRYPT_FAIL': {
                        // checking/ok → blocked (typed → wrong-password, background → key-mismatch).
                        // awaiting-approval → без изменений (таблица §7.4 молчит: заявка продолжает поллинг).
                        // v0.5 (M2 §4.2): вход в blocked персистится (эффект persist-cache) — M-15:
                        // причина переживает рестарт.
                        // v0.5 (M2 §4.3): фон больше НЕ заявляет «rotated» — мы не знаем причину
                        // (ротация / переиздание / порча записи); честный вердикт — key-mismatch
                        // с подсказкой «попросите хозяина переиздать».
                        if (state.status === 'checking' || state.status === 'ok') {
                                const typed = event.context === 'typed';
                                return {
                                        next: withStatus(state, {
                                                status: 'blocked',
                                                reason: typed ? 'wrong-password' : 'key-mismatch',
                                                awaitingSince: null,
                                        }),
                                        probe: { present: true, authOk: false, reason: typed ? 'wrong password' : 'record key mismatch (ask administrator to re-issue)' },
                                        effects: typed
                                                ? ['notify-subscribers', 'open-retry-modal', 'persist-cache']
                                                : ['notify-subscribers', 'open-rotation-modal', 'persist-cache'],
                                };
                        }
                        return noChange(state);
                }

                case 'USER_NOT_FOUND': {
                        // v0.5.2 (полевой репорт №2): запись 404 при САМОМ нечитаемом канале
                        // (channel.json тоже не отдаётся — токен потерял репозиторий, канал
                        // переименован/умер) — это НЕ отзыв хозяина, это недоступность канала.
                        // Запомненная сессия (main ставит channelGone только при живом remember)
                        // уходит в грейс degraded-channel — «помнить до отзыва» (H-2): отзыв =
                        // запись удалена при ЧИТАЕМОМ channel.json, kill-пин или ротация.
                        if (event.channelGone && event.everOk
                                && (state.status === 'ok' || state.status === 'checking' || state.status === 'degraded-channel')) {
                                const wasLive = state.status === 'ok' || state.status === 'degraded-channel';
                                return {
                                        next: withStatus(state, { status: 'degraded-channel', awaitingSince: null }),
                                        probe: wasLive ? { present: true, authOk: true } : null,
                                        effects: ['notify-subscribers', 'persist-cache'],
                                };
                        }
                        if (event.everOk) {
                                // ok/checking/blocked → blocked revoked (S5: отзыв).
                                if (state.status === 'unconfigured' || state.status === 'awaiting-approval') return noChange(state);
                                return {
                                        next: withStatus(state, { status: 'blocked', reason: 'revoked', awaitingSince: null }),
                                        probe: { present: true, authOk: false, reason: 'access revoked' },
                                        effects: ['notify-subscribers', 'persist-cache'],
                                };
                        }
                        // никогда не был ok: checking → awaiting-approval + push-request (S2).
                        if (state.status === 'checking') {
                                return {
                                        next: withStatus(state, { status: 'awaiting-approval', reason: undefined }),
                                        probe: null,
                                        effects: ['push-request', 'start-approval-polling'],
                                };
                        }
                        // awaiting-approval → awaiting-approval (поллинг продолжается)
                        return noChange(state);
                }

                case 'DEVICE_MISMATCH': {
                        // v0.6 (M4 «device binding light»): пароль верен, но эта машина не
                        // зачислена. НЕ blocked — та же семантика, что у первичной заявки
                        // (USER_NOT_FOUND из checking): доступ на ЭТОМ устройстве не
                        // подтверждён → авто-заявка на зачисление + поллинг одобрения.
                        // Хозяин видит «⚠ вход с нового устройства» в очереди заявок;
                        // права (userHasRights) сняты — fail-closed. Заявка повторно не
                        // плодится: из awaiting-approval переход — noChange (как у заявки).
                        if (state.status === 'unconfigured' || state.status === 'awaiting-approval') return noChange(state);
                        return {
                                next: withStatus(state, { status: 'awaiting-approval', reason: undefined, awaitingSince: null }),
                                probe: null,
                                effects: ['push-request', 'start-approval-polling', 'notify-subscribers', 'persist-cache'],
                        };
                }

                case 'NET_ERROR': {
                        // Сетевые ошибки НЕ блокируют сразу — вердикт живёт до TTL (FR-8).
                        // staleAt обновляется всегда (это последняя сетевая попытка, любой исход).
                        // v0.5.2 (репорт №2): сеть недоступна ≠ отзыв. Если сессия запомнена
                        // (main ставит grace только при пароле из remember + everOk + без
                        // kill-пина) — offline-грейс degraded-channel, права сохраняются;
                        // иначе статус не меняется (TTL-тик вынесет вердикт §4.2).
                        if (event.grace
                                && (state.status === 'ok' || state.status === 'degraded-channel')) {
                                return {
                                        next: withStatus(state, { status: 'degraded-channel', staleAt: event.now, awaitingSince: null }),
                                        probe: { present: true, authOk: true },
                                        effects: ['notify-subscribers', 'persist-cache'],
                                };
                        }
                        if (event.grace && state.status === 'checking') {
                                // typed-попытка при мёртвой сети у запомненного пользователя:
                                // грейс без probe (пароль этой сессии не перепроверен сетью).
                                return {
                                        next: withStatus(state, { status: 'degraded-channel', staleAt: event.now, awaitingSince: null }),
                                        probe: null,
                                        effects: ['notify-subscribers', 'persist-cache'],
                                };
                        }
                        return { next: withStatus(state, { staleAt: event.now }), probe: null, effects: [] };
                }

                case 'CHANNEL_AUTH_ERROR': {
                        // v0.5 (M2 §4.3, M-5): 401/403 — канал деградировал (истёк PAT хозяина),
                        // но это НЕ приговор доступу: вердикт живёт офлайн-грейсом (checkedAt +
                        // ttl, §4.2; после грейса тик заблокирует по TTL). Раньше — мгновенный
                        // blocked: один битый токен отрубал всех легитимных офлайн-пользователей.
                        // degraded-channel ДАЁТ права (userHasRights): enforcement не деградирует
                        // вместе с каналом — политика кэширована локально.
                        // Уже blocked (kill/revoked/…) — деградация канала не «лечит» блок.
                        if (state.status === 'ok' || state.status === 'degraded-channel') {
                                return {
                                        next: withStatus(state, { status: 'degraded-channel', awaitingSince: null }),
                                        probe: { present: true, authOk: true }, // грейс: синк жив, канал чинит хозяин
                                        effects: ['notify-subscribers', 'persist-cache'],
                                };
                        }
                        if (state.status === 'checking') {
                                // никогда не был ok — грейс недоказуем (checkedAt нет): тик заблокирует
                                // по §4.2 сразу; до того честный degraded без probe (FR-17: молчание)
                                return {
                                        next: withStatus(state, { status: 'degraded-channel', awaitingSince: null }),
                                        probe: null,
                                        effects: ['notify-subscribers', 'persist-cache'],
                                };
                        }
                        return noChange(state);
                }

                case 'REQUEST_PUSHED': {
                        // * → awaiting-approval (awaitingSince=now), probe null (FR-17).
                        return {
                                next: withStatus(state, { status: 'awaiting-approval', reason: undefined, awaitingSince: event.now }),
                                probe: null,
                                effects: ['start-approval-polling'],
                        };
                }

                case 'KILL_SWITCH': {
                        // ok → blocked kill-switch (таблица). Расширение по FR-12 («немедленный blocked при
                        // каждом контакте»): из checking — с probe; из awaiting — probe null (FR-17: молчание,
                        // доступ никогда не был подтверждён).
                        // v0.5 (M2 §4.2): persist-cache — kill-вердикт и его причина переживают рестарт
                        // (в дополнение к пину B-2, который main'ом пишется отдельно).
                        if (state.status === 'unconfigured') return noChange(state);
                        const silent = state.status === 'awaiting-approval';
                        return {
                                next: withStatus(state, { status: 'blocked', reason: 'kill-switch', awaitingSince: null }),
                                probe: silent ? null : { present: true, authOk: false, reason: 'kill switch' },
                                effects: ['notify-subscribers', 'persist-cache'],
                        };
                }

                case 'TTL_EXPIRED': {
                        // ok → blocked ttl + probe (таблица); awaiting → blocked ttl, probe null (FR-17).
                        // Расширение: checking (первый вход так и не состоялся) → blocked ttl, probe null.
                        // v0.5 (M2 §4.2): persist-cache — M-15: рестарт сохраняет причину.
                        if (state.status === 'ok' || state.status === 'degraded-channel') {
                                return {
                                        next: withStatus(state, { status: 'blocked', reason: 'ttl' }),
                                        probe: { present: true, authOk: false, reason: 'offline TTL exceeded' },
                                        effects: ['notify-subscribers', 'persist-cache'],
                                };
                        }
                        if (state.status === 'checking' || state.status === 'awaiting-approval') {
                                return {
                                        next: withStatus(state, { status: 'blocked', reason: 'ttl', awaitingSince: null }),
                                        probe: null,
                                        effects: ['notify-subscribers', 'persist-cache'],
                                };
                        }
                        return noChange(state);
                }

                case 'ACCESS_EXPIRED': {
                        // v0.5 (M2 §4.2, M-4): срок доступа (expiresAt из записи) истёк — проверка
                        // ЛОКАЛЬНАЯ, на тике, без сети и без ожидания DECRYPT_OK. Раньше expired
                        // ловился только при успешной расшифровке: канал жив, запись просрочена —
                        // вердикт ok висел до первого pull. Семантика как у DECRYPT_OK-expired,
                        // но источник — снапшот. degraded-channel тоже гасим: грейс канала не
                        // продлевает срок самого доступа (§4.3: грейс ≠ вечность).
                        if (state.status === 'ok' || state.status === 'degraded-channel') {
                                return {
                                        next: withStatus(state, { status: 'blocked', reason: 'expired', awaitingSince: null }),
                                        probe: { present: true, authOk: false, reason: 'access expired' },
                                        effects: ['notify-subscribers', 'persist-cache'],
                                };
                        }
                        return noChange(state);
                }

                case 'PASSWORD_FORGOTTEN': {
                        // * → unconfigured + clear-remember (таблица §7.4; main дополнительно открывает
                        // модалку ввода — пользователь сразу может ввести пароль заново).
                        return {
                                next: {
                                        status: 'unconfigured',
                                        checkedAt: null,
                                        staleAt: null,
                                        channelHead: null,
                                        awaitingSince: null,
                                        userId: state.userId,
                                },
                                probe: null,
                                effects: ['clear-remember'],
                        };
                }
        }
}

function noChange(state: AuthStateDetail): Transition {
        return { next: state, probe: null, effects: [] };
}

export function checkTtl(state: AuthStateDetail, now: number, ttlHours: number): AuthEvent | null {
        // База — checkedAt (при null — staleAt); старше ttl → TTL_EXPIRED (FR-8).
        const base = state.checkedAt ?? state.staleAt;
        if (base === null) return null;
        if (now - base > ttlHours * 3_600_000) return { type: 'TTL_EXPIRED' };
        return null;
}

export function toPublicStatus(s: AuthStateDetail): 'ok' | 'blocked' | 'unset' | 'checking' | 'degraded' {
        // unconfigured → 'unset'; checking|awaiting-approval → 'checking';
        // v0.5 (M2 §4.3): degraded-channel → 'degraded' (грейс канала — отдельный честный статус).
        if (s.status === 'unconfigured') return 'unset';
        if (s.status === 'degraded-channel') return 'degraded';
        if (s.status === 'checking' || s.status === 'awaiting-approval') return 'checking';
        return s.status;
}
