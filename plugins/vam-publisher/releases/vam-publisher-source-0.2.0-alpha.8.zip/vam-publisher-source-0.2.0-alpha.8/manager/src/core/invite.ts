// src/core/invite.ts — код подключения VAMI1 (v0.3): одна строка вместо
// «URL репозитория + токен + идентификатор + пароль». Хозяин собирает код
// (buildChannelInvite / buildUserInvite), пользователь вставляет его в поле
// «Быстрое подключение» — main.applyInviteCode() разбирает и заполняет настройки.
// Формат: 'VAMI1.' + base64url(JSON{ s, o, r, t?, u?, p? }). Код = носитель секрета
// (пароль ± токен канала): передавать только по доверенному каналу, как и пароль.
// Модуль чистый (NFR-1). base64url (A-Z a-z 0-9 - _) не ломается переносами строк
// и clipboard; decode вычищает все пробельные символы (мессенджеры переносят строки).

export interface InvitePayload {
        baseUrl: string;            // https://api.github.com | https://<host>/api/v1
        owner: string;
        repo: string;
        token: string | null;       // опционально: общий токен канала (PAT, скоуп — только репо канала)
        identifier: string | null;  // опционально: логин (идентификатор) пользователя
        password: string | null;    // опционально: пароль доступа, выданный хозяином
}

export const INVITE_PREFIX = 'VAMI1.';

// --- base64url без padding ---

function b64urlEncode(bytes: Uint8Array): string {
        let bin = '';
        for (const b of bytes) bin += String.fromCharCode(b);
        return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function b64urlDecode(s: string): Uint8Array {
        const b64 = s.replace(/-/g, '+').replace(/_/g, '/');
        const padded = b64 + '='.repeat((4 - (b64.length % 4)) % 4);
        const bin = atob(padded);
        const bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        return bytes;
}

// --- кодирование ---

export function encodeInvite(payload: InvitePayload): string {
        const obj: Record<string, string> = { s: payload.baseUrl, o: payload.owner, r: payload.repo };
        if (payload.token) obj.t = payload.token;
        if (payload.identifier) obj.u = payload.identifier;
        if (payload.password) obj.p = payload.password;
        return INVITE_PREFIX + b64urlEncode(new TextEncoder().encode(JSON.stringify(obj)));
}

export function decodeInvite(code: string): InvitePayload | null {
        // null = код повреждён/неполон (вызывающий покажет quickBadCode).
        const compact = code.replace(/\s+/g, ''); // переносы/пробелы из мессенджеров не существуют
        if (compact.length < INVITE_PREFIX.length + 8) return null;
        if (compact.slice(0, INVITE_PREFIX.length).toLowerCase() !== INVITE_PREFIX.toLowerCase()) return null;
        const body = compact.slice(INVITE_PREFIX.length);
        if (!/^[A-Za-z0-9_-]+$/.test(body)) return null;
        let raw: unknown;
        try {
                raw = JSON.parse(new TextDecoder().decode(b64urlDecode(body)));
        } catch {
                return null;
        }
        if (typeof raw !== 'object' || raw === null) return null;
        const r = raw as Record<string, unknown>;
        const str = (v: unknown): string | null => (typeof v === 'string' && v.length > 0 ? v : null);
        const baseUrl = str(r.s);
        const owner = str(r.o);
        const repo = str(r.r);
        if (baseUrl === null || owner === null || repo === null) return null;
        if (!/^https:\/\//.test(baseUrl)) return null; // только https (§7.3)
        return { baseUrl, owner, repo, token: str(r.t), identifier: str(r.u), password: str(r.p) };
}

// --- сборщики (хозяйская сторона) ---

export interface InviteChannelCfg {
        baseUrl: string;
        owner: string;
        repo: string;
        token: string;
}

export function buildChannelInvite(cfg: InviteChannelCfg, opts?: { includeToken?: boolean }): string {
        // Канальный код: без логина/пароля — для самостоятельной регистрации (авто-подтверждение
        // с дефолтным паролем). Пользователь вводит только идентификатор и пароль.
        return encodeInvite({
                baseUrl: cfg.baseUrl,
                owner: cfg.owner,
                repo: cfg.repo,
                token: opts?.includeToken === false ? null : cfg.token,
                identifier: null,
                password: null,
        });
}

export function buildUserInvite(cfg: InviteChannelCfg, identifier: string, password: string, opts?: { includeToken?: boolean }): string {
        // Полный код: одна строка = всё, что нужно пользователю.
        return encodeInvite({
                baseUrl: cfg.baseUrl,
                owner: cfg.owner,
                repo: cfg.repo,
                token: opts?.includeToken === false ? null : cfg.token,
                identifier,
                password,
        });
}

// --- URL канала для человека (обратный parseRepoUrl) ---

export function repoUrlFromCfg(cfg: { baseUrl: string; owner: string; repo: string }): string {
        // github → github.com; gitea/GHE → хост без /api/v1 (gitea) или /api/v3 (GHE).
        if (cfg.baseUrl === 'https://api.github.com') return `https://github.com/${cfg.owner}/${cfg.repo}`;
        const host = cfg.baseUrl.replace(/^https?:\/\//, '').replace(/\/api\/v[13]$/, '');
        return `https://${host}/${cfg.owner}/${cfg.repo}`;
}
