// src/core/diagnostics.ts — v0.5.3 (полевой репорт №3): глубокая диагностика.
//
// Репорт пользователя: «включение доступа всё равно блокируется, даже хотя доступ
// разрешён» — при живом «разрешённом» статусе UI молчит о ПРИЧИНЕ блокировки
// включения. Симптом порождается цепочкой из 5 независимых слоёв (вердикт FSM →
// права → источник политики → интерцептор → замок), и каждый слой до сих пор
// репортировал только «да/нет». Этот модуль — ЧИСТЫЙ рендерер полного отчёта:
// каждый вход решения виден поимённо, секреты маскируются, гипотезы причины
// формулируются детерминированными правилами из фактов (не догадками).
//
// Дизайн-инварианты:
//   • чистота: никакого obsidian/fetch внутри рендера — весь ввод собирает main;
//   • секреты: пароль НИКОГДА не попадает во вход (только булевы), токен
//     маскируется maskToken, remember.bin отдаёт только exists+userIdMatch;
//   • детерминизм: одинаковый вход → одинаковый текст (снимки в тестах);
//   • машинная читаемость: секции нумерованы «=== N. NAME ===», строки фильтруются
//     по префиксу [VAM] в консоли Obsidian (Ctrl+Shift+I).

import { maskToken, classifyChannelFailure } from './channel';
import type { ChannelClient, ChannelFailureKind } from './channel';
import type { ManagerSettings, JournalEntry, DataAdapter } from './store';
import type { PluginPolicy } from './plugin-policy';
import type { AuthStateDetail } from './auth-state';
import type { LockRegistryEntry } from './plugin-lock';
import type { VamGateSnapshot } from '../sdk/vam-bridge';

// --- вход рендера ---

/** Одна строка живого probe канала: что спросили и что ответили. */
export interface ChannelProbeLine {
        path: string;               // 'channel.json' | 'plugins.json' | 'users/<id>.enc' | 'users/' (листинг)
        url: string;                // фактический URL без токена (Authorization-заголовок токен не содержит)
        outcome: 'ok' | 'not-found' | 'not-modified' | 'auth' | 'network' | 'http' | 'unknown';
        httpStatus?: number;        // последний HTTP-код (для auth/http/network со статусом)
        detail: string;             // краткое содержание (kill/ttl, размер записи, число файлов)
}

export interface InterceptorDecision {
        id: string;                 // рантайм-ключ плагина (папка/manifest.id)
        blocked: boolean;
        why: string;                // имя ветки решения (см. main.explainForbiddenRuntimeKey)
}

export interface DiagnosticsInput {
        generatedAt: number;
        managerVersion: string;
        settings: ManagerSettings;
        authState: AuthStateDetail;
        userHasRights: boolean;
        passwordInMemory: boolean;
        passwordFromRemember: boolean;
        everOk: boolean;
        killSwitchPinned: boolean;
        ttlHours: number;
        verdictExpiresAt: number | null;
        metaEtag: string | null;
        pluginsEtag: string | null;
        pluginPolicy: PluginPolicy | null;
        pluginPolicyIsBuiltin: boolean;
        lockEntries: LockRegistryEntry[] | null; // null = модуль замка недоступен
        communityPlugins: string[] | null;       // null = файл не читается
        gate: VamGateSnapshot;
        rememberBin: { exists: boolean; userIdMatch: boolean } | null;
        syncPlugin: { present: boolean; perSession: boolean; minManagerVersion: string | null } | null;
        journal: JournalEntry[];
        interceptor: InterceptorDecision[];
        channelProbe: ChannelProbeLine[] | null; // null = канал не настроен — probe пропущен
        lastRequestError: string | null;
        reasonText: string;                    // локализованный reason (как видит пользователь в UI)
}

// --- утилиты ---

function iso(ts: number): string {
        return new Date(ts).toISOString();
}

function age(ts: number | null, now: number): string {
        if (ts === null) return 'never';
        const h = (now - ts) / 3_600_000;
        if (h < 1) return `${Math.max(0, Math.round((now - ts) / 60_000))}m ago`;
        if (h < 48) return `${h.toFixed(1)}h ago`;
        return `${(h / 24).toFixed(1)}d ago`;
}

function line(s: string): string {
        return `${s}\n`;
}

// --- рендер отчёта ---

export function renderDiagnosticsReport(inp: DiagnosticsInput): string {
        const s = inp.settings;
        const out: string[] = [];
        out.push(line('=== VAM DIAGNOSTICS REPORT ==='));
        out.push(line(`generated: ${iso(inp.generatedAt)}`));
        out.push(line(`manager version: ${inp.managerVersion}`));

        // 1. идентичность
        out.push(line('=== 1. IDENTITY ==='));
        out.push(line(`role: ${s.role}`));
        out.push(line(`identifier: ${s.identifier ?? '—'}`));
        out.push(line(`derivedUserId: ${s.derivedUserId ?? '—'}`));
        if (s.channel) {
                out.push(line(`channel: ${s.channel.baseUrl}/${s.channel.owner}/${s.channel.repo} token=${maskToken(s.channel.token)}`));
        } else {
                out.push(line('channel: not configured'));
        }
        out.push(line(`remember setting: ${s.remember} (optOut=${s.rememberOptOut})`));

        // 2. вердикт
        out.push(line('=== 2. AUTH VERDICT (FSM) ==='));
        out.push(line(`status: ${inp.authState.status}${inp.authState.reason ? ` (reason: ${inp.authState.reason} — UI: ${inp.reasonText})` : ''}`));
        out.push(line(`userHasRights(): ${inp.userHasRights}`));
        out.push(line(`checkedAt: ${inp.authState.checkedAt !== null ? `${iso(inp.authState.checkedAt)} (${age(inp.authState.checkedAt, inp.generatedAt)})` : 'never'}`));
        out.push(line(`staleAt: ${inp.authState.staleAt !== null ? `${iso(inp.authState.staleAt)} (${age(inp.authState.staleAt, inp.generatedAt)})` : 'never'}`));
        out.push(line(`channelHead: ${inp.authState.channelHead ?? '—'}`));
        out.push(line(`passwordInMemory: ${inp.passwordInMemory} (fromRemember: ${inp.passwordFromRemember})`));
        out.push(line(`everOk: ${inp.everOk}; killSwitchPinned: ${inp.killSwitchPinned}`));
        out.push(line(`ttlHours: ${inp.ttlHours}; verdictExpiresAt: ${inp.verdictExpiresAt !== null ? `${iso(inp.verdictExpiresAt)} (${age(inp.verdictExpiresAt, inp.generatedAt)})` : 'none'}`));
        out.push(line(`metaEtag: ${inp.metaEtag ?? '—'}; pluginsEtag: ${inp.pluginsEtag ?? '—'}`));
        if (inp.lastRequestError !== null) out.push(line(`lastRequestError: ${inp.lastRequestError}`));

        // 3. политика
        out.push(line('=== 3. PLUGIN POLICY ==='));
        if (inp.pluginPolicy === null) {
                out.push(line('source: none (no policy — nothing is forbidden; blocking comes only from channel policy entries)'));
        } else {
                out.push(line(`source: ${inp.pluginPolicyIsBuiltin ? 'BUILTIN managed (auto, no channel policy)' : 'CHANNEL (cached from plugins.json)'}`));
                if (inp.pluginPolicy.plugins.length === 0) {
                        out.push(line('entries: none'));
                } else {
                        for (const e of inp.pluginPolicy.plugins) {
                                out.push(line(`entry: ${e.id} action=${e.action}${e.aliases && e.aliases.length > 0 ? ` aliases=[${e.aliases.join(',')}]` : ''}`));
                        }
                }
        }

        // 4. интерцептор: решение на СЕГОДНЯШНИХ входах
        out.push(line('=== 4. ENABLE INTERCEPTOR DECISIONS (would block RIGHT NOW) ==='));
        if (inp.interceptor.length === 0) {
                out.push(line('no plugin ids found in manifests/enabled/community-plugins.json'));
        } else {
                for (const d of inp.interceptor) {
                        out.push(line(`${d.blocked ? 'BLOCK' : 'ALLOW'} ${d.id} — ${d.why}`));
                }
        }

        // 5. реестр замка
        out.push(line('=== 5. LOCK REGISTRY ==='));
        if (inp.lockEntries === null) {
                out.push(line('lock module unavailable'));
        } else if (inp.lockEntries.length === 0) {
                out.push(line('empty (nothing locked)'));
        } else {
                for (const e of inp.lockEntries) {
                        out.push(line(`locked: manifestId=${e.manifestId} folder=${e.folder} wasEnabled=${e.wasEnabled}`));
                }
        }

        // 6. community-plugins.json
        out.push(line('=== 6. COMMUNITY-PLUGINS.JSON ==='));
        if (inp.communityPlugins === null) {
                out.push(line('unreadable/missing'));
        } else if (inp.communityPlugins.length === 0) {
                out.push(line('empty (all plugins disabled)'));
        } else {
                out.push(line(`enabled: ${inp.communityPlugins.join(', ')}`));
        }

        // 7. hook-гейт кастомных плагинов
        out.push(line('=== 7. VAM GATE (what window.__VAM__ tells hook plugins) ==='));
        out.push(line(`status: ${inp.gate.status} reason: ${inp.gate.reason ?? '—'}`));

        // 8. remember.bin
        out.push(line('=== 8. REMEMBER.BIN ==='));
        if (inp.rememberBin === null) {
                out.push(line('not checked (no adapter or read failed)'));
        } else {
                out.push(line(`exists: ${inp.rememberBin.exists}; userIdMatch: ${inp.rememberBin.userIdMatch} (password never printed)`));
        }

        // 9. синк-мост
        out.push(line('=== 9. SYNC PLUGIN BRIDGE ==='));
        if (inp.syncPlugin === null) {
                out.push(line('not probed'));
        } else {
                out.push(line(`present: ${inp.syncPlugin.present}; perSession: ${inp.syncPlugin.perSession}; minManagerVersion: ${inp.syncPlugin.minManagerVersion ?? '—'}`));
        }

        // 10. журнал
        out.push(line('=== 10. JOURNAL (last entries) ==='));
        if (inp.journal.length === 0) {
                out.push(line('empty'));
        } else {
                for (const e of inp.journal) {
                        out.push(line(`${iso(e.ts)} [${e.kind}] ${e.detail}`));
                }
        }

        // 11. живой probe канала
        out.push(line('=== 11. LIVE CHANNEL PROBE ==='));
        if (inp.channelProbe === null) {
                out.push(line('skipped: channel not configured'));
        } else {
                for (const p of inp.channelProbe) {
                        out.push(line(`GET ${p.path} → ${p.outcome}${p.httpStatus !== undefined ? ` (HTTP ${p.httpStatus})` : ''}${p.detail !== '' ? ` | ${p.detail}` : ''}`));
                        out.push(line(`  url: ${p.url}`));
                }
        }

        // 12. гипотезы
        out.push(line('=== 12. TOP HYPOTHESES (rule-based, see sections above) ==='));
        for (const h of buildHypotheses(inp)) out.push(line(`* ${h}`));
        return out.join('');
}

// --- детерминированные гипотезы ---

function buildHypotheses(inp: DiagnosticsInput): string[] {
        const h: string[] = [];
        const probe = inp.channelProbe ?? [];
        const channelProbeLine = probe.find((p) => p.path === 'channel.json');
        const recordLine = probe.find((p) => p.path.startsWith('users/'));

        // H-канал: репозиторий не виден токену — всё 404
        if (channelProbeLine?.outcome === 'not-found' && recordLine?.outcome === 'not-found') {
                h.push('channel.json AND user record are both 404 → the token cannot see the repository: check repo owner/name and fine-grained PAT "Repository access" (must include this repo). Until fixed, every pull looks like "not found" and access can never be confirmed.');
        }
        if (probe.some((p) => p.outcome === 'auth')) {
                h.push('401/403 from the channel → the PAT is rejected (expired/revoked or wrong repo permissions). The administrator must issue a fresh token.');
        }
        if (probe.some((p) => p.outcome === 'network')) {
                h.push('network error on channel probe → GitHub is unreachable from this machine (proxy/VPN/DNS). Offline grace applies only to remembered sessions; a first login cannot be verified without the channel.');
        }

        // H-вердикт: жёсткая блокировка переживает рестарт
        if (inp.authState.status === 'blocked') {
                const r = inp.authState.reason ?? 'no-password';
                if (r === 'revoked') {
                        h.push('verdict=blocked(revoked): the last readable channel state did not contain your record. If the administrator says access IS granted, the channel probe (section 11) shows WHY the record could not be read (404 on everything = token cannot see the repo, not an administrator revocation).');
                } else {
                        h.push(`verdict=blocked(${r}) — this reason survives restarts (persisted cache). With the channel readable again, typing the password re-verifies; with the channel dead, only remember.bin grants offline grace.`);
                }
        }

        // H-грейс: запомненная сессия
        if (inp.authState.status === 'degraded-channel') {
                h.push('verdict=degraded-channel (offline grace): rights are ACTIVE from a remembered session. If enabling still gets blocked, look at section 3 (policy source) and section 4 (interceptor decisions) — a stale cached channel policy keeps its forbidden list while the channel is unreadable.');
        }

        // H-политика: застрявший кэш запрещает вошедшему
        if (inp.userHasRights && inp.pluginPolicy !== null && inp.pluginPolicyIsBuiltin) {
                h.push('builtin managed policy is still active WHILE the user has rights — informational only (v0.5.6: builtin entries are regulated, they never block); this build clears it on the next enforcement pass; if it persists, report section 3 as a bug.');
        }
        if (inp.userHasRights && inp.pluginPolicy !== null && !inp.pluginPolicyIsBuiltin) {
                const forbidden = inp.pluginPolicy.plugins.filter((p) => p.action === 'forbidden');
                if (forbidden.length > 0) {
                        h.push(`stale/actual channel policy still forbids: ${forbidden.map((p) => p.id).join(', ')}. If the administrator already allowed these, the local cache has not refreshed because the channel is unreadable (section 11) — fix channel access or have the administrator re-push plugins.json; after a successful pull the smooth-unlock fires.`);
                }
        }
        if (!inp.userHasRights && inp.pluginPolicy === null) {
                h.push('no rights and no policy → nothing is plugin-blocked by default (v0.5.6: hardcoded managed plugins are tracked, not forbidden); only an explicit forbidden entry in channel policy blocks. Hook-integrated plugins are gated by the verdict (section 7). The blocker is the verdict, not the plugin: fix sections 2 and 11 first.');
        }

        // H-пароль: модалка каждый раз
        if (!inp.passwordInMemory && inp.settings.remember && inp.rememberBin?.exists === false) {
                h.push('remember.bin does not exist although "remember" is on → the session was never remembered on this machine (or the file was deleted). One successful login writes it; without it every restart asks for the password again.');
        }

        // H-канал читаем, но статус не ok
        if (recordLine?.outcome === 'ok' && inp.authState.status !== 'ok' && inp.passwordInMemory) {
                h.push('the user record IS readable but the verdict is not ok → decryption failed (wrong password / administrator re-issued the record). Ask the administrator to re-issue access if the password is definitely correct.');
        }
        if (h.length === 0) h.push('no anomalies detected by the rule set — capture the console trace ([VAM] lines) during the failing action and report it.');
        return h;
}

// --- живой probe канала ---

/** Probe читающими методами того же ChannelClient, что и продакшн-pull:
 *  одинаковые URL/заголовки/ретраи → отчёт показывает ровно то, что видит pull.
 *  Токен в URL не попадает (Authorization-заголовок), маскируем и в отчёте. */
export async function probeChannelConnectivity(
        client: ChannelClient,
        derivedUserId: string | null,
): Promise<ChannelProbeLine[]> {
        const lines: ChannelProbeLine[] = [];
        const baseUrl = (client as unknown as { cfg?: { baseUrl: string; owner: string; repo: string } }).cfg;
        const root = baseUrl ? `${baseUrl.baseUrl}/repos/${baseUrl.owner}/${baseUrl.repo}/contents` : '<unknown-repo>';

        const push = (path: string, outcome: ChannelProbeLine['outcome'], detail: string, httpStatus?: number): void => {
                lines.push({ path, url: `${root}/${path}`, outcome, httpStatus, detail });
        };
        const failure = (path: string, err: unknown): ChannelProbeLine => {
                const kind: ChannelFailureKind = classifyChannelFailure(err);
                const status = err instanceof Error && 'status' in err ? (err as { status?: number }).status : undefined;
                const outcome: ChannelProbeLine['outcome'] = kind === 'auth' ? 'auth' : kind === 'network' ? 'network' : kind === 'http' ? 'http' : 'unknown';
                return { path, url: `${root}/${path}`, outcome, httpStatus: status, detail: err instanceof Error ? err.message : String(err) };
        };

        // channel.json
        try {
                const meta = await client.getChannelMeta();
                if (meta.status === 'ok') push('channel.json', 'ok', `kill=${meta.meta.killSwitch} ttl=${meta.meta.offlineTtlHours}h minVersion=${meta.meta.minManagerVersion}`);
                else if (meta.status === 'not-found') push('channel.json', 'not-found', 'no meta file (kill/TTL pins retained)');
                else push('channel.json', 'not-modified', 'etag cached (file exists)');
        } catch (err) {
                lines.push(failure('channel.json', err));
        }

        // plugins.json
        try {
                const res = await client.getPluginPolicy();
                if (res.status === 'ok') {
                        const p = res.policy;
                        push('plugins.json', 'ok', p === null ? 'file exists but is NOT a valid policy (ignored, fail-closed)' : `entries=${p.plugins.map((e) => `${e.id}:${e.action}`).join(';') || 'none'}`);
                } else if (res.status === 'not-found') push('plugins.json', 'not-found', 'policy file missing (cached policy stays active while repo is unreadable)');
                else push('plugins.json', 'not-modified', 'etag cached');
        } catch (err) {
                lines.push(failure('plugins.json', err));
        }

        // users/<id>.enc
        if (derivedUserId !== null) {
                const path = `users/${derivedUserId}.enc`;
                try {
                        const rec = await client.getUserRecord(derivedUserId);
                        if (rec.status === 'ok') push(path, 'ok', `record found (${rec.bytes.length} bytes) — password check happens on decrypt`);
                        else if (rec.status === 'not-found') push(path, 'not-found', 'NO record for this userId (never approved / revoked / repo invisible to token)');
                        else push(path, 'not-modified', 'etag cached (record exists)');
                } catch (err) {
                        lines.push(failure(path, err));
                }
        }

        // users/ listing — «канал вообще жив?» и сколько записей
        try {
                const listing = await client.listDir('users');
                push('users/', 'ok', `${listing.length} record(s) on channel`);
        } catch (err) {
                lines.push(failure('users/', err));
        }
        return lines;
}

// --- журнал: хвост для отчёта ---

export async function readJournalTail(adapter: DataAdapter, limit: number): Promise<JournalEntry[]> {
        try {
                const raw: unknown = JSON.parse(await adapter.read('manager-journal.json'));
                if (typeof raw === 'object' && raw !== null && Array.isArray((raw as { entries?: unknown }).entries)) {
                        const entries = (raw as { entries: JournalEntry[] }).entries;
                        return entries.slice(-limit);
                }
        } catch {
                // нет файла или битый — пусто
        }
        return [];
}
