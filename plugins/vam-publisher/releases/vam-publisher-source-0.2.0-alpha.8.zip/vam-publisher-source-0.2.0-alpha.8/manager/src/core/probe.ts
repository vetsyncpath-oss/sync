// src/core/probe.ts — мост вердиктов менеджер → синк-плагин (§7.5, FR-16/17).
// ManagerProbe — точная копия типа из src/core/governance.ts синк-плагина (контракт §3.2, НЕ менять).

import type { AuthBlockReason, AuthStateDetail } from './auth-state';

export type ManagerProbe =
        | { present: true; authOk: true }
        | { present: true; authOk: false; reason: string }
        | { present: false; reason: string };

export function reasonText(r: AuthBlockReason): string {
        // Человекочитаемые строки (английский, попадают в Notice синк-плагина — §3.2).
        // v0.5 (M2 §4.3): 'key-mismatch' вместо «password rotated» — честно: мы не знаем
        // причину, знаем только факт «запись не расшифровывается вашим ключом».
        switch (r) {
                case 'revoked':
                        return 'access revoked';
                case 'expired':
                        return 'access expired';
                case 'wrong-password':
                        return 'wrong password';
                case 'kill-switch':
                        return 'kill switch';
                case 'ttl':
                        return 'offline TTL exceeded';
                case 'channel-error':
                        return 'channel unavailable';
                case 'no-password':
                        return 'no password';
                case 'key-mismatch':
                        return 'record key mismatch (ask administrator to re-issue)';
        }
}

export function buildProbe(state: AuthStateDetail): ManagerProbe | null {
        // ok → {present:true, authOk:true}; blocked → {present:true, authOk:false, reason};
        // unconfigured/awaiting-approval/checking → null (FR-17: молчание до первого доказательства).
        // v0.5 (M2 §4.3): degraded-channel → authOk:true — грейс канала: доступ жив,
        // синк работает, канал чинит хозяин (Notice хозяину — на его машине, §4.3).
        if (state.status === 'ok' || state.status === 'degraded-channel') return { present: true, authOk: true };
        if (state.status === 'blocked') {
                return { present: true, authOk: false, reason: reasonText(state.reason ?? 'channel-error') };
        }
        return null;
}

export function unloadProbe(): ManagerProbe {
        return { present: false, reason: 'manager unloaded' };
}
