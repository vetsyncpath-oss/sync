// src/core/plugin-policy.ts — политика контролируемых плагинов.
// v0.5.6: директива владельца — со hardcoded (managed) плагинов снят статус
//   forbidden: встроенная политика отдаёт их «под контролем» (regulated),
//   без входа они НЕ блокируются; запирает только явный forbidden в политике
//   канала. Убраны и «managed-без-входа» ветки интерцептора/isStillForbidden.
// v0.5.5: переработка по результатам аудита v0.5.4 (UI-audit §6.1):
//   • режимов (report/enforce) больше НЕТ — регулировка всегда жёсткая;
//   • действие «required» (обязателен = предупреждение, путаница в терминах)
//     заменено на «regulated» (под контролем) — СТАНДАРТНЫЙ режим записи:
//     плагин просто работает, пользователь сам решает, включён ли он;
//   • «forbidden» (запрещён) оставлен как редкое действие — жёсткая блокировка;
//     в UI хозяина оно скрыто за настройкой «Расширенный режим» (в файле
//     работает всегда, скрытие — только вопрос видимости в редакторе);
//   • файл на канале по-прежнему v:1 + mode:'enforce' — клиенты v0.5.2–0.5.4
//     продолжат блокировать forbidden-записи (совместимость на запись через
//     serializePluginPolicy; чтение mode игнорируется).
// v0.4.6: поддержка aliases — список альтернативных id одного плагина
// (v-clone / v-CLONE / v-sync-plugin; open-llm-chat / v-open-llm / llm-chat).

export type PluginPolicyAction = 'regulated' | 'forbidden';

export interface PluginPolicyEntry {
        id: string;                 // canonical id (главное имя) плагина
        action: PluginPolicyAction; // regulated = под контролем; forbidden = запрещён
        note: string;               // произвольная пометка хозяина (необязательна)
        aliases?: string[];         // v0.4.6: альтернативные id/имена папок (case-insensitive)
}

export interface PluginPolicy {
        v: 1;
        plugins: PluginPolicyEntry[];
}

export const EMPTY_PLUGIN_POLICY: PluginPolicy = { v: 1, plugins: [] };

/** Сериализация для записи на канал. mode:'enforce' в файле — только ради
 *  обратной совместимости старых клиентов (см. шапку); новые клиенты поле
 *  игнорируют: регулировка безусловна. */
export function serializePluginPolicy(policy: PluginPolicy): { v: 1; mode: 'enforce'; plugins: PluginPolicyEntry[] } {
        return { v: 1, mode: 'enforce', plugins: policy.plugins };
}

export interface PluginPolicyViolation {
        id: string;
        action: 'forbidden';
        problem: 'present';
}

export interface PluginPolicyStatus {
        violations: PluginPolicyViolation[];
        ok: boolean;
}

/**
 * v0.4.6: Встроенный список «управляемых плагинов» — тех, которые менеджер
 * отслеживает по умолчанию (синк-плагины и плагины доступа к vault).
 * v0.5.6: hardcoded-плагины НЕ запрещены: они попадают в список «под
 * контролем» (regulated) даже без явной политики канала и без входа —
 * но работают свободно. Жёсткая блокировка возможна только явной
 * forbidden-записью политики канала (решение хозяина).
 *
 * Группы алиасов (один плагин под разными именами):
 *   - v-clone / v-CLONE / v-sync-plugin — синк-плагин клонирования
 *   - open-llm-chat / v-open-llm / llm-chat — LLM-чат с доступом к vault
 *
 * Case-insensitive matching: 'V-CLONE' и 'v-clone' считаются одинаковыми.
 */
export const MANAGED_PLUGIN_GROUPS: { canonicalId: string; aliases: string[] }[] = [
        { canonicalId: 'v-clone', aliases: ['v-clone', 'v-CLONE', 'v-sync-plugin'] },
        { canonicalId: 'open-llm-chat', aliases: ['open-llm-chat', 'v-open-llm', 'llm-chat'] },
];

/**
 * v0.4.6: получить список всех id (canonical + aliases) управляемых плагинов.
 * v0.5.6: используется только для отчётов/отладки — блокирующей роли больше
 * нет (hardcoded-плагины не forbidden).
 */
export function getManagedPluginIds(): string[] {
        const ids: string[] = [];
        for (const group of MANAGED_PLUGIN_GROUPS) {
                ids.push(group.canonicalId);
                for (const alias of group.aliases) {
                        if (!ids.includes(alias)) ids.push(alias);
                }
        }
        return ids;
}

/**
 * v0.4.6: встроенная политика для управляемых плагинов. v0.5.6: записи —
 * «под контролем» (regulated), НЕ forbidden: без входа и без политики канала
 * менеджер показывает hardcoded-плагины в списке «под контролем», но ничего
 * не блокирует. Блокирует только явный forbidden в политике канала.
 * Применяется (локально) когда у пользователя нет подтверждённого доступа;
 * может быть расширена политикой канала (merge).
 */
export function getBuiltinManagedPolicy(): PluginPolicy {
        return {
                v: 1,
                plugins: MANAGED_PLUGIN_GROUPS.map(g => ({
                        id: g.canonicalId,
                        action: 'regulated' as const,
                        note: 'managed plugin (tracked by the manager)',
                        aliases: g.aliases,
                })),
        };
}

export function normalizePluginPolicy(raw: unknown): PluginPolicy | null {
        // null = это не политика (чужой формат / битый JSON): менеджер игнорирует файл,
        // контроль плагинов не применяется. Целостность файла — ответственность хозяина канала.
        // v0.5.5: mode игнорируется (регулировка безусловна); легаси-действие
        // 'required' переводится в 'regulated' — миграция на лету при чтении.
        if (typeof raw !== 'object' || raw === null) return null;
        const r = raw as Record<string, unknown>;
        if (r.v !== 1) return null;
        const plugins: PluginPolicyEntry[] = [];
        const seen = new Set<string>();
        if (Array.isArray(r.plugins)) {
                for (const item of r.plugins) {
                        if (typeof item !== 'object' || item === null) continue;
                        const e = item as Record<string, unknown>;
                        if (typeof e.id !== 'string' || e.id.trim() === '') continue;
                        // v0.5.5: 'required' (легаси, до v0.5.4) → 'regulated'.
                        if (e.action !== 'required' && e.action !== 'forbidden' && e.action !== 'regulated') continue;
                        const id = e.id.trim();
                        if (seen.has(id.toLowerCase())) continue; // дубликат (case-insensitive): первый выигрывает
                        seen.add(id.toLowerCase());
                        // v0.4.6: parse aliases (array of strings, case-insensitive)
                        const aliases: string[] = [];
                        if (Array.isArray(e.aliases)) {
                                for (const a of e.aliases) {
                                        if (typeof a === 'string' && a.trim() !== '' && a.trim().toLowerCase() !== id.toLowerCase()) {
                                                aliases.push(a.trim());
                                        }
                                }
                        }
                        plugins.push({
                                id,
                                action: e.action === 'forbidden' ? 'forbidden' : 'regulated',
                                note: typeof e.note === 'string' ? e.note : '',
                                aliases: aliases.length > 0 ? aliases : undefined,
                        });
                }
        }
        return { v: 1, plugins };
}

/**
 * v0.4.6: получить все id, которые матчутся с entry (id + aliases, case-insensitive).
 */
export function getEntryAllIds(entry: PluginPolicyEntry): string[] {
        const ids = [entry.id];
        if (entry.aliases) {
                for (const alias of entry.aliases) {
                        if (!ids.some(i => i.toLowerCase() === alias.toLowerCase())) {
                                ids.push(alias);
                        }
                }
        }
        return ids;
}

export function evaluatePluginPolicy(policy: PluginPolicy, enabledIds: string[]): PluginPolicyStatus {
        // enabledIds — идентификаторы ВКЛЮЧЁННЫХ плагинов Obsidian (ключи app.plugins.plugins).
        // v0.5.5: нарушение ровно одно — «запрещённый плагин включён». Записи «под
        // контролем» (regulated) НИКОГДА не нарушают: пользователь сам решает,
        // включён ли плагин (требование заказчика: «работают, если сам пользователь
        // их не отключил вручную» — и не принуждать, если отключил).
        const enabledLower = new Set(enabledIds.map(id => id.toLowerCase()));
        const violations: PluginPolicyViolation[] = [];
        for (const entry of policy.plugins) {
                if (entry.action !== 'forbidden') continue;
                const allIds = getEntryAllIds(entry);
                const isEnabled = allIds.some(id => enabledLower.has(id.toLowerCase()));
                if (isEnabled) {
                        violations.push({ id: entry.id, action: 'forbidden', problem: 'present' });
                }
        }
        return { violations, ok: violations.length === 0 };
}

/**
 * v0.4.6: объединить политику канала со встроенной managed-политикой.
 * Если в политике канала уже есть плагин с таким id (или alias) — не дублируем.
 * Если нет — добавляем из managed-политики (v0.5.6: как regulated-запись —
 * отображение/трекинг, блокировки managed больше не добавляют).
 */
export function mergeWithBuiltinManagedPolicy(channelPolicy: PluginPolicy): PluginPolicy {
        const seenLower = new Set<string>();
        for (const entry of channelPolicy.plugins) {
                seenLower.add(entry.id.toLowerCase());
                if (entry.aliases) {
                        for (const a of entry.aliases) seenLower.add(a.toLowerCase());
                }
        }
        const managedPolicy = getBuiltinManagedPolicy();
        const merged = [...channelPolicy.plugins];
        for (const managed of managedPolicy.plugins) {
                const allIds = getEntryAllIds(managed);
                const alreadyPresent = allIds.some(id => seenLower.has(id.toLowerCase()));
                if (!alreadyPresent) {
                        merged.push(managed);
                }
        }
        return { v: 1, plugins: merged };
}
