// src/core/channel.ts — REST-клиент credentials-канала (GitHub/GHE/Gitea, §7.3).
// Contents API: users/<id>.enc, requests/<uuid>.json, channel.json. Транспортные правила:
// Bearer-токен; ETag/304-кэш; ретраи только 429/5xx (3 ретрая, паузы 1000/2000/4000 мс);
// 401/403 → ChannelAuthError без ретраев; таймаут 15 с (AbortController). Токен в логах
// маскируется, пароль сюда не попадает вообще (NFR-7/8). Модуль чистый (NFR-1).

import { b64ToBytes, bytesToB64 } from './crypto';
import type { ChannelCfg } from './store';
import { normalizePluginPolicy, serializePluginPolicy } from './plugin-policy';
import type { PluginPolicy } from './plugin-policy';

export type { ChannelCfg } from './store';

// --- парсинг URL репозитория (FR-2) ---

export interface ParsedRepo {
        baseUrl: string;
        owner: string;
        repo: string;
}

export function parseRepoUrl(input: string): ParsedRepo | null {
        const s = input.trim();
        // github.com → публичный API
        let m = /^https?:\/\/github\.com\/([\w.-]+)\/([\w.-]+?)(?:\.git)?\/?$/i.exec(s);
        if (m) return { baseUrl: 'https://api.github.com', owner: m[1], repo: m[2] };
        // прочий хост → Gitea-конвенция https://<host>/api/v1
        m = /^https?:\/\/([^/\s]+)\/([\w.-]+)\/([\w.-]+?)(?:\.git)?\/?$/i.exec(s);
        if (m && m[1].toLowerCase() !== 'github.com') {
                return { baseUrl: `https://${m[1]}/api/v1`, owner: m[2], repo: m[3] };
        }
        return null;
}

// --- ошибки ---

export class ChannelError extends Error {
        constructor(message: string) {
                super(message);
                this.name = 'ChannelError';
        }
}

export class ChannelAuthError extends ChannelError {
        constructor(message = 'channel auth failed (401/403)') {
                super(message);
                this.name = 'ChannelAuthError';
        }
}

export class ChannelNetworkError extends ChannelError {
        // status — HTTP-код последнего ответа (для диагностики: 409 = пустой репозиторий,
        // 404 = репозиторий не виден токену и т.д.); undefined при сетевом сбое/таймауте.
        constructor(message = 'channel network error', public readonly status?: number) {
                super(message);
                this.name = 'ChannelNetworkError';
        }
}

// --- метаданные канала (§8.3) ---

export interface ChannelMeta {
        v: 1;
        minManagerVersion: string;
        killSwitch: boolean;
        offlineTtlHours: number;
}

export const DEFAULT_CHANNEL_META: ChannelMeta = {
        v: 1,
        minManagerVersion: '0.1.0',
        killSwitch: false,
        offlineTtlHours: 48,
};

export function normalizeChannelMeta(raw: unknown): ChannelMeta {
        if (typeof raw !== 'object' || raw === null) return { ...DEFAULT_CHANNEL_META };
        const r = raw as Record<string, unknown>;
        if (r.v !== undefined && r.v !== 1) throw new ChannelError('unsupported channel.json version');
        return {
                v: 1,
                minManagerVersion: typeof r.minManagerVersion === 'string' ? r.minManagerVersion : DEFAULT_CHANNEL_META.minManagerVersion,
                killSwitch: r.killSwitch === true,
                offlineTtlHours:
                        typeof r.offlineTtlHours === 'number' && Number.isFinite(r.offlineTtlHours) && r.offlineTtlHours > 0
                                ? r.offlineTtlHours
                                : DEFAULT_CHANNEL_META.offlineTtlHours,
        };
}

// --- клиент ---

const REQUEST_TIMEOUT_MS = 15_000;        // NFR-7
const RETRY_DELAYS_MS = [1000, 2000, 4000]; // 3 ретрая для 429/5xx (§7.3-6)
const LOG_PREFIX = '[VaultAccessManager]';

export function maskToken(token: string): string {
        // 'ghp_abc…' → 'ghp_***' — для логов (NFR-8)
        return `${token.slice(0, 4)}***`;
}

interface ChannelResponse {
        status: number;
        headers: { get(name: string): string | null };
        json(): Promise<unknown>;
        arrayBuffer(): Promise<ArrayBuffer>;
}

export interface ChannelDeps {
        fetchImpl?: typeof fetch;
        sleep?: (ms: number) => Promise<void>;
        now?: () => number;
}

type FileResult =
        | { status: 'ok'; bytes: Uint8Array; etag: string }
        | { status: 'not-found' }
        | { status: 'not-modified' };

export class ChannelClient {
        private readonly cfg: ChannelCfg;
        private readonly fetchImpl: typeof fetch;
        private readonly sleep: (ms: number) => Promise<void>;
        readonly now: () => number;

        constructor(cfg: ChannelCfg, deps?: ChannelDeps) {
                this.cfg = cfg;
                // v0.3.2: fetch в браузере/Electron — метод Window с brand-check: вызов
                // с чужим this («this.fetchImpl(...)» из strict-контекста класса) бросает
                // «Failed to execute 'fetch' on 'Window': Illegal invocation» (Obsidian).
                // Node-fetch брендов не проверяет, поэтому bind безвреден и для моков тестов.
                this.fetchImpl = (deps?.fetchImpl ?? fetch).bind(globalThis);
                this.sleep = deps?.sleep ?? ((ms) => new Promise<void>((resolve) => setTimeout(resolve, ms)));
                this.now = deps?.now ?? (() => Date.now());
        }

        // URL: ${baseUrl}/repos/${owner}/${repo}/contents/${path} (§7.3-1, TC-26)
        private url(path: string): string {
                const { baseUrl, owner, repo } = this.cfg;
                const segments = path.split('/').map((s) => encodeURIComponent(s)).join('/');
                return `${baseUrl}/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/contents/${segments}`;
        }

        private async request(
                method: 'GET' | 'PUT' | 'DELETE',
                path: string,
                opts: { accept: 'raw' | 'json'; etag?: string | null; body?: unknown },
        ): Promise<ChannelResponse> {
                const url = this.url(path);
                const headers: Record<string, string> = {
                        Authorization: `Bearer ${this.cfg.token}`,
                        // v0.3.4: для «json»-запросов — нейтральный application/json. Специфичный
                        // application/vnd.github+json на части хостов/прокси ломает контент-неготиацию
                        // contents-API: вместо метаданных приходило ТЕЛО файла (см. putFile).
                        Accept: opts.accept === 'raw' ? 'application/vnd.github.raw' : 'application/json',
                };
                if (opts.etag) headers['If-None-Match'] = opts.etag;
                const init: RequestInit = {
                        method,
                        headers,
                        signal: undefined as unknown as AbortSignal,
                };
                if (opts.body !== undefined) {
                        init.body = JSON.stringify(opts.body);
                        headers['Content-Type'] = 'application/json';
                }

                // Таймаут 15 с на каждую попытку (AbortController, NFR-7).
                const ctrl = new AbortController();
                init.signal = ctrl.signal;
                const timer = setTimeout(() => ctrl.abort(), REQUEST_TIMEOUT_MS);

                let attempt = 0;
                try {
                        while (true) {
                                let res: ChannelResponse;
                                try {
                                        res = (await this.fetchImpl(url, init as Parameters<typeof fetch>[1])) as unknown as ChannelResponse;
                                } catch (err) {
                                        // Сетевая ошибка / таймаут-abort — ретраев нет (только 429/5xx, §7.3-6).
                                        throw new ChannelNetworkError(`network error: ${err instanceof Error ? err.message : String(err)}`);
                                }
                                if (res.status === 401 || res.status === 403) {
                                        throw new ChannelAuthError(`HTTP ${res.status} (token ${maskToken(this.cfg.token)})`);
                                }
                                if (res.status === 429 || res.status >= 500) {
                                        if (attempt < RETRY_DELAYS_MS.length) {
                                                console.debug(`${LOG_PREFIX} channel ${method} ${path} → ${res.status}, retry ${attempt + 1}`);
                                                await this.sleep(RETRY_DELAYS_MS[attempt]);
                                                attempt += 1;
                                                continue;
                                        }
                                        throw new ChannelNetworkError(`HTTP ${res.status} after ${attempt} retries`, res.status);
                                }
                                // 200/201/204/304/404 и прочие статусы отдаются вызывающему коду;
                                // неожидаемые 4xx (409/422…) — сразу ChannelNetworkError со статусом.
                                if (res.status >= 400 && res.status !== 404) {
                                        throw new ChannelNetworkError(`HTTP ${res.status}`, res.status);
                                }
                                return res;
                        }
                } finally {
                        clearTimeout(timer);
                }
        }

        // --- GET файла как raw-байтов (users/<id>.enc, requests/<uuid>.json) ---

        async getFile(path: string, etag?: string | null): Promise<FileResult> {
                const res = await this.request('GET', path, { accept: 'raw', etag });
                if (res.status === 304) return { status: 'not-modified' };
                if (res.status === 404) return { status: 'not-found' };
                const bytes = new Uint8Array(await res.arrayBuffer());
                const etagOut = res.headers.get('ETag') ?? '';
                // v0.3.4: Gitea/Forgejo и часть прокси игнорируют raw-media-type и на запрос
                // файла возвращают JSON-метаданные {content: <base64>, encoding: 'base64'}.
                // Распознаём такой ответ и декодируем content. Настоящий raw-ответ (конверт
                // VSAM или JSON канала) полей content+encoding не имеет и проходит как есть.
                if (bytes.length > 0) {
                        try {
                                const parsed = JSON.parse(new TextDecoder().decode(bytes)) as unknown;
                                if (
                                        parsed !== null && typeof parsed === 'object' && !Array.isArray(parsed) &&
                                        typeof (parsed as Record<string, unknown>).content === 'string' &&
                                        (parsed as Record<string, unknown>).encoding === 'base64'
                                ) {
                                        return { status: 'ok', bytes: b64ToBytes((parsed as Record<string, unknown>).content as string), etag: etagOut };
                                }
                        } catch {
                                // бинарный/не-JSON ответ — нормальный raw-путь
                        }
                }
                return { status: 'ok', bytes, etag: etagOut };
        }

        async getUserRecord(userId: string, etag?: string | null): Promise<FileResult> {
                return this.getFile(`users/${userId}.enc`, etag);
        }

        // --- листинг директории (users | requests) ---

        async listDir(path: 'users' | 'requests'): Promise<Array<{ name: string; sha: string }>> {
                const res = await this.request('GET', path, { accept: 'json' });
                if (res.status === 404) return [];
                const body = await res.json();
                if (!Array.isArray(body)) throw new ChannelNetworkError('listDir: unexpected body');
                return body
                        .filter((item) => typeof item === 'object' && item !== null && (item as { type?: string }).type !== 'dir')
                        .map((item) => {
                                const it = item as { name?: unknown; sha?: unknown };
                                return { name: typeof it.name === 'string' ? it.name : '', sha: typeof it.sha === 'string' ? it.sha : '' };
                        })
                        .filter((item) => item.name !== '');
        }

        // --- PUT/DELETE (§7.3-5) ---

        // v0.3.4: sha для PUT/DELETE добывается в два приёма: из метаданных файла, а если
        // хост вместо метаданных отдал тело (наблюдалось на реальных инсталляциях: ответ
        // 200 + содержимое файла → JSON.parse падал с «Unexpected token 'V', "VSAM…"», sha
        // не извлекался → PUT без sha → 422, DELETE с пустым sha → 409) — из ЛИСТИНГА
        // директории: JSON-массив {name, sha} стабильно отдают все хосты (GitHub/GHE/Gitea).
        private async metadataSha(path: string): Promise<{ exists: boolean; sha?: string }> {
                const res = await this.request('GET', path, { accept: 'json' });
                if (res.status === 404) return { exists: false };
                try {
                        const info = (await res.json()) as { sha?: unknown } | null;
                        if (info !== null && typeof info === 'object' && typeof info.sha === 'string') {
                                return { exists: true, sha: info.sha };
                        }
                } catch {
                        // тело — не метаданные (raw-ответ «патологического» хоста)
                }
                return { exists: true };
        }

        private async listingSha(path: string): Promise<string | null> {
                // Надёжный источник sha — листинг родительской директории ('' = корень репо).
                const slash = path.lastIndexOf('/');
                const parent = slash === -1 ? '' : path.slice(0, slash);
                const name = path.slice(slash + 1);
                const res = await this.request('GET', parent, { accept: 'json' });
                if (res.status === 404) return null;
                try {
                        const body = await res.json();
                        if (!Array.isArray(body)) return null;
                        for (const item of body as Array<{ name?: unknown; sha?: unknown }>) {
                                if (item !== null && typeof item === 'object' && item.name === name && typeof item.sha === 'string') {
                                        return item.sha;
                                }
                        }
                } catch {
                        // неожиданное тело листинга
                }
                return null;
        }

        private async putOnce(path: string, bytes: Uint8Array, message: string, sha: string | undefined): Promise<{ sha: string | null }> {
                const res = await this.request('PUT', path, {
                        accept: 'json',
                        body: { message, content: bytesToB64(bytes), sha },
                });
                if (res.status !== 200 && res.status !== 201) throw new ChannelNetworkError(`PUT failed: HTTP ${res.status}`, res.status);
                let outSha: string | null = null;
                try {
                        const body = (await res.json()) as { content?: { sha?: unknown } } | null;
                        if (body && typeof body.content === 'object' && body.content !== null && typeof body.content.sha === 'string') {
                                outSha = body.content.sha;
                        }
                } catch {
                        outSha = null;
                }
                return { sha: outSha };
        }

        async putFile(path: string, bytes: Uint8Array, message: string): Promise<{ sha: string | null }> {
                const meta = await this.metadataSha(path);
                let sha = meta.sha;
                if (meta.exists && sha === undefined) sha = (await this.listingSha(path)) ?? undefined;
                try {
                        return await this.putOnce(path, bytes, message, sha);
                } catch (err) {
                        // 409 (устаревший sha, гонка с параллельной записью) / 422 (sha не
                        // передан для существующего файла) — лечим одним повтором со свежим
                        // sha из листинга.
                        if (!(err instanceof ChannelNetworkError) || (err.status !== 409 && err.status !== 422)) throw err;
                        const fresh = await this.listingSha(path);
                        return this.putOnce(path, bytes, message, fresh ?? undefined);
                }
        }

        private async deleteOnce(path: string, message: string, sha: string | undefined): Promise<void> {
                const res = await this.request('DELETE', path, { accept: 'json', body: { message, sha } });
                // 404 = файла уже нет — идемпотентный успех.
                if (res.status !== 200 && res.status !== 204 && res.status !== 404) {
                        throw new ChannelNetworkError(`DELETE failed: HTTP ${res.status}`, res.status);
                }
        }

        async deleteFile(path: string, message: string): Promise<void> {
                const meta = await this.metadataSha(path);
                if (!meta.exists) return;
                let sha = meta.sha;
                if (sha === undefined) sha = (await this.listingSha(path)) ?? undefined;
                if (sha === undefined) {
                        // файл числится существующим, но sha недоступен ни из метаданных, ни
                        // из листинга — на таких хостах DELETE без sha всё равно отвергается;
                        // считаем отсутствующим (идемпотентно, как и 404).
                        console.debug(`${LOG_PREFIX} deleteFile ${path}: sha unavailable, treating as absent`);
                        return;
                }
                try {
                        await this.deleteOnce(path, message, sha);
                } catch (err) {
                        if (!(err instanceof ChannelNetworkError) || (err.status !== 409 && err.status !== 422)) throw err;
                        const fresh = await this.listingSha(path);
                        if (fresh === null) return; // исчез между попытками — успех
                        await this.deleteOnce(path, message, fresh);
                }
        }

        // --- channel.json (§8.3) ---

        async getChannelMeta(etag?: string | null):
                Promise<{ status: 'ok'; meta: ChannelMeta; etag: string } | { status: 'not-found' } | { status: 'not-modified' }> {
                const res = await this.request('GET', 'channel.json', { accept: 'json', etag });
                if (res.status === 304) return { status: 'not-modified' };
                if (res.status === 404) return { status: 'not-found' };
                const body = (await res.json()) as { content?: unknown } | null;
                if (body === null || typeof body !== 'object') throw new ChannelNetworkError('channel.json: unexpected body');
                let raw: unknown;
                if (typeof body.content === 'string') {
                        // обычный вид: метаданные с base64; переносы строк вычищаем (§7.3-4)
                        try {
                                raw = JSON.parse(new TextDecoder().decode(b64ToBytes(body.content)));
                        } catch {
                                throw new ChannelNetworkError('channel.json: bad base64');
                        }
                } else {
                        // v0.3.4: «сырой» ответ — тело и есть содержимое channel.json (хосты,
                        // отдающие файл вместо метаданных на JSON-запрос)
                        raw = body;
                }
                return { status: 'ok', meta: normalizeChannelMeta(raw), etag: res.headers.get('ETag') ?? '' };
        }

        async putChannelMeta(meta: ChannelMeta): Promise<void> {
                const json = JSON.stringify({ v: 1, minManagerVersion: meta.minManagerVersion, killSwitch: meta.killSwitch, offlineTtlHours: meta.offlineTtlHours });
                await this.putFile('channel.json', new TextEncoder().encode(json), 'Vault Access Manager: update channel.json');
        }

        // --- plugins.json (v0.3, расширение §8.3: контролируемые плагины) ---

        async getPluginPolicy(etag?: string | null):
                Promise<{ status: 'ok'; policy: PluginPolicy | null; etag: string } | { status: 'not-found' } | { status: 'not-modified' }> {
                // policy === null при битом JSON/чужом формате: файл есть, но это не политика —
                // менеджер игнорирует (целостность канала — ответственность хозяина, §2).
                const res = await this.getFile('plugins.json', etag);
                if (res.status === 'not-found') return { status: 'not-found' };
                if (res.status === 'not-modified') return { status: 'not-modified' };
                let raw: unknown;
                try {
                        raw = JSON.parse(new TextDecoder().decode(res.bytes));
                } catch {
                        return { status: 'ok', policy: null, etag: res.etag };
                }
                return { status: 'ok', policy: normalizePluginPolicy(raw), etag: res.etag };
        }

        async putPluginPolicy(policy: PluginPolicy): Promise<void> {
                // v0.5.5: сериализация с mode:'enforce' — файл остаётся читаемым для
                // клиентов v0.5.2–0.5.4 (записи forbidden у них продолжают блокироваться).
                const json = JSON.stringify(serializePluginPolicy(policy));
                await this.putFile('plugins.json', new TextEncoder().encode(json), 'Vault Access Manager: update plugins.json');
        }
}

// --- классификация сбоев канала (диагностика для хозяина, §10.1) ---

export type ChannelFailureKind =
        | 'auth'          // 401/403 — токен отвергнут или без права записи
        | 'empty-repo'    // 409 — репозиторий без единого коммита (Contents API не работает)
        | 'repo-missing'  // 404 на PUT/DELETE — репозитория нет или токен его не видит
        | 'network'       // таймаут/сеть/5xx-после-ретраев
        | 'http'          // прочий неожидаемый HTTP
        | 'unknown';

export function classifyChannelFailure(err: unknown): ChannelFailureKind {
        // 409 на contents-API GitHub означает «Git Repository is empty»: GET/PUT/DELETE в
        // репозитории без коммитов не работают — нужен первый коммит (README при создании).
        // 404 при корректном URL = токен не видит репозиторий (fine-grained PAT: Repository
        // access → Only select repositories без этого репо). Сетевые сбои — status undefined.
        if (err instanceof ChannelAuthError) return 'auth';
        if (err instanceof ChannelNetworkError) {
                if (err.status === 409) return 'empty-repo';
                if (err.status === 404) return 'repo-missing';
                if (err.status === undefined) return 'network';
                return 'http';
        }
        return 'unknown';
}
