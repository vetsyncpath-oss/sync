// src/core/quarantine-sweeper.ts — одноразовые автопочинки (W-C/C-6, Р4; v0.5.1 H-1; v0.5.2 полевой репорт №2).
//
// ПОЧИНКА 1 (.vam-quarantine, v0.4.7): карантин v0.4.7 был неработоспособен
// (двойной префикс путей, C-1) и УДАЛЁН в W-C/C-0. Но на диске пользователей
// может остаться его мусор: .obsidian/plugins/.vam-quarantine/ с папками
// (в т.ч. с двойной вложенностью .vam-quarantine/<id>/.obsidian/plugins/<id>/).
// Это данные пользователей (main.js, data.json) — их надо вернуть в plugins/,
// а не выбросить.
//
// ПОЧИНКА 2 (.vam-manifest, v0.5-beta — v0.5.1 H-1): нейтрализация манифеста
// (rename manifest.json → .vam-manifest) удалена по полевому репорту — застрявшие
// файлы надо вернуть: .vam-manifest → manifest.json (папка снова видна Obsidian).
// Конфликт (живой manifest.json есть) — живой выигрывает, наш маркер-мусор
// удаляется; НИКОГДА не перезаписываем manifest.json.
//
// v0.5.2 (полевой репорт №2 — «manifest sweep failed: can't read property 'queue'»):
// методы DataAdapter вызывались ОТОРВАННЫМИ от объекта (const rename = adapter.rename;
// await rename(...)). Моки харнесса — замыкания без this, и detach прощали; реальный
// Obsidian — прототипные методы: отрыв от this валится TypeError'ом, sweep ронял
// ВСЕ восстановления и (см. main.ts) всё равно помечал миграцию выполненной.
// Теперь: (а) вызовы только через bound-ссылки; (б) если rename недоступен/бросает —
// fallback «read → write → remove» (маленький JSON, портативно везде); (в) провал
// папки → report.failed (НЕ «cleaned»/«conflicts»), флаг миграции вызывающий код
// ставит только при failed=[] и degraded=null — починка повторится на следующем старте.
//
// ОБЩИЙ АЛГОРИТМ (план §3.3 C-6):
//   1. мусора нет → готово (ran:false);
//   2. dry-run: план → в журнал ДО первого переноса (рельс «сначала опишем»);
//   3. перенос по одному файлу/папке (rename, атомарно); КОНФЛИКТ — НЕ
//      перезаписывать никогда: остаётся на месте, фиксация в журнале;
//   4. итог в журнал.
//
// ДЕГРАДАЦИЯ: list/rename недоступны → sweep пропускается, флаг НЕ ставится —
// повтор на следующем старте (окружение может измениться). Один journal-entry на бут.

import type { DataAdapter } from './store';
import { NEUTRALIZED_MANIFEST } from './plugin-lock';

export const QUARANTINE_DIR_NAME = '.vam-quarantine';

// --- v0.5.2: bound-доступ к опциональным методам адаптера ---
// Feature-detect остаётся, но вызов идёт через .bind(adapter): оторванный метод
// в реальном Obsidian читает внутреннее состояние несуществующего this (TypeError).
type ListFn = (path: string) => Promise<{ files: string[]; folders: string[] }>;
type RenameFn = (from: string, to: string) => Promise<void>;

function boundList(adapter: DataAdapter): ListFn | undefined {
        const fn = adapter.list;
        return typeof fn === 'function' ? (fn as unknown as ListFn).bind(adapter) : undefined;
}

function boundRename(adapter: DataAdapter): RenameFn | undefined {
        const fn = adapter.rename;
        return typeof fn === 'function' ? (fn as unknown as RenameFn).bind(adapter) : undefined;
}

export interface SweepReport {
        /** false = карантина нет (или флаг уже стоит — вызывающий не зовёт) — работы не было. */
        ran: boolean;
        /** имена перенесённых папок (как они лягут в plugins/). */
        restored: string[];
        /** имена, оставленные на месте из-за занятого места (правило неперезаписи) — легитимный исход. */
        conflicts: string[];
        /** v0.5.2: имена, чей перенос БРОСИЛ — мусор не тронут, повтор на следующем старте. */
        failed: string[];
        /** путь карантина, если он ещё существует после прохода. */
        leftoverDir: string | null;
        /** причина пропуска (degraded) — null, если всё прошло. */
        degraded: string | null;
}

export interface SweepDeps {
        /** полный vault.adapter (пути от корня vault). */
        adapter: DataAdapter;
        configDir: string;
        pluginsDir?: string;
        onEvent?: (detail: string) => void;
}

function baseName(p: string): string {
        const i = p.lastIndexOf('/');
        return i === -1 ? p : p.slice(i + 1);
}

function errText(err: unknown): string {
        return err instanceof Error ? err.message : String(err);
}

export async function sweepQuarantine(deps: SweepDeps): Promise<SweepReport> {
        const pluginsDir = deps.pluginsDir ?? `${deps.configDir}/plugins`;
        const quarantineDir = `${pluginsDir}/${QUARANTINE_DIR_NAME}`;
        const event = (detail: string): void => {
                try {
                        deps.onEvent?.(detail);
                } catch {
                        // наблюдаемость не роняет починку
                }
        };

        const report: SweepReport = { ran: false, restored: [], conflicts: [], failed: [], leftoverDir: null, degraded: null };

        try {
                if (!(await deps.adapter.exists(quarantineDir))) {
                        return report; // нет мусора — тихо
                }
        } catch (err) {
                report.degraded = `exists failed: ${errText(err)}`;
                return report;
        }

        // --- поиск кандидатов (рекурсивно, снаружи внутрь) ---
        // v0.5.2: bound — detached list в реальном Obsidian TypeError-ится.
        const list = boundList(deps.adapter);
        if (list === undefined) {
                report.degraded = 'adapter.list unavailable';
                event(`quarantine sweep degraded: ${report.degraded} — will retry on next boot`);
                return report;
        }
        const candidates: string[] = []; // пути (vault-относительные) папок-кандидатов
        const walk = async (dir: string): Promise<void> => {
                let entries: { files: string[]; folders: string[] };
                try {
                        entries = await list(dir);
                } catch (err) {
                        event(`quarantine sweep: cannot list '${dir}' (${errText(err)}) — skipped`);
                        return;
                }
                const hasManifest = entries.files.some(f => baseName(f) === 'manifest.json' || baseName(f) === NEUTRALIZED_MANIFEST);
                if (hasManifest) {
                        candidates.push(dir);
                        return; // внешняя папка поглощает вложенность — не углубляемся
                }
                for (const folder of entries.folders) {
                        await walk(folder); // list даёт ПОЛНЫЕ пути (контракт C-1-харнесса/TC-61)
                }
        };
        await walk(quarantineDir);

        report.ran = true;

        // --- dry-run: план в журнал ДО переносов (рельс «сначала опишем, потом сделаем») ---
        if (candidates.length > 0) {
                const plan = candidates.map(c => `${c.slice(quarantineDir.length + 1)} -> ${pluginsDir}/${baseName(c)}`);
                event(`quarantine sweep plan (dry-run): ${plan.join('; ')}`);
        } else {
                event(`quarantine sweep: no plugin candidates in '${quarantineDir}'`);
        }

        // --- переносы: по одной папке, конфликт = остаться на месту ---
        // v0.5.2: bound + честный failed (провал ≠ конфликт: конфликт — решение не
        // перезаписывать, провал — окружение не дало перенести; провал = повтор на старте).
        const rename = boundRename(deps.adapter);
        for (const src of candidates) {
                const name = baseName(src);
                const dst = `${pluginsDir}/${name}`;
                try {
                        if (await deps.adapter.exists(dst)) {
                                report.conflicts.push(name);
                                event(`quarantine sweep conflict: '${pluginsDir}/${name}' already exists — '${name}' left in quarantine (never overwrite)`);
                                continue;
                        }
                        if (rename === undefined) {
                                report.degraded = 'adapter.rename unavailable';
                                event(`quarantine sweep degraded: ${report.degraded} — will retry on next boot`);
                                return report; // флаг не встанет: повтор на следующем старте
                        }
                        await rename(src, dst);
                        report.restored.push(name);
                        event(`quarantine sweep restored: '${name}' -> '${dst}'`);
                } catch (err) {
                        report.failed.push(name);
                        event(`quarantine sweep failed for '${name}' (${errText(err)}) — left in place, will retry on next boot`);
                }
        }

        // --- финал: пустые каталоги убрать снизу вверх (оболочки двойной вложенности),
        // непустой остаток — зафиксировать. adapter.remove снимает только пустые папки —
        // идеальный инструмент: ничего непустого не пропадёт. ---
        const pruneEmptyDirs = async (dir: string): Promise<boolean> => {
                try {
                        let entries = await list(dir);
                        for (const folder of [...entries.folders]) {
                                await pruneEmptyDirs(folder);
                                entries = await list(dir); // перечитать после удаления ребёнка
                        }
                        if (entries.files.length === 0 && entries.folders.length === 0) {
                                try {
                                        await deps.adapter.remove(dir);
                                        return true;
                                } catch {
                                        return false;
                                }
                        }
                } catch {
                        return false;
                }
                return false;
        };
        try {
                await pruneEmptyDirs(quarantineDir);
                if (await deps.adapter.exists(quarantineDir)) {
                        report.leftoverDir = quarantineDir;
                        const remaining = await list(quarantineDir);
                        const names = [...remaining.folders, ...remaining.files].map(f => baseName(f));
                        event(`quarantine sweep: '${quarantineDir}' kept — leftovers: ${names.join(', ')}`);
                } else {
                        event(`quarantine sweep: '${quarantineDir}' cleaned up (empty shells removed)`);
                }
        } catch (err) {
                report.leftoverDir = quarantineDir;
                event(`quarantine sweep: cannot finalize '${quarantineDir}' (${errText(err)})`);
        }

        return report;
}

// ---------------------------------------------------------------------------
// ПОЧИНКА 2 (v0.5.1, H-1): застрявшие .vam-manIFEST от удалённой нейтрализации.
// ---------------------------------------------------------------------------

export interface ManifestSweepReport {
        /** false = маркеров нет (или флаг уже стоит — вызывающий не зовёт). */
        ran: boolean;
        /** папки, где .vam-manifest переименован обратно в manifest.json. */
        restored: string[];
        /** папки, где живой manifest.json уже есть — наш маркер-мусор удалён. */
        cleaned: string[];
        /** v0.5.2: папки, которые восстановить НЕ удалось — повтор на следующем старте. */
        failed: string[];
        /** причина пропуска (degraded) — null, если всё прошло. */
        degraded: string | null;
}

/**
 * Перенос одного маркера в manifest.json. v0.5.2: приоритет — атомарный rename
 * (bound); при его отсутствии/ошибке — перенос контентом (read → write → remove):
 * маленький JSON-файл, копирование тривиально и портативно на любом адаптере
 * (в т.ч. без rename вообще — мобайл/ограниченные окружения). Живой manifest.json
 * вызывающий код проверил ДО вызова — сюда попадаем только когда его нет.
 */
async function restoreMarkerFile(adapter: DataAdapter, marker: string, live: string): Promise<'rename' | 'copy'> {
        const rename = boundRename(adapter);
        if (rename !== undefined) {
                try {
                        await rename(marker, live);
                        return 'rename';
                } catch {
                        // реальный rename бросил (права/файловая система/метод оторван) — контент-fallback
                }
        }
        const content = await adapter.read(marker);
        await adapter.write(live, content);
        await adapter.remove(marker);
        return 'copy';
}

/**
 * Одноразовая автопочинка застрявших .vam-manIFEST: вернуть манифесты видимость
 * Obsidian. Порядок гарантий (main.ts зовёт ДО enforcement):
 *   sweep восстановил manifest.json → если плагин forbidden — lockAllForbidden
 *   запрёт его штатными слоями (disable+scrub), папка остаётся видимой.
 * Правила:
 *   • manifest.json отсутствует → rename маркера обратно (восстановление),
 *     rename недоступен/бросает → контент-fallback (v0.5.2);
 *   • manifest.json жив → маркер — НАШ мусор, удалить (живой выигрывает;
 *     manifest.json не трогаем НИКОГДА);
 *   • провал → report.failed, флаг НЕ ставится — повтор на следующем старте.
 */
export async function sweepNeutralizedManifests(deps: SweepDeps): Promise<ManifestSweepReport> {
        const pluginsDir = deps.pluginsDir ?? `${deps.configDir}/plugins`;
        const event = (detail: string): void => {
                try {
                        deps.onEvent?.(detail);
                } catch {
                        // наблюдаемость не роняет починку
                }
        };
        const report: ManifestSweepReport = { ran: false, restored: [], cleaned: [], failed: [], degraded: null };

        // скан: папки plugins/ с маркером .vam-manifest (bound — v0.5.2)
        const list = boundList(deps.adapter);
        if (list === undefined) {
                report.degraded = 'adapter.list unavailable';
                event(`manifest sweep degraded: ${report.degraded} — will retry on next boot`);
                return report;
        }
        const marked: string[] = [];
        try {
                const entries = await list(pluginsDir);
                for (const folder of entries.folders) {
                        const name = baseName(folder);
                        if (name.startsWith('.')) continue; // dot-папки невидимы для Obsidian — не наши
                        try {
                                if (await deps.adapter.exists(`${pluginsDir}/${name}/${NEUTRALIZED_MANIFEST}`)) {
                                        marked.push(name);
                                }
                        } catch {
                                // exists бросил — пропускаем папку, флаг не критичен
                        }
                }
        } catch (err) {
                report.degraded = `list failed: ${errText(err)}`;
                event(`manifest sweep degraded: ${report.degraded} — will retry on next boot`);
                return report;
        }
        if (marked.length === 0) {
                return report; // чисто — тихо
        }
        report.ran = true;

        // dry-run: план в журнал ДО первого действия (рельс «сначала опишем»)
        const plan = marked.map(f => {
                const dir = `${pluginsDir}/${f}`;
                return `${dir}/${NEUTRALIZED_MANIFEST} -> ${dir}/manifest.json`;
        });
        event(`manifest sweep plan (dry-run): ${plan.join('; ')}`);

        for (const name of marked) {
                const dir = `${pluginsDir}/${name}`;
                const marker = `${dir}/${NEUTRALIZED_MANIFEST}`;
                const live = `${dir}/manifest.json`;
                try {
                        if (await deps.adapter.exists(live)) {
                                // живой манифест выигрывает; маркер — НАШ файл, удаление безопасно
                                await deps.adapter.remove(marker);
                                report.cleaned.push(name);
                                event(`manifest sweep cleaned: stale marker of '${name}' removed (live manifest.json kept)`);
                                continue;
                        }
                        const how = await restoreMarkerFile(deps.adapter, marker, live);
                        report.restored.push(name);
                        event(`manifest sweep restored: '${name}' manifest.json is visible again (${how})`);
                } catch (err) {
                        // v0.5.2: провал = failed (не «cleaned»): флаг миграции не встанет,
                        // следующая загрузка Obsidian повторит попытку.
                        report.failed.push(name);
                        event(`manifest sweep failed for '${name}' (${errText(err)}) — left in place, will retry on next boot`);
                }
        }
        event(`manifest sweep done: ${report.restored.length} restored, ${report.cleaned.length} cleaned, ${report.failed.length} failed`);
        return report;
}
