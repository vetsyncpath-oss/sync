// src/core/store.ts — настройки data.json, remember.bin, журнал, хозяйские данные (§7.2, FR-20/21/26..31).
// Модуль чистый: obsidian не импортируется, работа с файлами — через структурный DataAdapter,
// который main.ts передаёт от vault.adapter (NFR-1/NFR-6). Пароль пользователя в data.json
// ОТСУТСТВИЕТ — только кэш вердикта (FR-29).

import { normalizePluginPolicy } from './plugin-policy';
import type { PluginPolicy } from './plugin-policy';
import { normalizeHookRecords } from './hook-registry';
import type { HookPluginRecord } from './hook-registry';

// --- структурная замена obsidian.DataAdapter (подмножество, нужное менеджеру) ---

export interface DataAdapter {
        read(path: string): Promise<string>;
        write(path: string, data: string): Promise<void>;
        remove(path: string): Promise<void>;
        exists(path: string): Promise<boolean>;
        mkdir(path: string): Promise<void>;
        list?(path: string): Promise<{ files: string[]; folders: string[] }>;
        /** Атомарный перенос файла/поддерева (FileSystemAdapter). НЕ гарантирован у всех
         *  адаптеров — код замка обязан feature-detect (v0.5/W-C, Q-3). */
        rename?(from: string, to: string): Promise<void>;
}

// Адаптер, скоупленный в папку плагина: main.ts передаёт vault.adapter + '.obsidian/plugins/<id>'.
// Контракт: пути снаружи — относительно скоупа. list() у Obsidian возвращает ПОЛНЫЕ пути
// (vault-относительные), поэтому адаптер срезает свой префикс — иначе listOwnerUsers читал бы
// файлы с двойным префиксом и users-local всегда был бы пуст (баг, найден аудитом TC-61).
export function scopeAdapter(base: DataAdapter, dir: string): DataAdapter {
        const join = (p: string) => `${dir}/${p}`;
        const strip = (p: string) => (p.startsWith(`${dir}/`) ? p.slice(dir.length + 1) : p);
        const baseList = base.list?.bind(base);
        return {
                read: (p) => base.read(join(p)),
                write: (p, d) => base.write(join(p), d),
                remove: (p) => base.remove(join(p)),
                exists: (p) => base.exists(join(p)),
                mkdir: (p) => base.mkdir(join(p)),
                list: baseList
                        ? async (p: string) => {
                                const res = await baseList(join(p));
                                return {
                                        files: res.files.map(strip),
                                        folders: res.folders.map(strip),
                                };
                        }
                        : undefined,
        };
}

// --- настройки (§7.2, §8.4) ---

export interface ChannelCfg {
        baseUrl: string;
        owner: string;
        repo: string;
        token: string;
}

export type AuthStatusPublic = 'ok' | 'blocked' | 'unset' | 'checking' | 'degraded';

export interface AuthCache {
        publicStatus: AuthStatusPublic;
        checkedAt: number | null;
        channelHead: string | null;
        ttlHours: number;
        // v0.5 (B-2): kill-пин — однажды увиденный killSwitch живёт в кэше до явной
        // записи killSwitch:false со свежим channel.json. Атака «удалить channel.json»
        // (write-токен у пользователя — принятый риск Р7, вектор C-4) больше не прощает kill.
        killSwitch?: boolean;
        // v0.5 (M2 §4.2): кэш достроен до VerdictSnapshot — поля добавлены, не переписаны.
        reason?: string | null;        // M-15: причина блокировки переживает рестарт
        expiresAt?: number | null;     // M-4: срок доступа из записи — локальная проверка на тике
        policyDigest?: string | null;  // лёгкий анти-откат: дайджест политики на момент вердикта
        // v0.5.1 (H-2): сессия «запомнена» (remember.bin). Запомненная сессия живёт
        // ДО ОТЗЫВА (kill/ротация/expiresAt) — офлайн-TTL её не гасит (требование владельца:
        // «помнить пользователя, пока хозяин не отзовёт доступ»).
        remembered?: boolean;
}

export interface ManagerSettings {
        version: 1;
        role: 'unset' | 'user' | 'owner';
        channel: ChannelCfg | null;              // parseRepoUrl + token
        identifier: string | null;               // как введён (не нормализуется при хранении)
        derivedUserId: string | null;            // кэш shortHashIdentifier
        autoApprove: boolean;                    // owner; default true (FR-23)
        defaultPassword: string | null;          // owner; плагин-папка приватна (NFR-6)
        ownerPassword: { saltB64: string; hashB64: string } | null; // PBKDF2 600k SHA-256 (FR-20)
        remember: boolean;                       // default true (v0.5.1 H-2: «помнить до отзыва»)
        rememberOptOut: boolean;                  // пользователь ЯВНО выключил запоминание
        cache: AuthCache | null;                 // вердикт БЕЗ пароля
        pluginPolicyCache: PluginPolicy | null;  // v0.3.5: последняя политика plugins.json — регуляция на старте без сети
        policyAdvanced: boolean;                 // v0.5.5: показывать действие «запрещён» в UI контроля плагинов (в файле работает всегда)
        knownHookPlugins: HookPluginRecord[];    // v0.5.5: hook-плагины, замеченные менеджером (переживает рестарт)
        migrations: {
                quarantineSwept: boolean;  // v0.5 (W-C/C-6): одноразовая автопочинка мусора v0.4.7
                vamFirstPromptDone: boolean; // v0.5 (M2 §4.4, Р6): «VAM первым» спросили — больше не спрашиваем
                manifestSwept: boolean;   // v0.5.1 (H-1): одноразовая автопочинка застрявших .vam-manIFEST
        };
}

export const DEFAULT_SETTINGS: ManagerSettings = {
        version: 1,
        role: 'unset',
        channel: null,
        identifier: null,
        derivedUserId: null,
        autoApprove: true,
        defaultPassword: null,
        ownerPassword: null,
        remember: true,
        rememberOptOut: false,
        cache: null,
        pluginPolicyCache: null,
        policyAdvanced: false,
        knownHookPlugins: [],
        migrations: { quarantineSwept: false, vamFirstPromptDone: false, manifestSwept: false },
};

function isRecord(v: unknown): v is Record<string, unknown> {
        return v !== null && typeof v === 'object' && !Array.isArray(v);
}

function str(v: unknown): string | null {
        return typeof v === 'string' ? v : null;
}

function normalizeChannelCfg(v: unknown): ChannelCfg | null {
        if (!isRecord(v)) return null;
        if (typeof v.baseUrl !== 'string' || typeof v.owner !== 'string' || typeof v.repo !== 'string' || typeof v.token !== 'string') {
                return null;
        }
        return { baseUrl: v.baseUrl, owner: v.owner, repo: v.repo, token: v.token };
}

const DEFAULT_TTL_HOURS = 48; // FR-8 дефолт; канальный TTL перезапишет (B-1)

function normalizeCache(v: unknown): AuthCache | null {
        // v0.5 (M2 §4.2, M-9/L-11): починка, а не зануление. Раньше любое битое поле
        // → cache=null → весь вердикт (включая kill-пин B-2!) сбрасывался — сброс кэша
        // как fail-open-вектор. Теперь: salvage-подход — salvageable поля сохраняются,
        // битые чинятся дефолтами по направлению fail-closed:
        //   • publicStatus-мусор  → 'blocked' (не unconfigured-сброс);
        //   • ttlHours-мусор      → дефолт 48 (не «нет кэша»);
        //   • checkedAt-мусор     → null — свежесть недоказуема, computeVerdict заблокирует.
        // Совсем не объект — честное «кэша нет» (null), это легитимная свежая установка.
        if (!isRecord(v)) return null;
        const statuses: AuthStatusPublic[] = ['ok', 'blocked', 'unset', 'checking', 'degraded'];
        const status = statuses.includes(v.publicStatus as AuthStatusPublic)
                ? (v.publicStatus as AuthStatusPublic)
                : 'blocked';
        const checkedAt = typeof v.checkedAt === 'number' && Number.isFinite(v.checkedAt) ? v.checkedAt : null;
        const channelHead = typeof v.channelHead === 'string' ? v.channelHead : null;
        const ttlHours = typeof v.ttlHours === 'number' && Number.isFinite(v.ttlHours) && v.ttlHours > 0
                ? v.ttlHours
                : DEFAULT_TTL_HOURS;
        return {
                publicStatus: status,
                checkedAt,
                channelHead,
                ttlHours,
                killSwitch: v.killSwitch === true,
                reason: typeof v.reason === 'string' ? v.reason : null,
                expiresAt: typeof v.expiresAt === 'number' && Number.isFinite(v.expiresAt) ? v.expiresAt : null,
                policyDigest: typeof v.policyDigest === 'string' ? v.policyDigest : null,
                remembered: v.remembered === true,
        };
}

function normalizeOwnerPassword(v: unknown): ManagerSettings['ownerPassword'] {
        if (!isRecord(v)) return null;
        if (typeof v.saltB64 !== 'string' || typeof v.hashB64 !== 'string') return null;
        return { saltB64: v.saltB64, hashB64: v.hashB64 };
}

export function normalizeSettings(raw: unknown): ManagerSettings {
        // Безопасная загрузка: отсутствующие/невалидные поля → дефолты; лишние ключи выбрасываются.
        if (!isRecord(raw) || raw.version !== 1) return { ...DEFAULT_SETTINGS };
        const role = raw.role === 'user' || raw.role === 'owner' ? raw.role : 'unset';
        return {
                version: 1,
                role,
                channel: normalizeChannelCfg(raw.channel),
                identifier: str(raw.identifier),
                derivedUserId: str(raw.derivedUserId),
                autoApprove: typeof raw.autoApprove === 'boolean' ? raw.autoApprove : true,
                defaultPassword: str(raw.defaultPassword),
                ownerPassword: normalizeOwnerPassword(raw.ownerPassword),
                // v0.5.1 (H-2): remember дефолт-ON. Легаси data.json (поле всегда писалось)
                // читается как есть; false у легаси поднимет автозапоминание при первом
                // успешном входе, если пользователь не opted-out (rememberOptOut).
                remember: typeof raw.remember === 'boolean' ? raw.remember : true,
                rememberOptOut: raw.rememberOptOut === true,
                cache: normalizeCache(raw.cache),
                pluginPolicyCache: normalizePluginPolicy(raw.pluginPolicyCache), // битый кэш → null, контроль по сети
                // v0.5.5: легаси-кэш v0.5.4 (mode/required) мигрирует при чтении —
                // normalizePluginPolicy; policyAdvanced = только видимость UI.
                policyAdvanced: raw.policyAdvanced === true,
                knownHookPlugins: normalizeHookRecords(raw.knownHookPlugins),
                migrations: {
                        quarantineSwept: isRecord(raw.migrations) && raw.migrations.quarantineSwept === true,
                        vamFirstPromptDone: isRecord(raw.migrations) && raw.migrations.vamFirstPromptDone === true,
                        manifestSwept: isRecord(raw.migrations) && raw.migrations.manifestSwept === true,
                },
        };
}

// --- remember.bin (FR-28, §8.5) ---
// utf-8: 'VSAR1\n' + base64(utf8(JSON {"userId","password"})). Обфускация БЕЗ шифрования.

const REMEMBER_PREFIX = 'VSAR1\n';
const REMEMBER_FILE = 'remember.bin';

export interface RememberedSecret {
        userId: string;
        password: string;
}

function b64encode(s: string): string {
        const bytes = new TextEncoder().encode(s);
        let bin = '';
        for (const b of bytes) bin += String.fromCharCode(b);
        return btoa(bin);
}

function b64decode(s: string): string {
        const bin = atob(s.replace(/\s+/g, ''));
        const bytes = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        return new TextDecoder().decode(bytes);
}

export async function readRemember(adapter: DataAdapter): Promise<RememberedSecret | null> {
        // Нет файла / битый префикс / битый base64 / битый JSON → null (молча; дальше — модалка ввода).
        try {
                const text = await adapter.read(REMEMBER_FILE);
                if (!text.startsWith(REMEMBER_PREFIX)) return null;
                const parsed: unknown = JSON.parse(b64decode(text.slice(REMEMBER_PREFIX.length)));
                if (typeof parsed !== 'object' || parsed === null) return null;
                const r = parsed as Record<string, unknown>;
                if (typeof r.userId !== 'string' || typeof r.password !== 'string') return null;
                return { userId: r.userId, password: r.password };
        } catch {
                return null;
        }
}

export async function writeRemember(adapter: DataAdapter, secret: RememberedSecret): Promise<void> {
        const json = JSON.stringify({ userId: secret.userId, password: secret.password });
        await adapter.write(REMEMBER_FILE, REMEMBER_PREFIX + b64encode(json));
}

export async function forgetRemember(adapter: DataAdapter): Promise<void> {
        // Удаление файла; ошибки глотаются.
        try {
                if (await adapter.exists(REMEMBER_FILE)) await adapter.remove(REMEMBER_FILE);
        } catch {
                // молча
        }
}

// --- хозяйский пароль (FR-20): PBKDF2 600k SHA-256 ---

const OWNER_KDF_ITERATIONS = 600_000;

async function pbkdf2B64(password: string, saltB64: string, iterations: number): Promise<string> {
        const saltBytes = Uint8Array.from(atob(saltB64), (c) => c.charCodeAt(0));
        const baseKey = await crypto.subtle.importKey('raw', new TextEncoder().encode(password) as BufferSource, 'PBKDF2', false, ['deriveBits']);
        const bits = await crypto.subtle.deriveBits(
                { name: 'PBKDF2', salt: saltBytes as BufferSource, iterations, hash: 'SHA-256' },
                baseKey,
                256,
        );
        const bytes = new Uint8Array(bits);
        let bin = '';
        for (const b of bytes) bin += String.fromCharCode(b);
        return btoa(bin);
}

export async function hashOwnerPassword(pw: string): Promise<{ saltB64: string; hashB64: string }> {
        const salt = crypto.getRandomValues(new Uint8Array(16));
        let bin = '';
        for (const b of salt) bin += String.fromCharCode(b);
        const saltB64 = btoa(bin);
        const hashB64 = await pbkdf2B64(pw, saltB64, OWNER_KDF_ITERATIONS);
        return { saltB64, hashB64 };
}

export async function verifyOwnerPassword(pw: string, stored: { saltB64: string; hashB64: string }): Promise<boolean> {
        try {
                const candidate = await pbkdf2B64(pw, stored.saltB64, OWNER_KDF_ITERATIONS);
                return candidate === stored.hashB64;
        } catch {
                return false;
        }
}

// --- журнал действий (FR-31, §8.7): кольцо 100 + консоль разработчика ---

const JOURNAL_FILE = 'manager-journal.json';
export const JOURNAL_RING = 100;
const JOURNAL_LOG_PREFIX = '[VaultAccessManager]';

export type JournalKind = 'probe' | 'rotation' | 'request' | 'approve' | 'ttl' | 'kill-switch' | 'config' | 'owner' | 'plugins' | 'device';

export interface JournalEntry {
        ts: number;
        kind: JournalKind;
        detail: string;
}

interface JournalFile {
        v: 1;
        entries: JournalEntry[];
}

async function readJournalFile(adapter: DataAdapter): Promise<JournalFile> {
        try {
                const raw: unknown = JSON.parse(await adapter.read(JOURNAL_FILE));
                if (typeof raw === 'object' && raw !== null && (raw as JournalFile).v === 1 && Array.isArray((raw as JournalFile).entries)) {
                        return raw as JournalFile;
                }
        } catch {
                // нет файла или битый — начинаем с пустого
        }
        return { v: 1, entries: [] };
}

// v0.4: serial-queue для pushJournalEntry — предотвращает гонку read-modify-write.
// Все вызовы pushJournalEntry сереализуются через Promise-chain, гарантируя что
// параллельные записи (из enforceViolations, watchers, dispatch) не теряются.
let journalWriteQueue: Promise<void> = Promise.resolve();

export async function pushJournalEntry(adapter: DataAdapter, entry: JournalEntry): Promise<void> {
        // Новые записи — в конец; кольцо 100 (старые выталкиваются). Ошибки не роняют менеджер (NFR-7).
        // v0.4: сереализация через queue — fixes BUG-02 (race condition в read-modify-write).
        // v0.6.1 (директива владельца): журнал вынесен из настроек в консоль разработчика —
        // каждая запись зеркалом падает в console.info (префикс [journal]); файл остаётся
        // кольцевым бэкапом для полного отчёта диагностики.
        console.info(JOURNAL_LOG_PREFIX, `[journal] ${new Date(entry.ts).toISOString()} [${entry.kind}] ${entry.detail}`);
        journalWriteQueue = journalWriteQueue.then(async () => {
                try {
                        const journal = await readJournalFile(adapter);
                        journal.entries.push(entry);
                        if (journal.entries.length > JOURNAL_RING) journal.entries = journal.entries.slice(-JOURNAL_RING);
                        await adapter.write(JOURNAL_FILE, JSON.stringify(journal));
                } catch {
                        // молча: журнал не критичен для вердиктов
                }
        }).catch(() => undefined);  // не роняем очередь при ошибке
        return journalWriteQueue;
}

export async function readJournal(adapter: DataAdapter): Promise<JournalEntry[]> {
        return (await readJournalFile(adapter)).entries;
}

// --- локальная хозяйская копия users (FR-21, §8.6) ---
// enc-файл без пароля пользователя не читается — метаданные для таблицы хранит users-local/.

const USERS_LOCAL_DIR = 'users-local';

export interface OwnerUserMeta {
        userId: string;
        note: string;
        issuedAt: number;
        expiresAt: number | null;
        permissions: string[];
        sha: string;
        updatedAt: number;
        // v0.6 (M4): кэш реестра устройств записи (локальная справка для таблицы;
        // источник истины — сама users/<id>.enc, кэш может отставать).
        // undefined — v1-запись без привязки.
        devices?: Array<{ id: string; name: string; addedAt: number }>;
        maxDevices?: number;
        // v0.6.1: false — ручной режим зачисления записи (после сброса устройств);
        // кэш может отставать — истина в записи.
        autoEnroll?: boolean;
}

export async function saveOwnerUserMeta(adapter: DataAdapter, meta: OwnerUserMeta): Promise<void> {
        try {
                await adapter.mkdir(USERS_LOCAL_DIR);
        } catch {
                // уже существует или недоступно — write ниже покажет реальную ошибку
        }
        await adapter.write(`${USERS_LOCAL_DIR}/${meta.userId}.json`, JSON.stringify(meta));
}

export async function removeOwnerUserMeta(adapter: DataAdapter, userId: string): Promise<void> {
        try {
                await adapter.remove(`${USERS_LOCAL_DIR}/${userId}.json`);
        } catch {
                // молча
        }
}

/** v0.6.2: чтение одного users-local/<userId>.json (null — нет/битый). Использует
 *  авто-скан для дедупа уведомлений о повторном использовании кода: свежий кэш
 *  = уведомление уже поднято, повторный прогон скана молчит. */
export async function readOwnerUserMeta(adapter: DataAdapter, userId: string): Promise<OwnerUserMeta | null> {
        try {
                return parseOwnerUserMeta(JSON.parse(await adapter.read(`${USERS_LOCAL_DIR}/${userId}.json`)));
        } catch {
                return null;
        }
}

function parseOwnerUserMeta(raw: unknown): OwnerUserMeta | null {
        if (typeof raw !== 'object' || raw === null) return null;
        const r = raw as Record<string, unknown>;
        if (typeof r.userId !== 'string' || typeof r.note !== 'string' || typeof r.issuedAt !== 'number') return null;
        if (r.expiresAt !== null && typeof r.expiresAt !== 'number') return null;
        if (!Array.isArray(r.permissions) || typeof r.sha !== 'string' || typeof r.updatedAt !== 'number') return null;
        // v0.6 (M4): devices/maxDevices опциональны; битая форма — не повод терять
        // мета (salvage, как у кэша): просто без реестра.
        const meta: OwnerUserMeta = raw as OwnerUserMeta;
        if (r.devices !== undefined && (!Array.isArray(r.devices)
                || !r.devices.every((d) => typeof d === 'object' && d !== null
                        && typeof (d as { id?: unknown }).id === 'string'
                        && typeof (d as { name?: unknown }).name === 'string'
                        && typeof (d as { addedAt?: unknown }).addedAt === 'number'))) {
                meta.devices = undefined;
        }
        if (r.maxDevices !== undefined && (typeof r.maxDevices !== 'number' || !Number.isFinite(r.maxDevices) || r.maxDevices < 1)) {
                meta.maxDevices = undefined;
        }
        if (r.autoEnroll !== undefined && typeof r.autoEnroll !== 'boolean') {
                meta.autoEnroll = undefined;
        }
        return meta;
}

export async function listOwnerUsers(adapter: DataAdapter): Promise<OwnerUserMeta[]> {
        if (!adapter.list) return [];
        let files: string[];
        try {
                files = (await adapter.list(USERS_LOCAL_DIR)).files;
        } catch {
                return [];
        }
        const metas: OwnerUserMeta[] = [];
        for (const file of files) {
                if (!file.endsWith('.json')) continue;
                try {
                        const meta = parseOwnerUserMeta(JSON.parse(await adapter.read(file)));
                        if (meta) metas.push(meta);
                } catch {
                        // битый файл пропускаем
                }
        }
        metas.sort((a, b) => b.updatedAt - a.updatedAt);
        return metas;
}
