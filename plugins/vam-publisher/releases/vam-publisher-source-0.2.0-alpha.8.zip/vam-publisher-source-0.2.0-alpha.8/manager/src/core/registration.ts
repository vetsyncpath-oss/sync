// src/core/registration.ts — заявки на регистрацию, proof, выдача/ротация записей,
// авто-подтверждение хозяином, экспорт бэкапа (FR-4,5,22,23,25,26; §8.2).
// Модуль чистый (NFR-1). Записи users/<id>.enc пишет хозяйская сторона
// (issueUserRecord/autoApproveScan). v0.6.1 — ЕДИНСТВЕННОЕ исключение из §14-2:
// selfEnrollDeviceRecord — пользовательская машина дописывает устройство в СВОЮ
// запись (append-only: все прочие поля переносятся из расшифрованной записи как есть,
// пароль — тот, которым запись только что расшифрована). Директива владельца:
// верный ключ = приглашение уже выдано → ждать одобрения устройства не нужно.
// v0.6.2 — семантика VAM-кода: первое использование (реестр записи ПУСТ) —
// подтверждение автоматическое; ПОВТОРНОЕ использование (к логину уже привязаны
// устройства, код применяется снова) — уведомление администратора ОБЯЗАТЕЛЬНО:
// заявка несёт reuse:true и НЕ удаляется сканом — она висит в очереди до явного
// решения администратора (зачисление при этом остаётся автоматическим).

import { b64ToBytes, bytesToB64, decryptProof, decryptUserRecord, encryptProof, encryptUserRecord, normalizeIdentifier, shortHashIdentifier } from './crypto';
import type { DeviceBinding, ProofPayload, UserPayload } from './crypto';
import type { ChannelClient } from './channel';
import { ChannelError } from './channel';
import { pushJournalEntry, readOwnerUserMeta, saveOwnerUserMeta } from './store';
import type { DataAdapter, OwnerUserMeta } from './store';
import { DEFAULT_MAX_DEVICES } from './device';

// --- встроенный словарь генератора паролей (FR-25): 256 слов, en, lowercase ---

export const WORDS: string[] = [
        'apple', 'amber', 'anchor', 'angle', 'autumn', 'azure', 'bacon', 'bamboo',
        'banana', 'basil', 'beach', 'berry', 'birch', 'bison', 'blade', 'blaze',
        'bloom', 'blue', 'brass', 'brave', 'bread', 'brick', 'bronze', 'brook',
        'brown', 'bubble', 'cabin', 'cactus', 'camel', 'candle', 'canoe', 'canyon',
        'carbon', 'castle', 'cedar', 'cherry', 'chest', 'chill', 'cider', 'cliff',
        'cloak', 'cloud', 'clover', 'coal', 'coast', 'copper', 'coral', 'cotton',
        'crane', 'creek', 'crown', 'crystal', 'curve', 'cycle', 'daisy', 'dawn',
        'delta', 'denim', 'diamond', 'dolphin', 'donut', 'dragon', 'dream', 'drift',
        'eagle', 'earth', 'echo', 'eclipse', 'elder', 'elm', 'ember', 'emerald',
        'evening', 'feather', 'fern', 'fiber', 'flame', 'flint', 'forest', 'fossil',
        'fox', 'frost', 'galaxy', 'garden', 'garnet', 'ginger', 'glacier', 'glass',
        'gleam', 'globe', 'glory', 'granite', 'grape', 'gravel', 'grove', 'harbor',
        'harvest', 'hazel', 'heather', 'hedge', 'heron', 'holly', 'honey', 'horizon',
        'island', 'ivory', 'jade', 'jasper', 'jungle', 'juniper', 'kettle', 'lagoon',
        'lantern', 'lapis', 'larch', 'lattice', 'laurel', 'lava', 'lemon', 'lens',
        'lilac', 'linen', 'lion', 'lotus', 'lucid', 'lumber', 'lunar', 'lynx',
        'magnolia', 'maple', 'marble', 'marina', 'meadow', 'melon', 'meteor', 'mint',
        'mirror', 'mist', 'morning', 'moss', 'mountain', 'nectar', 'needle', 'nest',
        'north', 'nova', 'oak', 'ocean', 'olive', 'onyx', 'opal', 'orbit',
        'orchid', 'otter', 'oval', 'owl', 'paddle', 'palm', 'panda', 'pansy',
        'pebble', 'pepper', 'petal', 'phoenix', 'piano', 'pine', 'planet', 'plum',
        'polar', 'poppy', 'prairie', 'prism', 'puffin', 'quill', 'radar', 'rainbow',
        'rapid', 'raven', 'reef', 'ribbon', 'river', 'robin', 'rocket', 'rose',
        'ruby', 'rustic', 'saffron', 'sage', 'sail', 'salmon', 'sand', 'sapphire',
        'savanna', 'scarlet', 'sequoia', 'shadow', 'shell', 'shore', 'silver', 'sky',
        'slate', 'smoke', 'snow', 'solar', 'sonnet', 'spring', 'spruce', 'star',
        'stone', 'storm', 'straw', 'summer', 'sunset', 'swallow', 'syrup', 'talon',
        'tangelo', 'terrace', 'thicket', 'thunder', 'tide', 'timber', 'topaz', 'torch',
        'trail', 'treasure', 'tree', 'tundra', 'tulip', 'turtle', 'twilight', 'valley',
        'vanilla', 'velvet', 'verbena', 'vertex', 'violet', 'vista', 'walnut', 'whale',
        'wheat', 'willow', 'wind', 'winter', 'wolf', 'wonder', 'wood', 'yarn',
        'yarrow', 'zenith', 'zephyr', 'zinc', 'zodiac', 'zone', 'almond', 'atlas',
];

export function generatePassword(deps?: { randomInt?: (max: number) => number }): string {
        // 4 слова из словаря + 2 цифры: word-word-word-word-42 (FR-25).
        const rnd = deps?.randomInt ?? ((max: number) => crypto.getRandomValues(new Uint32Array(1))[0] % max);
        const words = [0, 1, 2, 3].map(() => WORDS[rnd(WORDS.length)]);
        const digits = 10 + rnd(90); // 10..99
        return `${words.join('-')}-${digits}`;
}

// --- сборка заявки (клон; §8.2) ---

export interface RequestDeps {
        now?: () => number;
        uuid?: () => string;
        envelope?: { iterations?: number; salt?: Uint8Array; nonce?: Uint8Array };
}

export interface RequestDevice {
        id: string;
        name: string;
}

export async function buildRequestFile(
        identifier: string,
        userId: string,
        defaultPassword: string,
        deps?: RequestDeps,
        device?: RequestDevice,
        reuse?: boolean,
): Promise<{ path: string; json: string }> {
        const now = deps?.now ?? (() => Date.now());
        const uuid = deps?.uuid ?? (() => crypto.randomUUID());
        const ts = now();
        const normalized = normalizeIdentifier(identifier);
        // proof-конверт шифруется тем паролем, что ввёл пользователь (он считает его дефолтным).
        const proof = await encryptProof(defaultPassword, { v: 1, userId, identifier: normalized, ts }, deps?.envelope);
        // v2 (M4): заявка с устройства несёт deviceId/deviceName — хозяин видит
        // «вход с нового девайса» и зачисляет устройство в запись. v1-заявка
        // (mobile/легаси-менеджер) — без полей, обе стороны читают обе версии.
        // v0.6.2: reuse=true — ПОВТОРНОЕ использование кода (реестр записи уже не
        // пуст): аддитивное поле, легаси-читатели его игнорируют, новые — обязаны
        // оставить заявку в очереди как уведомление.
        const file = device !== undefined
                ? { v: 2 as const, userId, identifier: normalized, proof: bytesToB64(proof), ts, deviceId: device.id, deviceName: device.name, ...(reuse === true ? { reuse: true } : {}) }
                : { v: 1 as const, userId, identifier: normalized, proof: bytesToB64(proof), ts };
        // v0.6.2: заявки с устройства пишутся в ДЕТЕРМИНИРОВАННЫЙ путь
        // requests/dev-<userId>-<deviceId>.json — одно событие = один файл.
        // Повторная попытка (poll-тик при упавшем PUT записи) и классическая
        // заявка того же эпизода ПЕРЕЗАПИСЫВАЮТ тот же файл, а не плодят uuid-копии;
        // заявка-уведомление и fallback-заявка устройства схлопываются в одну.
        const path = device !== undefined
                ? `requests/dev-${userId}-${device.id}.json`
                : `requests/${uuid()}.json`;
        return { path, json: JSON.stringify(file) };
}

export async function buildAndPushRequest(
        client: ChannelClient,
        identifier: string,
        userId: string,
        password: string,
        deps?: RequestDeps,
        device?: RequestDevice,
        reuse?: boolean,
): Promise<string> {
        const { path, json } = await buildRequestFile(identifier, userId, password, deps, device, reuse);
        await client.putFile(path, new TextEncoder().encode(json), 'Vault Access Manager: registration request');
        return path;
}

// --- парсинг и проверка заявки (хозяин) ---

export interface RequestSummary {
        uuid: string;
        userId: string;
        identifier: string;
        ts: number;
        proofB64: string;
        fileName: string;
        // v2 (M4): заявка с устройства (desktop). undefined — v1-заявка (mobile/легаси).
        deviceId?: string;
        deviceName?: string;
        // v0.6.2: true — ПОВТОРНОЕ использование кода (реестр записи на момент
        // подачи был не пуст). Такая заявка = обязательное уведомление: скан её
        // НЕ удаляет. undefined — первое использование (или легаси-заявка без поля).
        reuse?: boolean;
}

export function parseRequestJson(fileName: string, json: string): RequestSummary | null {
        let raw: unknown;
        try {
                raw = JSON.parse(json);
        } catch {
                return null;
        }
        if (typeof raw !== 'object' || raw === null) return null;
        const r = raw as Record<string, unknown>;
        if ((r.v !== 1 && r.v !== 2) || typeof r.userId !== 'string' || typeof r.identifier !== 'string' || typeof r.proof !== 'string' || typeof r.ts !== 'number') {
                return null;
        }
        const summary: RequestSummary = { uuid: fileName.replace(/\.json$/, ''), userId: r.userId, identifier: r.identifier, ts: r.ts, proofB64: r.proof, fileName };
        if (r.v === 2) {
                // v2 без deviceId/deviceName — битая форма, а не тихий откат к v1
                if (typeof r.deviceId !== 'string' || typeof r.deviceName !== 'string') return null;
                summary.deviceId = r.deviceId;
                summary.deviceName = r.deviceName;
                // v0.6.2: строго true (любой мусор = отсутствие флага — fail-open
                // к семантике первого использования, но не к доступу)
                if (r.reuse === true) summary.reuse = true;
        }
        return summary;
}

export async function verifyProof(proofB64: string, defaultPassword: string, expectedUserId?: string): Promise<ProofPayload | null> {
        // Успешная расшифровка = заявитель знает дефолтный пароль. Любая ошибка → null.
        try {
                const payload = await decryptProof(defaultPassword, b64ToBytes(proofB64));
                if (expectedUserId !== undefined && payload.userId !== expectedUserId) return null;
                return payload;
        } catch {
                return null;
        }
}

// --- выдача/переиздание записи пользователя (хозяин; FR-21/22) ---

export interface IssueParams {
        identifier: string;
        password: string;
        expiresAt: number | null;
        note?: string;
        permissions?: string[];
        userId?: string;
        // v2 (M4): реестр устройств записи. undefined — v1-запись (проверка на
        // пользовательской стороне выключена); [] — активен и пуст; заполнен —
        // допущенные устройства.
        devices?: DeviceBinding[];
        maxDevices?: number;
        // v0.6.1: false — ручной режим зачисления (сброс устройств). undefined/true —
        // новые устройства под капом зачисляются сами. Ротация/переиздание поле НЕ
        // переносят — новый пароль возвращает авто-режим (инцидент закрыт).
        autoEnroll?: boolean;
}

export interface IssueDeps {
        now?: () => number;
        // envelope — только для тестов (быстрый PBKDF2); в продакшене — undefined.
        envelope?: { iterations?: number; salt?: Uint8Array; nonce?: Uint8Array };
}

export async function issueUserRecord(client: ChannelClient, params: IssueParams, deps?: IssueDeps): Promise<OwnerUserMeta> {
        const now = deps?.now ?? (() => Date.now());
        const userId = params.userId ?? (await shortHashIdentifier(params.identifier));
        const payload: UserPayload = {
                v: params.devices !== undefined || params.maxDevices !== undefined ? 2 : 1,
                userId,
                issuedAt: now(),
                expiresAt: params.expiresAt,
                permissions: params.permissions ?? [],
                note: params.note ?? params.identifier,
        };
        if (params.devices !== undefined) payload.devices = params.devices;
        if (params.maxDevices !== undefined) payload.maxDevices = params.maxDevices;
        if (params.autoEnroll !== undefined) payload.autoEnroll = params.autoEnroll;
        const bytes = await encryptUserRecord(params.password, userId, payload, deps?.envelope);
        const { sha } = await client.putFile(`users/${userId}.enc`, bytes, `Vault Access Manager: issue access ${userId}`);
        return {
                userId,
                note: payload.note,
                issuedAt: payload.issuedAt,
                expiresAt: payload.expiresAt,
                permissions: payload.permissions,
                sha: sha ?? '',
                updatedAt: now(),
                devices: params.devices,
                maxDevices: params.maxDevices,
                autoEnroll: params.autoEnroll,
        };
}

// --- само-зачисление устройства (пользовательская сторона; v0.6.1) ---

export interface SelfEnrollResult {
        payload: UserPayload;   // запись с дописанным устройством
        head: string | null;    // sha PUT-ответа (канальный etag новой версии) — null, если PUT не понадобился
}

/** v0.6.1 (директива владельца): новая машина с ВЕРНЫМ паролем зачисляется сразу,
 *  без ожидания одобрения — приглашение уже выдано вместе с ключом. Исключение из
 *  §14-2 узкое и осознанное (см. шапку файла): запись ТОЛЬКО своя, изменение — ТОЛЬКО
 *  append устройства в реестр; права/срок/пароль/режим переносимы из расшифрованной
 *  записи байт-в-байт. Идемпотентно (устройство уже в реестре — PUT не нужен).
 *  Сверх лимита — EnrollLimitError; ручной режим записи здесь НЕ проверяется —
 *  его отсекает вызывающий (main.verdictFromPayload) до вызова. */
export async function selfEnrollDeviceRecord(
        client: ChannelClient,
        userId: string,
        password: string,
        payload: UserPayload,
        device: RequestDevice,
        deps?: EnrollDeps,
): Promise<SelfEnrollResult> {
        const now = deps?.now ?? (() => Date.now());
        const devices = payload.devices ?? [];
        if (devices.some((d) => d.id === device.id)) return { payload, head: null };
        if (devices.length >= (payload.maxDevices ?? DEFAULT_MAX_DEVICES)) {
                throw new EnrollLimitError(`device limit exceeded (${devices.length}/${payload.maxDevices ?? DEFAULT_MAX_DEVICES})`);
        }
        const updated: UserPayload = {
                ...payload,
                devices: [...devices, { id: device.id, name: device.name, addedAt: now() }],
        };
        const bytes = await encryptUserRecord(password, userId, updated, deps?.envelope);
        const { sha } = await client.putFile(`users/${userId}.enc`, bytes, `Vault Access Manager: self device enrollment ${userId}`);
        return { payload: updated, head: sha ?? null };
}

// --- зачисление устройства (хозяин; v0.6 M4) ---

export class EnrollLimitError extends Error {
        constructor(message = 'device limit exceeded') {
                super(message);
                this.name = 'EnrollLimitError';
        }
}

export interface EnrollDeps {
        now?: () => number;
        envelope?: { iterations?: number; salt?: Uint8Array; nonce?: Uint8Array };
}

/** Одобрить заявку «вход с нового устройства»: переиздать запись пользователя,
 *  добавив устройство в реестр (источник истины — сама запись: она расшифровывается
 *  паролем, который хозяин вводит в модалке; локальный кэш users-local не нужен).
 *  Идемпотентно: устройство уже в реестре — заявка просто удаляется.
 *  Ошибки: DecryptError (неверный пароль записи), EnrollLimitError (лимит),
 *  ChannelError (запись/канал недоступны) — вызывающий показывает их пользователю. */
export async function approveDeviceEnrollment(
        client: ChannelClient,
        summary: RequestSummary,
        password: string,
        adapter: DataAdapter | null,
        deps?: EnrollDeps,
): Promise<OwnerUserMeta> {
        if (summary.deviceId === undefined) throw new ChannelError('request has no device');
        const now = deps?.now ?? (() => Date.now());
        const res = await client.getUserRecord(summary.userId);
        if (res.status !== 'ok') throw new ChannelError('user record not found on channel');
        const payload = await decryptUserRecord(password, summary.userId, res.bytes);
        const devices = payload.devices ?? [];
        const maxDevices = payload.maxDevices ?? DEFAULT_MAX_DEVICES;
        const device: DeviceBinding = { id: summary.deviceId, name: summary.deviceName ?? '', addedAt: now() };
        if (devices.some((d) => d.id === device.id)) {
                // уже зачислено (повторная заявка) — переиздание не нужно, заявку убираем
                await client.deleteFile(`requests/${summary.fileName}`, 'Vault Access Manager: device already enrolled');
                return {
                        userId: summary.userId,
                        note: payload.note,
                        issuedAt: payload.issuedAt,
                        expiresAt: payload.expiresAt,
                        permissions: payload.permissions,
                        sha: '',
                        updatedAt: now(),
                        devices,
                        maxDevices: payload.maxDevices,
                        autoEnroll: payload.autoEnroll,
                };
        }
        if (devices.length >= maxDevices) throw new EnrollLimitError(`device limit exceeded (${devices.length}/${maxDevices})`);
        const meta = await issueUserRecord(client, {
                identifier: summary.identifier,
                userId: summary.userId,
                password,
                expiresAt: payload.expiresAt,
                note: payload.note,
                permissions: payload.permissions,
                devices: [...devices, device],
                maxDevices: payload.maxDevices,
                // v0.6.1: одобрение — узкий акт («этой машине можно»), глобальный режим
                // записи не меняет: ручной (после сброса) остаётся ручным.
                autoEnroll: payload.autoEnroll,
        }, { now: () => now(), envelope: deps?.envelope });
        await client.deleteFile(`requests/${summary.fileName}`, 'Vault Access Manager: approve device');
        if (adapter) {
                await saveOwnerUserMeta(adapter, meta);
                await pushJournalEntry(adapter, { ts: now(), kind: 'device', detail: `device approved ${device.name} (${device.id}) for ${summary.userId}` });
        }
        return meta;
}

// --- авто-подтверждение заявок (хозяин; FR-23) ---

export interface ScanResult {
        approved: number;
        details: string[];
        // v0.6.2: identifier-ы, для которых скан ОСТАВИЛ заявку-уведомление о
        // ПОВТОРНОМ использовании кода (обязательное уведомление администратора —
        // директива владельца). Вызывающий показывает Notice: молчать нельзя.
        notified: string[];
}

/** v0.6.2: свеж ли users-local для записи (реестр совпадает с записью)?
 *  Первый прогон скана по reuse-заявке видит отставание → освежает кэш,
 *  пишет журнал и поднимает уведомление; повторные прогоны (админ ещё не
 *  посмотрел очередь) — тихие: заявка уже в очереди, кэш точен, спама нет. */
function localRegistryFresh(local: OwnerUserMeta | null, payload: UserPayload): boolean {
        if (local === null) return false;
        const a = local.devices ?? [];
        const b = payload.devices ?? [];
        if (a.length !== b.length) return false;
        for (let i = 0; i < a.length; i++) {
                if (a[i].id !== b[i].id) return false;
        }
        return local.autoEnroll === payload.autoEnroll && local.maxDevices === payload.maxDevices;
}

export async function autoApproveScan(
        client: ChannelClient,
        defaultPassword: string,
        adapter: DataAdapter | null,
        deps?: { now?: () => number; envelope?: { iterations?: number; salt?: Uint8Array; nonce?: Uint8Array } },
): Promise<ScanResult> {
        const now = deps?.now ?? (() => Date.now());
        const result: ScanResult = { approved: 0, details: [], notified: [] };
        const files = await client.listDir('requests');
        for (const file of files) {
                if (!file.name.endsWith('.json')) continue;
                let summary: RequestSummary | null = null;
                try {
                        const res = await client.getFile(`requests/${file.name}`);
                        if (res.status === 'ok') summary = parseRequestJson(file.name, new TextDecoder().decode(res.bytes));
                } catch {
                        continue;
                }
                if (!summary) continue;
                // Самосогласованность: userId заявки = shortHash(identifier заявки).
                if ((await shortHashIdentifier(summary.identifier)) !== summary.userId) continue;
                // Proof расшифровался дефолтным паролем и привязан к userId заявки.
                const proof = await verifyProof(summary.proofB64, defaultPassword, summary.userId);
                if (!proof) continue;
                // v2 (M4): заявка с устройства — два пути в зависимости от того,
                // существует ли уже запись пользователя.
                if (summary.deviceId !== undefined) {
                        const device: DeviceBinding = { id: summary.deviceId, name: summary.deviceName ?? '', addedAt: now() };
                        let recordStatus: 'ok' | 'absent' | 'unreadable' = 'absent';
                        let payload: UserPayload | null = null;
                        try {
                                const rec = await client.getUserRecord(summary.userId);
                                if (rec.status === 'ok') {
                                        recordStatus = 'ok';
                                        payload = await decryptUserRecord(defaultPassword, summary.userId, rec.bytes);
                                }
                        } catch {
                                // запись есть, но не читается дефолтным паролем (ротация)
                                // или канал дрогнул — ручная очередь, не решение вслепую
                                recordStatus = 'unreadable';
                        }
                        if (recordStatus === 'unreadable') continue;
                        if (recordStatus === 'ok' && payload !== null) {
                                // зачисление устройства в существующую запись
                                const devices = payload.devices ?? [];
                                if (devices.some((d) => d.id === device.id)) {
                                        // v0.6.2 (директива владельца): ПОВТОРНОЕ использование кода —
                                        // уведомление ОБЯЗАТЕЛЬНО. Заявку НЕ удаляем: она висит в очереди
                                        // до явного решения администратора (отклонить/принять к сведению).
                                        // Кэш users-local при этом освежаем — таблица «Пользователи»
                                        // должна показывать реальный реестр. Зачисление уже произошло
                                        // (selfEnroll) — уведомление пост-фактум, но неустранимое.
                                        if (summary.reuse === true) {
                                                try {
                                                        if (adapter !== null) {
                                                                const local = await readOwnerUserMeta(adapter, summary.userId);
                                                                if (!localRegistryFresh(local, payload)) {
                                                                        await saveOwnerUserMeta(adapter, {
                                                                                userId: summary.userId,
                                                                                note: payload.note,
                                                                                issuedAt: payload.issuedAt,
                                                                                expiresAt: payload.expiresAt,
                                                                                permissions: payload.permissions,
                                                                                sha: '',
                                                                                updatedAt: now(),
                                                                                devices: payload.devices,
                                                                                maxDevices: payload.maxDevices,
                                                                                autoEnroll: payload.autoEnroll,
                                                                        });
                                                                        await pushJournalEntry(adapter, { ts: now(), kind: 'device', detail: `code REUSED: device ${device.name} (${device.id}) self-enrolled for ${summary.identifier} (${summary.userId}) — notification kept in queue` });
                                                                        if (!result.notified.includes(summary.identifier)) result.notified.push(summary.identifier);
                                                                }
                                                        } else if (!result.notified.includes(summary.identifier)) {
                                                                // без локального хранилища дедупа нет — уведомляем как новое
                                                                result.notified.push(summary.identifier);
                                                        }
                                                } catch {
                                                        // канальная ошибка по одной заявке не останавливает скан
                                                }
                                                continue;
                                        }
                                        // первое использование кода (v0.6.1): заявка-уведомление уже
                                        // сыграла роль — заявку подчищаем и ОСВЕЖАЕМ users-local:
                                        // само-зачисление обновило запись без хозяина, локальный кэш
                                        // отстаёт — скан доводит его до истины, чтобы таблица
                                        // «Пользователи» показывала реестр «точно».
                                        try {
                                                await client.deleteFile(`requests/${file.name}`, 'Vault Access Manager: device already enrolled');
                                                if (adapter) {
                                                        await saveOwnerUserMeta(adapter, {
                                                                userId: summary.userId,
                                                                note: payload.note,
                                                                issuedAt: payload.issuedAt,
                                                                expiresAt: payload.expiresAt,
                                                                permissions: payload.permissions,
                                                                sha: '',
                                                                updatedAt: now(),
                                                                devices: payload.devices,
                                                                maxDevices: payload.maxDevices,
                                                                autoEnroll: payload.autoEnroll,
                                                        });
                                                        await pushJournalEntry(adapter, { ts: now(), kind: 'device', detail: `device ${device.name} (${device.id}) already enrolled for ${summary.identifier} (${summary.userId}) — registry cache refreshed` });
                                                }
                                        } catch {
                                                // канальная ошибка по одной заявке не останавливает скан
                                        }
                                        continue;
                                }
                                // v0.6.1: ручной режим записи (сброс устройств) — авто-скан НЕ
                                // зачисляет: каждое новое устройство — осознанное решение
                                // хозяина (заявка остаётся в ручной очереди)
                                if (payload.autoEnroll === false) continue;
                                if (devices.length >= (payload.maxDevices ?? DEFAULT_MAX_DEVICES)) continue; // сверх лимита — ручная очередь
                                try {
                                        const meta = await issueUserRecord(client, {
                                                identifier: summary.identifier,
                                                userId: summary.userId,
                                                password: defaultPassword,
                                                expiresAt: payload.expiresAt,
                                                note: payload.note,
                                                permissions: payload.permissions,
                                                devices: [...devices, device],
                                                maxDevices: payload.maxDevices,
                                        }, { now: () => now(), envelope: deps?.envelope });
                                        // v0.6.2: зачислили по заявке с повторным использованием кода —
                                        // уведомление обязательно и после зачисления: заявку НЕ удаляем
                                        // (очередь до явного решения), журнал + notified. Первое
                                        // использование — как раньше: заявка сыграла роль и удалена.
                                        if (summary.reuse === true) {
                                                if (adapter) {
                                                        // users-local пишем и здесь: следующий скан увидит «уже зачислено
                                                        // + свежий кэш» и промолчит (дедуп уведомления)
                                                        await saveOwnerUserMeta(adapter, meta);
                                                        await pushJournalEntry(adapter, { ts: now(), kind: 'device', detail: `code REUSED: device ${device.name} (${device.id}) enrolled for ${summary.identifier} (${summary.userId}) — notification kept in queue` });
                                                }
                                                if (!result.notified.includes(summary.identifier)) result.notified.push(summary.identifier);
                                        } else {
                                                await client.deleteFile(`requests/${file.name}`, 'Vault Access Manager: auto-approve device');
                                                if (adapter) {
                                                        await saveOwnerUserMeta(adapter, meta);
                                                        await pushJournalEntry(adapter, { ts: now(), kind: 'device', detail: `auto-approved device ${device.name} (${device.id}) for ${summary.identifier} (${summary.userId})` });
                                                }
                                        }
                                        result.approved += 1;
                                        result.details.push(`${summary.identifier}/${device.name}`);
                                } catch {
                                        // канальная ошибка по одной заявке не останавливает скан
                                }
                                continue;
                        }
                        // записи нет — новый пользователь: устройство зашивается в запись
                        // сразу («код выдан администратором — данные привязываются к устройству»)
                        try {
                                const meta = await issueUserRecord(client, {
                                        identifier: summary.identifier,
                                        password: defaultPassword,
                                        expiresAt: null,
                                        devices: [device],
                                        maxDevices: DEFAULT_MAX_DEVICES,
                                }, { now: () => now(), envelope: deps?.envelope });
                                // v0.6.2: заявка помечена повторным использованием кода (напр.,
                                // после отзыва записи код применили снова) — уведомление обязано
                                // пережить авто-подтверждение: заявку оставляем в очереди.
                                if (summary.reuse === true) {
                                        if (adapter) {
                                                await saveOwnerUserMeta(adapter, meta);
                                                await pushJournalEntry(adapter, { ts: now(), kind: 'approve', detail: `auto-approved ${summary.identifier} (${summary.userId}), device ${device.name} bound at issue — CODE REUSED, notification kept in queue` });
                                        }
                                        if (!result.notified.includes(summary.identifier)) result.notified.push(summary.identifier);
                                } else {
                                        await client.deleteFile(`requests/${file.name}`, 'Vault Access Manager: auto-approve request');
                                        if (adapter) {
                                                await saveOwnerUserMeta(adapter, meta);
                                                await pushJournalEntry(adapter, { ts: now(), kind: 'approve', detail: `auto-approved ${summary.identifier} (${summary.userId}), device ${device.name} bound at issue` });
                                        }
                                }
                                result.approved += 1;
                                result.details.push(summary.identifier);
                        } catch {
                                // канальная ошибка по одной заявке не останавливает скан
                        }
                        continue;
                }
                // Подтверждение (v1-заявка): users/<id>.enc с ДЕФОЛТНЫМ паролем + удаление заявки.
                try {
                        const meta = await issueUserRecord(client, { identifier: summary.identifier, password: defaultPassword, expiresAt: null }, deps);
                        await client.deleteFile(`requests/${file.name}`, 'Vault Access Manager: auto-approve request');
                        if (adapter) {
                                await saveOwnerUserMeta(adapter, meta);
                                await pushJournalEntry(adapter, { ts: now(), kind: 'approve', detail: `auto-approved ${summary.identifier} (${summary.userId})` });
                        }
                        result.approved += 1;
                        result.details.push(summary.identifier);
                } catch {
                        // канальная ошибка по одной заявке не останавливает скан
                }
        }
        return result;
}

// --- локальный бэкап users/ (хозяин; FR-26) ---

export async function exportUsersBackup(client: ChannelClient, adapter: DataAdapter, targetFolder: string): Promise<number> {
        const files = await client.listDir('users');
        try {
                await adapter.mkdir(targetFolder);
        } catch {
                // папка существует
        }
        let count = 0;
        for (const file of files) {
                if (!file.name.endsWith('.enc')) continue;
                const res = await client.getFile(`users/${file.name}`);
                if (res.status !== 'ok') continue;
                await adapter.write(`${targetFolder}/${file.name}`, bytesToB64(res.bytes));
                count += 1;
        }
        return count;
}
