// src/core/verdict-snapshot.ts — VerdictSnapshot: вычисляемый вердикт (план §4.2).
//
// Принцип: вердикт ВЫЧИСЛЯЕТСЯ из одного снапшота, а не запоминается россыпью полей.
// B-1 (W-B) уже сделал гидрацию кэша одним чтением — этот модуль достраивает объект
// до полного снапшота, не переписывая его: AuthCache (store.ts) остаётся персистентной
// формой, здесь — правила вычисления над ней.
//
// Правила (каждый тик, ЛОКАЛЬНО, без сети — план §4.2):
//   • killSwitch (пин B-2)          → blocked(kill-switch) — главнее всего;
//   • expiresAt из записи пользователя → blocked(expired)   — M-4: раньше expired
//     ловился только при успешной расшифровке (нужна сеть); теперь — на тике.
//     Для запомненной сессии это ТОЖЕ блок: срок — явный отзыв хозяина;
//   • now > checkedAt + ttlHours    → blocked(ttl)          — C-2: НО только для
//     НЕзапомненных сессий. v0.5.1 (H-2): remembered=true — «вход хранится до отзыва
//     хозяина»: офлайн-TTL не гасит, kill/ротация/срок погасят при первом контакте
//     (kill-пин B-2 делает отзыв переживающим рестарт);
//   • ok/degraded-channel в грейсе  → живёт; checkedAt === null при ok и !remembered —
//     свежесть НЕДОКАЗУЕМА → fail-closed blocked(ttl), не «вечный ok».
//
// Анти-откат без криптографии (рамка §1 smooth-lock): policyDigest в снапшоте —
// лёгкое наблюдение рассогласования «вердикт писался при другой политике»;
// fail-closed на not-found и пиннинг kill — в B-2/main. Откатить политику старой
// версией может только случайность, не атакующий.

import type { AuthCache } from './store';
import type { AuthBlockReason, InternalStatus } from './auth-state';

/** Вердикт снапшота. «checking» — транзиентное состояние pull'а, НЕ персистится:
 *  публичное 'checking' из кэша означает awaiting-approval (initialAuthState). */
export type SnapshotVerdict =
        | 'ok'
        | 'blocked'
        | 'awaiting-approval'
        | 'unconfigured'
        | 'degraded-channel';

export interface VerdictSnapshot {
        verdict: SnapshotVerdict;
        /** M-15: причина блокировки переживает рестарт. */
        reason: string | null;
        /** Последний УСПЕШНЫЙ контакт — база офлайн-грейса (C-2). */
        checkedAt: number | null;
        /** Офлайн-грейс из channel.json (гидратируется B-1). */
        ttlHours: number;
        /** M-4: expiresAt записи пользователя — проверяется локально на тике. */
        expiresAt: number | null;
        /** Пин kill (B-2): снятие — только свежим полным channel.json. */
        killSwitch: boolean;
        /** Лёгкий анти-откат: дайджест политики, при которой писался вердикт. */
        policyDigest: string | null;
        /** v0.5.1 (H-2): запомненная сессия (remember.bin). TTL её не гасит —
         *  только kill/expiresAt (отзыв). */
        hasRemember: boolean;
}

export interface ComputedVerdict {
        verdict: SnapshotVerdict;
        reason: AuthBlockReason | null;
}

const HOUR_MS = 3_600_000;

/** Собрать снапшот из живого состояния автомата (persistCache / тик). */
export function buildSnapshot(parts: {
        status: InternalStatus;
        reason?: AuthBlockReason;
        checkedAt: number | null;
        ttlHours: number;
        expiresAt: number | null;
        killSwitch: boolean;
        policyDigest?: string | null;
        hasRemember?: boolean;
}): VerdictSnapshot {
        return {
                verdict: verdictFromStatus(parts.status),
                reason: parts.reason ?? null,
                checkedAt: parts.checkedAt,
                ttlHours: parts.ttlHours,
                expiresAt: parts.expiresAt,
                killSwitch: parts.killSwitch,
                policyDigest: parts.policyDigest ?? null,
                hasRemember: parts.hasRemember === true,
        };
}

/** Собрать снапшот из персистентного кэша (рестарт). */
export function snapshotFromCache(cache: AuthCache): VerdictSnapshot {
        return buildSnapshot({
                status: statusFromPublic(cache.publicStatus),
                reason: (cache.reason ?? undefined) as AuthBlockReason | undefined,
                checkedAt: cache.checkedAt,
                ttlHours: cache.ttlHours,
                expiresAt: cache.expiresAt ?? null,
                killSwitch: cache.killSwitch === true,
                policyDigest: cache.policyDigest ?? null,
                hasRemember: cache.remembered === true,
        });
}

/**
 * Чистая функция вычисления вердикта: снапшот + сейчас → вердикт. Никаких
 * побочных эффектов — идемпотентна, монотонна по now (verdict не «улучшается»
 * со временем при фиксированном снапшоте). Свойство проверяется fast-check (§4.5).
 */
export function computeVerdict(s: VerdictSnapshot, now: number): ComputedVerdict {
        if (s.killSwitch) return { verdict: 'blocked', reason: 'kill-switch' };
        if (s.verdict === 'unconfigured') return { verdict: 'unconfigured', reason: null };
        // M-4: срок доступа вшит в запись — проверка не ждёт сети. Для remembered
        // это тоже блок: срок — ЯВНЫЙ отзыв хозяина, не «свежесть сети» (H-2).
        if (s.expiresAt !== null && now > s.expiresAt) return { verdict: 'blocked', reason: 'expired' };
        if (s.verdict === 'ok' || s.verdict === 'degraded-channel') {
                // v0.5.1 (H-2): запомненная сессия — «до отзыва»: TTL не гасит.
                if (!s.hasRemember) {
                        // C-2: свежесть доказуема только checkedAt'ом. null при ok — не доказать → блок.
                        if (s.checkedAt === null) return { verdict: 'blocked', reason: 'ttl' };
                        if (now > s.checkedAt + s.ttlHours * HOUR_MS) return { verdict: 'blocked', reason: 'ttl' };
                }
                if (s.verdict === 'degraded-channel') {
                        // M-5 (§4.3): канал сломан (401/403), доступ жив в грейсе.
                        return { verdict: 'degraded-channel', reason: 'channel-error' };
                }
                return { verdict: 'ok', reason: null };
        }
        // blocked / awaiting-approval — как записано (M-15: причина уже в снапшоте).
        return { verdict: s.verdict, reason: (s.reason as AuthBlockReason | null) ?? null };
}

// --- маппинги статусов ---

function verdictFromStatus(status: InternalStatus): SnapshotVerdict {
        switch (status) {
                case 'ok':
                        return 'ok';
                case 'blocked':
                        return 'blocked';
                case 'unconfigured':
                        return 'unconfigured';
                case 'degraded-channel':
                        return 'degraded-channel';
                case 'awaiting-approval':
                case 'checking':
                        return 'awaiting-approval'; // транзиент сворачивается
        }
}

function statusFromPublic(publicStatus: AuthCache['publicStatus']): InternalStatus {
        switch (publicStatus) {
                case 'ok':
                        return 'ok';
                case 'blocked':
                        return 'blocked';
                case 'degraded':
                        return 'degraded-channel';
                case 'checking':
                        return 'awaiting-approval'; // initialAuthState-семантика кэша
                case 'unset':
                        return 'unconfigured';
        }
}
