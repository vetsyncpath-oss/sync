// src/core/semver.ts — сравнение версий x.y.z для детекта синк-плагина (FR-19, §7.8).
// Нечисловые суффиксы ('3.2.0-beta.1') игнорируются: сравниваются только числовые части.

export function semverCompare(a: string, b: string): number {
	const [amaj, amin, apat] = parseSemver(a);
	const [bmaj, bmin, bpat] = parseSemver(b);
	if (amaj !== bmaj) return amaj < bmaj ? -1 : 1;
	if (amin !== bmin) return amin < bmin ? -1 : 1;
	if (apat !== bpat) return apat < bpat ? -1 : 1;
	return 0;
}

function parseSemver(v: string): [number, number, number] {
	const m = /^v?(\d+)\.(\d+)(?:\.(\d+))?/.exec(String(v ?? '').trim());
	if (!m) return [0, 0, 0];
	return [Number(m[1]) || 0, Number(m[2]) || 0, Number(m[3]) || 0];
}
