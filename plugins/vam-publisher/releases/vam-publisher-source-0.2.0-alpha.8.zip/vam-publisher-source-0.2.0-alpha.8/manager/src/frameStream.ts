import type { Token, TokenSource } from "./types";
import { pivotIndex } from "./pivot";
import { syllabify } from "./syllables";
import { decideParts } from "./layout";

/**
 * Кадровый поток: обёртка над TokenSource для сцены (Д3, В12).
 *
 * Движок считает «токен = один показ», но слово, которое не влезает в сцену
 * даже с усадкой кегля до 65% (мобильный экран + крупный шрифт + длинное
 * русское слово), должно пройти НЕСКОЛЬКИМИ кадрами-слогами. FrameStream
 * реализует тот же интерфейс TokenSource, разворачивая такие слова в кадры:
 * движок ничего не знает о разрезании и не меняется.
 *
 * Пивот закреплён в центре сцены (CSS grid), слово строится вокруг него —
 * поэтому «влезает» считается по ПАРТАМ вокруг пивота: availL — бюджет
 * левой половины, availR — правой (дефис куска — на счёту вью). Каскад Д3
 * согласован с layout.decideParts: fit/shrink остаются на уровне вью
 * (усадка кегля не меняет количество кадров), split — здесь. Куски одного
 * слова несут общий chunkId; НЕпервый кусок — isChunkTail; дефис вью рисует
 * сам (isLastPiece), текст куска остаётся чистым для пивота.
 *
 * Отображение лениво как и внутренний поток: соответствие кадр→токен
 * строится по мере готовности токенов (append-only, порядок документа
 * сохраняется). При смене кегля/ширины сцены обёртка пересоздаётся.
 *
 * Чанкинг пар (getChunk): пары склеиваются только из ЦЕЛЫХ слов — кусок
 * разрезанного слова в пару не вступает (и пары не вклеиваются внутрь слова).
 */

export type MeasureFn = (s: string) => number;

export class FrameStream implements TokenSource {
  private readonly inner: TokenSource;
  private readonly measure: MeasureFn;
  /** Бюджеты половин сцены вокруг ЗАКРЕПЛЁННОГО пивота. */
  private readonly availL: number;
  private readonly availR: number;
  private readonly minScale: number;

  /** Кадр → индекс токена (неубывающий). */
  private readonly tokOf: number[] = [];
  /** Кадр → номер куска внутри токена. */
  private readonly subOf: number[] = [];
  /** Токен → куски (null = целое слово, один кадр). */
  private readonly piecesOf: (string[] | null)[] = [];
  /** Токен → общий id кусков (0 = не разрезано). */
  private readonly chunkIdOf: number[] = [];
  /** Сколько токенов уже отображено в кадры. */
  private mapped = 0;
  /** Сколько кадров построено. */
  private frameCount = 0;
  private nextChunkId = 1;
  /** Отображение завершено (внутренний поток финализирован и разобран). */
  private done = false;

  /**
   * @param availL бюджет левой половины сцены (от центра до края с полем)
   * @param availR бюджет правой половины (симметричный пивоту в центре)
   */
  constructor(
    inner: TokenSource,
    measure: MeasureFn,
    availL: number,
    availR: number,
    minScale = 0.65,
  ) {
    this.inner = inner;
    this.measure = measure;
    this.availL = availL;
    this.availR = availR;
    this.minScale = minScale;
  }

  /* ═══════════ контракт TokenSource ═══════════ */

  get length(): number {
    this.ensureAll();
    return this.done ? this.frameCount : -1;
  }

  get totalReadableChars(): number {
    return this.inner.totalReadableChars;
  }

  isReady(i: number): boolean {
    if (i < 0) return false;
    if (this.done) return i < this.frameCount;
    this.ensure(i);
    return i < this.frameCount;
  }

  get(i: number): Token {
    this.ensure(i);
    if (i < 0 || i >= this.frameCount) {
      throw new Error(`FrameStream.get: кадр ${i} не построен (кадров: ${this.frameCount})`);
    }
    const t = this.tokOf[i];
    const sub = this.subOf[i];
    const pieces = this.piecesOf[t];
    if (pieces === null) {
      return this.inner.get(t);
    }
    const token = this.inner.get(t);
    const piece = pieces[sub];
    const last = sub === pieces.length - 1;
    let pivot = pivotIndex(piece);
    if (pivot < 0) pivot = 0;
    if (pivot >= piece.length) pivot = piece.length - 1;
    return {
      ...token,
      text: piece,
      pivot,
      // конец абзаца — только у последнего куска, иначе пауза ×2.2
      // сработала бы на каждом слоге одного слова
      isParaEnd: last ? token.isParaEnd : false,
      chunkId: this.chunkIdOf[t],
      isChunkTail: sub > 0,
    };
  }

  async seek(sectionIdx: number): Promise<void> {
    // Кадры append-only и не переупорядочиваются: seek делегируется
    // внутреннему потоку (он синхронно добирает пропуск до раздела).
    await this.inner.seek(sectionIdx);
  }

  charsBefore(i: number): number {
    if (i <= 0) return 0;
    this.ensure(i - 1);
    const t = i < this.frameCount ? this.tokOf[i] : this.inner.length;
    return this.inner.charsBefore(t);
  }

  getSection(idx: number): ReturnType<TokenSource["getSection"]> {
    return this.inner.getSection(idx);
  }

  getChunk(i: number, wpm: number): string {
    this.ensure(i);
    if (i >= this.frameCount) return "";
    const t = this.tokOf[i];
    if (this.piecesOf[t] !== null) return this.get(i).text;
    this.ensure(i + 1);
    if (i + 1 >= this.frameCount) return this.get(i).text;
    const t1 = this.tokOf[i + 1];
    // следующий кадр — кусок (этого или чужого слова): пара не собирается
    if (t1 === t || this.piecesOf[t1] !== null) return this.get(i).text;
    return this.inner.getChunk(t, wpm);
  }

  /* ═══════════ доп. API для вью/хранилища (не входит в контракт) ═══════════ */

  /** Токен кадра i (−1, если кадр не построен). */
  tokenOf(i: number): number {
    this.ensure(i);
    return i < this.frameCount ? this.tokOf[i] : -1;
  }

  /** Первый кадр токена t (−1, пока токен не отображён). */
  frameOfToken(t: number): number {
    if (t < 0) return -1;
    while (this.mapped <= t && !this.done) {
      const len = this.inner.length;
      if (len >= 0 && this.mapped >= len) {
        this.done = true;
        break;
      }
      if (!this.inner.isReady(this.mapped)) return -1;
      this.mapToken(this.mapped);
    }
    if (this.mapped <= t) return -1;
    let lo = 0;
    let hi = this.frameCount;
    while (lo < hi) {
      const mid = (lo + hi) >> 1;
      if (this.tokOf[mid] < t) lo = mid + 1;
      else hi = mid;
    }
    return lo < this.frameCount && this.tokOf[lo] === t ? lo : -1;
  }

  /** Последний ли кусок слова у кадра i (для дефиса В12). */
  isLastPiece(i: number): boolean {
    this.ensure(i);
    if (i >= this.frameCount) return true;
    const t = this.tokOf[i];
    const pieces = this.piecesOf[t];
    if (pieces === null) return true;
    return this.subOf[i] === pieces.length - 1;
  }

  /* ═══════════ построение отображения ═══════════ */

  /** Достроить кадры, пока их не станет больше need. */
  private ensure(need: number): void {
    while (this.frameCount <= need && !this.done) {
      const len = this.inner.length;
      if (len >= 0 && this.mapped >= len) {
        this.done = true;
        return;
      }
      if (!this.inner.isReady(this.mapped)) return;
      this.mapToken(this.mapped);
    }
  }

  /** Финализировать длину, когда внутренний поток закончился. */
  private ensureAll(): void {
    if (this.done) return;
    const len = this.inner.length;
    if (len < 0) return;
    while (this.mapped < len) {
      this.mapToken(this.mapped);
    }
    this.done = true;
  }

  private mapToken(t: number): void {
    const token = this.inner.get(t);
    const word = token.text;
    let pieces: string[] | null = null;
    if (word.length > 0 && this.availL > 0 && this.availR > 0) {
      const d = decideParts(word, token.pivot, this.measure, this.availL, this.availR, this.minScale);
      if (d.kind === "split") {
        // Оценка допустимой длины куска: сколько символов слова помещается
        // в min(availL, availR) при усадке до minScale — при ЛЮБОМ пивоте
        // куска части влезают в свои половины. Точный контроль ширины куска
        // остаётся за вью (усадка кегля как страховка Д3).
        const w = this.measure(word);
        const cap = Math.min(this.availL, this.availR) / this.minScale;
        const est = w > 0 ? (word.length * cap) / w : word.length;
        const maxLen = Math.max(2, Math.floor(est));
        pieces = syllabify(word, maxLen);
        if (pieces.length <= 1) pieces = null;
      }
    }
    if (pieces === null) {
      this.piecesOf[t] = null;
      this.chunkIdOf[t] = 0;
      this.tokOf.push(t);
      this.subOf.push(0);
      this.frameCount += 1;
    } else {
      const id = this.nextChunkId++;
      this.piecesOf[t] = pieces;
      this.chunkIdOf[t] = id;
      for (let k = 0; k < pieces.length; k++) {
        this.tokOf.push(t);
        this.subOf.push(k);
      }
      this.frameCount += pieces.length;
    }
    this.mapped += 1;
  }
}
