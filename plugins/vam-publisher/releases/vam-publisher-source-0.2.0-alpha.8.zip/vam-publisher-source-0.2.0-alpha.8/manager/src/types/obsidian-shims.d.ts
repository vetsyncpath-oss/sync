// src/types/obsidian-shims.d.ts — ambient-объявление модуля 'obsidian' для tsc --noEmit.
// В рантайме (vitest) алиас из vitest.config.ts ведёт на tests/mocks/obsidian.ts;
// в самом Obsidian модуль предоставляет платформа. Здесь — только типы, нужные менеджеру.

declare module 'obsidian' {
        export type App = {
                vault: {
                        adapter: import('obsidian').DataAdapter;
                        configDir?: string;
                        [key: string]: unknown;
                };
                plugins?: { plugins?: Record<string, any> };
                setting?: { open(): void; openTabById(id: string): void };
                [key: string]: unknown;
        };

        export type PluginManifest = {
                id: string;
                name?: string;
                version: string;
                minAppVersion?: string;
                description?: string;
                author?: string;
                isDesktopOnly?: boolean;
                [key: string]: unknown;
        };

        export type DataAdapter = {
                read(path: string): Promise<string>;
                write(path: string, data: string): Promise<void>;
                remove(path: string): Promise<void>;
                exists(path: string): Promise<boolean>;
                mkdir(path: string): Promise<void>;
                list?(path: string): Promise<{ files: string[]; folders: string[] }>;
        };

        export class Notice {
                constructor(message: string | DocumentFragment, timeout?: number);
                hide(): void;
                setMessage(message: string | DocumentFragment): this;
        }

        export class Modal {
                constructor(app: App);
                app: App;
                contentEl: HTMLElement;
                modalEl: HTMLElement;
                open(): void;
                close(): void;
                onOpen(): void;
                onClose(): void;
        }

        export type TextComponent = {
                inputEl: HTMLInputElement;
                setValue(v: string): this;
                getValue(): string;
                setPlaceholder(p: string): this;
                onChange(cb: () => any): this;
        };

        export type ToggleComponent = {
                setValue(v: boolean): this;
                getValue(): boolean;
                onChange(cb: (v: boolean) => any): this;
        };

        export type ButtonComponent = {
                buttonEl: HTMLButtonElement;
                setButtonText(t: string): this;
                setCta(): this;
                setWarning(): this;
                onClick(cb: (evt: MouseEvent) => any): this;
        };

        export type DropdownComponent = {
                addOption(value: string, display: string): this;
                setValue(v: string): this;
                getValue(): string;
                onChange(cb: (v: string) => any): this;
        };

        export type ExtraButtonComponent = {
                setIcon(icon: string): this;
                setTooltip(t: string): this;
                onClick(cb: () => any): this;
        };

        export class Setting {
                constructor(containerEl: HTMLElement);
                settingEl: HTMLElement;
                nameEl: HTMLElement;
                descEl: HTMLElement;
                controlEl: HTMLElement;
                setName(name: string | DocumentFragment): this;
                setDesc(desc: string | DocumentFragment): this;
                setClass(cls: string): this;
                addText(cb: (c: TextComponent) => any): this;
                addToggle(cb: (c: ToggleComponent) => any): this;
                addButton(cb: (c: ButtonComponent) => any): this;
                addDropdown(cb: (c: DropdownComponent) => any): this;
                addExtraButton(cb: (c: ExtraButtonComponent) => any): this;
        }

        export abstract class Plugin {
                constructor(app: App, manifest: PluginManifest);
                app: App;
                manifest: PluginManifest;
                loadData(): Promise<any>;
                saveData(data: any): Promise<void>;
                addSettingTab(tab: any): void;
                addCommand(command: { id: string; name: string; callback: () => any; [k: string]: unknown }): any;
                registerInterval(id: number): number;
                register(cb: () => any): void;
        }

        export abstract class PluginSettingTab {
                constructor(app: App, plugin: any);
                app: App;
                containerEl: HTMLElement;
                display(): void;
                hide(): void;
        }

        export class SuggestModal<T> extends Modal {
                getSuggestions(query: string): T[];
                renderSuggestion(value: T, el: HTMLElement): void;
        }
}

// Глобалы Obsidian, используемые менеджером.
declare const moment: { locale(): string; [k: string]: any };

// Расширения прототипа HTMLElement, которые добавляет Obsidian (createEl/empty/addClass…).
// В тестах их полифиллит tests/mocks/obsidian.ts, в Obsidian они нативные.
interface HTMLElement {
        createEl<K extends keyof HTMLElementTagNameMap>(
                tag: K,
                o?: string | { cls?: string; text?: string; attr?: Record<string, string> },
        ): HTMLElementTagNameMap[K];
        createEl(tag: string, o?: string | { cls?: string; text?: string; attr?: Record<string, string> }): HTMLElement;
        empty(): void;
        addClass(cls: string): void;
        removeClass(cls: string): void;
        toggleClass(cls: string, value?: boolean): void;
}
