/**
 * ORC-пивот (Optimal Recognition Center) — индекс акцентной буквы слова.
 *
 * RSVP подсвечивает одну букву слова и ставит её на фиксированную
 * вертикальную линию. Психолингвистика: точка распознавания (ORP)
 * лежит в ПЕРВОЙ трети слова (~25–35 % от начала — таблица Spritz
 * держит ту же зону), а не в середине. Правило ревизии: акцент —
 * одна из первых букв, никогда не дальше первой трети; для коротких
 * слов (≤ 4–5 букв) трет фактически совпадает с серединой.
 *
 * Правила (ревизия 2: «строгая первая треть»):
 *  1. raw === "" → 0.
 *  2. Краевая пунктуация (не-буквы и не-цифры с обоих концов) срезается
 *     в «ядро» (core); итог маппится обратно в индексы raw.
 *  3. Есть гласные в ядре не дальше первой трети: target = coreLen / 3,
 *     берём ближайшую к target гласную (точная целочисленная метрика
 *     |3·ci − coreLen|); при равенстве расстояний — левее. Жёсткий
 *     предел: ci ≤ min(⌈coreLen/3⌉, ⌊(coreLen − 1)/2⌋) — у длинных
 *     слов акцент не уезжает глубже первой трети («польЗОвателя»
 *     → «пОльзователя»), у коротких — не дальше середины.
 *  4. Гласных в первой трети нет (или гласных нет вовсе), но буквы
 *     есть: таблица Spritz по длине ядра (позиционные значения всегда
 *     в первой трети–половине).
 *  5. Букв нет (числа/URL): ⌊core.length / 3⌋.
 *
 * Вспомогательные предикаты по кодам символов (isVowelCode/isWordCode/
 * isLetterCode) экспортируются для переиспользования в syllables.ts,
 * чтобы наборы гласных/букв не расползались по двум модулям.
 *
 * Поддержка скриптов: ASCII-буквы/цифры + кириллица (0x400–0x4FF,
 * включая Ё/ё и укр./бел. буквы). Прочие скрипты трактуются как
 * пунктуация — для токенов реальных заметок этого достаточно.
 */

/** Гласные (регистронезависимо): а е ё и о у ы э ю я a e i o u y. */
const VOWEL_CODES: readonly number[] = [
  0x0430, 0x0435, 0x0451, 0x0438, 0x043e, 0x0443, 0x044b, 0x044d, 0x044e, 0x044f, // а е ё и о у ы э ю я
  0x0410, 0x0415, 0x0401, 0x0418, 0x041e, 0x0423, 0x042b, 0x042d, 0x042e, 0x042f, // А Е Ё И О У Ы Э Ю Я
  0x0061, 0x0065, 0x0069, 0x006f, 0x0075, 0x0079, // a e i o u y
  0x0041, 0x0045, 0x0049, 0x004f, 0x0055, 0x0059, // A E I O U Y
];

/**
 * Таблица гласных до 0x4FF (ASCII + кириллица) — O(1) без хеширования:
 * hot-path пивота пробегает слово целиком, Set.has здесь заметно дороже.
 */
const VOWEL_TABLE = new Uint8Array(0x500);
for (const code of VOWEL_CODES) VOWEL_TABLE[code] = 1;

/** Буква или цифра (ASCII + кириллица). */
export function isWordCode(code: number): boolean {
  return (
    (code >= 0x30 && code <= 0x39) || // 0-9
    (code >= 0x41 && code <= 0x5a) || // A-Z
    (code >= 0x61 && code <= 0x7a) || // a-z
    (code >= 0x400 && code <= 0x4ff) // кириллица
  );
}

/** Только буква (без цифр). */
export function isLetterCode(code: number): boolean {
  return (
    (code >= 0x41 && code <= 0x5a) ||
    (code >= 0x61 && code <= 0x7a) ||
    (code >= 0x400 && code <= 0x4ff)
  );
}

export function isVowelCode(code: number): boolean {
  return code < 0x500 && VOWEL_TABLE[code] === 1;
}

/**
 * Индекс акцентной буквы (ORC) в исходной строке токена.
 *
 * Расстояние до target = coreLen / 3 сравнивается точной целочисленной
 * арифметикой |3·ci − coreLen| (эквивалент |ci − coreLen/3| без
 * погрешностей float): одинаковые математические расстояния дают
 * одинаковые целые, ничья детерминированно уходит левее (сканирование
 * слева направо со строгим «меньше»). Кандидаты — только гласные
 * первой трети ядра: ci ≤ min(⌈coreLen/3⌉, ⌊(coreLen − 1)/2⌋).
 */
export function pivotIndex(raw: string): number {
  const len = raw.length;
  if (len === 0) return 0;

  // Ядро без краевой пунктуации: raw[start, end).
  let start = 0;
  let end = len;
  while (start < end && !isWordCode(raw.charCodeAt(start))) start++;
  while (end > start && !isWordCode(raw.charCodeAt(end - 1))) end--;
  const coreLen = end - start;
  if (coreLen === 0) return 0;

  // Правило 3: гласная, ближайшая к coreLen/3, не дальше первой трети
  // (у коротких слов ⌈L/3⌉ доходит до середины — кап к «(L−1)/2»).
  const cap = Math.min(Math.ceil(coreLen / 3), Math.floor((coreLen - 1) / 2));
  let bestCore = -1;
  let bestDist = Number.MAX_SAFE_INTEGER;
  for (let ci = 0; ci <= cap; ci++) {
    const code = raw.charCodeAt(start + ci);
    if (code < 0x500 && VOWEL_TABLE[code] === 1) {
      const dist = Math.abs(3 * ci - coreLen);
      if (dist < bestDist) {
        bestDist = dist;
        bestCore = ci;
        if (dist === 0) break; // ближе уже не бывает
      }
    }
  }
  if (bestCore >= 0) return start + bestCore;

  // Правила 4/5: в первой трети гласных нет (или их нет вовсе).
  let hasLetter = false;
  for (let i = start; i < end; i++) {
    if (isLetterCode(raw.charCodeAt(i))) {
      hasLetter = true;
      break;
    }
  }

  let idx: number;
  if (hasLetter) {
    // Таблица Spritz: 1→0; 2–5→1; 6–9→2; 10–13→3; 14+→4.
    if (coreLen <= 1) idx = 0;
    else if (coreLen <= 5) idx = 1;
    else if (coreLen <= 9) idx = 2;
    else if (coreLen <= 13) idx = 3;
    else idx = 4;
  } else {
    idx = Math.floor(coreLen / 3);
  }
  if (idx < 0) idx = 0;
  if (idx > coreLen - 1) idx = coreLen - 1;
  return start + idx;
}
