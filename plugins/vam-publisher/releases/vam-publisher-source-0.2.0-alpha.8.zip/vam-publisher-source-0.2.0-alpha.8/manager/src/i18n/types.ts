// src/i18n/types.ts — интерфейс словаря: ключи = контракт (FR-30). Значения — строки либо
// функции (n: number) => string. Паритет en/ru/types проверяет TC-40; неиспользуемый ключ — TC-41.

export type TranslationValue = string | ((n: number) => string);

export interface Translations {
        tabTitle: string;
        statusOk: string;
        statusChecking: string;
        statusBlocked: string;
        statusDegraded: string; // v0.5 (M2 §4.3): канал деградировал, доступ в грейсе
        noticeEnforcementDegraded: string; // M-16: внутренний API Obsidian недоступен
        noticeChannelAuth: string; // M-5: PAT хозяина истёк (Notice хозяину)
        vamFirstTitle: string; // Р6: «VAM первым» — заголовок предложения
        vamFirstBody: (position: number) => string; // Р6: текст с номером позиции
        vamFirstDone: string; // Р6: подтверждение переноса
        statusUnset: string;
        reasonKeyMismatch: string; // v0.5 (M2 §4.3): честный вердикт вместо «rotated»
        reasonRevoked: string;
        reasonExpired: string;
        reasonWrongPassword: string;
        reasonKillSwitch: string;
        reasonTtl: string;
        reasonChannelError: string;
        reasonNoPassword: string;
        lastChecked: (n: number) => string;
        minutesAgo: (n: number) => string;
        hoursValue: (n: number) => string;
        staleNotice: string;
        accountTitle: string;
        identifierLabel: string;
        identifierPlaceholder: string;
        passwordLabel: string;
        enterPasswordBtn: string;
        forgotPasswordBtn: string;
        rememberLabel: string; // v0.6.1: подпись rememberDesc убрана из пользовательских настроек (директива владельца)
        userIdLabel: string;
        channelTitle: string;
        channelUrlLabel: string;
        channelUrlHint: string;
        tokenLabel: string;
        tokenHint: string;
        testChannelBtn: string;
        channelTestOkWrite: string;
        channelTestFail: string;
        channelTestErrAuth: string;
        channelTestErrEmpty: string;
        channelTestErrNotFound: string;
        channelTestErrNet: string;
        channelTestErrWrite: string;
        channelBadUrl: string;
        ogGuideBtn: string;
        ogTitle: string;
        ogIntro: string;
        ogStep1: string;
        ogStep2: string;
        ogStep3: string;
        ogStep4: string;
        ogTokenTitle: string;
        ogTokenBody: string;
        ogFilesTitle: string;
        ogFilesBody: string;
        ogTroubleTitle: string;
        ogTroubleBody: string;
        requestTitle: string;
        requestPending: string;
        requestRejected: string;
        requestResendBtn: string;
        requestFailedDetail: string;
        diagTitle: string;
        diagCheckedAt: string;
        diagChannelHead: string;
        diagTtlLeft: string;
        diagPullNowBtn: string;
        // v0.5.3 (репорт №3): глубокая диагностика — команда/кнопка/модалка отчёта
        diagRunCmd: string;
        diagRunBtn: string;
        diagModalTitle: string;
        diagSavedPath: string;
        diagModalHint: string; // подпись в модалке отчёта (осознанное действие); из настроек убрана (v0.6.1)
        diagCopyBtn: string;
        diagCopied: string;
        diagCopyFailed: string;
        syncPluginMissing: string;
        syncPluginOld: string;
        syncPluginOk: string;
        minVersionWarn: string;
        // v0.6.1 (директива владельца): журнал — в консоли разработчика;
        // journalTitle/journalEmpty из настроек убраны, ключи удалены
        journalShowCmd: string;
        aboutTitle: string;
        aboutBody: string;
        onbTitle: string;
        onbUserRole: string;
        onbOwnerRole: string;
        onbOwnerRoleDesc: string;
        ownerGateTitle: string;
        ownerGateSetup: string;
        ownerGateWrong: string;
        repeatLabel: string;
        ownerDefaultPwLabel: string;
        accessTitle: string;
        ownerAutoApproveLabel: string;
        ownerAutoApproveDesc: string;
        ownerUsersBtn: string;
        // v0.5.5: подпись «Пользователи…» — семантика права на плагины
        ownerUsersBtnDesc: string;
        ownerRequestsBtn: string;
        ownerChannelMetaBtn: string;
        ownerBackupBtn: string;
        metaMinVersion: string;
        metaKillSwitch: string;
        metaTtlHours: string;
        metaKillConfirm: string;
        backupResult: (n: number) => string;
        umTitle: string;
        umEmpty: string;
        // v0.5.5: вводная UsersModal — что даёт запись (право, не список плагинов)
        umIntro: string;
        umIssueBtn: string;
        umRotateBtn: string;
        umRevokeBtn: string;
        umReissueBtn: string;
        umConfirmRevoke: string;
        expiresLabel: string;
        datePlaceholder: string;
        noteLabel: string;
        expiredLabel: string;
        rmTitle: string;
        rmEmpty: string;
        rmApproveBtn: string;
        rmRejectBtn: string;
        rmAutoNote: string;
        pwFirstTitle: string;
        pwFirstDesc: string;
        pwRotationTitle: string;
        pwRotationDesc: string;
        pwRetryTitle: string;
        pwRetryDesc: string;
        pwShow: string;
        submitBtn: string;
        cancelBtn: string;
        closeBtn: string;
        genPasswordBtn: string;
        copiedNotice: string;
        noticeRequestSent: string;
        noticeRequestFailed: string;
        ownerOpFailed: string;
        noticeBlocked: string;
        neverExpires: string;
        quickTitle: string; // v0.6.1: quickDesc убран (директива: без пояснительных подписей)
        quickApplyBtn: string;
        quickApplied: string;
        quickNeedPassword: string;
        quickBadCode: string;
        quickNotUser: string;
        qcChannelBtn: string;
        qcChannelDesc: string;
        umInviteBtn: string;
        umInviteHint: string;
        umIdentifierRotateHint: string;
        ppTitle: string;
        ppStatusOk: string;
        ppNoticeViolations: string;
        ppRegulated: string;
        ppForbidden: string;
        ppPresent: string;
        ppAddBtn: string;
        ppRemoveBtn: string;
        ppEmpty: string;
        ppSaved: string;
        ppEditBtn: string;
        // v0.5.5: подпись кнопки + жёсткость регулировки (режимов больше нет)
        ppEditBtnDesc: string;
        // v0.6.1: ppEnforceHint убран из пользовательских настроек (директива владельца)
        ppIdLabel: string;
        ppActionLabel: string;
        ppDisabledNotice: string;
        ppEnableBlockedNotice: string;
        // v0.5 (W-C): smooth-lock — unlock-уведомления, статус замка, recovery-кнопка
        ppUnlockNotice: string;
        ppUnlockRestartHint: string;
        ppUnlockFolderMissing: string;
        lockedLabel: string;
        lockedHint: string;
        lockedLoading: string;
        lockedEmpty: string;
        sweepSummary: (restored: number, conflicts: number) => string;
        sweepManifestSummary: (restored: number, cleaned: number) => string;
        sweepManifestRetry: (failed: number) => string;
        ownerRecoveryLabel: string;
        ownerRecoveryDesc: string;
        ownerRecoveryBtn: string;
        ownerRecoveryConfirm: string;
        ownerRecoveryDone: (n: number) => string;
        ownerRecoveryEmpty: string;
        // v0.4.1: improved PluginPolicyModal UI; v0.5.5 — переработка без режимов
        ppModalIntro: string;
        ppForbiddenHiddenHint: string;
        ppAdvancedName: string;
        ppAdvancedDesc: string;
        ppForbidBtn: string;
        ppUnforbidBtn: string;
        ppRegulatedHint: string;
        ppPickLabel: string;
        ppPickHint: string;
        ppPickPlaceholder: string;
        ppPluginsListTitle: string;
        ppPluginsCount: (n: number) => string;
        ppAddNewTitle: string;
        ppIdHint: string;
        ppForbiddenHint: string;
        ppNoteHint: string;
        ppIdRequired: string;
        ppIdDuplicate: string;
        // v0.5.5: подсекция «Hook-плагины» (реестр замеченных гвардов)
        hkTitle: string;
        hkIntro: string;
        hkEmpty: string;
        hkActiveChip: string;
        hkSeenChip: string;
        hkLastSeen: (n: number) => string;
        hkApiHint: string;
        // v0.4.2: ConfirmModal severity
        confirmDangerBtn: string;
        // v0.4.2: PasswordModal В3
        pwShowLabel: string;
        pwHide: string;
        pwRotationBtn: string;
        pwRetryBtn: string;
        pwEmptyWarn: string;
        pwSubmitFailed: string;
        pwResultAwaiting: string;
        pwResultKeyMismatch: string;
        pwResultRevoked: string;
        pwResultKillSwitch: string;
        // v0.4.2: OnboardingModal full redesign
        onbRoleIntro: string;
        onbQuickTitle: string;
        onbQuickDesc: string;
        onbQuickIntro: string;
        onbQuickBtn: string;
        onbQuickDone: string;
        onbTokenLabel: string;
        onbTokenHint: string;
        onbTokenRequired: string;
        onbRequestTitle: string;
        onbRequestDesc: string;
        onbRequestIntro: string;
        onbChannelStepLabel: string;
        onbChannelStepHint: string;
        onbChannelTokenLabel: string;
        onbRequestBtn: string;
        onbEmailLabel: string;
        onbEmailHint: string;
        onbPwLabel: string;
        onbPwHint: string;
        onbAllFieldsRequired: string;
        onbOwnerWarn: string;
        onbOwnerRequirements: string;
        onbOwnerConfirm: string;
        onbBackBtn: string;
        // v0.4.2: Notices — разделённые контексты
        noticeAccessConfirmed: string;
        noticeRequestApproved: string;
        noticeAccessIssued: string;
        noticeRotated: string;
        noticeReissued: string;
        opFailed: string;
        copyBtnLabel: string;
        // v0.4.2: RequestsModal
        rmSentAt: string;
        rmRejectConfirm: string;
        rmRefreshBtn: string;
        rmAutoOffNote: string;
        rmApprovePreview: string;
        // v0.4.2: UsersModal
        umSearchLabel: string;
        umSearchPlaceholder: string;
        umNoMatch: string;
        umIdentifierHint: string;
        umIssueIntro: string;
        umIssueConfirm: (n: number) => string;
        umIdRequired: string;
        umPwRequired: string;
        umInviteNeedsFields: string;
        umInviteNeedsChannel: string;
        umRotateWarn: string;
        // v0.6 (M4 «device binding light»): устройства
        onbDeviceBind: (name: string) => string;     // предупреждение при первом входе (desktop)
        pwDeviceBindHint: string;                    // подсказка в модалке пароля (desktop)
        noticeDeviceMismatch: string;                // не зачислено (сверх лимита / ручной режим) — заявка
        noticeDeviceAutoEnrolled: (n: number, max: number) => string; // v0.6.1: само-зачисление под капом
        noticeDeviceAutoEnrolledReuse: (n: number, max: number) => string; // v0.6.2: зачисление при повторном использовании кода (с уведомлением администратора)
        noticeReuseKept: (users: string) => string;   // v0.6.2: администратору — код использован повторно
        pwResultDeviceMismatch: string;              // итог ввода пароля на незачисленном устройстве
        umDevicesCol: string;                        // колонка «Устройства» в таблице
        umDevicesLegacy: string;                     // запись без реестра
        umDevicesManual: string;                     // v0.6.1: ручной режим зачисления (после сброса)
        umMaxDevicesLabel: string;                   // поле лимита в форме выдачи
        umMaxDevicesHint: string;
        umResetDevicesBtn: string;                   // «Сбросить устройства»
        umResetDevicesIntro: string;
        umResetDevicesConfirm: string;
        umResetDevicesPwLabel: string;               // текущий пароль записи для переиздания
        noticeDevicesReset: string;
        rmTypeCol: string;                           // колонка типа заявки
        rmTypeNewUser: string;                       // новый пользователь (v1)
        rmTypeNewUserDevice: string;                 // новый пользователь + устройство
        rmTypeNewDevice: string;                     // «⚠ НОВОЕ УСТРОЙСТВО» существующего
        rmTypeReuse: string;                         // v0.6.2: «⚠ КОД ПОВТОРНО» — заявка-уведомление
        rmReuseHint: string;                         // v0.6.2: подсказка семантики reuse-заявки
        rmAckBtn: string;                            // v0.6.2: «Принять к сведению» для reuse-заявки
        rmAckConfirm: string;                        // v0.6.2: подтверждение принятия уведомления
        rmProofStale: string;                        // proof не подтвердился дефолтным паролем
        rmProofStaleHint: string;
        rmApproveDeviceBtn: string;
        rmDeviceIntro: string;                       // что произойдёт при одобрении устройства
        rmDevicePwLabel: string;                     // пароль записи пользователя
        rmDevicePwHint: string;
        noticeDeviceApproved: string;
        deviceLimitErr: string;                      // EnrollLimitError → человекочитаемо
        umRotateConfirm: string;
        umReissueExplain: string;
        umReissueConfirm: string;
        // v0.4.2: PluginPolicyModal — ConfirmModal для Save
        ppSaveConfirmTitle: string;
        ppSaveConfirmMsg: string;
        // v0.4.3: PasswordModal — нельзя закрыть без пароля в first режиме
        // v0.4.4: PasswordModal — мягкое информационное сообщение
        pwCloseHint: string;
}
