// src/i18n/index.ts — синглтон словаря + t() (§11). Язык — по языку интерфейса Obsidian
// (moment.locale(): 'ru*' → русский, иначе английский); выбор делается один раз в onload.

import type { Translations } from './types';
import { en } from './en';
import { ru } from './ru';

export type Lang = 'ru' | 'en';

let currentLang: Lang = 'en';

export function setLanguage(lang: Lang): void {
        currentLang = lang;
}

export function getLanguage(): Lang {
        return currentLang;
}

export function detectLanguage(): Lang {
        // Автоопределение по языку Obsidian: глобал moment доступен внутри приложения.
        try {
                const locale = typeof moment !== 'undefined' && typeof moment.locale === 'function' ? String(moment.locale()) : '';
                if (locale.toLowerCase().startsWith('ru')) return 'ru';
        } catch {
                // moment недоступен (тесты) — английский по умолчанию
        }
        return 'en';
}

export function t(key: keyof Translations, ...args: unknown[]): string {
        // v0.5 (W-C/C-6): вариадик — переводы-функции с несколькими параметрами
        // (sweepSummary(restored, conflicts)); прежние одноаргументные работают как раньше.
        const dict: Translations = currentLang === 'ru' ? ru : en;
        const value = dict[key];
        return typeof value === 'function' ? (value as (...a: unknown[]) => string)(...args) : value;
}

export { en, ru };
export type { Translations };
