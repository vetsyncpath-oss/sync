// src/api/vault-sync-auth.ts — публичный read-only API для партнёрских плагинов (§7.6, FR-14/15).
// window.vaultSyncAuth v1: { version, getState(), onChanged(cb)→unsub, prompt(), beforeSession() }.
// Инстанс-fallback: app.plugins.plugins['vault-access-manager'].auth — тот же объект.
// Реестр подписчиков — Set, копия перед notify, try/catch на каждого; beforeSession дедуплицирует
// всплеск (один pull на серию вызовов, FR-6) и никогда не reject-ится (§3.5).

import { toPublicStatus } from '../core/auth-state';
import type { AuthStateDetail } from '../core/auth-state';
import type { AuthBlockReason } from '../core/auth-state';

export interface PublicAuthState {
        // v0.5 (M2 §4.3): 'degraded' — канал деградировал (401/403), доступ живёт офлайн-грейсом.
        // Аддитивное значение публичного контракта; партнёру достаточно status==='ok' как было.
        status: 'ok' | 'blocked' | 'unset' | 'checking' | 'degraded';
        userId?: string;
        checkedAt?: number; // ms epoch последнего успешного контакта с каналом
        reason?: AuthBlockReason;
}

export interface VaultSyncAuth {
        version: 1;
        getState(): PublicAuthState;
        onChanged(cb: (s: PublicAuthState) => void): () => void; // отписка; идемпотентная подписка
        prompt(): void; // открыть модалку ввода пароля
        beforeSession(): Promise<void>; // pull-цикл с дедупликацией (FR-6)
}

/** Внутреннее расширение API: менеджер дергает notify при смене вердикта. */
export interface AuthApiInternal extends VaultSyncAuth {
        notify(): void;
        dispose(): void;
}

/** Хост — менеджер-плагин (структурный интерфейс, развязывает цикл импортов main ↔ api). */
export interface AuthHost {
        authState: AuthStateDetail;
        auth?: VaultSyncAuth;
        openPasswordModal(mode: 'first' | 'rotation' | 'retry'): void;
        runPullCycle(opts: { context: 'typed' | 'background'; trigger?: 'timer' | 'before-session' | 'onchanged' | 'manual' }): Promise<void>;
}

export type PullTrigger = 'timer' | 'before-session' | 'onchanged' | 'manual';

function globalScope(): Record<string, unknown> {
        // В Obsidian это window; в node-тестах — globalThis.
        return (typeof window !== 'undefined' ? window : globalThis) as Record<string, unknown>;
}

export function installVaultSyncAuth(plugin: AuthHost): () => void {
        const subscribers = new Set<(s: PublicAuthState) => void>();
        let inFlight: Promise<void> | null = null;

        const getState = (): PublicAuthState => {
                const s = plugin.authState;
                const base: PublicAuthState = { status: toPublicStatus(s) };
                if (s.userId) base.userId = s.userId;
                if (s.checkedAt !== null) base.checkedAt = s.checkedAt;
                if (s.status === 'blocked') base.reason = s.reason;
                return base;
        };

        const api: AuthApiInternal = {
                version: 1,
                getState,
                onChanged(cb: (s: PublicAuthState) => void): () => void {
                        subscribers.add(cb); // повторная подписка той же функцией — no-op
                        return () => {
                                subscribers.delete(cb);
                        };
                },
                prompt(): void {
                        plugin.openPasswordModal('first');
                },
                beforeSession(): Promise<void> {
                        // Дедупликация всплеска: пока pull идёт — все новые вызовы получают тот же promise.
                        if (!inFlight) {
                                inFlight = plugin
                                        .runPullCycle({ context: 'background', trigger: 'before-session' })
                                        .catch(() => undefined) // никогда не reject-ится (§3.5)
                                        .finally(() => {
                                                inFlight = null;
                                        });
                        }
                        return inFlight;
                },
                notify(): void {
                        const snapshot = [...subscribers]; // копия: подписка/отписка во время notify безопасна
                        const state = getState();
                        for (const cb of snapshot) {
                                try {
                                        cb(state);
                                } catch (err) {
                                        console.warn('[VaultAccessManager] auth subscriber failed:', err instanceof Error ? err.message : String(err));
                                }
                        }
                },
                dispose(): void {
                        subscribers.clear();
                },
        };

        // 1) глобал; 2) инстанс-fallback (FR-15)
        const scope = globalScope();
        scope.vaultSyncAuth = api;
        plugin.auth = api;

        // cleanup: снять глобал + dispose реестра
        return () => {
                if (scope.vaultSyncAuth === api) delete scope.vaultSyncAuth;
                plugin.auth = undefined;
                api.dispose();
        };
}
