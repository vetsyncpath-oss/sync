import {
  FuzzySuggestModal,
  ItemView,
  Notice,
  Platform,
  TFile,
  setIcon,
  type ViewStateResult,
  type WorkspaceLeaf,
} from "obsidian";
import type { Position, SectionEntry, Token } from "./types";
import { RsvpEngine } from "./engine";
import { FrameStream } from "./frameStream";
import { TokenStream } from "./tokenStream";
import { buildIndex } from "./sectionIndex";
import { hashFilters } from "./filters";
import { decideParts } from "./layout";
import { buildFingerprint, findResumeIndex } from "./storage";
import type RsvpPlugin from "../main";
import type { RsvpSettings } from "./settings";

export const VIEW_TYPE_RSVP = "rsvp-reading-flow";

/** Запрос чтения: источник текста (вся заметка / выделение / от курсора). */
export type ReadingRequest =
  | { kind: "note"; file: TFile; resume: Position | null }
  | { kind: "selection"; file: TFile | null; text: string; label: string }
  | { kind: "cursor"; file: TFile | null; text: string; label: string };

/** Состояние, переживаемое перезапуском Obsidian (setState/getState). */
interface PersistedViewState {
  path?: string;
}

const FONT_STACK = 'Inter, "Segoe UI", system-ui, -apple-system, sans-serif';
/** Отступы сцены от краёв слова, px. */
const STAGE_SIDE_PAD = 16;
/** Пол каскада Д3: ниже — резать по слогам (в FrameStream тот же порог). */
const MIN_SCALE = 0.65;
/** Прыжок стрелками ←/→. */
const JUMP_WORDS = 10;
/** Шаг скорости ↑/↓ и кнопками −/+. */
const WPM_STEP = 25;
const WPM_MIN = 60;
const WPM_MAX = 1500;
/** Минимальная экспозиция слова: границы и шаг (синхронны со слайдером настроек). */
const MINMS_STEP = 10;
const MINMS_MIN = 0;
const MINMS_MAX = 400;
/** Кегль: границы и шаг синхронны со слайдером настроек (16–72, шаг 2). */
const FONT_MIN = 16;
const FONT_MAX = 72;
const FONT_STEP = 2;
/** Вертикаль строки чтения (пивот), % высоты сцены: минус — выше центра. */
const WORD_SHIFT_MIN = -20;
const WORD_SHIFT_MAX = 20;

interface StreamCache {
  key: string;
  stream: TokenStream;
  index: ReturnType<typeof buildIndex>;
}

/**
 * Вкладка RSVP-чтения: сцена (пивот ЗАКРЕПЛЁН грид-раскладкой в центре
 * сцены — без JS-измерений и трансформов, поэтому не дрожит ни на одном
 * кадре и платформе; вертикаль строки — настройкой), пульт, раскладка
 * «Плеер» (В10), фокус-режим (В1), автопауза при уходе со вкладки,
 * автосохранение позиции (В2).
 *
 * Двигун — единственная точка истины воспроизведения; вью — только
 * подписчик (onToken/onWait/onEnd) и диспетчер команд (play/pause/jump).
 */
export class RsvpView extends ItemView {
  private readonly plugin: RsvpPlugin;

  /* ── DOM сцены ── */
  private appEl!: HTMLElement;
  private crumbsEl!: HTMLElement;
  private noteEl!: HTMLElement;
  private stageEl!: HTMLElement;
  private wordEl!: HTMLElement;
  private beforeEl!: HTMLElement;
  private pivotEl!: HTMLElement;
  private afterGroupEl!: HTMLElement;
  private afterEl!: HTMLElement;
  private hyphenEl!: HTMLElement;
  private statusEl!: HTMLElement;
  private progressFillEl!: HTMLElement;
  private progressLabelEl!: HTMLElement;
  private counterEl!: HTMLElement;
  private wpmEl!: HTMLElement;
  private fontEl!: HTMLElement;
  private minEl!: HTMLElement;
  private focusBtn!: HTMLElement;
  private playBtn!: HTMLElement;
  private focusExitBtn!: HTMLElement;

  /* ── сессия ── */
  private req: ReadingRequest | null = null;
  private cache: StreamCache | null = null;
  private frames: FrameStream | null = null;
  private engine: RsvpEngine | null = null;
  private lastToken: Token | null = null;
  private lastFrame = -1;
  private focusHidden = false;
  private measureCanvas: HTMLCanvasElement | null = null;
  private resizeTimer: ReturnType<typeof setTimeout> | null = null;
  private rebuildTimer: ReturnType<typeof setTimeout> | null = null;
  private settingsTimer: ReturnType<typeof setTimeout> | null = null;
  private stageObserver: ResizeObserver | null = null;
  private fontsHooked = false;
  private destroyed = false;

  constructor(leaf: WorkspaceLeaf, plugin: RsvpPlugin) {
    super(leaf);
    this.plugin = plugin;
  }

  getViewType(): string {
    return VIEW_TYPE_RSVP;
  }

  getDisplayText(): string {
    if (this.req?.kind === "note") return `RSVP: ${this.req.file.basename}`;
    if (this.req) return "RSVP-чтение";
    return "RSVP-чтение";
  }

  getIcon(): string {
    return "book-open";
  }

  /* ═══════════════ жизненный цикл ═══════════════ */

  async onOpen(): Promise<void> {
    this.buildShell();
    this.registerAutoPause();
    this.registerDomEvent(window, "resize", () => this.onStageResize());
    // ResizeObserver ловит смену ширины сцены, которую window-resize не
    // видит: collapse/expand сайдбаров (фокус-режим), перетасовку сплитов.
    // Пивот закреплён CSS — переякоривать нечего, только пересборка кадров
    // (сайдбары/сплиты меняют ширину сцены и пороги резки).
    if (typeof ResizeObserver !== "undefined") {
      this.stageObserver = new ResizeObserver(() => this.onStageResize());
      this.stageObserver.observe(this.stageEl);
    }
    // Поздняя загрузка шрифтов меняет метрики усадки — пересчитать кадр
    // (закрепление пивота от шрифтов не зависит).
    if (!this.fontsHooked && typeof document !== "undefined" && document.fonts !== undefined) {
      this.fontsHooked = true;
      void document.fonts.ready
        .then(() => {
          if (this.destroyed) return;
          const st = this.engine?.state;
          if (st !== "playing" && st !== "waiting") this.renderFrame(Math.max(0, this.lastFrame));
        })
        .catch(() => undefined);
    }
  }

  async onClose(): Promise<void> {
    this.destroyed = true;
    if (this.resizeTimer !== null) clearTimeout(this.resizeTimer);
    if (this.rebuildTimer !== null) clearTimeout(this.rebuildTimer);
    if (this.settingsTimer !== null) {
      clearTimeout(this.settingsTimer);
      void this.plugin.saveSettings();
    }
    this.stageObserver?.disconnect();
    this.stageObserver = null;
    this.engine?.destroy();
    this.savePositionNow();
    await this.plugin.store.flush();
    this.restoreSplits();
    this.contentEl.empty();
  }

  /** Переживание перезапуска: точка восстановления источника. */
  getState(): Record<string, unknown> {
    if (this.req?.kind === "note") return { path: this.req.file.path };
    return {};
  }

  async setState(state: unknown, result: ViewStateResult): Promise<void> {
    try {
      const s = (state ?? {}) as PersistedViewState;
      if (typeof s.path === "string" && this.req === null) {
        const f = this.app.vault.getAbstractFileByPath(s.path);
        if (f instanceof TFile) {
          await this.startReading({ kind: "note", file: f, resume: this.plugin.store.get(s.path) ?? null });
        }
      }
    } catch {
      // битое состояние — остаёмся в пустой сцене
    }
    await super.setState(state, result);
  }

  /* ═══════════════ запуск чтения ═══════════════ */

  async startReading(req: ReadingRequest): Promise<void> {
    const settings = this.plugin.settings;

    // Текст источника.
    let text: string;
    if (req.kind === "note") {
      try {
        text = await this.app.vault.cachedRead(req.file);
      } catch (e) {
        new Notice(`RSVP: не удалось прочитать «${req.file.basename}»`);
        console.error("rsvp: read failed", e);
        return;
      }
      if (text.trim().length === 0) {
        new Notice("RSVP: заметка пуста");
        return;
      }
    } else {
      text = req.text;
      if (text.trim().length === 0) {
        new Notice("RSVP: пустой диапазон");
        return;
      }
    }

    // Смена сессии: остановить прежнюю (позиция уже сохранена на каждом кадре).
    this.engine?.destroy();
    this.engine = null;
    this.frames = null;
    this.req = req;
    this.lastToken = null;
    this.lastFrame = -1;
    this.showScene();

    // Фаза A + фаза B. Кэш — только для заметок (path+mtime+filters);
    // сессии выделения/курсора не кэшируются: ключ по длине дал бы
    // коллизии между разными диапазонами, а повторное открытие
    // сессионного чтения — редкий сценарий.
    const filters = settings.filters;
    let stream: TokenStream;
    if (req.kind === "note") {
      const sourceKey = `${req.file.path}|${req.file.stat.mtime}|${hashFilters(filters)}`;
      if (this.cache?.key === sourceKey) {
        stream = this.cache.stream;
      } else {
        const index = buildIndex(text, filters, sourceKey);
        stream = new TokenStream(text, index, filters);
        this.cache = { key: sourceKey, stream, index };
        // В13: фоновая доготовка сразу, старт не ждёт весь файл.
        void stream.pumpAhead().catch(() => undefined);
      }
    } else {
      const index = buildIndex(text, filters, "session");
      stream = new TokenStream(text, index, filters);
      this.cache = { key: "session", stream, index };
      void stream.pumpAhead().catch(() => undefined);
    }

    // Кадровый поток под геометрию сцены (пивот в центре — парты).
    const avail = this.partAvail();
    const frames = new FrameStream(stream, this.measure.bind(this), avail.left, avail.right, MIN_SCALE);
    this.frames = frames;

    // Точка старта: резюм или начало.
    let frameIdx = 0;
    if (req.kind === "note" && req.resume) {
      const tokenIdx = await findResumeIndex(stream, req.resume);
      frameIdx = Math.max(0, frames.frameOfToken(tokenIdx));
    }

    const wpm = req.kind === "note" && req.resume ? req.resume.wpm : settings.wpm;
    this.engine = new RsvpEngine(frames, this.engineCallbacks(), {
      startWpm: wpm,
      minWordMs: settings.minWordMs,
      minMsMaxLetters: settings.minWordMaxLetters,
    });
    this.updateWpmHud();
    this.updateMinHud();
    this.updateHud(0);

    if (settings.hideSidebarOnOpen && !Platform.isMobile) {
      this.hideSplits();
    }

    if (settings.autoPlay) {
      this.engine.play(frameIdx);
    } else {
      this.renderFrame(frameIdx);
    }
    this.appEl.focus();
  }

  /** Реакция на живые настройки (кегль, минимум показа, вертикаль строки). */
  applySettings(settings: RsvpSettings): void {
    this.fontEl?.setText(`${settings.fontSize}`);
    this.minEl?.setText(this.minHudText(settings.minWordMs));
    this.engine?.setMinWordMs(settings.minWordMs);
    this.engine?.setMinWordMaxLetters(settings.minWordMaxLetters);
    this.applyWordShift();
    if (this.req !== null) {
      void this.rebuildFrames();
    }
  }

  /* ═══════════════ сцена ═══════════════ */

  private buildShell(): void {
    this.contentEl.empty();
    this.appEl = this.contentEl.createDiv({ cls: "rsvp-app" });
    this.appEl.setAttribute("tabindex", "0");
    this.registerDomEvent(this.appEl, "keydown", (e: KeyboardEvent) => {
      if (this.onKeyDown(e)) e.preventDefault();
    });
    this.registerDomEvent(this.appEl, "click", (e: MouseEvent) => {
      // Тап по сцене = пауза/старт (мобильный пульт В6).
      if ((e.target as HTMLElement).closest(".rsvp-controls")) return;
      this.togglePlay();
    });

    const top = this.appEl.createDiv({ cls: "rsvp-top" });
    this.crumbsEl = top.createDiv({ cls: "rsvp-crumbs", text: "—" });
    this.noteEl = top.createDiv({ cls: "rsvp-note", text: "" });

    const stage = this.appEl.createDiv({ cls: "rsvp-stage" });
    this.stageEl = stage;
    // Полосы поля чтения следуют за строкой (var --rsvp-word-shift).
    stage.createDiv({ cls: "rsvp-band-line rsvp-band-top" });
    stage.createDiv({ cls: "rsvp-band-line rsvp-band-bottom" });
    // Грид [1fr auto 1fr]: ПИВОТ ВСЕГДА В ЦЕНТРЕ СЦЕНЫ (треки 1fr слева и
    // справа равны), части слова пристраиваются к нему, при нехватке
    // перетекают за край своего трека — без трансформов и измерений на кадр.
    this.wordEl = stage.createDiv({ cls: "rsvp-word" });
    this.beforeEl = this.wordEl.createSpan({ cls: "rsvp-w-part rsvp-w-before" });
    this.pivotEl = this.wordEl.createSpan({ cls: "rsvp-pivot" });
    this.afterGroupEl = this.wordEl.createSpan({ cls: "rsvp-w-part rsvp-w-after" });
    this.afterEl = this.afterGroupEl.createSpan({ cls: "rsvp-w-after-text" });
    this.hyphenEl = this.afterGroupEl.createSpan({ cls: "rsvp-hyphen", text: "" });
    this.statusEl = stage.createDiv({ cls: "rsvp-status", text: "" });
    this.applyWordShift();

    const bottom = this.appEl.createDiv({ cls: "rsvp-bottom" });
    const bar = bottom.createDiv({ cls: "rsvp-progress" });
    this.progressFillEl = bar.createDiv({ cls: "rsvp-progress-fill" });
    this.progressLabelEl = bar.createDiv({ cls: "rsvp-progress-label", text: "0%" });

    const controls = bottom.createDiv({ cls: "rsvp-controls" });
    this.playBtn = this.button(controls, "play", "Старт/пауза (Space)", () => this.togglePlay());
    // Единая пара «шевронов» для ±10 слов — одинаковый стиль/вес линий.
    this.button(controls, "chevrons-left", "−10 слов (←)", () => this.engine?.jump(-JUMP_WORDS));
    this.button(controls, "chevrons-right", "+10 слов (→)", () => this.engine?.jump(JUMP_WORDS));
    const wpmGroup = controls.createDiv({ cls: "rsvp-wpm-group" });
    this.holdButton(wpmGroup, "minus", "Медленнее (↓)", () => this.stepWpm(-WPM_STEP));
    this.wpmEl = wpmGroup.createDiv({ cls: "rsvp-wpm" });
    this.holdButton(wpmGroup, "plus", "Быстрее (↑)", () => this.stepWpm(WPM_STEP));
    // Минимальная экспозиция КОРОТКИХ слов: общий темп не трогаем.
    const minGroup = controls.createDiv({ cls: "rsvp-min-group" });
    this.holdButton(minGroup, "minus", "Минимум показа коротких слов −10 мс", () => this.stepMinMs(-MINMS_STEP));
    this.minEl = minGroup.createDiv({
      cls: "rsvp-min",
      text: this.minHudText(this.plugin.settings.minWordMs),
      attr: {
        "aria-label": `Минимальное время показа коротких слов (до ${this.plugin.settings.minWordMaxLetters} букв), мс (0 — выкл.)`,
      },
    });
    this.holdButton(minGroup, "plus", "Минимум показа коротких слов +10 мс", () => this.stepMinMs(MINMS_STEP));
    const fontGroup = controls.createDiv({ cls: "rsvp-font-group" });
    this.holdButton(fontGroup, "A−", "Кегль меньше", () => this.stepFontSize(-FONT_STEP), true);
    this.fontEl = fontGroup.createDiv({
      cls: "rsvp-font",
      text: `${this.plugin.settings.fontSize}`,
      attr: { "aria-label": "Кегль слова, px" },
    });
    this.holdButton(fontGroup, "A+", "Кегль больше", () => this.stepFontSize(FONT_STEP), true);
    this.counterEl = controls.createDiv({ cls: "rsvp-counter", text: "0" });
    this.button(controls, "list", "Разделы (заголовки)", () => this.openSectionModal());
    this.focusBtn = this.button(
      controls,
      "maximize-2",
      "Фокус-режим (F): убрать панели",
      () => this.toggleFocusMode(),
    );

    // Выход из иммерсивного фокус-режима на мобильных (Esc нет).
    this.focusExitBtn = this.appEl.createDiv({
      cls: "rsvp-focus-exit",
      attr: { "aria-label": "Выйти из фокус-режима" },
    });
    setIcon(this.focusExitBtn, "minimize-2");
    this.focusExitBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      this.toggleFocusMode();
    });

    this.showEmpty();
  }

  private button(parent: HTMLElement, icon: string, tooltip: string, onClick: () => void): HTMLElement {
    const el = parent.createDiv({ cls: "rsvp-btn", attr: { "aria-label": tooltip } });
    setIcon(el, icon.trim());
    el.addEventListener("click", (e) => {
      e.stopPropagation();
      onClick();
    });
    return el;
  }

  /**
   * Кнопка-шаг с авто-повтором при удержании (скорость, кегль).
   * glyph — имя иконки Lucide либо текст (isText = true: «A−»/«A+»).
   */
  private holdButton(
    parent: HTMLElement,
    glyph: string,
    tooltip: string,
    onStep: () => void,
    isText = false,
  ): HTMLElement {
    const el = parent.createDiv({ cls: "rsvp-btn rsvp-btn-wpm", attr: { "aria-label": tooltip } });
    if (isText) el.setText(glyph);
    else setIcon(el, glyph.trim());
    let holdTimer: ReturnType<typeof setTimeout> | null = null;
    let repeatTimer: ReturnType<typeof setInterval> | null = null;
    const stop = (): void => {
      if (holdTimer !== null) {
        clearTimeout(holdTimer);
        holdTimer = null;
      }
      if (repeatTimer !== null) {
        clearInterval(repeatTimer);
        repeatTimer = null;
      }
      el.classList.remove("is-active");
    };
    el.addEventListener("pointerdown", (e) => {
      e.stopPropagation();
      e.preventDefault();
      onStep();
      el.classList.add("is-active");
      holdTimer = setTimeout(() => {
        holdTimer = null;
        repeatTimer = setInterval(() => onStep(), 110);
      }, 450);
    });
    el.addEventListener("pointerup", stop);
    el.addEventListener("pointercancel", stop);
    el.addEventListener("pointerleave", stop);
    return el;
  }

  private showEmpty(): void {
    this.crumbsEl.setText("RSVP Reading Flow");
    this.noteEl.setText("");
    this.wordEl.style.display = "none";
    this.statusEl.setText("Откройте команду «RSVP: читать заметку», «читать выделенное» или «продолжить чтение»");
    this.statusEl.classList.add("rsvp-status-empty");
  }

  private showScene(): void {
    this.wordEl.style.display = "";
    this.statusEl.setText("");
    this.statusEl.classList.remove("rsvp-status-empty");
    this.noteEl.setText(
      this.req?.kind === "note"
        ? this.req.file.basename
        : this.req?.kind === "selection"
          ? this.req.label
          : this.req?.label ?? "",
    );
  }

  /* ═══════════════ рендер слова (якорь пивота) ═══════════════ */

  private engineCallbacks() {
    return {
      onToken: (index: number, display: string, token: Token): void => {
        this.lastToken = token;
        this.lastFrame = index;
        this.renderWord(display, token, index);
        this.updateHud(index);
        this.savePositionNow();
      },
      onWait: (): void => {
        this.statusEl.setText("подготовка…");
      },
      onEnd: (): void => {
        this.statusEl.setText("конец");
        this.playIcon("rotate-ccw");
        if (this.req?.kind === "note") {
          // Чтение завершено — прогресс обнуляем, следующий старт с начала.
          this.plugin.store.forget(this.req.file.path);
          void this.plugin.store.flush();
        }
      },
    };
  }

  /**
   * Кадр: разметка «до | пивот | после», пивот ЗАКРЕПЛЁН гридом в центре
   * сцены (двигать ничего не надо), каскад Д3 по партам: правая часть с
   * дефисом куска — в правую половину, левая — в левую; не влезает с
   * усадкой до 0.65 — уже порезано FrameStream. Дефис не последнего
   * куска (В12).
   */
  private renderWord(display: string, token: Token, frameIdx: number): void {
    const fontSize = this.plugin.settings.fontSize;
    let pivot = token.pivot;
    if (pivot < 0 || pivot >= display.length) {
      pivot = Math.min(Math.max(0, display.length > 0 ? Math.floor(display.length / 3) : 0), Math.max(0, display.length - 1));
    }

    const showHyphen = this.frames !== null && !this.frames.isLastPiece(frameIdx);
    const before = display.slice(0, pivot);
    const after = display.slice(pivot + 1);

    // Каскад Д3 вокруг закреплённого пивота: дефис учитывается в правой
    // части (он дописывается в конец строки для измерения).
    const avail = this.partAvail();
    let scale = 1;
    if (display.length > 0 && avail.left > 0 && avail.right > 0) {
      const d = decideParts(
        display + (showHyphen ? "-" : ""),
        pivot,
        this.measure,
        avail.left,
        avail.right,
        MIN_SCALE,
      );
      if (d.kind === "shrink") scale = d.scale;
      else if (d.kind === "split") scale = MIN_SCALE; // страховка: резка в FrameStream
    }

    this.beforeEl.setText(before);
    this.pivotEl.setText(display.length > 0 ? display[pivot] : "");
    this.afterEl.setText(after);
    this.hyphenEl.setText(showHyphen ? "-" : "");
    this.wordEl.style.fontSize = `${Math.round(fontSize * scale)}px`;

    if (this.engine?.state === "waiting") this.statusEl.setText("подготовка…");
    else if (this.statusEl.getText() === "подготовка…") this.statusEl.setText("");
  }

  /** Показ кадра без запуска движка (пауза, Home/End, старт без autoPlay). */
  private renderFrame(frameIdx: number): void {
    if (this.frames === null) return;
    const len = this.frames.length;
    let idx = frameIdx;
    if (len >= 0) idx = Math.min(Math.max(0, idx), len - 1);
    if (!this.frames.isReady(idx)) {
      this.statusEl.setText("подготовка…");
      return;
    }
    try {
      const token = this.frames.get(idx);
      this.lastToken = token;
      this.lastFrame = idx;
      this.renderWord(token.text, token, idx);
      this.updateHud(idx);
    } catch {
      // кадр ещё строится
    }
  }

  /* ═══════════════ HUD ═══════════════ */

  private updateHud(frameIdx: number): void {
    const frames = this.frames;
    if (frames === null) return;
    const total = frames.totalReadableChars;
    const done = frames.charsBefore(frameIdx);
    const pct = total > 0 ? Math.min(100, Math.round((done / total) * 100)) : 0;
    this.progressFillEl.style.width = `${pct}%`;
    this.progressLabelEl.setText(`${pct}%`);
    const len = frames.length;
    this.counterEl.setText(len >= 0 ? `${frameIdx + 1}/${len}` : `${frameIdx + 1}`);
    this.updateCrumbs();
  }

  private updateCrumbs(): void {
    const tok = this.lastToken;
    if (tok === null) return;
    let title = "";
    if (tok.sectionIdx >= 0 && this.frames !== null) {
      try {
        title = this.frames.getSection(tok.sectionIdx).title;
      } catch {
        title = "";
      }
    }
    if (title === "") {
      title = this.req?.kind === "note" ? "начало заметки" : (this.req?.label ?? "текст");
    }
    this.crumbsEl.setText(title);
  }

  private updateWpmHud(): void {
    if (this.engine !== null) {
      this.wpmEl.setText(`${this.engine.wpm}`);
    }
  }

  /** HUD минимальной экспозиции: «выкл» — признак нуля, иначе «N мс». */
  private minHudText(v: number): string {
    return v <= MINMS_MIN ? "выкл" : `${v} мс`;
  }

  private updateMinHud(): void {
    this.minEl?.setText(this.minHudText(this.plugin.settings.minWordMs));
  }

  private playIcon(icon: string): void {
    setIcon(this.playBtn, icon);
  }

  private syncPlayIcon(): void {
    const st = this.engine?.state ?? "idle";
    this.playIcon(st === "playing" || st === "waiting" ? "pause" : st === "ended" ? "rotate-ccw" : "play");
  }

  /* ═══════════════ управление ═══════════════ */

  private togglePlay(): void {
    const e = this.engine;
    if (e === null) return;
    const st = e.state;
    if (st === "playing" || st === "waiting") {
      e.pause();
      this.savePositionNow();
      void this.plugin.store.flush();
    } else if (st === "ended") {
      e.play(0);
    } else if (st === "paused" || st === "idle") {
      e.play();
    }
    this.syncPlayIcon();
    this.appEl.focus();
  }

  /** Прыжок с показом кадра (стрелки, Home/End). */
  private jumpTo(frameIdx: number): void {
    const e = this.engine;
    if (e === null || this.frames === null) return;
    const wasActive = e.state === "playing" || e.state === "waiting";
    e.pause();
    e.play(Math.max(0, frameIdx));
    if (!wasActive) {
      e.pause();
      this.renderFrame(Math.max(0, frameIdx));
    }
    // активное чтение: движок сам покажет кадр по расписанию
    this.syncPlayIcon();
  }

  /** Шаг скорости из UI (кнопки −/+ или стрелки): кламп, живой HUD,
   *  память последней скорости (В6-2) с дебаунс-записью настроек. */
  private stepWpm(delta: number): void {
    const cur = this.engine?.wpm ?? this.plugin.settings.wpm;
    const next = Math.min(WPM_MAX, Math.max(WPM_MIN, cur + delta));
    this.engine?.setWpm(next);
    this.plugin.settings.wpm = next;
    this.updateWpmHud();
    if (this.settingsTimer !== null) clearTimeout(this.settingsTimer);
    this.settingsTimer = setTimeout(() => {
      this.settingsTimer = null;
      void this.plugin.saveSettings();
    }, 1200);
  }

  /**
   * Шаг минимальной экспозиции из пульта (только короткие слова —
   * общий темп не трогается): движок применяет пол к следующему же
   * интервалу (текущий кадр не прерывается), сохранение настроек —
   * дебаунс 1.2 с (флеш при закрытии).
   */
  private stepMinMs(delta: number): void {
    const cur = this.plugin.settings.minWordMs;
    const next = Math.min(MINMS_MAX, Math.max(MINMS_MIN, cur + delta));
    if (next === cur) return;
    this.plugin.settings.minWordMs = next;
    this.engine?.setMinWordMs(next);
    this.updateMinHud();
    if (this.settingsTimer !== null) clearTimeout(this.settingsTimer);
    this.settingsTimer = setTimeout(() => {
      this.settingsTimer = null;
      void this.plugin.saveSettings();
    }, 1200);
  }

  /**
   * Шаг кегля из пульта: мгновенный визуальный отклик (текущий кадр
   * и переякорка), пересборка кадров (слоги/усадка под новую геометрию)
   * — дебаунс 250 мс, сохранение настроек — дебаунс 1.2 с.
   */
  private stepFontSize(delta: number): void {
    const cur = this.plugin.settings.fontSize;
    const next = Math.min(FONT_MAX, Math.max(FONT_MIN, cur + delta));
    if (next === cur) return;
    this.plugin.settings.fontSize = next;
    this.fontEl.setText(`${next}`);
    // Пивот закреплён CSS: кегль меняется мгновенно без переякорки.
    this.wordEl.style.fontSize = `${next}px`;
    if (this.settingsTimer !== null) clearTimeout(this.settingsTimer);
    this.settingsTimer = setTimeout(() => {
      this.settingsTimer = null;
      void this.plugin.saveSettings();
    }, 1200);
    if (this.rebuildTimer !== null) clearTimeout(this.rebuildTimer);
    this.rebuildTimer = setTimeout(() => {
      this.rebuildTimer = null;
      void this.rebuildFrames();
    }, 250);
  }

  private onKeyDown(e: KeyboardEvent): boolean {
    if (this.engine === null) return false;
    switch (e.key) {
      case " ":
        this.togglePlay();
        return true;
      case "ArrowLeft":
        this.engine.jump(-JUMP_WORDS);
        return true;
      case "ArrowRight":
        this.engine.jump(JUMP_WORDS);
        return true;
      case "ArrowUp":
        this.stepWpm(WPM_STEP);
        return true;
      case "ArrowDown":
        this.stepWpm(-WPM_STEP);
        return true;
      case "Home":
        this.jumpToSectionStart();
        return true;
      case "End":
        this.jumpToEnd();
        return true;
      case "f":
      case "F":
        this.toggleFocusMode();
        return true;
      case "Escape":
        if (this.focusHidden) {
          this.toggleFocusMode();
        } else {
          this.engine.pause();
          this.savePositionNow();
          void this.plugin.store.flush();
          this.syncPlayIcon();
        }
        return true;
      default:
        return false;
    }
  }

  private jumpToSectionStart(): void {
    const tok = this.lastToken;
    if (tok === null || this.frames === null) return;
    let target = 0;
    if (tok.sectionIdx >= 0) {
      try {
        const sec = this.frames.getSection(tok.sectionIdx);
        if (sec.firstTokenIdx >= 0) target = sec.firstTokenIdx;
      } catch {
        target = 0;
      }
    }
    const frame = this.frames.frameOfToken(target);
    if (frame >= 0) this.jumpTo(frame);
  }

  private jumpToEnd(): void {
    if (this.frames === null) return;
    const len = this.frames.length;
    let frame: number;
    if (len >= 0) {
      frame = len - 1;
    } else {
      // не финализировано: последний готовый кадр
      let f = Math.max(0, this.lastFrame);
      while (this.frames.isReady(f + 1)) f++;
      frame = f;
    }
    if (frame >= 0) this.jumpTo(frame);
  }

  /* ═══════════════ модалка разделов (В4: продолжить с заголовка) ═══════════════ */

  openSectionModal(): void {
    const index = this.cache?.index;
    if (index === undefined || index === null) {
      new Notice("RSVP: сначала откройте чтение");
      return;
    }
    if (index.sections.length === 0) {
      new Notice("RSVP: в тексте нет заголовков");
      return;
    }
    new SectionSuggestModal(this, index.sections).open();
  }

  /** Переход к разделу (вызов из модалки разделов). */
  async goToSection(sectionIdx: number): Promise<void> {
    if (this.frames === null) return;
    try {
      await this.frames.seek(sectionIdx);
    } catch {
      new Notice("RSVP: не удалось перейти к разделу");
      return;
    }
    const sec = this.cache?.index.sections[sectionIdx];
    const tokenIdx = sec?.firstTokenIdx ?? 0;
    const frame = this.frames.frameOfToken(Math.max(0, tokenIdx));
    if (frame < 0) {
      this.renderFrame(0);
      return;
    }
    this.jumpTo(frame);
  }

  /* ═══════════════ фокус-режим (В1) ═══════════════ */

  toggleFocusMode(): void {
    if (Platform.isMobile) {
      // Мобильный: сайдбаров нет — иммерсивный режим (скрыть HUD).
      this.focusHidden = !this.focusHidden;
      this.appEl.classList.toggle("rsvp-focus", this.focusHidden);
      setIcon(this.focusBtn, this.focusHidden ? "minimize-2" : "maximize-2");
      return;
    }
    if (this.focusHidden) this.restoreSplits();
    else this.hideSplits();
  }

  private hideSplits(): void {
    const splitApi = (side: "leftSplit" | "rightSplit"): { collapse(): void } | null => {
      const s = (this.app.workspace as unknown as Record<string, unknown>)[side];
      return typeof s === "object" && s !== null && "collapse" in (s as object)
        ? (s as unknown as { collapse(): void })
        : null;
    };
    try {
      splitApi("leftSplit")?.collapse();
      splitApi("rightSplit")?.collapse();
      this.focusHidden = true;
      this.appEl.classList.add("rsvp-focus");
      setIcon(this.focusBtn, "minimize-2");
    } catch (e) {
      console.warn("rsvp: collapse() недоступен", e);
    }
  }

  private restoreSplits(): void {
    if (!this.focusHidden) return;
    const splitApi = (side: "leftSplit" | "rightSplit"): { expand(): void } | null => {
      const s = (this.app.workspace as unknown as Record<string, unknown>)[side];
      return typeof s === "object" && s !== null && "expand" in (s as object)
        ? (s as unknown as { expand(): void })
        : null;
    };
    try {
      splitApi("leftSplit")?.expand();
      splitApi("rightSplit")?.expand();
    } catch (e) {
      console.warn("rsvp: expand() недоступен", e);
    }
    this.focusHidden = false;
    this.appEl.classList.remove("rsvp-focus");
    setIcon(this.focusBtn, "maximize-2");
  }

  /* ═══════════════ автопауза и позиция ═══════════════ */

  private registerAutoPause(): void {
    this.registerEvent(
      this.app.workspace.on("active-leaf-change", (leaf) => {
        if (leaf !== this.leaf) {
          const st = this.engine?.state;
          if (st === "playing" || st === "waiting") {
            this.engine?.pause();
            this.savePositionNow();
            void this.plugin.store.flush();
            this.syncPlayIcon();
          }
        }
      }),
    );
    this.registerDomEvent(window, "blur", () => {
      const st = this.engine?.state;
      if (st === "playing" || st === "waiting") {
        this.engine?.pause();
        this.syncPlayIcon();
      }
    });
  }

  private savePositionNow(): void {
    const req = this.req;
    const frames = this.frames;
    const engine = this.engine;
    if (req?.kind !== "note" || frames === null || engine === null) return;
    const len = frames.length;
    let frameIdx = engine.index;
    if (len >= 0) frameIdx = Math.min(Math.max(0, frameIdx), Math.max(0, len - 1));
    if (frameIdx < 0) return;
    let tokenIdx = frames.tokenOf(frameIdx);
    if (tokenIdx < 0) tokenIdx = frameIdx;
    const cache = this.cache;
    if (cache === null) return;
    let sectionIdx = -1;
    let charOffset = 0;
    if (cache.stream.isReady(tokenIdx)) {
      const t = cache.stream.get(tokenIdx);
      sectionIdx = t.sectionIdx;
      charOffset = t.charStart;
    }
    const pos: Position = {
      sectionIdx,
      charOffset,
      fingerprint: buildFingerprint(cache.stream, tokenIdx),
      wpm: engine.wpm,
      tokenIdx,
      updatedAt: Date.now(),
    };
    this.plugin.store.save(req.file.path, pos);
  }

  /* ═══════════════ геометрия и пересборка кадров ═══════════════ */

  /**
   * Бюджеты половин сцены вокруг ЗАКРЕПЛЁННОГО пивота: от центра до края
   * минус поле STAGE_SIDE_PAD (пивот стоит ровно в центре).
   */
  private partAvail(): { left: number; right: number } {
    const w = this.stageEl?.clientWidth ?? 0;
    if (w <= 0) return { left: 0, right: 0 };
    const half = Math.max(24, (w - STAGE_SIDE_PAD * 2) / 2);
    return { left: half, right: half };
  }

  /** Вертикаль строки чтения: CSS-переменная, направляющие следуют сами. */
  private applyWordShift(): void {
    if (!this.appEl) return;
    const v = Math.min(WORD_SHIFT_MAX, Math.max(WORD_SHIFT_MIN, this.plugin.settings.wordVerticalShift));
    this.appEl.style.setProperty("--rsvp-word-shift", `${v}%`);
  }

  /** Смена геометрии сцены: пересборка кадров (пивот в CSS не зависит от неё). */
  private onStageResize(): void {
    if (this.resizeTimer !== null) clearTimeout(this.resizeTimer);
    this.resizeTimer = setTimeout(() => {
      this.resizeTimer = null;
      void this.rebuildFrames();
    }, 300);
  }

  private measure(s: string): number {
    if (this.measureCanvas === null) {
      this.measureCanvas = document.createElement("canvas");
    }
    const ctx = this.measureCanvas.getContext("2d");
    const fs = this.plugin.settings.fontSize;
    if (ctx === null) return s.length * fs * 0.6 + s.length * 0.01 * fs;
    ctx.font = `400 ${fs}px ${FONT_STACK}`;
    // CSS letter-spacing (0.01em) дописывается после КАЖДОГО символа и
    // масштабируется вместе с кеглем — canvas его не меряет, компенсируем.
    return ctx.measureText(s).width + s.length * 0.01 * fs;
  }

  /** Пересборка FrameStream (кегль/размер окна): сохраняет место чтения. */
  private async rebuildFrames(): Promise<void> {
    const old = this.frames;
    const engine = this.engine;
    if (old === null || engine === null || this.cache === null || this.destroyed) return;
    const wasActive = engine.state === "playing" || engine.state === "waiting";
    const tokenIdx = Math.max(0, old.tokenOf(Math.max(0, engine.index)));
    engine.destroy();
    const avail = this.partAvail();
    const frames = new FrameStream(this.cache.stream, this.measure.bind(this), avail.left, avail.right, MIN_SCALE);
    this.frames = frames;
    let frameIdx = frames.frameOfToken(tokenIdx);
    if (frameIdx < 0) frameIdx = 0;
    this.engine = new RsvpEngine(frames, this.engineCallbacks(), {
      startWpm: engine.wpm,
      minWordMs: this.plugin.settings.minWordMs,
      minMsMaxLetters: this.plugin.settings.minWordMaxLetters,
    });
    this.updateWpmHud();
    if (wasActive) {
      this.engine.play(frameIdx);
    } else {
      this.renderFrame(frameIdx);
    }
    this.syncPlayIcon();
  }
}

/* ═══════════ модалка выбора раздела ═══════════ */

class SectionSuggestModal extends FuzzySuggestModal<SectionEntry> {
  private readonly view: RsvpView;
  private readonly sections: SectionEntry[];

  constructor(view: RsvpView, sections: SectionEntry[]) {
    super(view.app);
    this.view = view;
    this.sections = sections;
    this.setPlaceholder("Продолжить с заголовка…");
  }

  getItems(): SectionEntry[] {
    return this.sections;
  }

  getItemText(item: SectionEntry): string {
    return `${"—".repeat(Math.max(0, item.level - 1))} ${item.title}`;
  }

  onChooseItem(item: SectionEntry): void {
    const idx = this.sections.indexOf(item);
    if (idx >= 0) void this.view.goToSection(idx);
  }
}
