/** Owner-supplied UTC calendar date; GitHub/Gitea do not consistently expose PAT expiry. */
export function validateExpiry(value: string | null): string | null {
    if (value === null || value === '') return null;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || !Number.isFinite(Date.parse(value)) || new Date(value).toISOString().slice(0, 10) !== value) throw new Error('Некорректная дата окончания PAT');
    return value;
}
export function patWarning(expiresOn: string | null, now = Date.now()): string | null {
    const date = validateExpiry(expiresOn); if (!date) return null;
    const days = Math.round((Date.parse(date) - Date.parse(new Date(now).toISOString().slice(0, 10))) / 86_400_000);
    if (days > 7) return null;
    if (days < 0) return 'Указанный срок действия PAT уже истёк. Пожалуйста, обновите его.';
    if (days === 0) return 'Сегодня заканчивается срок действия PAT. Пожалуйста, обновите его.';
    const word = days === 1 ? 'день' : days <= 4 ? 'дня' : 'дней';
    return `Через ${days} ${word} срок действия PAT заканчивается. Пожалуйста, обновите его.`;
}
