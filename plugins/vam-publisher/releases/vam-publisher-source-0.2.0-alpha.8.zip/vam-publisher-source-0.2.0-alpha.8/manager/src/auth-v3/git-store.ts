import { validateRepo } from '../auth-v2/model';
import type { Repo } from './model';
export type GitFailure = 'authentication' | 'permission' | 'sso' | 'rate-limit' | 'repository-unavailable' | 'empty-repository' | 'conflict' | 'validation' | 'network' | 'timeout' | 'transport' | 'redirect' | 'server' | 'unknown-write' | 'invalid-response';
const messages: Record<GitFailure, string> = {
    authentication: 'Git отклонил авторизацию. Обратитесь к администратору за кодом обновления подключения.',
    permission: 'Недостаточно прав Git. Администратору нужно проверить доступ к приватному репозиторию.',
    sso: 'Git требует подтверждения SSO для токена.', 'rate-limit': 'Git временно ограничил число запросов. Повторите позже.',
    'repository-unavailable': 'Приватный репозиторий недоступен либо не существует.', conflict: 'Данные изменились. Обновите состояние и повторите действие.',
    'empty-repository': 'Репозиторий Git пуст. Создайте первый коммит, например README, и повторите подключение.',
    timeout: 'Git не ответил за отведённое время. Проверьте подключение и повторите попытку.',
    transport: 'Ошибка вызова HTTP-транспорта Obsidian. Обновите Издатель и перевыпустите менеджер.',
    redirect: 'Git перенаправил запрос за пределы закреплённого API. Проверьте адрес API у Издателя.',
    validation: 'Git отклонил параметры записи.', network: 'Нет связи с Git.', server: 'Git временно недоступен.',
    'unknown-write': 'Результат отправки пока неизвестен. Повторная проверка использует ту же заявку.', 'invalid-response': 'Git вернул некорректные данные.',
};
export class GitError extends Error { constructor(readonly kind: GitFailure, readonly status = 0) { super(messages[kind]); } }
export interface File { sha: string; text: string }
export interface Store { checkPrivate?(): Promise<void>; read(path: string): Promise<File | null>; write(path: string, text: string, sha: string | null): Promise<void>; listRequests(): Promise<string[]>; listInstallations?(): Promise<string[]> }
export interface GitLayout { state: string; requests: string; extension: string }
export function transient(error: unknown): boolean { return error instanceof GitError && ['network', 'timeout', 'server', 'rate-limit'].includes(error.kind); }
/** Every update uses exactly the SHA accompanying the verified body. Writes are never blindly retried. */
export class GitStore implements Store {
    private repo: Repo;
    private cooldownUntil = 0;
    private readonly fetcher: typeof fetch;
    private apiBase: string;
    constructor(repo: Repo, private token: string, fetcher: typeof fetch = fetch, private pause = (ms: number) => new Promise<void>(resolve => setTimeout(resolve, ms)), private layout: GitLayout = { state: 'state.jws', requests: 'requests', extension: 'jwe' }) {
        this.repo = validateRepo(repo);
        // Restore the original ChannelClient's Window receiver: Electron fetch performs a brand check.
        this.fetcher = fetcher.bind(globalThis);
        this.apiBase = `${this.repo.baseUrl}/repos/${encodeURIComponent(this.repo.owner)}/${encodeURIComponent(this.repo.repo)}`;
    }
    private async api(suffix: string, method = 'GET', body?: unknown): Promise<{ status: number; data: any; raw: string; hasMore: boolean }> {
        const headers: Record<string, string> = { Accept: 'application/json', Authorization: `Bearer ${this.token}` };
        if (body !== undefined) headers['Content-Type'] = 'application/json';
        for (let attempt = 0; ; attempt++) {
            if (Date.now() < this.cooldownUntil) throw new GitError('rate-limit');
            const ctrl = new AbortController(), timer = setTimeout(() => ctrl.abort(), 15_000);
            try {
                const r = await this.fetcher(this.apiBase + suffix, { method, headers, body: body === undefined ? undefined : JSON.stringify(body), signal: ctrl.signal, cache: 'no-store', redirect: method === 'GET' ? 'follow' : 'error' });
                if (r.url) {
                    const final = new URL(r.url), api = new URL(this.repo.baseUrl), prefix = api.pathname.replace(/\/$/, '') + '/repos/';
                    if (final.origin !== api.origin || final.username || final.password || !final.pathname.startsWith(prefix)) throw new GitError('redirect', r.status);
                    // A repository rename may redirect the metadata GET. Subsequent writes use that same-origin canonical API path.
                    if (suffix === '' && method === 'GET' && /^([^/]+)\/([^/]+)\/?$/.test(final.pathname.slice(prefix.length))) this.apiBase = final.origin + final.pathname.replace(/\/$/, '');
                }
                // Keep timeout active while consuming the body; never surface server text containing credentials.
                const raw = await r.text();
                if (raw.length > 6_000_000) throw new GitError('invalid-response', r.status);
                let data: any; try { data = raw ? JSON.parse(raw) : null; } catch { /* Legacy hosts may return raw file bytes for application/json. */ }
                if (r.ok || r.status === 404) return { status: r.status, data, raw, hasMore: /rel="next"/.test(r.headers.get('link') ?? '') || (Array.isArray(data) && Number(r.headers.get('x-total-count')) > data.length) };
                const rate = r.status === 429 || (r.status === 403 && (r.headers.get('x-ratelimit-remaining') === '0' || r.headers.has('retry-after')));
                if (rate) {
                    const retry = r.headers.get('retry-after');
                    const until = retry ? (/^\d+$/.test(retry) ? Date.now() + Number(retry) * 1000 : Date.parse(retry)) : Number(r.headers.get('x-ratelimit-reset')) * 1000;
                    if (Number.isFinite(until) && until > Date.now()) this.cooldownUntil = until;
                }
                const empty = r.status === 409 && method === 'GET' && typeof data?.message === 'string' && /empty|unborn|not initialized/i.test(data.message);
                const kind: GitFailure = rate ? 'rate-limit' : r.status === 401 ? 'authentication' : r.status === 403 ? (r.headers.has('x-github-sso') ? 'sso' : 'permission') : empty ? 'empty-repository' : r.status === 409 ? 'conflict' : r.status === 422 ? 'validation' : r.status >= 500 ? 'server' : 'permission';
                throw new GitError(kind, r.status);
            } catch (e) {
                // Never expose exception text: it can contain the URL or credentials supplied by a proxy.
                const contextError = e instanceof TypeError && /illegal invocation|incompatible receiver|called on incompatible|fetch.*Window/i.test(e.message);
                const error = e instanceof GitError ? e : new GitError(ctrl.signal.aborted ? 'timeout' : contextError ? 'transport' : 'network');
                if (method !== 'GET' || attempt >= 2 || !transient(error)) throw error;
                clearTimeout(timer); await this.pause(Math.min(1000 * 2 ** attempt, 4000));
            } finally { clearTimeout(timer); }
        }
    }
    async checkPrivate(): Promise<void> {
        const response = await this.api('');
        if (response.status === 404) throw new GitError('repository-unavailable', 404);
        if (!response.data || typeof response.data.private !== 'boolean') throw new GitError('invalid-response', response.status);
        if (response.data?.private !== true) throw new Error('Репозиторий должен быть приватным. Проверьте настройки Git.');
    }
    private path(path: string): string {
        if (this.layout.state === 'vam/config.json' && (path==='vam/installations' || /^vam\/installations\/[a-f0-9-]{36}\.json$/i.test(path))) return '/contents/'+path;
        const prefix = this.layout.requests + '/';
        if (path !== this.layout.state && path !== this.layout.requests && !(path.startsWith(prefix) && new RegExp('^[a-zA-Z0-9-]+\\.' + this.layout.extension + '$').test(path.slice(prefix.length)))) throw new Error('Invalid Git path');
        return `/contents/${path}`;
    }
    private async missing(): Promise<void> { if ((await this.api('')).status === 404) throw new GitError('repository-unavailable', 404); }
    async read(path: string): Promise<File | null> {
        for (let attempt = 0; attempt < 2; attempt++) {
            const r = await this.api(this.path(path));
            if (r.status === 404) { await this.missing(); return null; }
            const f = r.data;
            if (f && typeof f.sha === 'string' && f.sha && f.encoding === 'base64' && typeof f.content === 'string') {
                if (f.content.length > 3_000_000) throw new GitError('invalid-response');
                try { return { sha: f.sha, text: new TextDecoder('utf-8', { fatal: true }).decode(Uint8Array.from(atob(f.content.replace(/\s/g, '')), c => c.charCodeAt(0))).trim() }; }
                catch { throw new GitError('invalid-response'); }
            }
            if (!r.raw || r.raw.length > 3_000_000 || Array.isArray(f) || (f && typeof f === 'object' && ('content' in f || 'encoding' in f || 'sha' in f))) throw new GitError('invalid-response');
            // Original clients support raw file responses and obtain SHA from the parent directory.
            // Verify the Git blob OID before pairing that SHA with the body; concurrent edits must not be overwritten.
            const slash = path.lastIndexOf('/'), parent = slash < 0 ? '' : path.slice(0, slash), name = path.slice(slash + 1);
            const listing = await this.api('/contents/' + parent);
            if (listing.status === 404) continue;
            if (!Array.isArray(listing.data)) throw new GitError('invalid-response');
            const sha = listing.data.find(entry => entry?.name === name && entry.type !== 'dir')?.sha;
            if (typeof sha !== 'string' || !/^(?:[a-f0-9]{40}|[a-f0-9]{64})$/i.test(sha)) throw new GitError('invalid-response');
            const bytes = new TextEncoder().encode(r.raw), header = new TextEncoder().encode(`blob ${bytes.length}\0`), blob = new Uint8Array(header.length + bytes.length); blob.set(header); blob.set(bytes, header.length);
            const digest = await crypto.subtle.digest(sha.length === 40 ? 'SHA-1' : 'SHA-256', blob), oid = Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
            if (oid === sha.toLowerCase()) return { sha, text: r.raw.trim() };
        }
        throw new GitError('conflict');
    }
    async write(path: string, text: string, sha: string | null): Promise<void> {
        let binary = ''; for (const b of new TextEncoder().encode(text)) binary += String.fromCharCode(b);
        try {
            const r = await this.api(this.path(path), sha === null && this.repo.baseUrl.endsWith('/api/v1') ? 'POST' : 'PUT', { message: `VAM: ${path}`, content: btoa(binary), ...(sha === null ? {} : { sha }) });
            if (r.status === 404) throw new GitError('repository-unavailable', 404);
            if (![200, 201].includes(r.status)) throw new GitError('unknown-write');
        } catch (e) {
            if (!(e instanceof GitError) || !['network', 'timeout', 'server', 'conflict', 'validation', 'unknown-write'].includes(e.kind)) throw e;
            // An interrupted response may have committed. Reconcile exact bytes, never merge stale data.
            try { if ((await this.read(path))?.text === text) return; } catch { throw new GitError('unknown-write'); }
            if (['conflict', 'validation'].includes(e.kind)) throw e;
            throw new GitError('unknown-write');
        }
    }
    async listInstallations() { return this.listDirectory('vam/installations'); }
    async listRequests(): Promise<string[]> { return this.listDirectory(this.layout.requests); }
    private async listDirectory(directory: string): Promise<string[]> {
        const r = await this.api(this.path(directory));
        if (r.status === 404) { await this.missing(); return []; }
        if (!Array.isArray(r.data)) throw new GitError('invalid-response');
        // Contents API is capped on GitHub; fail explicitly instead of silently ignoring a truncated queue.
        if (r.hasMore || r.data.length >= 1000) throw new Error('Очередь достигла лимита Contents API. Администратору нужно архивировать обработанные заявки в Git.');
        const pattern = new RegExp('^[a-zA-Z0-9-]+\\.' + this.layout.extension + '$');
        return r.data.filter(e => typeof e?.name === 'string' && pattern.test(e.name)).map(e => `${directory}/${e.name}`);
    }
}
