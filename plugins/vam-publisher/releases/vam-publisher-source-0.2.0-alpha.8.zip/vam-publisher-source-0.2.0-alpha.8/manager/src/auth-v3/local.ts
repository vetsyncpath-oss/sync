import { encode64, decode64, keyId, signJws, verifyJws, type Identity } from '../auth-v2/crypto';
/** IndexedDB belongs to this Obsidian installation, outside the vault and plugin updates. */
export class LocalStore {
    private db: Promise<IDBDatabase>;
    constructor(name = 'vam-installation-v3') {
        this.db = new Promise((resolve, reject) => {
            const r = indexedDB.open(name, 1);
            r.onupgradeneeded = () => r.result.createObjectStore('local');
            r.onsuccess = () => resolve(r.result); r.onerror = () => reject(new Error('Локальное хранилище ключей недоступно'));
        });
    }
    private async transaction<T>(mode: IDBTransactionMode, work: (store: IDBObjectStore, done: (value: T) => void) => void): Promise<T> {
        const db = await this.db;
        return new Promise((resolve, reject) => {
            const tx = db.transaction('local', mode); let value: T;
            tx.oncomplete = () => resolve(value); tx.onerror = tx.onabort = () => reject(new Error('Не удалось сохранить локальный профиль'));
            work(tx.objectStore('local'), v => { value = v; });
        });
    }
    get<T>(key: string): Promise<T | undefined> { return this.transaction('readonly', (s, done) => { const r = s.get(key); r.onsuccess = () => done(r.result); }); }
    set(key: string, value: unknown): Promise<void> { return this.transaction('readwrite', (s, done) => { s.put(value, key); done(undefined); }); }
    /** Non-secret version pointer: a late writer must not roll a shared connection back. */
    advanceVersion(key: string, version: number): Promise<void> {
        return this.transaction('readwrite', (store, done) => {
            const request = store.get(key);
            request.onsuccess = () => { if (!Number.isSafeInteger(request.result) || request.result < version) store.put(version, key); done(undefined); };
        });
    }
    /** Atomic creation for protected profiles; never silently replaces an existing signing key. */
    create(key: string, value: unknown): Promise<boolean> {
        return this.transaction('readwrite', (store, done) => {
            const request = store.get(key);
            request.onsuccess = () => { if (request.result !== undefined) done(false); else { store.put(value, key); done(true); } };
        });
    }
    /** First writer wins atomically, even when several vault windows initialize simultaneously. */
    private keep<T>(key: string, candidate: T): Promise<T> { return this.transaction('readwrite', (s, done) => { const r = s.get(key); r.onsuccess = () => { if (r.result !== undefined) done(r.result); else { s.put(candidate, key); done(candidate); } }; }); }
    async inbox(): Promise<CryptoKeyPair> {
        const existing = await this.get<CryptoKeyPair>('transport-inbox');
        return existing ?? this.keep('transport-inbox', await crypto.subtle.generateKey({name:'ECDH',namedCurve:'P-256'},false,['deriveKey']));
    }
    async identity(name: 'user' | 'device'): Promise<Identity> {
        const existing = await this.get<Identity>(name);
        if (existing) {
            if (existing.privateKey?.extractable !== false || existing.privateKey.type !== 'private' || await keyId(existing.publicKey) !== existing.keyId) throw new Error('Повреждён локальный ключ');
            const challenge = crypto.randomUUID();
            if (await verifyJws(await signJws(challenge, existing), existing.publicKey) !== challenge) throw new Error('Не подтверждено владение локальным ключом');
            return existing;
        }
        const pair = await crypto.subtle.generateKey({ name: 'ECDSA', namedCurve: 'P-256' }, false, ['sign', 'verify']) as CryptoKeyPair;
        const publicKey = await crypto.subtle.exportKey('jwk', pair.publicKey);
        return this.keep(name, { publicKey, privateKey: pair.privateKey, keyId: await keyId(publicKey) });
    }
    private async storageKey(): Promise<CryptoKey> { return await this.get<CryptoKey>('storage-key') ?? this.keep('storage-key', await crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt'])); }
    async saveSecret(name: string, payload: unknown): Promise<void> {
        const iv = crypto.getRandomValues(new Uint8Array(12));
        const bytes = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: new TextEncoder().encode(`vam-v3:${name}`) }, await this.storageKey(), new TextEncoder().encode(JSON.stringify(payload)));
        await this.set(name, { iv: encode64(iv), ciphertext: encode64(new Uint8Array(bytes)) });
    }
    async secret<T>(name: string): Promise<T | undefined> {
        const raw = await this.get<{ iv: string; ciphertext: string }>(name); if (!raw) return undefined;
        const bytes = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: decode64(raw.iv), additionalData: new TextEncoder().encode(`vam-v3:${name}`) }, await this.storageKey(), decode64(raw.ciphertext));
        return JSON.parse(new TextDecoder().decode(bytes));
    }
    async close(): Promise<void> { (await this.db).close(); }
}
