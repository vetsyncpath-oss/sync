import { CompactEncrypt, compactDecrypt, generateKeyPair, exportJWK, importJWK } from 'jose';
import { encode64, inspectJws, keyId, publicKey, signJws, verifyJws, type Identity } from '../auth-v2/crypto';
import { base, id, rsaPublic, verifyPackage, DAY, type Enrollment, type Package, type Tenant, type TrustRoots } from './model';
export async function digest(text: string): Promise<string> { return encode64(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text)))); }
export async function generateInbox(): Promise<{ publicKey: JsonWebKey; privateKey: JsonWebKey }> {
    const pair = await generateKeyPair('RSA-OAEP-256', { modulusLength: 2048, extractable: true });
    return { publicKey: rsaPublic(await exportJWK(pair.publicKey)), privateKey: await exportJWK(pair.privateKey) };
}
export async function seal(code: string, tenant: Tenant): Promise<string> {
    return new CompactEncrypt(new TextEncoder().encode(code)).setProtectedHeader({ alg: 'RSA-OAEP-256', enc: 'A256GCM', typ: 'vam-request+jwe' }).encrypt(await importJWK(tenant.inboxKey, 'RSA-OAEP-256'));
}
export async function open(ciphertext: string, privateKey: JsonWebKey): Promise<string> {
    if (ciphertext.length > 2_000_000) throw new Error('Request too large');
    const result = await compactDecrypt(ciphertext, await importJWK(privateKey, 'RSA-OAEP-256'), { keyManagementAlgorithms: ['RSA-OAEP-256'], contentEncryptionAlgorithms: ['A256GCM'] });
    if (result.protectedHeader.typ !== 'vam-request+jwe') throw new Error('Invalid request envelope');
    return new TextDecoder('utf-8', { fatal: true }).decode(result.plaintext);
}
async function binding(r: Omit<Enrollment, 'deviceProof'>): Promise<Record<string, unknown>> {
    return { v: 3, type: 'device-proof', tenantId: r.tenantId, bundleId: r.bundleId, accountId: r.accountId, requestId: r.requestId,
        invitationDigest: await digest(r.invitation), userId: await keyId(r.userKey), deviceId: await keyId(r.deviceKey), issuedAt: r.issuedAt, expiresAt: r.expiresAt };
}
export async function enrollment(invitation: string, p: Package, tenant: Tenant, user: Identity, device: Identity, now: number): Promise<{ requestId: string; ciphertext: string }> {
    const r: Omit<Enrollment, 'deviceProof'> = { v: 3, type: 'enroll', tenantId: p.tenantId, bundleId: p.bundleId, accountId: p.accountId, requestId: crypto.randomUUID(), invitation, userKey: user.publicKey, deviceKey: device.publicKey, issuedAt: now, expiresAt: Math.min(now + 7 * DAY, p.expiresAt) };
    const code = await signJws({ ...r, deviceProof: await signJws(await binding(r), device) }, user);
    return { requestId: r.requestId, ciphertext: await seal(code, tenant) };
}
export async function verifyEnrollment(code: string, tenant: Tenant, roots: TrustRoots, now: number): Promise<{ request: Enrollment; package: Package; digest: string; userId: string; deviceId: string }> {
    const hint = inspectJws(code) as Enrollment;
    const r = base(await verifyJws(code, publicKey(hint.userKey)), 'enroll', now) as Enrollment;
    id(r.requestId); publicKey(r.deviceKey);
    const p = (await verifyPackage(r.invitation, roots, now)).package;
    if (r.tenantId !== tenant.tenantId || r.bundleId !== tenant.bundleId || r.accountId !== p.accountId || p.tenantId !== tenant.tenantId || p.bundleId !== tenant.bundleId || p.purpose === 'update' || r.expiresAt > p.expiresAt || r.expiresAt - r.issuedAt > 7 * DAY) throw new Error('Enrollment context mismatch');
    const proof = await verifyJws(r.deviceProof, r.deviceKey);
    if (JSON.stringify(proof) !== JSON.stringify(await binding(r))) throw new Error('Device possession proof mismatch');
    return { request: r, package: p, digest: await digest(r.invitation), userId: await keyId(r.userKey), deviceId: await keyId(r.deviceKey) };
}
