import type { Decision, Query } from './model';
/** Protocol 6: bundle scope is mandatory. Legacy global gates cannot grant access. */
export function installBridge(access: (q: Query) => Decision, owner: (tenantId: string) => boolean) {
    const listeners = new Set<(status: string, reason: string) => void>(), authListeners = new Set<(state: any) => void>();
    let disposed = false;
    const state = () => ({ role: 'unknown', authenticated: false, gate: 'blocked', reason: disposed ? 'vam-unloaded' : 'bundle-scope-required', managerVersion: '6' });
    const api = {
        version: '6', getStatus: () => 'blocked', getReason: () => state().reason, getAuthState: state,
        isOwner: (id?: string) => !disposed && !!id && owner(id),
        isAdministrator: (id?: string) => !disposed && !!id && owner(id),
        access: (q: Query): Decision => { if (disposed) return { status: 'blocked', reason: 'vam-unloaded', validUntil: null }; try { return { ...access(q) }; } catch { return { status: 'blocked', reason: 'verification-failed', validUntil: null }; } },
        getPermission: () => ({ permission: 'forbidden', source: 'channel', note: 'bundle-scope-required' }), register: (_id: string) => undefined,
        subscribe: (cb: (status: string, reason: string) => void) => { listeners.add(cb); cb('blocked', state().reason); return () => listeners.delete(cb); },
        subscribeAuth: (cb: (s: any) => void) => { authListeners.add(cb); cb(state()); return () => authListeners.delete(cb); },
    };
    (globalThis as any).__VAM__ = api;
    const refresh = () => { for (const cb of listeners) try { cb('blocked', state().reason); } catch {} for (const cb of authListeners) try { cb(state()); } catch {} };
    return { refresh, dispose: () => { disposed = true; refresh(); listeners.clear(); authListeners.clear(); } };
}
