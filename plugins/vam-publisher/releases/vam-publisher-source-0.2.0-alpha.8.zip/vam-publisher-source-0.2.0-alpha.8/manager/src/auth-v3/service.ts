import { encode64, inspectJws, keyId, publicKey, signJws, verifyJws, type Identity } from '../auth-v2/crypto';
import { base, DAY, OFFLINE_MS, verifyState, verifyTenant, type Connection, type Credentials, type Decision, type Member, type Package, type Query, type State, type Tenant, type TrustRoots } from './model';
import { digest, open, seal, verifyEnrollment } from './enrollment';
import { GitError, GitStore, transient, type Store } from './git-store';
export interface Cache { document: string; verifiedAt: number }
export interface Pending { id: string; code: string; accountId: string; purpose: 'activate' | 'replace'; deviceId: string }
export type AdminAction = { kind: 'revoke-member'; accountId: string } | { kind: 'remove-device'; accountId: string; deviceId: string } | { kind: 'set-limit'; accountId: string; limit: number };
export class Service {
    readonly tenant: Tenant;
    private snapshot: { state: State; sha: string; document: string; verifiedAt: number } | null = null;
    private highRevision = 0;
    private highDocument = '';
    private owner: Identity | null = null;
    private inbox: JsonWebKey | null = null;
    private disposed = false;
    private refreshing: Promise<void> | null = null;
    private working = false;
    private epoch = 0;
    error = '';
    online = false;
    private constructor(tenant: Tenant, readonly connection: Connection, readonly user: Identity, readonly device: Identity,
        private roots: TrustRoots, private stores: { access: Store; requests: Store }, private now: () => number, private changed: () => void) { this.tenant = tenant; }
    static async connect(connection: Connection, user: Identity, device: Identity, roots: TrustRoots, options: { stores?: { access: Store; requests: Store }; fetcher?: typeof fetch; now?: () => number; changed?: () => void } = {}): Promise<Service> {
        const now = options.now ?? Date.now, tenant = await verifyTenant(connection.certificate, roots, now());
        if (!connection.credentials || !['access', 'requests'].every(k => typeof connection.credentials[k as keyof Credentials] === 'string' && !!connection.credentials[k as keyof Credentials])) throw new Error('Missing credentials');
        const stores = options.stores ?? { access: new GitStore(tenant.access, connection.credentials.access, options.fetcher), requests: new GitStore(tenant.requests, connection.credentials.requests, options.fetcher) };
        return new Service(tenant, connection, user, device, roots, stores, now, options.changed ?? (() => undefined));
    }
    get state(): State | null { return this.snapshot ? structuredClone(this.snapshot.state) : null; }
    get watermark(): string { return this.highDocument; }
    async restoreWatermark(document: string | undefined): Promise<void> {
        if (!document) return;
        const hint = inspectJws(document) as State;
        const state = await verifyState(document, this.tenant, hint.issuedAt);
        if (!this.disposed) { this.highRevision = state.revision; this.highDocument = document; }
    }
    get cache(): Cache | null { return this.snapshot ? { document: this.snapshot.document, verifiedAt: this.snapshot.verifiedAt } : null; }
    isOwner(): boolean { return !this.disposed && !!this.owner && this.tenant.expiresAt > this.now(); }
    async unlockOwner(identity: Identity, inbox: JsonWebKey): Promise<void> {
        const epoch = this.epoch;
        if (identity.keyId !== await keyId(this.tenant.ownerKey) || inbox.n !== this.tenant.inboxKey.n || inbox.e !== this.tenant.inboxKey.e || !inbox.d) throw new Error('Ключ не принадлежит назначенному хозяину');
        // Prove encryption key possession, not merely matching its public fields.
        const challenge = crypto.randomUUID(); if (await open(await seal(challenge, this.tenant), inbox) !== challenge) throw new Error('Invalid inbox key');
        if (this.disposed || epoch !== this.epoch) throw new Error('Разблокировка отменена'); this.owner = identity; this.inbox = inbox; this.epoch++; this.changed();
    }
    lockOwner(): void { this.owner = null; this.inbox = null; this.epoch++; this.changed(); }
    access(q: Query): Decision {
        const no = (reason: string): Decision => ({ status: 'blocked', reason, validUntil: null });
        if (this.disposed) return no('manager-unloaded');
        if (!q || q.tenantId !== this.tenant.tenantId || q.bundleId !== this.tenant.bundleId || (q.capability !== undefined && q.capability !== 'use')) return no('scope-mismatch');
        const s = this.snapshot;
        if (!s || this.now() < s.verifiedAt - 60_000 || this.now() >= s.verifiedAt + OFFLINE_MS || this.tenant.expiresAt <= this.now() || s.state.expiresAt <= this.now()) return no(this.error || 'not-verified');
        const m = s.state.members.find(m => m.accountId === this.connection.accountId);
        if (!m || m.expiresAt <= this.now()) return no('access-revoked-or-expired');
        if (!m.devices.some(d => d.deviceId === this.device.keyId && d.userId === this.user.keyId)) return { status: 'pending', reason: 'device-not-approved', validUntil: null };
        return { status: 'granted', reason: null, validUntil: Math.min(this.tenant.expiresAt, s.state.expiresAt, m.expiresAt, s.verifiedAt + OFFLINE_MS) };
    }
    private async check(document: string): Promise<State> {
        const state = await verifyState(document, this.tenant, this.now());
        if (state.revision < this.highRevision || (state.revision === this.highRevision && this.highDocument && document !== this.highDocument)) throw new Error('Обнаружен откат состояния доступа');
        return state;
    }
    async restoreCache(cache: Cache | null): Promise<void> {
        if (!cache || !Number.isSafeInteger(cache.verifiedAt) || cache.verifiedAt > this.now() + 60_000 || cache.verifiedAt + OFFLINE_MS <= this.now()) return;
        const state = await this.check(cache.document);
        if (this.disposed) return;
        this.snapshot = { state, sha: '', ...cache }; this.highRevision = state.revision; this.highDocument = cache.document;
    }
    refresh(): Promise<void> {
        if (!this.refreshing) this.refreshing = this.load().finally(() => { this.refreshing = null; });
        return this.refreshing;
    }
    private async load(): Promise<void> {
        if (this.disposed) return;
        try {
            await this.stores.access.checkPrivate?.();
            const file = await this.stores.access.read('state.jws');
            if (!file) throw new Error('Реестр доступа ещё не инициализирован хозяином');
            const state = await this.check(file.text);
            if (this.disposed) return;
            this.snapshot = { state, sha: file.sha, document: file.text, verifiedAt: this.now() };
            this.highRevision = state.revision; this.highDocument = file.text; this.online = true; this.error = '';
        } catch (e) {
            if (this.disposed) return;
            this.online = false; this.error = e instanceof Error ? e.message : 'Не удалось проверить доступ';
            // A signed cache survives transient transport outages only, never bad signatures or authorization failure.
            if (!transient(e)) this.snapshot = null;
        }
        this.changed();
    }
    private async exclusive<T>(work: () => Promise<T>): Promise<T> {
        if (this.working || this.disposed) throw new Error('Операция уже выполняется');
        this.working = true; try { return await work(); } finally { this.working = false; await this.refresh(); }
    }
    async initialize(): Promise<void> {
        await this.exclusive(async () => {
            if (!this.isOwner()) throw new Error('Требуется подписанное назначение хозяина');
            const epoch = this.epoch, owner = this.owner!;
            await this.stores.access.checkPrivate?.();
            if (await this.stores.access.read('state.jws')) throw new Error('Реестр уже существует');
            const state: State = { v: 3, type: 'state', tenantId: this.tenant.tenantId, bundleId: this.tenant.bundleId, revision: 1, issuedAt: this.now(), expiresAt: this.tenant.expiresAt, members: [], invitations: [], admins: [], receipts: [] };
            const code = await signJws(state, owner);
            if (epoch !== this.epoch || !this.isOwner()) throw new Error('Хозяин заблокирован');
            await this.stores.access.write('state.jws', code, null);
        });
    }
    /** Replay the operation against freshly verified state after a conflict, never old members with a fresh SHA. */
    private async mutate(change: (state: State) => Promise<void> | void, operationId: string = crypto.randomUUID()): Promise<void> {
        await this.exclusive(async () => {
            const epoch = this.epoch;
            for (let attempt = 0; attempt < 3; attempt++) {
                if (!this.isOwner() || epoch !== this.epoch) throw new Error('Разблокируйте хозяина');
                await this.stores.access.checkPrivate?.();
                const file = await this.stores.access.read('state.jws'); if (!file) throw new Error('Инициализируйте организацию');
                const state = await this.check(file.text);
                if (state.receipts.some(r => r.id === operationId)) return;
                await change(state);
                state.revision++; state.issuedAt = this.now(); state.receipts = state.receipts.filter(r => r.expiresAt > this.now());
                state.receipts.push({ id: operationId, expiresAt: Math.min(this.now() + 7 * DAY, this.tenant.expiresAt) });
                // Expired/consumed invitations need not grow forever; receipts preserve operation idempotency.
                state.invitations = state.invitations.filter(i => i.expiresAt > this.now());
                const code = await signJws(state, this.owner!); await verifyState(code, this.tenant, this.now());
                if (!this.isOwner() || epoch !== this.epoch) throw new Error('Хозяин заблокирован');
                try {
                    await this.stores.access.write('state.jws', code, file.sha);
                    if (!this.disposed) { this.highRevision = state.revision; this.highDocument = code; this.snapshot = { state, document: code, sha: '', verifiedAt: this.now() }; }
                    return;
                }
                catch (e) { if (!(e instanceof GitError) || e.kind !== 'conflict' || attempt === 2) throw e; }
            }
        });
    }
    async invite(label: string, credentials: Credentials, version: number, options: { accountId?: string; expiresAt?: number; replaceDeviceId?: string } = {}): Promise<string> {
        if (!this.isOwner()) throw new Error('Разблокируйте хозяина');
        this.userCredentials(credentials);
        if (!Number.isSafeInteger(version) || version < 1) throw new Error('Некорректная версия подключения');
        if (options.expiresAt !== undefined && (!Number.isSafeInteger(options.expiresAt) || options.expiresAt <= this.now())) throw new Error('Некорректный срок доступа');
        const accountId = options.accountId ?? crypto.randomUUID(), now = this.now();
        const p: Package = { v: 3, type: 'connection', certificate: this.connection.certificate, tenantId: this.tenant.tenantId, bundleId: this.tenant.bundleId, accountId, credentials, version, purpose: options.replaceDeviceId ? 'replace' : 'activate', invitationId: crypto.randomUUID(), secret: encode64(crypto.getRandomValues(new Uint8Array(32))), issuedAt: now, expiresAt: Math.min(now + 7 * DAY, this.tenant.expiresAt) };
        const code = await signJws(p, this.owner!), hash = await digest(code);
        await this.mutate(state => {
            let member = state.members.find(m => m.accountId === accountId);
            if (!member) { if (options.accountId) throw new Error('Пользователь отсутствует'); member = { accountId, label, maxDevices: 1, devices: [], expiresAt: options.expiresAt ?? this.tenant.expiresAt }; state.members.push(member); }
            if (member.expiresAt <= this.now()) throw new Error('Доступ пользователя истёк');
            if (options.replaceDeviceId && !member.devices.some(d => d.deviceId === options.replaceDeviceId)) throw new Error('Заменяемое устройство отсутствует');
            if (!options.replaceDeviceId && member.devices.length >= member.maxDevices) throw new Error('Лимит устройств исчерпан. Используйте замену устройства.');
            state.invitations.push({ id: p.invitationId!, digest: hash, accountId, purpose: p.purpose as 'activate' | 'replace', ...(options.replaceDeviceId ? { replaceDeviceId: options.replaceDeviceId } : {}), expiresAt: p.expiresAt, consumedBy: null });
        });
        return code;
    }
    private userCredentials(c: Credentials): void {
        if (!c.access || !c.requests || c.access === c.requests || Object.values(c).some(t => Object.values(this.connection.credentials).includes(t))) throw new Error('Нужны отдельные пользовательские PAT: чтение прав и запись заявок. PAT хозяина передавать нельзя.');
    }
    async connectionUpdate(accountId: string, credentials: Credentials, version: number): Promise<string> {
        if (!this.isOwner()) throw new Error('Разблокируйте хозяина'); this.userCredentials(credentials);
        if (!Number.isSafeInteger(version) || version < 1) throw new Error('Некорректная версия подключения');
        await this.refresh(); if (!this.online || !this.snapshot?.state.members.some(m => m.accountId === accountId)) throw new Error('Пользователь отсутствует либо Git недоступен');
        return signJws({ v: 3, type: 'connection', certificate: this.connection.certificate, tenantId: this.tenant.tenantId, bundleId: this.tenant.bundleId, accountId, credentials, version, purpose: 'update', issuedAt: this.now(), expiresAt: Math.min(this.now() + 7 * DAY, this.tenant.expiresAt) } satisfies Package, this.owner!);
    }
    async submit(outbox: { requestId: string; ciphertext: string }): Promise<void> {
        if (this.disposed) throw new Error('Manager unloaded');
        await this.stores.requests.checkPrivate?.();
        const path = `requests/${outbox.requestId}.jwe`, existing = await this.stores.requests.read(path);
        if (existing) { if (existing.text !== outbox.ciphertext) throw new Error('Конфликт идентификатора заявки'); return; }
        await this.stores.requests.write(path, outbox.ciphertext, null);
    }
    async approve(code: string, allowReplacement = false): Promise<void> {
        const verified = await verifyEnrollment(code, this.tenant, this.roots, this.now());
        const { request: r, package: p } = verified;
        await this.mutate(state => {
            const i = state.invitations.find(i => i.id === p.invitationId && i.digest === verified.digest && i.accountId === p.accountId);
            if (!i || i.expiresAt <= this.now() || i.purpose !== p.purpose) throw new Error('Приглашение не найдено или истекло');
            if (i.consumedBy) { if (i.consumedBy === r.requestId) return; throw new Error('Приглашение уже использовано'); }
            const m = state.members.find(m => m.accountId === r.accountId);
            if (!m || m.expiresAt <= this.now()) throw new Error('Пользователь отозван или срок доступа истёк');
            if (i.purpose === 'replace') {
                if (!allowReplacement) throw new Error('Замена устройства требует подтверждения хозяина');
                if (!m.devices.some(d => d.deviceId === i.replaceDeviceId)) throw new Error('Заменяемое устройство уже отозвано');
                m.devices = m.devices.filter(d => d.deviceId !== i.replaceDeviceId);
            }
            if (state.members.some(m => m.devices.some(d => d.deviceId === verified.deviceId))) throw new Error('Устройство уже зарегистрировано');
            if (m.devices.length >= m.maxDevices) throw new Error('Лимит устройств исчерпан');
            m.devices.push({ deviceId: verified.deviceId, userId: verified.userId, addedAt: this.now() }); i.consumedBy = r.requestId;
        }, r.requestId);
    }
    async inboxRequests(): Promise<{ pending: Pending[]; rejected: number }> {
        if (!this.isOwner() || !this.inbox) throw new Error('Разблокируйте хозяина');
        await this.refresh(); if (!this.online) throw new Error(this.error);
        const pending: Pending[] = []; let rejected = 0;
        await this.stores.requests.checkPrivate?.();
        for (const path of await this.stores.requests.listRequests()) {
            const requestId = path.split('/').pop()!.replace('.jwe', '');
            if (this.snapshot?.state.receipts.some(r => r.id === requestId)) continue;
            try {
                const file = await this.stores.requests.read(path); if (!file) continue;
                if (!this.isOwner() || !this.inbox) break;
                const code = await open(file.text, this.inbox);
                const hint = inspectJws(code) as any;
                if (hint.requestId !== requestId) throw new Error('Filename/request mismatch');
                if (hint.type === 'admin-command') { await this.applyCommand(code); continue; }
                const v = await verifyEnrollment(code, this.tenant, this.roots, this.now());
                if (v.package.purpose === 'activate') await this.approve(code);
                else pending.push({ id: requestId, code, accountId: v.request.accountId, purpose: 'replace', deviceId: v.deviceId });
            } catch (e) { if (e instanceof GitError) throw e; rejected++; }
        }
        return { pending, rejected };
    }
    private action(state: State, action: AdminAction): void {
        const member = state.members.find(m => m.accountId === action.accountId); if (!member) throw new Error('Пользователь не найден');
        if (action.kind === 'revoke-member') { state.members = state.members.filter(m => m.accountId !== action.accountId); state.invitations = state.invitations.filter(i => i.accountId !== action.accountId); }
        else if (action.kind === 'remove-device') { member.devices = member.devices.filter(d => d.deviceId !== action.deviceId); state.invitations = state.invitations.filter(i => i.accountId !== action.accountId); }
        else if (action.kind === 'set-limit') { if (!Number.isInteger(action.limit) || action.limit < Math.max(1, member.devices.length) || action.limit > 100) throw new Error('Лимит меньше числа действующих устройств либо вне диапазона 1–100'); member.maxDevices = action.limit; }
        else throw new Error('Недопустимое действие администратора');
    }
    async change(action: AdminAction): Promise<void> { await this.mutate(state => this.action(state, action)); }
    async setAdmin(key: JsonWebKey, expiresAt: number): Promise<void> {
        if (!Number.isSafeInteger(expiresAt) || expiresAt < 0) throw new Error('Некорректный срок полномочий');
        const subject = await keyId(publicKey(key));
        await this.mutate(async state => { state.admins = (await Promise.all(state.admins.map(async a => ({ a, id: await keyId(a.key) })))).filter(a => a.id !== subject).map(a => a.a); if (expiresAt > this.now()) state.admins.push({ key: publicKey(key), expiresAt }); });
    }
    async propose(action: AdminAction): Promise<void> {
        await this.refresh(); if (!this.online) throw new Error(this.error);
        const allowed = await Promise.all((this.snapshot?.state.admins ?? []).map(async a => a.expiresAt > this.now() && await keyId(a.key) === this.user.keyId));
        if (!allowed.includes(true)) throw new Error('Нет действующих полномочий администратора');
        const requestId = crypto.randomUUID();
        const code = await signJws({ v: 3, type: 'admin-command', tenantId: this.tenant.tenantId, bundleId: this.tenant.bundleId, requestId, key: this.user.publicKey, action, issuedAt: this.now(), expiresAt: Math.min(this.now() + DAY, this.tenant.expiresAt) }, this.user);
        await this.submit({ requestId, ciphertext: await seal(code, this.tenant) });
    }
    private async applyCommand(code: string): Promise<void> {
        const hint = inspectJws(code) as any, key = publicKey(hint.key);
        const r = base(await verifyJws(code, key), 'admin-command', this.now());
        if (r.tenantId !== this.tenant.tenantId || r.bundleId !== this.tenant.bundleId || r.expiresAt - r.issuedAt > DAY) throw new Error('Invalid command context');
        const subject = await keyId(key);
        await this.mutate(async state => {
            if (r.expiresAt <= this.now()) throw new Error('Срок команды истёк');
            let allowed = false; for (const a of state.admins) if (a.expiresAt > this.now() && await keyId(a.key) === subject) allowed = true;
            if (!allowed) throw new Error('Администратор отозван'); this.action(state, r.action);
        }, r.requestId);
    }
    dispose(): void { this.disposed = true; this.lockOwner(); this.snapshot = null; }
}
