import { inspectJws, keyId, publicKey, verifyJws } from '../auth-v2/crypto';
import { record, validateRepo, type Repo, type TrustRoots } from '../auth-v2/model';
export { type Repo, type TrustRoots };
export const DAY = 86_400_000;
export const OFFLINE_MS = DAY;
export interface Tenant {
    v: 3; type: 'tenant'; publisherId: string; tenantId: string; bundleId: string;
    ownerKey: JsonWebKey; inboxKey: JsonWebKey; access: Repo; requests: Repo; issuedAt: number; expiresAt: number;
}
export interface Credentials { access: string; requests: string }
export interface Connection { certificate: string; credentials: Credentials; version: number; accountId: string }
export interface Device { deviceId: string; userId: string; addedAt: number }
export interface Member { accountId: string; label: string; expiresAt: number; maxDevices: number; devices: Device[] }
export interface Invitation { id: string; digest: string; accountId: string; purpose: 'activate' | 'replace'; replaceDeviceId?: string; expiresAt: number; consumedBy: string | null }
export interface Admin { key: JsonWebKey; expiresAt: number }
export interface State { v: 3; type: 'state'; tenantId: string; bundleId: string; revision: number; issuedAt: number; expiresAt: number; members: Member[]; invitations: Invitation[]; admins: Admin[]; receipts: Array<{ id: string; expiresAt: number }> }
export interface Package { v: 3; type: 'connection'; certificate: string; tenantId: string; bundleId: string; accountId: string; credentials: Credentials; version: number; purpose: 'activate' | 'replace' | 'update'; invitationId?: string; secret?: string; issuedAt: number; expiresAt: number }
export interface Enrollment { v: 3; type: 'enroll'; tenantId: string; bundleId: string; accountId: string; requestId: string; invitation: string; userKey: JsonWebKey; deviceKey: JsonWebKey; deviceProof: string; issuedAt: number; expiresAt: number }
export interface Query { tenantId: string; bundleId: string; capability?: string }
export interface Decision { status: 'granted' | 'blocked' | 'pending'; reason: string | null; validUntil: number | null }
export function id(value: unknown): asserts value is string { if (typeof value !== 'string' || !/^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,127}$/.test(value)) throw new Error('Invalid identifier'); }
export function stamp(value: unknown): asserts value is number { if (!Number.isSafeInteger(value) || (value as number) < 0) throw new Error('Invalid timestamp'); }
export function lifetime(r: any, now: number): void { stamp(r.issuedAt); stamp(r.expiresAt); if (r.issuedAt > now + 60_000 || r.expiresAt <= now || r.expiresAt <= r.issuedAt) throw new Error('Document expired or not yet valid'); }
export function base(raw: unknown, type: string, now: number): any { const r = record(raw); if (r.v !== 3 || r.type !== type) throw new Error('Unsupported document'); lifetime(r, now); return r; }
export function rsaPublic(raw: unknown): JsonWebKey {
    const r = record(raw);
    if (r.kty !== 'RSA' || typeof r.n !== 'string' || !/^[A-Za-z0-9_-]{342,1024}$/.test(r.n) || r.e !== 'AQAB' || r.d) throw new Error('Invalid inbox key');
    return { kty: 'RSA', n: r.n, e: r.e, alg: 'RSA-OAEP-256', ext: true };
}
export async function verifyTenant(code: string, roots: TrustRoots, now: number): Promise<Tenant> {
    const hint = record(inspectJws(code));
    if (typeof hint.publisherId !== 'string' || !Object.hasOwn(roots, hint.publisherId)) throw new Error('Unknown publisher');
    const r = base(await verifyJws(code, roots[hint.publisherId]), 'tenant', now);
    id(r.publisherId); id(r.tenantId); id(r.bundleId); publicKey(r.ownerKey); rsaPublic(r.inboxKey);
    r.access = validateRepo(r.access); r.requests = validateRepo(r.requests);
    if (JSON.stringify(r.access).toLowerCase() === JSON.stringify(r.requests).toLowerCase()) throw new Error('Requests require a separate repository');
    return r as Tenant;
}
export async function verifyState(code: string, tenant: Tenant, now: number): Promise<State> {
    const r = base(await verifyJws(code, tenant.ownerKey), 'state', now);
    if (r.tenantId !== tenant.tenantId || r.bundleId !== tenant.bundleId || r.expiresAt > tenant.expiresAt || !Number.isSafeInteger(r.revision) || r.revision < 1) throw new Error('State context mismatch');
    if (!Array.isArray(r.members) || r.members.length > 10000 || !Array.isArray(r.invitations) || r.invitations.length > 10000 || !Array.isArray(r.admins) || r.admins.length > 100 || !Array.isArray(r.receipts) || r.receipts.length > 10000) throw new Error('Invalid state');
    const accounts = new Set<string>(), devices = new Set<string>(), invites = new Set<string>(), admins = new Set<string>();
    for (const m of r.members) {
        record(m); id(m.accountId); stamp(m.expiresAt);
        if (accounts.has(m.accountId) || typeof m.label !== 'string' || m.label.length > 200 || m.expiresAt > r.expiresAt || !Number.isInteger(m.maxDevices) || m.maxDevices < 1 || m.maxDevices > 100 || !Array.isArray(m.devices) || m.devices.length > m.maxDevices) throw new Error('Invalid member');
        accounts.add(m.accountId);
        for (const d of m.devices) { record(d); stamp(d.addedAt); if (!/^[\w-]{43}$/.test(d.deviceId) || !/^[\w-]{43}$/.test(d.userId) || devices.has(d.deviceId)) throw new Error('Invalid device'); devices.add(d.deviceId); }
    }
    for (const i of r.invitations) {
        record(i); id(i.id); stamp(i.expiresAt);
        if (invites.has(i.id) || !accounts.has(i.accountId) || !/^[\w-]{43}$/.test(i.digest) || !['activate', 'replace'].includes(i.purpose) || i.expiresAt > r.expiresAt || (i.consumedBy !== null && typeof i.consumedBy !== 'string') || (i.purpose === 'replace' && !/^[\w-]{43}$/.test(i.replaceDeviceId))) throw new Error('Invalid invitation');
        invites.add(i.id);
    }
    const owner = await keyId(tenant.ownerKey);
    for (const a of r.admins) { record(a); stamp(a.expiresAt); const k = await keyId(publicKey(a.key)); if (k === owner || admins.has(k) || a.expiresAt > r.expiresAt) throw new Error('Invalid administrator'); admins.add(k); }
    for (const receipt of r.receipts) { record(receipt); id(receipt.id); stamp(receipt.expiresAt); if (receipt.expiresAt > r.expiresAt) throw new Error('Invalid receipt expiry'); }
    if (new Set(r.receipts.map((receipt: any) => receipt.id)).size !== r.receipts.length) throw new Error('Duplicate receipt');
    return r as State;
}
export async function verifyPackage(code: string, roots: TrustRoots, now: number): Promise<{ package: Package; tenant: Tenant }> {
    const hint = record(inspectJws(code));
    if (typeof hint.certificate !== 'string') throw new Error('Missing certificate');
    const tenant = await verifyTenant(hint.certificate, roots, now);
    const r = base(await verifyJws(code, tenant.ownerKey), 'connection', now);
    id(r.accountId);
    if (r.tenantId !== tenant.tenantId || r.bundleId !== tenant.bundleId || !Number.isSafeInteger(r.version) || r.version < 1 || !['activate', 'replace', 'update'].includes(r.purpose) || r.expiresAt > tenant.expiresAt) throw new Error('Invalid connection package');
    const c = record(r.credentials);
    if (['access', 'requests'].some(k => typeof c[k] !== 'string' || !c[k] || c[k].length > 4096)) throw new Error('Invalid credentials');
    if (r.purpose !== 'update') { id(r.invitationId); if (!/^[\w-]{43}$/.test(r.secret)) throw new Error('Missing invitation secret'); }
    return { package: r as Package, tenant };
}
