import { Notice, Plugin } from 'obsidian';
import { decryptSecret, encryptSecret, generateIdentity, importIdentity, inspectJws, keyId, signJws, type EncryptedIdentity, type Identity } from '../auth-v2/crypto';
import { TRUSTED_PUBLISHERS } from '../auth-v2/trusted-publishers';
import { verifyPackage, verifyTenant, id, DAY, type Connection, type Credentials, type Decision, type Query, type TrustRoots } from './model';
import { digest, enrollment, generateInbox } from './enrollment';
import { Service, type Cache, type Pending } from './service';
import { LocalStore } from './local';
import { patWarning, validateExpiry } from './pat';
import { installBridge } from './bridge';
import { SettingsTab } from './settings-tab';
interface Profile {
    connection?: Connection; cache?: Cache | null; watermark?: string;
    outbox?: { requestId: string; ciphertext: string; invitationDigest?: string; expiresAt?: number }; submitted?: boolean;
    ownerDraft?: { tenantId: string; bundleId: string; request: string }; ownerCertificateDraft?: string;
    ownerBox?: EncryptedIdentity; ownerPublic?: JsonWebKey;
    distribution?: { credentials: Credentials; version: number; expiry: { access: string | null; requests: string | null } };
    ownerWatermark?: string; ownerConnection?: Connection; expiry?: { access: string | null; requests: string | null };
}
export class Runtime {
    service: Service | null = null;
    ownerService: Service | null = null;
    user!: Identity; device!: Identity;
    profile: Profile = {};
    pending: Pending[] = [];
    rejectedRequests = 0;
    error = '';
    sending = false;
    legacyOwnerDetected = false;
    get hasTrustRoots(): boolean { return Object.keys(this.roots).length > 0; }
    private ownerKeys: { identity: Identity; inbox: JsonWebKey } | null = null;
    private disposed = false;
    private ownerEpoch = 0;
    private busy = false;
    private tickBusy = false;
    private bridge?: ReturnType<typeof installBridge>;
    private timers: ReturnType<typeof setInterval>[] = [];
    private listeners = new Set<() => void>();
    private legacyApi: any;
    private saveQueue: Promise<void> = Promise.resolve();
    constructor(private plugin: Plugin, private roots: TrustRoots = TRUSTED_PUBLISHERS, private fetcher?: typeof fetch, readonly local = new LocalStore()) {}
    async start(): Promise<void> {
        // Install a closed gate before any storage/crypto/network await.
        this.bridge = installBridge(q => this.access(q), id => this.ownerService?.tenant.tenantId === id && !!this.ownerService?.isOwner());
        // Unscoped integrations must upgrade to SDK 6; explicitly close stale legacy sessions.
        this.legacyApi = { version: 1, getState: () => ({ status: 'blocked', reason: 'channel-error' }), onChanged: (cb: any) => { cb({ status: 'blocked', reason: 'channel-error' }); return () => undefined; }, prompt: () => this.openSettings(), beforeSession: async () => undefined };
        (globalThis as any).vaultSyncAuth = this.legacyApi; (this.plugin as any).auth = this.legacyApi;
        const sync = this.plugin.app.plugins?.plugins?.['cloud-vault-sync'];
        if (typeof sync?.applyManagerProbe === 'function') void Promise.resolve().then(() => sync.applyManagerProbe({ present: true, authOk: false, reason: 'Требуется SDK 6 с tenantId и bundleId' })).catch(() => undefined);
        this.plugin.addSettingTab(new SettingsTab(this.plugin.app, this.plugin, this));
        this.plugin.addCommand({ id: 'vam-access', name: 'Доступ к бандлу', callback: () => this.openSettings() });
        this.plugin.addCommand({ id: 'vam-lock-owner', name: 'Заблокировать управление организацией', callback: () => this.lockOwner() });
        try {
            // Legacy settings are a migration hint only, never an authority source.
            try { this.legacyOwnerDetected = (await this.plugin.loadData())?.role === 'owner'; } catch { /* optional hint */ }
            [this.user, this.device] = await Promise.all([this.local.identity('user'), this.local.identity('device')]);
            this.profile = await this.local.secret<Profile>('profile') ?? {};
            if (this.disposed) return;
            if (this.profile.connection) {
                try {
                    this.service = await this.connectService(this.profile.connection);
                    await this.service.restoreWatermark(this.profile.watermark);
                    try { await this.service.restoreCache(this.profile.cache ?? null); } catch { this.profile.cache = null; }
                } catch { this.service?.dispose(); this.service = null; this.error = 'Подключение требует нового кода от администратора'; }
            }
            if (this.profile.ownerConnection) {
                try {
                    this.ownerService = await this.connectService(this.profile.ownerConnection);
                    await this.ownerService.restoreWatermark(this.profile.ownerWatermark);
                    if (this.profile.ownerPublic && await keyId(this.profile.ownerPublic) === await keyId(this.ownerService.tenant.ownerKey)) {
                        const entries: Array<[string, string | null | undefined]> = [ ['PAT хозяина — реестр', this.profile.expiry?.access], ['PAT хозяина — заявки', this.profile.expiry?.requests], ['PAT пользователей — чтение', this.profile.distribution?.expiry.access], ['PAT пользователей — заявки', this.profile.distribution?.expiry.requests] ];
                        const warnings = entries.flatMap(([label, date]) => { const warning = patWarning(date ?? null); return warning ? [`${label}: ${warning}`] : []; });
                        if (warnings.length) new Notice(warnings.join('\n'), 15000);
                    }
                } catch { this.ownerService?.dispose(); this.ownerService = null; this.error = 'Хозяину нужно обновить сертификат или подключение'; }
            }
            await this.tick();
        } catch { this.error = 'Не удалось открыть локальное хранилище. Проверьте поддержку IndexedDB/WebCrypto; доступ закрыт.'; this.changed(); return; }
        if (this.disposed) return;
        this.timers.push(setInterval(() => { void this.tick(); }, 60_000));
        this.timers.push(setInterval(() => this.changed(), 10_000)); this.changed();
    }
    private connectService(c: Connection): Promise<Service> {
        return Service.connect(c, this.user, this.device, this.roots, { fetcher: this.fetcher, changed: () => {
            this.changed();
            void this.save().catch(() => { this.error = 'Не удалось сохранить локальный профиль'; this.changed(); });
        } });
    }
    openSettings(): void { this.plugin.app.setting?.open(); this.plugin.app.setting?.openTabById(this.plugin.manifest.id); }
    async sendToPublisher(request: string): Promise<void> {
        const publisher = this.plugin.app.plugins?.plugins?.['vam-publisher'];
        if (typeof publisher?.acceptOwnerRequest !== 'function') throw new Error('VAM Publisher не включён. Установите его либо скопируйте заявку и передайте издателю вручную.');
        await publisher.acceptOwnerRequest(request);
    }
    async receiveOwnerCertificate(code: string): Promise<void> {
        if (!this.hasTrustRoots) throw new Error('Сначала экспортируйте публичный корень издателя в trusted-publishers.ts менеджера, пересоберите и перезагрузите менеджер.');
        const tenant = await verifyTenant(code.trim(), this.roots, Date.now());
        if (!this.profile.ownerPublic || await keyId(tenant.ownerKey) !== await keyId(this.profile.ownerPublic)) throw new Error('Назначение выпущено для другого ключа хозяина');
        if (this.disposed) throw new Error('Менеджер закрыт');
        this.profile.ownerCertificateDraft = code.trim(); await this.save(); this.openSettings();
        new Notice('Назначение получено. Разблокируйте хозяина и проверьте Git-подключение ниже.');
    }
    subscribe(cb: () => void): () => void { this.listeners.add(cb); return () => this.listeners.delete(cb); }
    changed = (): void => { this.bridge?.refresh(); for (const cb of this.listeners) try { cb(); } catch {} };
    access(q: Query): Decision { return !this.disposed && this.service ? this.service.access(q) : { status: 'blocked', reason: this.disposed ? 'vam-unloaded' : 'not-configured', validUntil: null }; }
    get decision(): Decision { return this.access({ tenantId: this.service?.tenant.tenantId ?? '', bundleId: this.service?.tenant.bundleId ?? '' }); }
    get status(): string {
        if (this.error && !this.profile.connection) return this.error;
        if (!this.profile.connection && this.ownerService?.isOwner()) return 'Управление хозяина разблокировано. Пользовательский доступ к бандлу выдаётся отдельно.';
        if (!this.profile.connection && (this.profile.ownerBox || this.legacyOwnerDetected)) return this.profile.ownerConnection ? 'Откройте управление хозяина для разблокировки' : 'Завершите первичную настройку хозяина ниже';
        if (this.sending) return 'Отправляем заявку…';
        if (!this.profile.connection) return 'Введите выданный код подключения';
        if (this.decision.status === 'granted') return this.service?.online ? 'Доступ к бандлу активен' : 'Доступ активен по проверенному кэшу';
        if (this.error || this.service?.error) return this.error || this.service!.error;
        if (this.service?.online && this.decision.reason === 'access-revoked-or-expired') return 'Доступ отозван или срок доступа истёк';
        if (this.profile.outbox && this.service?.online) {
            const state = this.service.state;
            const invitation = state?.invitations.find(i => i.digest === this.profile.outbox?.invitationDigest);
            if (invitation?.consumedBy && invitation.consumedBy !== this.profile.outbox.requestId) return 'Код уже использован другим устройством. Обратитесь к хозяину за заменой.';
            if (this.profile.outbox.expiresAt !== undefined && this.profile.outbox.expiresAt <= Date.now()) return 'Срок приглашения истёк. Запросите новый код у хозяина.';
            const member = state?.members.find(m => m.accountId === this.profile.connection?.accountId);
            if (invitation?.purpose === 'activate' && member && member.devices.length >= member.maxDevices) return 'Лимит устройств исчерпан. Запросите у хозяина замену устройства.';
        }
        if (this.profile.outbox && !this.profile.submitted) return 'Заявка ещё не подтверждена Git. Повторите отправку.';
        if (this.profile.outbox && this.profile.submitted) return 'Заявка отправлена. Ожидаем подтверждения хозяина.';
        return this.decision.reason === 'device-not-approved' ? 'Устройство не допущено. Обратитесь к администратору.' : 'Доступ отозван или срок доступа истёк';
    }
    private save(): Promise<void> {
        if (this.disposed) return Promise.resolve();
        if (this.service) { this.profile.cache = this.service.cache; this.profile.watermark = this.service.watermark; }
        if (this.ownerService) this.profile.ownerWatermark = this.ownerService.watermark;
        const snapshot = structuredClone(this.profile);
        const task = this.saveQueue.catch(() => undefined).then(() => this.local.saveSecret('profile', snapshot));
        this.saveQueue = task; return task;
    }
    private async exclusive<T>(work: () => Promise<T>): Promise<T> {
        if (this.busy || this.disposed || !this.user) throw new Error('Профиль занят либо ещё не открыт');
        this.busy = true; this.error = '';
        try { return await work(); } finally { this.busy = false; this.changed(); }
    }
    async applyCode(code: string): Promise<void> {
        await this.exclusive(async () => {
            const { package: p, tenant } = await verifyPackage(code.trim(), this.roots, Date.now());
            const previous = this.profile.connection;
            if (previous) {
                const oldTenant = await verifyTenant(previous.certificate, this.roots, (inspectJws(previous.certificate) as any).issuedAt);
                if (p.tenantId !== oldTenant.tenantId || p.bundleId !== oldTenant.bundleId || p.accountId !== previous.accountId || await keyId(tenant.ownerKey) !== await keyId(oldTenant.ownerKey)) throw new Error('Код принадлежит другой организации или пользователю');
                if (p.version < previous.version) throw new Error('Нельзя понизить версию подключения');
                if (p.purpose === 'update' && p.version <= previous.version) throw new Error('Нужен код с более новой версией подключения');
                if (p.purpose !== 'update' && this.decision.status === 'granted') throw new Error('Устройство уже активно. Для PAT используйте код обновления подключения.');
            } else if (p.purpose === 'update') throw new Error('Код обновления не заменяет первичное приглашение');
            const connection: Connection = { certificate: p.certificate, credentials: p.credentials, version: p.version, accountId: p.accountId };
            const next = await this.connectService(connection);
            await next.restoreWatermark(this.profile.watermark); await next.refresh();
            if (!next.online) { next.dispose(); throw new Error(next.error || 'Не удалось проверить новое подключение'); }
            let outbox = this.profile.outbox;
            if (p.purpose !== 'update') {
                const hash = await digest(code.trim()), member = next.state?.members.find(m => m.accountId === p.accountId);
                const invitation = next.state?.invitations.find(i => i.id === p.invitationId && i.digest === hash && i.accountId === p.accountId);
                if (!member || member.expiresAt <= Date.now() || !invitation || invitation.expiresAt <= Date.now()) { next.dispose(); throw new Error('Приглашение недействительно или доступ отозван'); }
                if (invitation.consumedBy && invitation.consumedBy !== outbox?.requestId) { next.dispose(); throw new Error('Код уже использован. Запросите у хозяина замену устройства.'); }
                if (p.purpose === 'activate' && member.devices.length >= member.maxDevices && !invitation.consumedBy) { next.dispose(); throw new Error('Лимит устройств исчерпан. Запросите у хозяина замену устройства.'); }
                if (outbox?.invitationDigest !== hash) outbox = { ...await enrollment(code.trim(), p, tenant, this.user, this.device, Date.now()), invitationDigest: hash, expiresAt: p.expiresAt };
            }
            if (this.disposed) { next.dispose(); return; }
            this.service?.dispose(); this.service = next; this.profile.connection = connection; this.profile.outbox = outbox;
            if (p.purpose !== 'update') this.profile.submitted = false;
            await this.save();
            if (outbox) await this.sendPending();
            this.error = ''; this.changed();
        });
    }
    async sendPending(): Promise<void> {
        if (!this.profile.outbox || !this.service || this.disposed || this.sending) return;
        this.sending = true; this.changed();
        try { await this.service.submit(this.profile.outbox); this.profile.submitted = true; this.error = ''; await this.save(); }
        catch (e) { this.error = e instanceof Error ? e.message : 'Заявка не отправлена'; await this.save(); throw e; }
        finally { this.sending = false; this.changed(); }
    }
    async tick(): Promise<void> {
        if (this.tickBusy || this.busy || this.disposed) return;
        this.tickBusy = true;
        try {
            await this.service?.refresh();
            if (this.profile.outbox && !this.profile.submitted && this.service?.online && this.decision.status !== 'granted') await this.sendPending();
            if (this.decision.status === 'granted') { delete this.profile.outbox; delete this.profile.submitted; this.error = ''; }
            if (this.ownerService?.isOwner()) {
                const result = await this.ownerService.inboxRequests(); this.pending = result.pending; this.rejectedRequests = result.rejected;
            }
            await this.save();
        } catch (e) { this.error = e instanceof Error ? e.message : 'Не удалось обновить состояние'; }
        finally { this.tickBusy = false; this.changed(); }
    }
    async createOwner(password: string, tenantId: string, bundleId: string): Promise<string> {
        return this.exclusive(async () => {
            id(tenantId); id(bundleId);
            if (this.profile.ownerBox) throw new Error('Ключ хозяина уже существует');
            const epoch = this.ownerEpoch;
            const identity = await generateIdentity(), inbox = await generateInbox();
            const ownerBox = await encryptSecret({ key: await crypto.subtle.exportKey('jwk', identity.privateKey), inbox: inbox.privateKey }, password);
            if (this.disposed || epoch !== this.ownerEpoch) throw new Error('Операция отменена');
            this.profile.ownerBox = ownerBox;
            this.profile.ownerPublic = identity.publicKey; this.ownerKeys = { identity, inbox: inbox.privateKey }; await this.save();
            return this.ownerRequest(tenantId, bundleId);
        });
    }
    async ownerRequest(tenantId: string, bundleId: string): Promise<string> {
        id(tenantId); id(bundleId);
        if (!this.ownerKeys) throw new Error('Разблокируйте хозяина');
        const epoch = this.ownerEpoch, identity = this.ownerKeys.identity;
        const { n, e } = this.ownerKeys.inbox;
        const request = await signJws({ v: 3, type: 'owner-request', tenantId, bundleId, key: this.ownerKeys.identity.publicKey, inboxKey: { kty: 'RSA', n, e, alg: 'RSA-OAEP-256', ext: true }, issuedAt: Date.now(), expiresAt: Date.now() + 7 * DAY }, identity);
        if (this.disposed || epoch !== this.ownerEpoch) throw new Error('Создание заявки отменено');
        this.profile.ownerDraft = { tenantId, bundleId, request }; await this.save();
        return request;
    }
    async unlockOwner(password: string): Promise<void> {
        await this.exclusive(async () => {
            if (!this.profile.ownerBox) throw new Error('Создайте или восстановите ключ хозяина');
            const epoch = this.ownerEpoch;
            const raw = await decryptSecret(this.profile.ownerBox, password) as any;
            const identity = await importIdentity(raw.key);
            if (this.disposed || epoch !== this.ownerEpoch) throw new Error('Разблокировка отменена');
            if (this.ownerService) await this.ownerService.unlockOwner(identity, raw.inbox);
            if (this.disposed || epoch !== this.ownerEpoch) { this.ownerService?.lockOwner(); throw new Error('Разблокировка отменена'); }
            if (!this.disposed) this.ownerKeys = { identity, inbox: raw.inbox };
        });
        await this.tick();
    }
    lockOwner(): void { this.ownerEpoch++; this.ownerKeys = null; this.ownerService?.lockOwner(); this.pending = []; this.changed(); }
    get ownerUnlocked(): boolean { return this.ownerKeys !== null; }
    async configureOwner(certificate: string, credentials: Credentials, expiry: { access: string | null; requests: string | null }): Promise<void> {
        await this.exclusive(async () => {
            if (!this.ownerKeys) throw new Error('Разблокируйте хозяина');
            const epoch = this.ownerEpoch;
            const c: Connection = { certificate: certificate.trim(), credentials, version: (this.profile.ownerConnection?.version ?? 0) + 1, accountId: 'owner-administration' };
            const next = await this.connectService(c); await next.restoreWatermark(this.profile.ownerWatermark); await next.unlockOwner(this.ownerKeys.identity, this.ownerKeys.inbox);
            if (this.ownerService && (next.tenant.tenantId !== this.ownerService.tenant.tenantId || next.tenant.bundleId !== this.ownerService.tenant.bundleId)) { next.dispose(); throw new Error('Нельзя заменить организацию этим действием'); }
            // Verify transport before replacing working credentials. Empty state is allowed for first setup only.
            const { GitStore } = await import('./git-store');
            const accessStore = new GitStore(next.tenant.access, credentials.access, this.fetcher);
            await accessStore.checkPrivate(); const existing = await accessStore.read('state.jws');
            if (existing) { await next.refresh(); if (!next.online) { next.dispose(); throw new Error(next.error); } }
            else if (this.profile.ownerConnection) { next.dispose(); throw new Error('Существующий реестр недоступен; подключение не заменено'); }
            const requestsStore = new GitStore(next.tenant.requests, credentials.requests, this.fetcher);
            await requestsStore.checkPrivate(); await requestsStore.listRequests();
            const dates = { access: validateExpiry(expiry.access), requests: validateExpiry(expiry.requests) };
            if (this.disposed || epoch !== this.ownerEpoch) { next.dispose(); throw new Error('Настройка отменена: управление заблокировано'); }
            this.ownerService?.dispose(); this.ownerService = next; this.profile.ownerConnection = c; this.profile.expiry = dates; await this.save(); await next.refresh();
        });
    }
    async configureDistribution(credentials: Credentials, version: number, expiry: { access: string | null; requests: string | null }): Promise<void> {
        await this.exclusive(async () => {
            if (!this.ownerService?.isOwner() || !this.profile.ownerConnection) throw new Error('Разблокируйте хозяина');
            if (!credentials.access || !credentials.requests || credentials.access === credentials.requests || Object.values(credentials).some(t => Object.values(this.profile.ownerConnection!.credentials).includes(t))) throw new Error('Нужны отдельные ограниченные пользовательские PAT');
            const previous = this.profile.distribution;
            if (!Number.isSafeInteger(version) || version < 1 || (previous && (version < previous.version || (JSON.stringify(credentials) !== JSON.stringify(previous.credentials) && version <= previous.version)))) throw new Error('При смене PAT увеличьте номер версии подключения');
            const candidate = await this.connectService({ ...this.profile.ownerConnection, credentials, version });
            try { await candidate.refresh(); if (!candidate.online) throw new Error(candidate.error); } finally { candidate.dispose(); }
            const { GitStore } = await import('./git-store');
            const requestsStore = new GitStore(this.ownerService.tenant.requests, credentials.requests, this.fetcher);
            await requestsStore.checkPrivate(); await requestsStore.listRequests();
            // Explicit date inputs: blank clears the date, so new credentials cannot inherit an old expiry.
            this.profile.distribution = { credentials, version, expiry: { access: validateExpiry(expiry.access), requests: validateExpiry(expiry.requests) } };
            await this.save();
        });
    }
    exportOwner(): string { if (!this.profile.ownerBox) throw new Error('Ключ хозяина отсутствует'); return JSON.stringify({ v: 3, ownerBox: this.profile.ownerBox }); }
    async restoreOwner(text: string, password: string): Promise<void> {
        await this.exclusive(async () => {
            const epoch = this.ownerEpoch;
            const raw = JSON.parse(text); if (raw.v !== 3) throw new Error('Неизвестный формат');
            const keys = await decryptSecret(raw.ownerBox, password) as any, identity = await importIdentity(keys.key);
            if (!keys.inbox?.d) throw new Error('Отсутствует ключ заявок');
            if (this.profile.ownerBox && (!this.profile.ownerPublic || identity.keyId !== await keyId(this.profile.ownerPublic))) throw new Error('Резервная копия принадлежит другому хозяину. Существующий ключ не заменён.');
            if (this.ownerService) await this.ownerService.unlockOwner(identity, keys.inbox);
            if (this.disposed || epoch !== this.ownerEpoch) throw new Error('Восстановление отменено');
            this.profile.ownerBox = raw.ownerBox; this.profile.ownerPublic = identity.publicKey; this.ownerKeys = { identity, inbox: keys.inbox }; await this.save();
        });
    }
    dispose(): void { this.disposed = true; this.ownerEpoch++; this.timers.forEach(clearInterval); this.ownerKeys = null; this.service?.dispose(); this.ownerService?.dispose(); this.bridge?.dispose(); this.listeners.clear(); if ((globalThis as any).vaultSyncAuth === this.legacyApi) delete (globalThis as any).vaultSyncAuth; (this.plugin as any).auth = undefined; void this.saveQueue.finally(() => this.local.close()).catch(() => undefined); }
}
