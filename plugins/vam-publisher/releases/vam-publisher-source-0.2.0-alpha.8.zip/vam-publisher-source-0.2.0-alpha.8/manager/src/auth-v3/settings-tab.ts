import { Notice, PluginSettingTab, type App, type Plugin } from 'obsidian';
import type { Runtime } from './runtime';
/** Background updates touch status nodes only: typing, focus and secrets are not lost on a poll. */
export class SettingsTab extends PluginSettingTab {
    private unsubscribe?: () => void;
    constructor(app: App, plugin: Plugin, private runtime: Runtime) { super(app, plugin); }
    private text(parent: HTMLElement, value: string): HTMLElement { const p = document.createElement('p'); p.textContent = value; parent.append(p); return p; }
    private group(parent: HTMLElement, title: string): HTMLDetailsElement { const d = document.createElement('details'), s = document.createElement('summary'); s.textContent = title; d.append(s); parent.append(d); return d; }
    private field(parent: HTMLElement, title: string, value = '', kind = 'text', readonly = false): HTMLInputElement | HTMLTextAreaElement {
        const label = document.createElement('label'); label.className = 'vam3-field'; label.textContent = title;
        const input = document.createElement(kind === 'textarea' ? 'textarea' : 'input'); input.value = value; input.readOnly = readonly;
        if (input instanceof HTMLInputElement) { input.type = kind; input.autocomplete = 'off'; } else input.rows = 4;
        input.spellcheck = false; label.append(input); parent.append(label); return input;
    }
    private button(parent: HTMLElement, title: string, action: () => Promise<unknown> | unknown, redraw = true): void {
        const b = document.createElement('button'); b.textContent = title; b.className = 'vam3-button'; parent.append(b);
        b.onclick = async () => { b.disabled = true; try { await action(); if (redraw) this.display(); } catch (e) { new Notice(e instanceof Error ? e.message : 'Действие не выполнено'); } finally { b.disabled = false; } };
    }
    hide(): void { this.unsubscribe?.(); this.unsubscribe = undefined; }
    display(): void {
        this.hide(); const root = this.containerEl; root.replaceChildren(); root.classList.add('vam3-settings'); const r = this.runtime;
        const status = this.text(root, r.status); status.className = 'vam3-status'; status.setAttribute('role', 'status');
        const connection = this.text(root, '');
        const update = () => { status.textContent = r.status; connection.textContent = r.service ? `Организация: ${r.service.tenant.tenantId} · Бандл: ${r.service.tenant.bundleId} · Подключение №${r.profile.connection?.version}` : ''; };
        this.unsubscribe = r.subscribe(update); update();
        const connect = r.profile.connection ? this.group(root, 'Обновить подключение по коду администратора') : root;
        const code = this.field(connect, r.profile.connection ? 'Новый код подключения' : 'Выданный вам код', '', 'textarea');
        this.button(connect, 'Подключить', async () => { await r.applyCode(code.value); code.value = ''; });
        if (r.profile.outbox && !r.profile.submitted) this.button(root, 'Повторить отправку заявки', () => r.sendPending());
        this.button(root, 'Проверить доступ', () => r.tick(), false);
        const diagnostic = this.group(root, 'Диагностика');
        this.text(diagnostic, 'Пароль и Git-токен для обычного входа не нужны. Если подключение недоступно, запросите новый код у администратора.');
        this.field(diagnostic, 'Устройство', r.device?.keyId ?? 'Инициализация…', 'text', true);
        this.field(diagnostic, 'Открытый ключ для назначения администратора', r.user ? JSON.stringify(r.user.publicKey) : '', 'textarea', true);
        if (r.service) {
            const admin = this.group(diagnostic, 'Действия назначенного администратора');
            this.text(admin, 'Изменения подписываются локальным ключом и ожидают работающего разблокированного хозяина.');
            const account = this.field(admin, 'ID пользователя'), device = this.field(admin, 'ID устройства'), limit = this.field(admin, 'Лимит устройств', '1', 'number');
            this.button(admin, 'Предложить отзыв пользователя', () => r.service!.propose({ kind: 'revoke-member', accountId: account.value.trim() }), false);
            this.button(admin, 'Предложить отзыв устройства', () => r.service!.propose({ kind: 'remove-device', accountId: account.value.trim(), deviceId: device.value.trim() }), false);
            this.button(admin, 'Предложить изменение лимита', () => r.service!.propose({ kind: 'set-limit', accountId: account.value.trim(), limit: Number(limit.value) }), false);
        }
        const owner = this.group(root, 'Первичная настройка и управление хозяина');
        owner.open = !r.profile.ownerConnection && (r.legacyOwnerDetected || !!r.profile.ownerBox);
        if (r.legacyOwnerDetected && !r.profile.ownerConnection) this.text(owner, 'Обнаружен профиль хозяина прежней версии. Его данные сохранены, но старая роль и старый пароль не являются ключом подписи v3. Создайте новый ключ ниже и получите назначение через VAM Publisher.');
        if (!r.hasTrustRoots) this.text(owner, 'В этой сборке ещё нет публичного ключа издателя. В VAM Publisher создайте или импортируйте издателя, экспортируйте trusted-publishers.ts в src/auth-v2/trusted-publishers.ts менеджера, выполните npm run build и перезагрузите менеджер. Создать заявку хозяина можно уже сейчас.');
        if (!r.profile.ownerConnection) this.text(owner, 'Первый запуск: 1) Создайте новый ключ хозяина и сохраните заявку. 2) В VAM Publisher проверьте заявку и выпустите назначение. 3) Вставьте сертификат и PAT в раздел Git. 4) Инициализируйте новый реестр. Если имеется резервная копия ключа v3, используйте восстановление вместо создания.');
        const phrase = this.field(owner, r.profile.ownerBox ? 'Пароль ключа хозяина v3' : 'Новый пароль ключа хозяина v3 (не менее 12 символов)', '', 'password');
        const tenantId = this.field(owner, 'ID организации', r.ownerService?.tenant.tenantId ?? r.profile.ownerDraft?.tenantId ?? '');
        const bundleId = this.field(owner, 'ID бандла', r.ownerService?.tenant.bundleId ?? r.profile.ownerDraft?.bundleId ?? '');
        const request = this.field(owner, 'Заявка издателю: это запрос на выпуск назначения, а не готовый ключ доступа', r.profile.ownerDraft?.request ?? '', 'textarea', true);
        this.text(owner, 'После создания ключа передайте эту заявку в VAM Publisher. Там издатель проверяет получателя и нажимает «Подписать назначение». Полученный сертификат возвращается сюда в раздел Git. Ожидание само по себе заявку не подтверждает.');
        this.button(owner, 'Передать заявку в VAM Publisher', async () => { if (!request.value) throw new Error('Сначала создайте ключ и заявку ниже'); await r.sendToPublisher(request.value); }, false);
        this.button(owner, 'Копировать заявку для передачи вручную', async () => { if (!request.value) throw new Error('Сначала создайте заявку'); try { await navigator.clipboard.writeText(request.value); new Notice('Заявка скопирована: вставьте её в настройки VAM Publisher'); } catch { request.focus(); request.select(); new Notice('Скопируйте выделенную заявку сочетанием Ctrl+C'); } }, false);
        if (!r.profile.ownerBox) {
            this.button(owner, 'Создать ключ хозяина и заявку издателю', async () => { request.value = await r.createOwner(phrase.value, tenantId.value.trim(), bundleId.value.trim()); phrase.value = ''; this.button(owner, 'Показать следующий шаг и резервную копию', () => undefined); }, false);
            const backup = this.field(owner, 'Восстановить зашифрованный ключ хозяина', '', 'textarea');
            this.button(owner, 'Восстановить ключ', () => r.restoreOwner(backup.value, phrase.value));
        } else if (!r.ownerUnlocked) this.button(owner, 'Разблокировать управление', async () => { await r.unlockOwner(phrase.value); phrase.value = ''; });
        if (r.profile.ownerBox && !r.ownerUnlocked) {
            this.text(owner, 'Если пароль текущего ключа недоступен, восстановите зашифрованную копию этого же ключа. Введите выше пароль резервной копии. Ключ другого хозяина не заменит существующий.');
            const recovery = this.field(owner, 'Зашифрованная резервная копия ключа хозяина v3', '', 'textarea');
            this.button(owner, 'Восстановить тот же ключ из резервной копии', () => r.restoreOwner(recovery.value, phrase.value));
        }
        if (!r.ownerUnlocked) return;
        this.button(owner, 'Заблокировать управление', () => r.lockOwner());
        this.button(owner, 'Сформировать заявку издателю', async () => { request.value = await r.ownerRequest(tenantId.value.trim(), bundleId.value.trim()); }, false);
        this.button(owner, 'Показать зашифрованную резервную копию', () => { this.field(owner, 'Зашифрованная резервная копия хозяина — сохраните отдельно', r.exportOwner(), 'textarea', true); }, false);
        this.text(owner, 'Сохраните резервную копию и пароль отдельно. Она переносит административный ключ, но не ключ устройства и не Git-токены.');
        const git = this.group(owner, 'Git: назначение хозяина и обновление PAT');
        git.open = !r.profile.ownerConnection;
        this.text(git, 'Все репозитории приватные. Новый PAT не наследует дату старого. Даты ниже — календарные даты UTC; пустое поле означает неизвестный срок.');
        this.text(git, `Учтённые даты: права — ${r.profile.expiry?.access ?? 'неизвестно'}, заявки — ${r.profile.expiry?.requests ?? 'неизвестно'}.`);
        const certificate = this.field(git, 'Подписанное назначение от издателя', r.profile.ownerCertificateDraft ?? '', 'textarea');
        const access = this.field(git, 'PAT хозяина: запись реестра', '', 'password'), accessExpiry = this.field(git, 'Дата окончания PAT реестра (UTC)', '', 'date');
        const requests = this.field(git, 'PAT хозяина: чтение заявок', '', 'password'), requestsExpiry = this.field(git, 'Дата окончания PAT заявок (UTC)', '', 'date');
        this.button(git, 'Проверить и сохранить', () => r.configureOwner(certificate.value.trim() || r.profile.ownerConnection?.certificate || '', { access: access.value.trim(), requests: requests.value.trim() }, { access: accessExpiry.value || null, requests: requestsExpiry.value || null }));
        const s = r.ownerService; if (!s?.isOwner()) return;
        this.text(owner, `Хозяин подтверждён для ${s.tenant.tenantId}. ${s.error || 'Подключение проверено.'}`);
        if (!s.state) this.button(owner, 'Инициализировать новый реестр', () => s.initialize());
        this.button(owner, 'Проверить очередь и обновить список', () => r.tick());
        this.text(owner, `Замен устройств на подтверждении: ${r.pending.length}. Некорректных или неисполняемых заявок: ${r.rejectedRequests}.`);
        for (const p of r.pending) {
            this.text(owner, `Замена: ${p.accountId}, новое устройство ${p.deviceId}`);
            this.button(owner, 'Подтвердить эту замену', async () => { await s.approve(p.code, true); await r.tick(); });
        }
        const codes = this.group(owner, 'Выдать приглашение или обновить подключение');
        this.text(codes, 'Используйте отдельные ограниченные PAT: чтение приватного реестра и запись только отдельного репозитория заявок. Не передавайте PAT хозяина. Проверьте ограничения токенов в настройках Git-хоста. Код содержит секреты: передайте его лично получателю.');
        this.text(codes, `Сохранённое подключение пользователей: №${r.profile.distribution?.version ?? 'не задано'}. Сроки PAT: чтение — ${r.profile.distribution?.expiry.access ?? 'неизвестно'}, заявки — ${r.profile.distribution?.expiry.requests ?? 'неизвестно'}.`);
        const userAccess = this.field(codes, 'Пользовательский PAT: только чтение реестра', '', 'password');
        const userAccessExpiry = this.field(codes, 'Дата окончания пользовательского PAT чтения (UTC)', '', 'date');
        const userRequests = this.field(codes, 'Пользовательский PAT: запись заявок', '', 'password');
        const userRequestsExpiry = this.field(codes, 'Дата окончания пользовательского PAT заявок (UTC)', '', 'date');
        const version = this.field(codes, 'Номер версии подключения', String(r.profile.distribution?.version ?? 1), 'number');
        this.button(codes, 'Сохранить подключение пользователей для организации', () => r.configureDistribution({ access: userAccess.value.trim(), requests: userRequests.value.trim() }, Number(version.value), { access: userAccessExpiry.value || null, requests: userRequestsExpiry.value || null }));
        const account = this.field(codes, 'ID существующего пользователя (пусто для нового)');
        const label = this.field(codes, 'Метка пользователя (видна читателям реестра; без личных данных)');
        const replace = this.field(codes, 'ID заменяемого устройства (только для замены)');
        const expiry = this.field(codes, 'Срок доступа нового пользователя (UTC; пусто — срок организации)', '', 'date');
        const output = this.field(codes, 'Код для личной передачи получателю', '', 'textarea', true);
        const distribution = () => { if (!r.profile.distribution) throw new Error('Сначала сохраните подключение пользователей для организации'); return r.profile.distribution; };
        this.button(codes, 'Выдать одноразовое приглашение', async () => { output.value = await s.invite(label.value, distribution().credentials, distribution().version, { ...(account.value.trim() ? { accountId: account.value.trim() } : {}), ...(replace.value.trim() ? { replaceDeviceId: replace.value.trim() } : {}), ...(expiry.value ? { expiresAt: Date.parse(expiry.value) + 86_400_000 } : {}) }); }, false);
        this.button(codes, 'Выдать код обновления PAT', async () => { output.value = await s.connectionUpdate(account.value.trim(), distribution().credentials, distribution().version); }, false);
        const members = this.group(owner, 'Пользователи и устройства');
        for (const m of s.state?.members ?? []) {
            const row = this.group(members, `${m.label || m.accountId} · ${m.devices.length}/${m.maxDevices} устройств`);
            this.field(row, 'ID пользователя', m.accountId, 'text', true);
            const max = this.field(row, 'Лимит', String(m.maxDevices), 'number');
            this.button(row, 'Сохранить лимит', () => s.change({ kind: 'set-limit', accountId: m.accountId, limit: Number(max.value) }));
            for (const d of m.devices) { this.text(row, d.deviceId); this.button(row, 'Отозвать это устройство', () => s.change({ kind: 'remove-device', accountId: m.accountId, deviceId: d.deviceId })); }
            this.button(row, 'Отозвать пользователя', () => s.change({ kind: 'revoke-member', accountId: m.accountId }));
        }
        const admins = this.group(owner, 'Администраторы');
        this.text(admins, 'Администраторы могут подавать команды отзыва и изменения лимита. Они не подписывают итоговый реестр и не назначают других администраторов.');
        const adminKey = this.field(admins, 'Открытый ключ администратора из его диагностики', '', 'textarea'), adminExpiry = this.field(admins, 'Срок полномочий (UTC)', '', 'date');
        this.button(admins, 'Назначить администратора', () => s.setAdmin(JSON.parse(adminKey.value), Date.parse(adminExpiry.value) + 86_400_000));
        for (const a of s.state?.admins ?? []) { this.field(admins, 'Назначенный ключ', JSON.stringify(a.key), 'textarea', true); this.button(admins, 'Отозвать этого администратора', () => s.setAdmin(a.key, 0)); }
    }
}
