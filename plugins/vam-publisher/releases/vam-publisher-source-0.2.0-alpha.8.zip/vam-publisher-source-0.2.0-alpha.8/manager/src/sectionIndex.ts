import type { BlockKind, BlockMode, Filters, SectionEntry, SectionIndex, SkipRange } from "./types";

/* ── Построчные регэкспы (семантика фазы A; хвостовой \r в строке допустим) ── */

/** Открытие код-блока: ≤3 пробелов + ``` или ~~~ (инфо-строка допускается). */
const FENCE_OPEN = /^ {0,3}(`{3,}|~{3,})/;
/** ATX-заголовок (по спеке). */
const ATX_HEADING = /^ {0,3}(#{1,6})\s+(.+?)(?:\s+#+)?\r?$/;
/** Setext-подчёркивание H1. */
const SETEXT_H1 = /^\s*=+\s*$/;
/** Setext-подчёркивание H2. */
const SETEXT_H2 = /^\s{0,3}-+\s*$/;
/** Строка-разделитель таблицы (минимум один «-», только | : - и пробелы). */
const TABLE_SEP = /^\s*\|?[\s:|-]*-[\s:|-]*\|?[\s:|-]*$/;
/** Горизонтальная линия — markdown-шум. */
const HR_LINE = /^ {0,3}(?:-{3,}|\*{3,}|_{3,})[ \t\r]*$/;
/** Маркер списка в начале читаемой строки — шум. */
const LIST_MARKER = /^ {0,3}(?:[-*+]|\d{1,9}\.)[ \t]/;
/** Маркеры цитаты в начале читаемой строки — шум. */
const QUOTE_MARKER = /^ {0,3}(?:>[ \t]?)+/;
/** Пустая строка. */
const BLANK_LINE = /^\s*$/;

const CH_TAB = 9;
const CH_SPACE = 32;
const CH_CR = 13;

function isInlineWs(code: number): boolean {
  return code === CH_SPACE || code === CH_TAB || code === CH_CR;
}

/** Строка начинается с ≤3 пробелов + ">". */
function isQuoteLineStart(L: string): boolean {
  let k = 0;
  while (k < 3 && L.charCodeAt(k) === CH_SPACE) k++;
  return L.charCodeAt(k) === 62;
}

/** trim(L) === "$$" без аллокаций. */
function isDollarDollar(L: string): boolean {
  let a = 0;
  let b = L.length;
  while (a < b && isInlineWs(L.charCodeAt(a))) a++;
  while (b > a && isInlineWs(L.charCodeAt(b - 1))) b--;
  return b - a === 2 && L.charCodeAt(a) === 36 && L.charCodeAt(a + 1) === 36;
}

/** Самая первая строка: "---" (BOM и хвостовой \r допускаются). */
function isFrontmatterOpen(L: string): boolean {
  let s = L;
  if (s.charCodeAt(0) === 0xfeff) s = s.slice(1);
  if (s.charCodeAt(s.length - 1) === CH_CR) s = s.slice(0, -1);
  return s === "---";
}

/** Строка-закрытие frontmatter: "---" (хвостовой \r допустим). */
function isFrontmatterClose(L: string): boolean {
  const s = L.charCodeAt(L.length - 1) === CH_CR ? L.slice(0, -1) : L;
  return s === "---";
}

/* Состояния автомата (числовые константы — скорость сравнения). */
const ST_PLAIN = 0;
const ST_FRONTMATTER = 1;
const ST_CODE = 2;
const ST_MATH = 3;
const ST_COMMENT = 4;
const ST_QUOTE = 5;

/**
 * Фаза A: один линейный проход по строкам текста (split ТОЛЬКО по "\n",
 * \r не нормализуется — все офсеты являются индексами исходной строки).
 *
 * Автомат: plain → frontmatter / code / mathBlock / blockComment (%% и <!--) /
 * quote → plain. Приоритет распознавания в plain:
 * frontmatter(строка 0) > fence > $$ > quote(blockquote=false) > таблица >
 * комментарий > ATX > setext.
 */
export function buildIndex(text: string, filters: Filters, sourceKey: string): SectionIndex {
  const n = text.length;
  const lines = text.split("\n");
  const lineCount = lines.length;

  const lineStart = new Int32Array(lineCount);
  {
    let off = 0;
    for (let k = 0; k < lineCount; k++) {
      lineStart[k] = off;
      off += lines[k].length + 1;
    }
  }

  const sections: SectionEntry[] = [];
  const skips: SkipRange[] = [];
  let noise = 0; // markdown-шум читаемых зон (символы)

  // Кандидат setext: предыдущая непустая строка обычного текста.
  let candStart = -1;
  let candLen = 0;

  let state = ST_PLAIN;
  let i = 0;
  let codeFrom = 0;
  let codeChar = 96; // `
  let codeLen = 3;
  let mathFrom = 0;
  let cmFrom = 0;
  let cmLine = 0;
  let cmRel = 0;
  let cmOpenLen = 2;
  let cmCloser = "%%";
  let quoteFrom = 0;

  const quoteSkip = filters.blockquote === false;
  const commentSkip = filters.comments === false;

  while (i < lineCount) {
    const L = lines[i];
    const start = lineStart[i];

    if (state !== ST_PLAIN) {
      if (state === ST_FRONTMATTER) {
        if (isFrontmatterClose(L)) {
          skips.push({ from: 0, to: start + L.length, kind: "frontmatter", mode: "skip" });
          state = ST_PLAIN;
        }
        i++;
        continue;
      }
      if (state === ST_CODE) {
        // закрытие: trim-старт начинается с того же маркера, длина ≥ открытой
        let p = 0;
        while (p < L.length && isInlineWs(L.charCodeAt(p))) p++;
        let cnt = 0;
        while (p + cnt < L.length && L.charCodeAt(p + cnt) === codeChar) cnt++;
        if (cnt >= codeLen) {
          skips.push({ from: codeFrom, to: start + L.length, kind: "code", mode: filters.code });
          state = ST_PLAIN;
        }
        i++;
        continue;
      }
      if (state === ST_MATH) {
        if (isDollarDollar(L)) {
          skips.push({ from: mathFrom, to: start + L.length, kind: "math", mode: filters.math });
          state = ST_PLAIN;
        }
        i++;
        continue;
      }
      if (state === ST_COMMENT) {
        const rel = i === cmLine ? cmRel + cmOpenLen : 0;
        const idx = L.indexOf(cmCloser, rel);
        if (idx !== -1) {
          skips.push({ from: cmFrom, to: start + idx + cmCloser.length, kind: "comment", mode: "skip" });
          state = ST_PLAIN;
        }
        i++;
        continue;
      }
      // ST_QUOTE: максимальная группа подряд идущих строк, начинающихся с ">"
      let j = i;
      while (j < lineCount && isQuoteLineStart(lines[j])) j++;
      skips.push({
        from: quoteFrom,
        to: lineStart[j - 1] + lines[j - 1].length,
        kind: "quote",
        mode: "skip",
      });
      state = ST_PLAIN;
      i = j;
      continue;
    }

    /* ── состояние plain ── */

    // frontmatter — только самая первая строка
    if (i === 0 && isFrontmatterOpen(L)) {
      state = ST_FRONTMATTER;
      candStart = -1;
      i++;
      continue;
    }

    const c0 = L.charCodeAt(0); // NaN для пустой строки — все проверки ниже безопасны
    let k = 0;
    while (k < 4 && L.charCodeAt(k) === CH_SPACE) k++;
    const fc = L.charCodeAt(k);

    // код-блок
    if (k <= 3 && (fc === 96 || fc === 126)) {
      const m = FENCE_OPEN.exec(L);
      if (m) {
        codeFrom = start;
        codeChar = m[1].charCodeAt(0);
        codeLen = m[1].length;
        state = ST_CODE;
        candStart = -1;
        i++;
        continue;
      }
    }

    // блочная формула $$ (однострочные $$…$$ не трогаем)
    if (
      fc === 36 ||
      ((fc === CH_SPACE || fc === CH_TAB || fc === CH_CR) && L.length < 16 && L.indexOf("$") !== -1)
    ) {
      if (isDollarDollar(L)) {
        mathFrom = start;
        state = ST_MATH;
        candStart = -1;
        i++;
        continue;
      }
    }

    // блок-цитаты — только когда blockquote === false
    if (quoteSkip && k <= 3 && fc === 62) {
      quoteFrom = start;
      state = ST_QUOTE;
      candStart = -1;
      continue; // строка i обрабатывается в состоянии quote
    }

    // таблица: строка содержит "|" И следующая строка — разделитель
    if (L.indexOf("|") !== -1 && i + 1 < lineCount && TABLE_SEP.test(lines[i + 1])) {
      let j = i + 2; // разделитель входит в таблицу безусловно
      while (j < lineCount && lines[j].indexOf("|") !== -1) j++;
      skips.push({
        from: start,
        to: lineStart[j - 1] + lines[j - 1].length,
        kind: "table",
        mode: filters.table,
      });
      candStart = -1;
      i = j;
      continue;
    }

    // комментарии %%…%% и <!-- … --> — только когда comments === false
    if (commentSkip) {
      const pPct = L.indexOf("%%");
      const pHtml = L.indexOf("<!--");
      if (pPct !== -1 || pHtml !== -1) {
        if (pHtml === -1 || (pPct !== -1 && pPct < pHtml)) {
          cmFrom = start + pPct;
          cmLine = i;
          cmRel = pPct;
          cmOpenLen = 2;
          cmCloser = "%%";
        } else {
          cmFrom = start + pHtml;
          cmLine = i;
          cmRel = pHtml;
          cmOpenLen = 4;
          cmCloser = "-->";
        }
        state = ST_COMMENT;
        candStart = -1;
        continue; // строка i обрабатывается в состоянии comment
      }
    }

    // ATX-заголовок (только в plain)
    if (k <= 3 && fc === 35) {
      const m = ATX_HEADING.exec(L);
      if (m) {
        const title = m[2].trim();
        sections.push({ level: m[1].length, title, charStart: start, charEnd: 0, firstTokenIdx: -1 });
        noise += L.length - title.length;
        candStart = -1;
        i++;
        continue;
      }
    }

    // setext-подчёркивание после непустой строки обычного текста
    if (candStart !== -1 && (c0 === 45 || c0 === 61 || isInlineWs(c0))) {
      let lvl = 0;
      if (SETEXT_H1.test(L)) lvl = 1;
      else if (SETEXT_H2.test(L)) lvl = 2;
      if (lvl !== 0) {
        const title = text.substring(candStart, candStart + candLen).trim();
        sections.push({ level: lvl, title, charStart: candStart, charEnd: 0, firstTokenIdx: -1 });
        noise += L.length + (candLen - title.length);
        candStart = -1;
        i++;
        continue;
      }
    }

    // пустая строка
    if (L.length === 0 || (isInlineWs(c0) && BLANK_LINE.test(L))) {
      candStart = -1;
      i++;
      continue;
    }

    // читаемая строка-цитата: маркеры ">" — шум; кандидатом setext не бывает
    if (k <= 3 && fc === 62) {
      const qm = QUOTE_MARKER.exec(L);
      if (qm) noise += qm[0].length;
      candStart = -1;
      i++;
      continue;
    }

    // обычный абзац: маркеры списков / горизонтальные линии — шум
    if (fc === 45 || fc === 42 || fc === 43 || fc === 95 || (fc >= 48 && fc <= 57)) {
      const lm = LIST_MARKER.exec(L);
      if (lm) noise += lm[0].length;
      else if (HR_LINE.test(L)) noise += L.length;
    }
    candStart = start;
    candLen = L.length;
    i++;
  }

  // незакрытый блок — до конца файла
  if (state !== ST_PLAIN) {
    let from = 0;
    let kind: BlockKind = "frontmatter";
    let mode: BlockMode = "skip";
    if (state === ST_CODE) {
      from = codeFrom;
      kind = "code";
      mode = filters.code;
    } else if (state === ST_MATH) {
      from = mathFrom;
      kind = "math";
      mode = filters.math;
    } else if (state === ST_COMMENT) {
      from = cmFrom;
      kind = "comment";
      mode = "skip";
    } else if (state === ST_QUOTE) {
      from = quoteFrom;
      kind = "quote";
      mode = "skip";
    }
    skips.push({ from, to: n, kind, mode });
  }

  // charEnd: началу следующего по порядку заголовка уровня <= данного (стек, O(S))
  const stack: number[] = [];
  for (let s = 0; s < sections.length; s++) {
    const cur = sections[s];
    while (stack.length > 0 && sections[stack[stack.length - 1]].level >= cur.level) {
      const top = stack[stack.length - 1];
      sections[top].charEnd = cur.charStart;
      stack.pop();
    }
    stack.push(s);
  }
  for (let t = 0; t < stack.length; t++) sections[stack[t]].charEnd = n;

  // читаемые символы: длина текста − skip-зоны − markdown-шум
  let skipLen = 0;
  for (let s = 0; s < skips.length; s++) {
    if (skips[s].mode === "skip") skipLen += skips[s].to - skips[s].from;
  }
  const totalReadableChars = Math.max(0, n - skipLen - noise);

  return { sections, skips, totalReadableChars, sourceKey };
}
