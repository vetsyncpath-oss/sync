import { inspectJws, keyId, publicKey, signJws, verifyJws, type Identity } from '../auth-v2/crypto';
import { base, DAY, id, rsaPublic, verifyTenant, type Repo, type Tenant } from '../auth-v3/model';

export interface OwnerRequest {
    v: 3; type: 'owner-request'; tenantId: string; bundleId: string;
    key: JsonWebKey; inboxKey: JsonWebKey; issuedAt: number; expiresAt: number;
}
export interface TenantConfig { tenantId: string; bundleId: string; access: Repo; requests: Repo; expiresAt: number }
export async function verifyOwnerRequest(code: string, now = Date.now()): Promise<OwnerRequest> {
    const hint = inspectJws(code) as OwnerRequest;
    const request = base(await verifyJws(code, publicKey(hint.key)), 'owner-request', now);
    id(request.tenantId); id(request.bundleId);
    if (request.expiresAt - request.issuedAt > 7 * DAY) throw new Error('Срок заявки превышает 7 дней');
    request.key = publicKey(request.key); request.inboxKey = rsaPublic(request.inboxKey);
    await crypto.subtle.importKey('jwk', request.inboxKey, { name: 'RSA-OAEP', hash: 'SHA-256' }, false, ['encrypt']);
    return request as OwnerRequest;
}
export async function issueTenant(publisherId: string, identity: Identity, requestCode: string, config: TenantConfig, now = Date.now()): Promise<string> {
    id(publisherId);
    const owner = await verifyOwnerRequest(requestCode, now);
    if (owner.tenantId !== config.tenantId || owner.bundleId !== config.bundleId) throw new Error('Организация или бандл не совпадают с заявкой хозяина');
    const tenant: Tenant = { v: 3, type: 'tenant', publisherId, tenantId: config.tenantId, bundleId: config.bundleId,
        ownerKey: owner.key, inboxKey: owner.inboxKey, access: config.access, requests: config.requests, issuedAt: now, expiresAt: config.expiresAt };
    const code = await signJws(tenant, identity);
    await verifyTenant(code, { [publisherId]: identity.publicKey }, now);
    return code;
}
export function publicAnchor(publisherId: string, key: JsonWebKey): string {
    id(publisherId);
    return `// Public release-time anchor. Never put the publisher private key here.\nexport const TRUSTED_PUBLISHERS: Readonly<Record<string, JsonWebKey>> = Object.freeze(${JSON.stringify({ [publisherId]: publicKey(key) }, null, 2)});\n`;
}
export async function ownerFingerprint(requestCode: string, now = Date.now()): Promise<string> { return keyId((await verifyOwnerRequest(requestCode, now)).key); }
