import { decryptSecret, encryptSecret, generateIdentity, importIdentity, keyId, publicKey, type EncryptedIdentity, type Identity } from '../auth-v2/crypto';
import { id } from '../auth-v3/model';
import { LocalStore } from '../auth-v3/local';
import { issueTenant, ownerFingerprint, publicAnchor, type TenantConfig } from './protocol';
interface Profile { v: 1; publisherId: string; publicKey: JsonWebKey; encryptedKey: EncryptedIdentity }
/** Creator-only local tool. It has no Git credentials and never installs trust in a manager implicitly. */
export class IssuerService {
    profile: Profile | null = null;
    private identity: Identity | null = null;
    private epoch = 0;
    private busy = false;
    private disposed = false;
    constructor(private local = new LocalStore('vam-publisher-installation-v1')) {}
    async start(): Promise<void> {
        const stored = await this.local.get<Profile>('publisher');
        if (stored) { this.validate(stored); if (!this.disposed) this.profile = stored; }
    }
    private validate(profile: Profile): void { if (!profile || profile.v !== 1 || !profile.encryptedKey) throw new Error('Неизвестный формат ключа издателя'); id(profile.publisherId); publicKey(profile.publicKey); }
    get unlocked(): boolean { return !this.disposed && this.identity !== null; }
    private async exclusive<T>(work: (epoch: number) => Promise<T>): Promise<T> {
        if (this.busy || this.disposed) throw new Error('Издатель занят или закрыт');
        this.busy = true; try { return await work(this.epoch); } finally { this.busy = false; }
    }
    private current(epoch: number): void { if (this.disposed || epoch !== this.epoch) throw new Error('Операция отменена: издатель заблокирован'); }
    private async store(profile: Profile, identity: Identity, epoch: number): Promise<void> {
        this.current(epoch);
        if (!await this.local.create('publisher', profile)) throw new Error('Ключ издателя уже существует. Разблокируйте его или используйте отдельную установку.');
        if (!this.disposed) this.profile = profile;
        this.current(epoch); this.identity = identity;
    }
    async create(publisherId: string, password: string): Promise<void> {
        await this.exclusive(async epoch => {
            id(publisherId); if (password.length < 12) throw new Error('Пароль должен содержать не менее 12 символов');
            if (this.profile) throw new Error('Ключ издателя уже существует');
            const identity = await generateIdentity();
            const encryptedKey = await encryptSecret({ key: await crypto.subtle.exportKey('jwk', identity.privateKey), publisherId }, password);
            await this.store({ v: 1, publisherId, publicKey: identity.publicKey, encryptedKey }, identity, epoch);
        });
    }
    async unlock(password: string): Promise<void> {
        await this.exclusive(async epoch => {
            if (!this.profile) throw new Error('Сначала создайте или импортируйте ключ издателя');
            const identity = await this.decode(this.profile, password);
            this.current(epoch); this.identity = identity;
        });
    }
    private async decode(profile: Profile, password: string): Promise<Identity> {
        this.validate(profile);
        const raw = await decryptSecret(profile.encryptedKey, password) as any;
        const identity = await importIdentity(raw.key);
        if (raw.publisherId !== profile.publisherId || identity.keyId !== await keyId(profile.publicKey)) throw new Error('Публичная часть не совпадает с защищённым ключом');
        return identity;
    }
    exportBackup(): string { if (!this.profile) throw new Error('Ключ издателя отсутствует'); return JSON.stringify(this.profile, null, 2); }
    exportAnchor(): string { if (!this.profile) throw new Error('Ключ издателя отсутствует'); return publicAnchor(this.profile.publisherId, this.profile.publicKey); }
    async restore(text: string, password: string): Promise<void> {
        await this.exclusive(async epoch => {
            if (this.profile) throw new Error('Существующий ключ нельзя перезаписать');
            const profile = JSON.parse(text) as Profile, identity = await this.decode(profile, password);
            const encryptedKey = await encryptSecret({ publisherId: profile.publisherId, key: await crypto.subtle.exportKey('jwk', identity.privateKey) }, password);
            await this.store({ v: 1, publisherId: profile.publisherId, publicKey: identity.publicKey, encryptedKey }, identity, epoch);
        });
    }
    /** Import existing CLI identity; retaining the old public root avoids locking out published managers. */
    async importCli(text: string, password: string): Promise<void> {
        await this.exclusive(async epoch => {
            if (this.profile) throw new Error('Существующий ключ нельзя перезаписать');
            const raw = JSON.parse(text); id(raw.publisherId);
            const identity = await importIdentity(raw.key);
            const encryptedKey = await encryptSecret({ publisherId: raw.publisherId, key: await crypto.subtle.exportKey('jwk', identity.privateKey) }, password);
            await this.store({ v: 1, publisherId: raw.publisherId, publicKey: identity.publicKey, encryptedKey }, identity, epoch);
        });
    }
    async issue(requestCode: string, config: TenantConfig, confirmedFingerprint: string): Promise<string> {
        return this.exclusive(async epoch => {
            if (!this.identity || !this.profile) throw new Error('Разблокируйте издателя');
            if (confirmedFingerprint !== await ownerFingerprint(requestCode)) throw new Error('Сначала проверьте заявку и подтвердите отпечаток хозяина');
            const code = await issueTenant(this.profile.publisherId, this.identity, requestCode, config);
            this.current(epoch); return code;
        });
    }
    lock(): void { this.epoch++; this.identity = null; }
    dispose(): void { this.disposed = true; this.lock(); void this.local.close().catch(() => undefined); }
}
