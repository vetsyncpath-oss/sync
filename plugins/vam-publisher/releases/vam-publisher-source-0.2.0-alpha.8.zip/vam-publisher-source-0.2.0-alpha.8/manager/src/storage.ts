import type { Position, SectionEntry, TokenSource } from "./types";

/**
 * Персистентность чтений (В2: одна позиция на заметку; В4: умный резюм).
 *
 * Проблема: сохранённый tokenIdx — ненадёжный якорь: любая правка заметки
 * выше по тексту сдвигает токены. Позиция обогащена отпечатком «3 слова до
 * + 3 слова после» и смещением символов — findResumeIndex восстанавливает
 * место даже в отредактированном тексте, с каскадом fallback'ов до старта
 * раздела.
 *
 * Хранилище — чистый TS: Obsidian-персистентность (saveData/loadData)
 * инжектируется. Запись дебаунсится: во время чтения позиция обновляется
 * на каждом показе слова — сохранять файл на каждый кадр недопустимо.
 */

export interface StoreData {
  version: 1;
  /** Ключ — путь заметки. */
  positions: Record<string, Position>;
}

export function emptyStore(): StoreData {
  return { version: 1, positions: {} };
}

/** Интервал дебаунса записи, мс. */
const SAVE_DEBOUNCE_MS = 1500;

/** Слов отпечатка ДО и ПОСЛЕ позиции (нормализованных). */
const FP_BEFORE = 3;
const FP_AFTER = 3;
/** Порог совпадений отпечатка для принятия якоря (из 6). */
const FP_MATCH_MIN = 3;

const WORD_CHARS_RE = /[^a-zа-яё0-9]/g;

/** Нормализация слова отпечатка: без регистра и пунктуации. */
export function normalizeWord(s: string): string {
  return s.toLowerCase().replace(WORD_CHARS_RE, "");
}

/** Собрать отпечаток позиции idx: [t-3, t-2, t-1, t, t+1, t+2]. */
export function buildFingerprint(tokens: TokenSource, idx: number): string[] {
  const out: string[] = [];
  for (let k = idx - FP_BEFORE; k < idx + FP_AFTER; k++) {
    if (k >= 0 && tokens.isReady(k)) out.push(normalizeWord(tokens.get(k).text));
    else out.push("");
  }
  return out;
}

interface FpScore {
  score: number;
  comparable: number;
}

function scoreAt(tokens: TokenSource, anchor: number, fp: string[]): FpScore {
  let score = 0;
  let comparable = 0;
  for (let k = 0; k < fp.length; k++) {
    const want = fp[k] ?? "";
    if (!want) continue;
    comparable += 1;
    const j = anchor - FP_BEFORE + k;
    if (j >= 0 && tokens.isReady(j) && normalizeWord(tokens.get(j).text) === want) {
      score += 1;
    }
  }
  return { score, comparable };
}

/**
 * Умный поиск позиции резюма (В4-1). Возвращает индекс токена, с которого
 * продолжать. Каскад:
 *   1. быстрый путь — сохранённый tokenIdx, если отпечаток совпал
 *      (заметка не менялась — типичный случай);
 *   2. seek в раздел + скан раздела: лучший отпечаток-матч
 *      (правки выше по тексту, сдвиг токенов);
 *   3. ближайший по charOffset токен раздела (правки рядом с местом);
 *   4. старт раздела (минимальная потеря: начало заголовка).
 */
export async function findResumeIndex(tokens: TokenSource, pos: Position): Promise<number> {
  const fp = Array.isArray(pos.fingerprint) ? pos.fingerprint.map((w) => normalizeWord(w)) : [];

  // Быстрый путь: tokenIdx всё ещё валиден и окружение совпало.
  if (pos.tokenIdx >= 0 && tokens.isReady(pos.tokenIdx)) {
    const s = scoreAt(tokens, pos.tokenIdx, fp);
    if (s.score >= FP_MATCH_MIN && s.score >= s.comparable) {
      return pos.tokenIdx;
    }
  }

  // Границы скана.
  let sec: SectionEntry | null = null;
  if (pos.sectionIdx >= 0) {
    try {
      sec = tokens.getSection(pos.sectionIdx);
    } catch {
      sec = null;
    }
  }

  if (sec !== null) {
    try {
      // Синхронно доготавливает раздел (и пропуск до него).
      await tokens.seek(pos.sectionIdx);
    } catch {
      // раздел исчез после правки — сканируем от tokenIdx/начала
    }
  }

  let from = 0;
  let to: number;
  if (sec !== null) {
    from = Math.max(0, sec.firstTokenIdx);
    to = sectionTokenEnd(tokens, pos.sectionIdx, sec);
  } else if (pos.sectionIdx < 0 && tokens.isReady(0)) {
    // Текст до первого заголовка: до первого токена раздела 0.
    to = firstSectionStart(tokens);
  } else {
    from = 0;
    to = firstSectionStart(tokens);
  }

  // Скан диапазона на лучший отпечаток (при равенстве — ближе к charOffset).
  let bestIdx = -1;
  let bestScore = 0;
  let bestDelta = Number.POSITIVE_INFINITY;
  for (let i = from; i < to; i++) {
    if (!tokens.isReady(i)) break;
    const s = scoreAt(tokens, i, fp);
    if (s.score >= FP_MATCH_MIN && s.score >= s.comparable) {
      const delta = Math.abs(tokens.get(i).charStart - pos.charOffset);
      if (s.score > bestScore || (s.score === bestScore && delta < bestDelta)) {
        bestScore = s.score;
        bestDelta = delta;
        bestIdx = i;
      }
    }
  }
  if (bestIdx >= 0) return bestIdx;

  // Fallback: ближайший к charOffset токен раздела.
  if (to > from && tokens.isReady(from)) {
    let nearest = -1;
    let nearestDelta = Number.POSITIVE_INFINITY;
    for (let i = from; i < to; i++) {
      if (!tokens.isReady(i)) break;
      const delta = Math.abs(tokens.get(i).charStart - pos.charOffset);
      if (delta < nearestDelta) {
        nearestDelta = delta;
        nearest = i;
      }
    }
    if (nearest >= 0 && nearestDelta <= (sec ? sec.charEnd - sec.charStart : Number.POSITIVE_INFINITY)) {
      return nearest;
    }
  }

  // Старт раздела / начала.
  return from;
}

/** Первый токен за пределами раздела idx (граница по charEnd раздела). */
function sectionTokenEnd(tokens: TokenSource, sectionIdx: number, sec: SectionEntry): number {
  const len = tokens.length;
  const hardEnd = len >= 0 ? len : Number.POSITIVE_INFINITY;
  // Раздел заканчивается там, где начинается следующий (charStart ≥ charEnd);
  // позиция токена относится к последнему разделу с charStart ≤ смещения.
  let i = Math.max(0, sec.firstTokenIdx);
  while (i < hardEnd && tokens.isReady(i) && tokens.get(i).charStart < sec.charEnd) {
    i++;
  }
  // Заглядываем на FP_AFTER токенов дальше для отпечатка «после» —
  // они могут принадлежать следующему разделу, это норма для матчинга.
  const lookaheadEnd = i + FP_AFTER;
  return Math.min(lookaheadEnd, hardEnd);
}

/** Индекс первого токена раздела 0 (или длина потока). */
function firstSectionStart(tokens: TokenSource): number {
  try {
    const first = tokens.getSection(0);
    const idx = first.firstTokenIdx;
    if (idx > 0) return idx;
  } catch {
    // разделов нет вовсе — весь текст один диапазон
  }
  const len = tokens.length;
  return len >= 0 ? len : Number.POSITIVE_INFINITY;
}

/* ═══════════════ Хранилище позиций ═══════════════ */

function isValidPosition(v: unknown): v is Position {
  if (typeof v !== "object" || v === null) return false;
  const p = v as Partial<Position>;
  return (
    typeof p.sectionIdx === "number" &&
    typeof p.charOffset === "number" &&
    Array.isArray(p.fingerprint) &&
    typeof p.wpm === "number" &&
    typeof p.tokenIdx === "number"
  );
}

/** Разбор данных хранилища (защита от мусора/старых версий). */
export function parseStoreData(raw: unknown): StoreData {
  if (typeof raw !== "object" || raw === null) return emptyStore();
  const positions = (raw as { positions?: unknown }).positions;
  if (typeof positions !== "object" || positions === null) {
    return emptyStore();
  }
  const out: Record<string, Position> = {};
  for (const [path, v] of Object.entries(positions as Record<string, unknown>)) {
    if (isValidPosition(v)) out[path] = v;
  }
  return { version: 1, positions: out };
}

export class RsvpStore {
  private data: StoreData;
  private readonly persist: (d: StoreData) => Promise<void>;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private writing: Promise<void> = Promise.resolve();

  constructor(
    persist: (d: StoreData) => Promise<void>,
    data: StoreData = emptyStore(),
  ) {
    this.persist = persist;
    this.data = data;
  }

  /** Загрузка с инжектированным читателем/писателем (plugin.loadData/saveData). */
  static async load(
    read: () => Promise<unknown>,
    persist: (d: StoreData) => Promise<void>,
  ): Promise<RsvpStore> {
    return new RsvpStore(persist, parseStoreData(await safeRead(read)));
  }

  /** Тесты/кастомная персистентность: создать с готовыми данными. */
  static withData(data: StoreData, persist: (d: StoreData) => Promise<void>): RsvpStore {
    return new RsvpStore(persist, data);
  }

  get(path: string): Position | undefined {
    return this.data.positions[path];
  }

  /** Дебаунс-запись позиции. */
  save(path: string, pos: Position): void {
    this.data.positions[path] = pos;
    if (this.timer !== null) clearTimeout(this.timer);
    this.timer = setTimeout(() => {
      this.timer = null;
      void this.flush();
    }, SAVE_DEBOUNCE_MS);
  }

  /** Немедленная запись (закрытие вкладки, пауза, конец). */
  async flush(): Promise<void> {
    if (this.timer !== null) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    const snapshot = this.data;
    this.writing = this.persist(snapshot).catch(() => undefined);
    await this.writing;
  }

  forget(path: string): void {
    delete this.data.positions[path];
  }

  /** Снимок данных (для объединённой записи data.json). */
  snapshot(): StoreData {
    return { version: 1, positions: { ...this.data.positions } };
  }

  /** Все позиции, свежие первыми (для модалки «Продолжить…»). */
  entries(): { path: string; pos: Position }[] {
    return Object.entries(this.data.positions)
      .map(([path, pos]) => ({ path, pos }))
      .sort((a, b) => b.pos.updatedAt - a.pos.updatedAt);
  }
}

async function safeRead(read: () => Promise<unknown>): Promise<unknown> {
  try {
    return await read();
  } catch {
    return null;
  }
}
