/**
 * Каскад fit-or-shrink-or-split для показа слова в сцене RSVP.
 *
 * Решение вычисляется ДО рендера (чистая функция с инжектированным
 * измерителем ширины) — DOM-код вью просто исполняет его:
 *   fit    — показать как есть;
 *   shrink — уменьшить кегль только для этого слова (scale ≤ 1);
 *   split  — резать на слоговые куски (syllabify) и показать куски
 *            следующими «словами» потока.
 *
 * Порядок каскада (Д3): целое слово читается лучше кусков, поэтому
 * подгонка шрифта предпочтительнее разреза — до пола minScale (0.65):
 * дальше узкие буквы вредят распознаванию сильнее переноса.
 *
 * decideParts — основная (продакшн) версия: пивот ЗАКРЕПЛЁН на
 * вертикали в центре сцены (CSS grid [1fr auto 1fr]), слово строится
 * вокруг него, поэтому влезание проверяется по ПАРТАМ: левая часть
 * должна влезть в availL, правая (включая дефис куска) — в availR.
 * Симметричный availL === availR соответствует пивоту ровно в центре.
 *
 * decide — классическая полная ширина (слово целиком ≤ maxWidth):
 * сохранена для полноты каскада и тестов; в проде не используется.
 */

export type FitDecision =
  | { kind: "fit" }
  | { kind: "shrink"; scale: number }
  | { kind: "split" };

export function decide(
  word: string,
  measure: (s: string) => number,
  maxWidth: number,
  minScale = 0.65,
): FitDecision {
  if (word.length === 0 || maxWidth <= 0) {
    return { kind: "split" };
  }
  const w = measure(word);
  if (w <= maxWidth) {
    return { kind: "fit" };
  }
  const scale = maxWidth / w;
  if (scale >= minScale && scale > 0) {
    return { kind: "shrink", scale: Math.min(scale, 1) };
  }
  return { kind: "split" };
}

/**
 * Part-aware каскад вокруг закреплённого пивота.
 *
 * word.slice(0, pivot) должно влезть в availL, word.slice(pivot + 1) —
 * в availR; масштаб общий, поэтому scale = min(availL/wL, availR/wR).
 * Пустые части не ограничивают (Infinity). pivot клампится в границы
 * слова. Дополнительный символ в конце строки (дефис куска) учитывается
 * вызывающей стороной — он просто удлиняет правую часть при измерении.
 */
export function decideParts(
  word: string,
  pivot: number,
  measure: (s: string) => number,
  availL: number,
  availR: number,
  minScale = 0.65,
): FitDecision {
  if (word.length === 0 || availL <= 0 || availR <= 0) {
    return { kind: "split" };
  }
  const p = Math.min(Math.max(0, Math.floor(pivot)), word.length - 1);
  const wL = measure(word.slice(0, p));
  const wR = measure(word.slice(p + 1));
  const sL = wL > 0 && Number.isFinite(wL) ? availL / wL : Infinity;
  const sR = wR > 0 && Number.isFinite(wR) ? availR / wR : Infinity;
  const scale = Math.min(sL, sR);
  if (scale >= 1) {
    return { kind: "fit" };
  }
  if (scale >= minScale && scale > 0) {
    return { kind: "shrink", scale: Math.min(scale, 1) };
  }
  return { kind: "split" };
}
