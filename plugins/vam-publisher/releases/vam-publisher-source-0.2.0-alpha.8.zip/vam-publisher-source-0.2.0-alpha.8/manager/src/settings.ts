import { App, PluginSettingTab, Setting } from "obsidian";
import type RsvpPlugin from "../main";
import type { Filters } from "./types";
import { DEFAULT_FILTERS } from "./filters";

/**
 * Настройки плагина (В3, В5, В11, В13 + фокус-режим В1).
 *
 * Деливрибл пользовательского уровня: скорость по умолчанию и «последняя
 * скорость» сессии хранятся раздельно — позиция заметки несёт wpm сессии,
 * настройки задают старт для новых чтений.
 */

export interface RsvpSettings {
  /** Стартовая скорость для новых чтений (В5: 300). */
  wpm: number;
  /**
   * Минимальная экспозиция КОРОТКИХ слов, мс (0 — выключено).
   * Дополняет wpm: мельтешащие короткие слова не быстрее порога,
   * общий темп и паузы пунктуации не меняются.
   */
  minWordMs: number;
  /** Слова скольких букв (без пунктуации) считать «короткими» для порога. Default 4. */
  minWordMaxLetters: number;
  /** Кегль слова сцены, px (В11: 16–72, Inter). */
  fontSize: number;
  /**
   * Вертикаль строки чтения (акцентная буква): смещение от центра
   * сцены в % её высоты (−20 выше … +20 ниже). Направляющие полосы
   * и засечки следуют за строкой. 0 — по центру.
   */
  wordVerticalShift: number;
  /** Сразу запускать воспроизведение при открытии чтения (В13). */
  autoPlay: boolean;
  /** Скрывать боковые панели при открытии сцены (В1). */
  hideSidebarOnOpen: boolean;
  /** Матрица фильтров контента (В3). */
  filters: Filters;
}

export const DEFAULT_SETTINGS: RsvpSettings = {
  wpm: 300,
  minWordMs: 0,
  minWordMaxLetters: 4,
  fontSize: 40,
  wordVerticalShift: 0,
  autoPlay: true,
  hideSidebarOnOpen: false,
  filters: { ...DEFAULT_FILTERS },
};

export class RsvpSettingTab extends PluginSettingTab {
  private readonly plugin: RsvpPlugin;

  constructor(app: App, plugin: RsvpPlugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display(): void {
    const { containerEl } = this;
    containerEl.empty();

    this.renderReadingSection();
    this.renderFilterSection();
    this.renderResetSection();
  }

  /* ── Чтение ── */

  private renderReadingSection(): void {
    const { containerEl } = this;

    containerEl.createEl("h2", { text: "Чтение" });

    new Setting(containerEl)
      .setName("Скорость по умолчанию")
      .setDesc("Слов в минуту для новых чтений. Внутри сессии меняется стрелками ↑/↓.")
      .addSlider((s) =>
        s
          .setLimits(100, 800, 10)
          .setValue(this.plugin.settings.wpm)
          .setDynamicTooltip()
          .onChange(async (v) => {
            this.plugin.settings.wpm = v;
            await this.plugin.saveSettings();
          }),
      );

    new Setting(containerEl)
      .setName("Минимальное время показа")
      .setDesc(
        "Нижний порог экспозиции коротких слов (не длиннее «Считать короткими слова до» букв), мс (0 — выключено). Дополняет скорость: общий темп, длинные слова и паузы на пунктуации не меняются. Меняется и кнопками в пульте чтения.",
      )
      .addSlider((s) =>
        s
          .setLimits(0, 400, 10)
          .setValue(this.plugin.settings.minWordMs)
          .setDynamicTooltip()
          .onChange(async (v) => {
            this.plugin.settings.minWordMs = v;
            await this.plugin.saveSettings();
            this.plugin.applySettingsToViews();
          }),
      );

    new Setting(containerEl)
      .setName("Считать короткими слова до")
      .setDesc(
        "Сколько букв (пунктуация не в счёт) — слово ещё «короткое»: только такие удлиняются порогом выше. Пары слов при чанкинге оцениваются по каждому слову.",
      )
      .addDropdown((d) => {
        for (let n = 2; n <= 8; n++) d.addOption(String(n), `${n} букв`);
        d.setValue(String(this.plugin.settings.minWordMaxLetters)).onChange(async (v) => {
          this.plugin.settings.minWordMaxLetters = Number(v);
          await this.plugin.saveSettings();
          this.plugin.applySettingsToViews();
        });
      });

    new Setting(containerEl)
      .setName("Размер слова")
      .setDesc("Кегль сцены, 16–72 px. Длинные слова либо ужимаются, либо режутся по слогам.")
      .addSlider((s) =>
        s
          .setLimits(16, 72, 2)
          .setValue(this.plugin.settings.fontSize)
          .setDynamicTooltip()
          .onChange(async (v) => {
            this.plugin.settings.fontSize = v;
            await this.plugin.saveSettings();
            this.plugin.applySettingsToViews();
          }),
      );

    new Setting(containerEl)
      .setName("Положение строки чтения")
      .setDesc(
        "Смещение строки с акцентной буквой от центра сцены, в % её высоты: минус — выше, плюс — ниже. Поле чтения и засечки следуют за строкой, горизонталь буквы всегда закреплена в центре.",
      )
      .addSlider((s) =>
        s
          .setLimits(-20, 20, 1)
          .setValue(this.plugin.settings.wordVerticalShift)
          .setDynamicTooltip()
          .onChange(async (v) => {
            this.plugin.settings.wordVerticalShift = v;
            await this.plugin.saveSettings();
            this.plugin.applySettingsToViews();
          }),
      );

    new Setting(containerEl)
      .setName("Запускать сразу")
      .setDesc("Начинать воспроизведение при открытии чтения, не дожидаясь пробела.")
      .addToggle((t) =>
        t.setValue(this.plugin.settings.autoPlay).onChange(async (v) => {
          this.plugin.settings.autoPlay = v;
          await this.plugin.saveSettings();
        }),
      );

    new Setting(containerEl)
      .setName("Скрывать панели при открытии")
      .setDesc("Убирать боковые панели (файлы/поиск) при входе в чтение. Вернуть — клавишей F.")
      .addToggle((t) =>
        t.setValue(this.plugin.settings.hideSidebarOnOpen).onChange(async (v) => {
          this.plugin.settings.hideSidebarOnOpen = v;
          await this.plugin.saveSettings();
        }),
      );
  }

  /* ── Фильтры контента (В3) ── */

  private renderFilterSection(): void {
    const { containerEl } = this;
    const filters = this.plugin.settings.filters;

    containerEl.createEl("h2", { text: "Что читать" });
    containerEl.createEl("p", {
      cls: "setting-item-description",
      text: "Изменения фильтров вступают в силу при следующем открытии чтения.",
    });

    const blockMode = (name: string, desc: string, key: "code" | "table" | "math"): void => {
      new Setting(containerEl)
        .setName(name)
        .setDesc(desc)
        .addDropdown((d) =>
          d
            .addOption("skip", "Пропускать")
            .addOption("read", "Читать как текст")
            .setValue(filters[key])
            .onChange(async (v) => {
              filters[key] = v as Filters["code"];
              await this.plugin.saveSettings();
            }),
        );
    };

    blockMode("Код-блоки", "``` и ~~~ целиком.", "code");
    blockMode("Таблицы", "Markdown-таблицы.", "table");
    blockMode("Формулы", "Блочные $$…$$.", "math");

    new Setting(containerEl)
      .setName("Комментарии")
      .setDesc("%%…%% и <!--…–>: выкидывать из потока слов.")
      .addToggle((t) =>
        t.setValue(!filters.comments).onChange(async (v) => {
          filters.comments = !v;
          await this.plugin.saveSettings();
        }),
      );

    new Setting(containerEl)
      .setName("Цитаты и callouts")
      .setDesc("Читать содержимое «> …», маркеры срезаются.")
      .addToggle((t) =>
        t.setValue(filters.blockquote).onChange(async (v) => {
          filters.blockquote = v;
          await this.plugin.saveSettings();
        }),
      );

    new Setting(containerEl)
      .setName("Инлайн-теги")
      .setDesc("Слова вида #тег в потоке (выключено — пропускать).")
      .addToggle((t) =>
        t.setValue(filters.tags).onChange(async (v) => {
          filters.tags = v;
          await this.plugin.saveSettings();
        }),
      );

    new Setting(containerEl)
      .setName("Эмбеды ![[…]]")
      .setDesc("Встраивания других заметок. Разворачивание — в следующей версии.")
      .addDropdown((d) =>
        d
          .addOption("skip", "Пропускать")
          .setValue(filters.embeds)
          .onChange(async (v) => {
            filters.embeds = v as Filters["embeds"];
            await this.plugin.saveSettings();
          }),
      );
  }

  /* ── Сброс ── */

  private renderResetSection(): void {
    const { containerEl } = this;
    containerEl.createEl("h2", { text: "Данные" });
    new Setting(containerEl)
      .setName("Забыть все позиции")
      .setDesc("Сбрасывает прогресс чтения всех заметок (файлы не трогаются).")
      .addButton((b) =>
        b
          .setButtonText("Сбросить")
          .setWarning()
          .onClick(async () => {
            await this.plugin.forgetAllPositions();
          }),
      );
  }
}
