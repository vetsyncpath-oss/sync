// src/ui/confirm-modal.ts — маленькая модалка подтверждения (отзыв, kill switch, сброс).
// v0.4.2: BUG-07 fix — onClose вызывает onCancel если confirmed !== true.
// v0.4.2: severity 'warning' | 'danger' для визуального различия.

import { Modal, Setting } from 'obsidian';
import { t } from '../i18n';

export type ConfirmSeverity = 'warning' | 'danger';

export class ConfirmModal extends Modal {
        private title: string;
        private message: string;
        private onConfirm: () => void;
        private onCancel?: () => void;
        private severity: ConfirmSeverity;
        /** v0.4.2: флаг что confirm уже произошёл — onClose не зовёт onCancel */
        private confirmed = false;
        /** v0.4.2: флаг что cancel уже был вызван явно — onClose не дублирует */
        private cancelCalled = false;

        constructor(
                app: ConstructorParameters<typeof Modal>[0],
                title: string,
                message: string,
                onConfirm: () => void,
                onCancel?: () => void,
                severity: ConfirmSeverity = 'warning',
        ) {
                super(app);
                this.title = title;
                this.message = message;
                this.onConfirm = onConfirm;
                this.onCancel = onCancel;
                this.severity = severity;
        }

        onOpen(): void {
                const { contentEl } = this;
                contentEl.empty();
                contentEl.createEl('h3', { text: this.title });

                // v0.4.2: severity-based rendering
                const msgCls = this.severity === 'danger' ? 'vam-confirm-danger' : 'vam-muted';
                contentEl.createEl('p', { text: this.message, cls: msgCls });

                const s = new Setting(contentEl);
                s.addButton((b) => {
                        const label = this.severity === 'danger' ? t('confirmDangerBtn') : t('submitBtn');
                        b.setButtonText(label);
                        b.setWarning();
                        b.onClick(() => {
                                this.confirmed = true;
                                this.close();
                                this.onConfirm();
                        });
                });
                s.addButton((b) => {
                        b.setButtonText(t('cancelBtn'));
                        b.onClick(() => {
                                this.cancelCalled = true;
                                this.close();
                                this.onCancel?.();
                        });
                });
        }

        /**
         * v0.4.2: BUG-07 fix.
         * onClose вызывается при ЛЮБОМ закрытии modal — кнопка Submit, кнопка Cancel,
         * крестик, Esc, клик вне modal. Если confirm не был выполнен И cancel не был
         * вызван явно — это закрытие через X/Esc, нужно позвать onCancel.
         */
        onClose(): void {
                if (!this.confirmed && !this.cancelCalled) {
                        try {
                                this.onCancel?.();
                        } catch {
                                // не роняем modal при ошибке в callback
                        }
                }
        }
}
