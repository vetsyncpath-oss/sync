// src/ui/users-modal.ts — (owner) таблица пользователей: выдача, ротация, отзыв, переиздание
// v0.4.2: input refs (BUG-01 fix), validation, ConfirmModal, search, expired highlight.

import { Modal, Notice, Setting } from 'obsidian';
import { t } from '../i18n';
import type ManagerPlugin from '../../legacy-manager';
import type { OwnerUserMeta } from '../core/store';
import { listOwnerUsers } from '../core/store';
import { generatePassword } from '../core/registration';
import { ConfirmModal } from './confirm-modal';

interface UserRow {
        userId: string;
        inChannel: boolean;
        meta: OwnerUserMeta | null;
}

function formatDate(ts: number | null): string {
        return ts === null ? '—' : new Date(ts).toLocaleDateString();
}

function expiresText(meta: OwnerUserMeta | null): string {
        if (!meta || meta.expiresAt === null) return t('neverExpires');
        return meta.expiresAt < Date.now() ? t('expiredLabel') : new Date(meta.expiresAt).toLocaleDateString();
}

// v0.6 (M4): колонка «Устройства» — кэш users-local (может отставать от записи;
// источник истины — сама users/<id>.enc). «2/2 · DESKTOP-AB12, NOTEBOOK» или «без привязки».
// v0.6.1: ручной режим (сброс устройств) — пометка в той же колонке: «0/2 · ручное зачисление».
function devicesText(meta: OwnerUserMeta | null): string {
        if (!meta || meta.devices === undefined) return t('umDevicesLegacy');
        const max = meta.maxDevices ?? 2;
        const names = meta.devices.map((d) => d.name || d.id).join(', ');
        const manual = meta.autoEnroll === false ? ` · ${t('umDevicesManual')}` : '';
        return `${meta.devices.length}/${max}${names ? ` · ${names}` : ''}${manual}`;
}

export class UsersModal extends Modal {
        private plugin: ManagerPlugin;
        private rows: UserRow[] = [];
        private loading = true;
        private searchQuery = '';

        constructor(app: ConstructorParameters<typeof Modal>[0], plugin: ManagerPlugin) {
                super(app);
                this.plugin = plugin;
        }

        onOpen(): void {
                this.render();
                void this.load();
        }

        private async load(): Promise<void> {
                try {
                        const client = this.plugin.makeClient();
                        const channelFiles = await client.listDir('users');
                        const localMetas = await listOwnerUsers(this.plugin.getPluginAdapter());
                        const byId = new Map(localMetas.map((m) => [m.userId, m]));
                        this.rows = channelFiles
                                .filter((f) => f.name.endsWith('.enc'))
                                .map((f) => {
                                        const userId = f.name.replace(/\.enc$/, '');
                                        return { userId, inChannel: true, meta: byId.get(userId) ?? null };
                                });
                        for (const meta of localMetas) {
                                if (!this.rows.some((r) => r.userId === meta.userId)) {
                                        this.rows.push({ userId: meta.userId, inChannel: false, meta });
                                }
                        }
                        this.rows.sort((a, b) => (b.meta?.updatedAt ?? 0) - (a.meta?.updatedAt ?? 0));
                } catch (err) {
                        console.warn('[VaultAccessManager] users list failed:', err instanceof Error ? err.message : String(err));
                }
                this.loading = false;
                this.render();
        }

        private render(): void {
                const { contentEl } = this;
                contentEl.empty();
                contentEl.createEl('h3', { text: t('umTitle') });

                // v0.5.5: вводная — запись = право на плагины, а не список плагинов
                // (аудит v0.5.4: пользователь смешивал «одобрение человека» с настройкой плагинов)
                const intro = contentEl.createEl('p', { cls: 'vam-muted' });
                intro.textContent = t('umIntro');

                // Toolbar: Issue button + Search field (v0.4.2: В2)
                const toolbar = new Setting(contentEl);
                toolbar.addButton((b) => {
                        b.setButtonText(t('umIssueBtn'));
                        b.setCta();
                        b.onClick(() => new IssueUserModal(this.app, this.plugin, () => void this.load()).open());
                });

                // Search field — только если есть что искать
                if (!this.loading && this.rows.length > 0) {
                        const search = new Setting(contentEl);
                        search.setName(t('umSearchLabel'));
                        search.addText((text) => {
                                text.setPlaceholder(t('umSearchPlaceholder'));
                                text.setValue(this.searchQuery);
                                text.onChange(() => {
                                        this.searchQuery = text.getValue().toLowerCase().trim();
                                        this.renderRows();
                                });
                        });
                }

                if (this.loading) {
                        contentEl.createEl('p', { text: t('statusChecking'), cls: 'vam-muted' });
                        return;
                }
                if (this.rows.length === 0) {
                        contentEl.createEl('p', { text: t('umEmpty'), cls: 'vam-muted' });
                        return;
                }

                this.renderRows();
                new Setting(contentEl).addButton((b) => {
                        b.setButtonText(t('closeBtn'));
                        b.onClick(() => this.close());
                });
        }

        private renderRows(): void {
                const { contentEl } = this;
                // Удалить существующую таблицу, если есть
                const existingTable = contentEl.querySelector('.vam-users-table');
                if (existingTable) existingTable.remove();

                // Фильтрация по поиску
                let rows = this.rows;
                if (this.searchQuery) {
                        rows = rows.filter(r => {
                                const id = r.userId.toLowerCase();
                                const note = (r.meta?.note ?? '').toLowerCase();
                                return id.includes(this.searchQuery) || note.includes(this.searchQuery);
                        });
                }

                if (rows.length === 0) {
                        const noMatch = contentEl.createEl('p', { cls: 'vam-muted', text: t('umNoMatch') });
                        noMatch.classList.add('vam-users-table');  // marker для удаления
                        return;
                }

                const tableWrap = contentEl.createEl('div', { cls: 'vam-users-table' });
                const table = tableWrap.createEl('table', { cls: 'vam-table' });
                const head = table.createEl('tr');
                // v0.6 (M4): + колонка «Устройства»
                for (const title of [t('userIdLabel'), t('noteLabel'), t('diagCheckedAt'), t('expiresLabel'), t('umDevicesCol'), '']) {
                        head.createEl('th', { text: title });
                }
                for (const row of rows) {
                        const tr = table.createEl('tr');
                        // v0.4.2: В1 — подсветка истёкших
                        const isExpired = row.meta !== null && row.meta.expiresAt !== null && row.meta.expiresAt < Date.now();
                        if (isExpired) tr.addClass('vam-row-expired');

                        tr.createEl('td', { text: row.userId });
                        tr.createEl('td', { text: row.meta?.note ?? '—' });
                        tr.createEl('td', { text: row.meta ? formatDate(row.meta.issuedAt) : '—' });
                        tr.createEl('td', { text: expiresText(row.meta) });
                        tr.createEl('td', { text: devicesText(row.meta) });
                        const actions = tr.createEl('td');
                        const actionsWrap = actions.createEl('div', { cls: 'vam-row-actions' });
                        if (row.inChannel) {
                                const rotate = actionsWrap.createEl('button', { text: t('umRotateBtn') });
                                rotate.addEventListener('click', () => {
                                        if (!row.meta) return;
                                        new RotateUserModal(this.app, this.plugin, row.meta as OwnerUserMeta, () => void this.load()).open();
                                });
                                const revoke = actionsWrap.createEl('button', { text: t('umRevokeBtn') });
                                revoke.addEventListener('click', () => {
                                        new ConfirmModal(this.app, t('umRevokeBtn'), t('umConfirmRevoke'), async () => {
                                                try {
                                                        await this.plugin.revokeAccess(row.userId);
                                                        await this.load();
                                                } catch (err) {
                                                        console.warn('[VaultAccessManager] revoke failed:', err instanceof Error ? err.message : String(err));
                                                }
                                        }, undefined, 'danger').open();
                                });
                        }
                        if (row.meta) {
                                const reissue = actionsWrap.createEl('button', { text: t('umReissueBtn') });
                                reissue.addEventListener('click', () => {
                                        new ReissueUserModal(this.app, this.plugin, row.meta as OwnerUserMeta, () => void this.load()).open();
                                });
                                // v0.6 (M4): сброс реестра устройств (кража/продажа ПК) —
                                // только для записей с активным реестром
                                const meta = row.meta as OwnerUserMeta;
                                if (meta.devices !== undefined) {
                                        const reset = actionsWrap.createEl('button', { text: t('umResetDevicesBtn') });
                                        reset.addEventListener('click', () => {
                                                new ResetDevicesModal(this.app, this.plugin, meta, () => void this.load()).open();
                                        });
                                }
                        }
                }
        }
}

// --- форма выдачи (S8) ---

export class IssueUserModal extends Modal {
        private plugin: ManagerPlugin;
        private reload: () => void;
        private identifier = '';
        private password = '';
        private expires = '';
        private note = '';
        private inviteEl: HTMLElement | null = null;
        // v0.6 (M4): лимит устройств записи (default 2; 0 — без реестра)
        private maxDevices = 2;
        // v0.4.2: BUG-01 fix — сохраняем ссылки на input элементы
        private passwordInput: HTMLInputElement | null = null;

        constructor(app: ConstructorParameters<typeof Modal>[0], plugin: ManagerPlugin, reload: () => void) {
                super(app);
                this.plugin = plugin;
                this.reload = reload;
        }

        onOpen(): void {
                const { contentEl } = this;
                contentEl.empty();
                contentEl.createEl('h3', { text: t('umIssueBtn') });
                contentEl.createEl('p', { text: t('umIssueIntro'), cls: 'vam-muted' });

                const idSetting = new Setting(contentEl);
                idSetting.setName(t('identifierLabel'));
                idSetting.setDesc(t('umIdentifierHint'));
                idSetting.addText((text) => {
                        text.setPlaceholder(t('identifierPlaceholder'));
                        text.onChange(() => {
                                this.identifier = text.getValue();
                        });
                });

                const pwSetting = new Setting(contentEl);
                pwSetting.setName(t('passwordLabel'));
                pwSetting.addText((text) => {
                        text.inputEl.type = 'text';
                        text.onChange(() => {
                                this.password = text.getValue();
                        });
                        // v0.4.2: сохраняем ссылку на input
                        this.passwordInput = text.inputEl;
                });
                pwSetting.addButton((b) => {
                        b.setButtonText(t('genPasswordBtn'));
                        b.onClick(() => {
                                this.password = generatePassword();
                                // v0.4.2: используем сохранённую ссылку, а не querySelector
                                if (this.passwordInput) this.passwordInput.value = this.password;
                                void copyToClipboard(this.password);
                        });
                });

                // Код подключения VAMI1 (v0.3): одна строка = канал + логин + пароль
                const invite = new Setting(contentEl);
                invite.setName(t('umInviteBtn')).setDesc(t('umInviteHint'));
                invite.addButton((b) => {
                        b.setButtonText(t('umInviteBtn'));
                        b.onClick(() => this.buildInvite());
                });
                this.inviteEl = contentEl.createEl('div', { cls: 'vam-pre' });
                this.inviteEl.style.display = 'none';

                const expSetting = new Setting(contentEl);
                expSetting.setName(t('expiresLabel')).setDesc(t('datePlaceholder'));
                expSetting.addText((text) => {
                        text.setPlaceholder('2027-12-31');
                        text.onChange(() => {
                                this.expires = text.getValue();
                        });
                });

                // v0.6 (M4): лимит устройств — запись активируется с реестром
                const maxSetting = new Setting(contentEl);
                maxSetting.setName(t('umMaxDevicesLabel')).setDesc(t('umMaxDevicesHint'));
                maxSetting.addText((text) => {
                        text.inputEl.type = 'number';
                        text.setValue('2');
                        text.onChange(() => {
                                const parsed = Number.parseInt(text.getValue(), 10);
                                this.maxDevices = Number.isFinite(parsed) ? parsed : 2;
                        });
                });

                const noteSetting = new Setting(contentEl);
                noteSetting.setName(t('noteLabel'));
                noteSetting.addText((text) => {
                        text.onChange(() => {
                                this.note = text.getValue();
                        });
                });

                const actions = new Setting(contentEl);
                actions.addButton((b) => {
                        b.setButtonText(t('submitBtn'));
                        b.setCta();
                        b.onClick(() => void this.confirmAndSubmit());
                });
                actions.addButton((b) => {
                        b.setButtonText(t('cancelBtn'));
                        b.onClick(() => this.close());
                });
        }

        private buildInvite(): void {
                // v0.4.2: проверяем что поля заполнены перед генерацией
                if (!this.identifier.trim() || !this.password) {
                        try { new Notice(t('umInviteNeedsFields')); } catch {}
                        return;
                }
                const code = this.plugin.makeUserInviteCode(this.identifier, this.password);
                if (code === null) {
                        try { new Notice(t('umInviteNeedsChannel')); } catch {}
                        return;
                }
                if (this.inviteEl) {
                        this.inviteEl.style.display = 'block';
                        this.inviteEl.textContent = code;
                }
                void copyToClipboard(code);
        }

        // v0.4.2: В5 — подтверждение перед submit
        private async confirmAndSubmit(): Promise<void> {
                if (!this.identifier.trim()) {
                        try { new Notice(t('umIdRequired')); } catch {}
                        return;
                }
                if (!this.password) {
                        try { new Notice(t('umPwRequired')); } catch {}
                        return;
                }
                new ConfirmModal(this.app, t('umIssueBtn'),
                        t('umIssueConfirm', 0) + ' ' + this.identifier.trim(),
                        () => void this.submit(),
                        undefined,
                        'warning',
                ).open();
        }

        private async submit(): Promise<void> {
                const expiresAt = parseDate(this.expires);
                try {
                        await this.plugin.issueAccess(this.identifier.trim(), this.password, expiresAt, this.note.trim() || undefined, undefined, this.maxDevices);
                        try { new Notice(t('noticeAccessIssued')); } catch {}
                        this.close();
                        this.reload();
                } catch (err) {
                        const msg = err instanceof Error ? err.message : String(err);
                        console.warn('[VaultAccessManager] issue failed:', msg);
                        try { new Notice(`${t('opFailed')}: ${msg}`); } catch {}
                }
        }
}

// --- сброс реестра устройств (v0.6, M4) ---

class ResetDevicesModal extends Modal {
        private plugin: ManagerPlugin;
        private meta: OwnerUserMeta;
        private reload: () => void;
        private password = '';

        constructor(app: ConstructorParameters<typeof Modal>[0], plugin: ManagerPlugin, meta: OwnerUserMeta, reload: () => void) {
                super(app);
                this.plugin = plugin;
                this.meta = meta;
                this.reload = reload;
        }

        onOpen(): void {
                const { contentEl } = this;
                contentEl.empty();
                contentEl.createEl('h3', { text: `${t('umResetDevicesBtn')} — ${this.meta.note || this.meta.userId}` });
                contentEl.createEl('p', { text: t('umResetDevicesIntro'), cls: 'vam-confirm-danger' });
                if (this.meta.devices !== undefined && this.meta.devices.length > 0) {
                        const list = contentEl.createEl('p', { cls: 'vam-muted' });
                        list.textContent = this.meta.devices.map((d) => d.name || d.id).join(', ');
                }

                const pwSetting = new Setting(contentEl);
                pwSetting.setName(t('umResetDevicesPwLabel'));
                pwSetting.addText((text) => {
                        text.inputEl.type = 'password';
                        text.setPlaceholder(this.plugin.settings.defaultPassword ?? '••••••••');
                        text.onChange(() => {
                                this.password = text.getValue();
                        });
                });

                const actions = new Setting(contentEl);
                actions.addButton((b) => {
                        b.setButtonText(t('umResetDevicesBtn'));
                        b.setWarning();
                        b.onClick(() => void this.confirmAndSubmit());
                });
                actions.addButton((b) => {
                        b.setButtonText(t('cancelBtn'));
                        b.onClick(() => this.close());
                });
        }

        private async confirmAndSubmit(): Promise<void> {
                if (!this.password) {
                        try { new Notice(t('umPwRequired')); } catch {}
                        return;
                }
                new ConfirmModal(this.app, t('umResetDevicesBtn'),
                        `${t('umResetDevicesConfirm')} ${this.meta.note || this.meta.userId}`,
                        () => void this.submit(),
                        undefined,
                        'danger',
                ).open();
        }

        private async submit(): Promise<void> {
                try {
                        await this.plugin.resetDevicesAccess(this.meta, this.password);
                        try { new Notice(t('noticeDevicesReset')); } catch {}
                        this.close();
                        this.reload();
                } catch (err) {
                        const msg = err instanceof Error ? err.message : String(err);
                        console.warn('[VaultAccessManager] reset devices failed:', msg);
                        try { new Notice(`${t('opFailed')}: ${msg}`); } catch {}
                }
        }
}

// --- смена пароля (S4, со стороны хозяина) ---

export class RotateUserModal extends Modal {
        private plugin: ManagerPlugin;
        private meta: OwnerUserMeta;
        private reload: () => void;
        private password = '';
        // v0.5 (B-6, H-1): идентификатор для инвайта — отдельное поле с валидацией,
        // а не вслепую meta.note (кастомная пометка ≠ логин — код был нерабочим).
        // Подставляется note как наиболее вероятное значение; хозяин проверяет.
        private identifier = '';
        private inviteEl: HTMLElement | null = null;
        // v0.4.2: BUG-01 fix
        private passwordInput: HTMLInputElement | null = null;

        constructor(app: ConstructorParameters<typeof Modal>[0], plugin: ManagerPlugin, meta: OwnerUserMeta, reload: () => void) {
                super(app);
                this.plugin = plugin;
                this.meta = meta;
                this.reload = reload;
        }

        onOpen(): void {
                const { contentEl } = this;
                contentEl.empty();
                contentEl.createEl('h3', { text: `${t('umRotateBtn')} — ${this.meta.note || this.meta.userId}` });
                // v0.4.2: предупреждение что старый пароль перестанет работать
                contentEl.createEl('p', { text: t('umRotateWarn'), cls: 'vam-muted' });

                const pwSetting = new Setting(contentEl);
                pwSetting.setName(t('passwordLabel'));
                pwSetting.addText((text) => {
                        text.inputEl.type = 'text';
                        text.setValue(generatePassword());
                        this.password = text.getValue();
                        text.onChange(() => {
                                this.password = text.getValue();
                        });
                        this.passwordInput = text.inputEl;
                });
                pwSetting.addButton((b) => {
                        b.setButtonText(t('genPasswordBtn'));
                        b.onClick(() => {
                                this.password = generatePassword();
                                if (this.passwordInput) this.passwordInput.value = this.password;
                                void copyToClipboard(this.password);
                        });
                });

                // v0.5 (B-6, H-1): идентификатор — с валидацией ввода (interim, без миграции OwnerUserMeta)
                const idSetting = new Setting(contentEl);
                idSetting.setName(t('identifierLabel')).setDesc(t('umIdentifierRotateHint'));
                idSetting.addText((text) => {
                        text.setPlaceholder(t('identifierPlaceholder'));
                        text.setValue(this.meta.note); // наиболее вероятное значение — хозяин проверяет
                        this.identifier = text.getValue();
                        text.onChange(() => {
                                this.identifier = text.getValue();
                        });
                });

                const invite = new Setting(contentEl);
                invite.setName(t('umInviteBtn')).setDesc(t('umInviteHint'));
                invite.addButton((b) => {
                        b.setButtonText(t('umInviteBtn'));
                        b.onClick(() => this.buildInvite());
                });
                this.inviteEl = contentEl.createEl('div', { cls: 'vam-pre' });
                this.inviteEl.style.display = 'none';

                const actions = new Setting(contentEl);
                actions.addButton((b) => {
                        b.setButtonText(t('submitBtn'));
                        b.setCta();
                        b.onClick(() => void this.confirmAndSubmit());
                });
                actions.addButton((b) => {
                        b.setButtonText(t('cancelBtn'));
                        b.onClick(() => this.close());
                });
        }

        private buildInvite(): void {
                if (!this.password || !this.identifier.trim()) {
                        try { new Notice(t('umInviteNeedsFields')); } catch {}
                        return;
                }
                // v0.5 (B-6, H-1): инвайт строится из введённого идентификатора,
                // не из meta.note — код обязан быть рабочим при note ≠ identifier
                const code = this.plugin.makeUserInviteCode(this.identifier.trim(), this.password);
                if (code === null) {
                        try { new Notice(t('umInviteNeedsChannel')); } catch {}
                        return;
                }
                if (this.inviteEl) {
                        this.inviteEl.style.display = 'block';
                        this.inviteEl.textContent = code;
                }
                void copyToClipboard(code);
        }

        private async confirmAndSubmit(): Promise<void> {
                if (!this.password) {
                        try { new Notice(t('umPwRequired')); } catch {}
                        return;
                }
                new ConfirmModal(this.app, t('umRotateBtn'),
                        t('umRotateConfirm') + ' ' + (this.meta.note || this.meta.userId),
                        () => void this.submit(),
                        undefined,
                        'warning',
                ).open();
        }

        private async submit(): Promise<void> {
                try {
                        await this.plugin.rotateAccess(this.meta, this.password);
                        void copyToClipboard(this.password);
                        try { new Notice(t('noticeRotated')); } catch {}
                        this.close();
                        this.reload();
                } catch (err) {
                        const msg = err instanceof Error ? err.message : String(err);
                        console.warn('[VaultAccessManager] rotate failed:', msg);
                        try { new Notice(`${t('opFailed')}: ${msg}`); } catch {}
                }
        }
}

// --- переиздание (обновление expiresAt с новым паролем) ---

export class ReissueUserModal extends Modal {
        private plugin: ManagerPlugin;
        private meta: OwnerUserMeta;
        private reload: () => void;
        private expires = '';
        private password = '';
        // v0.5 (B-6, H-1): идентификатор для инвайта (валидация ввода, см. RotateUserModal)
        private identifier = '';
        private inviteEl: HTMLElement | null = null;

        constructor(app: ConstructorParameters<typeof Modal>[0], plugin: ManagerPlugin, meta: OwnerUserMeta, reload: () => void) {
                super(app);
                this.plugin = plugin;
                this.meta = meta;
                this.reload = reload;
        }

        onOpen(): void {
                const { contentEl } = this;
                contentEl.empty();
                contentEl.createEl('h3', { text: `${t('umReissueBtn')} — ${this.meta.note || this.meta.userId}` });
                // v0.4.2: объяснение vs Rotate
                contentEl.createEl('p', { text: t('umReissueExplain'), cls: 'vam-muted' });

                const expSetting = new Setting(contentEl);
                expSetting.setName(t('expiresLabel')).setDesc(t('datePlaceholder'));
                expSetting.addText((text) => {
                        text.setPlaceholder('2027-12-31');
                        text.onChange(() => {
                                this.expires = text.getValue();
                        });
                });

                const pwSetting = new Setting(contentEl);
                pwSetting.setName(t('passwordLabel'));
                pwSetting.addText((text) => {
                        text.inputEl.type = 'text';
                        text.setValue(generatePassword());
                        this.password = text.getValue();
                        text.onChange(() => {
                                this.password = text.getValue();
                        });
                });

                // v0.5 (B-6, H-1): идентификатор — с валидацией ввода (interim, без миграции OwnerUserMeta)
                const idSetting = new Setting(contentEl);
                idSetting.setName(t('identifierLabel')).setDesc(t('umIdentifierRotateHint'));
                idSetting.addText((text) => {
                        text.setPlaceholder(t('identifierPlaceholder'));
                        text.setValue(this.meta.note); // наиболее вероятное значение — хозяин проверяет
                        this.identifier = text.getValue();
                        text.onChange(() => {
                                this.identifier = text.getValue();
                        });
                });

                const invite = new Setting(contentEl);
                invite.setName(t('umInviteBtn')).setDesc(t('umInviteHint'));
                invite.addButton((b) => {
                        b.setButtonText(t('umInviteBtn'));
                        b.onClick(() => this.buildInvite());
                });
                this.inviteEl = contentEl.createEl('div', { cls: 'vam-pre' });
                this.inviteEl.style.display = 'none';

                const actions = new Setting(contentEl);
                actions.addButton((b) => {
                        b.setButtonText(t('submitBtn'));
                        b.setCta();
                        b.onClick(() => void this.confirmAndSubmit());
                });
                actions.addButton((b) => {
                        b.setButtonText(t('cancelBtn'));
                        b.onClick(() => this.close());
                });
        }

        private buildInvite(): void {
                if (!this.password || !this.identifier.trim()) {
                        try { new Notice(t('umInviteNeedsFields')); } catch {}
                        return;
                }
                // v0.5 (B-6, H-1): инвайт строится из введённого идентификатора,
                // не из meta.note — код обязан быть рабочим при note ≠ identifier
                const code = this.plugin.makeUserInviteCode(this.identifier.trim(), this.password);
                if (code === null) {
                        try { new Notice(t('umInviteNeedsChannel')); } catch {}
                        return;
                }
                if (this.inviteEl) {
                        this.inviteEl.style.display = 'block';
                        this.inviteEl.textContent = code;
                }
                void copyToClipboard(code);
        }

        private async confirmAndSubmit(): Promise<void> {
                if (!this.password) {
                        try { new Notice(t('umPwRequired')); } catch {}
                        return;
                }
                new ConfirmModal(this.app, t('umReissueBtn'),
                        t('umReissueConfirm') + ' ' + (this.meta.note || this.meta.userId),
                        () => void this.submit(),
                        undefined,
                        'warning',
                ).open();
        }

        private async submit(): Promise<void> {
                try {
                        await this.plugin.reissueAccess(this.meta, this.password, parseDate(this.expires));
                        void copyToClipboard(this.password);
                        try { new Notice(t('noticeReissued')); } catch {}
                        this.close();
                        this.reload();
                } catch (err) {
                        const msg = err instanceof Error ? err.message : String(err);
                        console.warn('[VaultAccessManager] reissue failed:', msg);
                        try { new Notice(`${t('opFailed')}: ${msg}`); } catch {}
                }
        }
}

// --- вспомогательные ---

function parseDate(input: string): number | null {
        const trimmed = input.trim();
        if (!trimmed) return null;
        const ts = Date.parse(trimmed);
        return Number.isFinite(ts) ? ts : null;
}

async function copyToClipboard(text: string): Promise<void> {
        try {
                await navigator.clipboard.writeText(text);
                try { new Notice(t('copiedNotice')); } catch {}
        } catch {
                // clipboard недоступен
        }
}
