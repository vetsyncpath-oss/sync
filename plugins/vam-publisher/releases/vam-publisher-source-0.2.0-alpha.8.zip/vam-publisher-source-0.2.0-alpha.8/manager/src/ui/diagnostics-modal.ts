// src/ui/diagnostics-modal.ts — v0.5.3 (репорт №3): модалка полного диагностического
// отчёта. Задача поля: пользователь ЖМЁТ кнопку и отправляет текст — без поиска
// файлов и без DevTools. Текст — <pre> (моноширинный, выделяется мышью), кнопка
// Copy — clipboard API с честным Notice об исходе. Путь к файлу-копии — в шапке.

import { Modal, Notice, Setting } from 'obsidian';
import { t } from '../i18n';

export class DiagnosticsModal extends Modal {
        private readonly report: string;
        private readonly savedPath: string;

        constructor(
                app: ConstructorParameters<typeof Modal>[0],
                report: string,
                savedPath: string,
        ) {
                super(app);
                this.report = report;
                this.savedPath = savedPath;
        }

        onOpen(): void {
                const { contentEl } = this;
                contentEl.empty();
                contentEl.createEl('h3', { text: t('diagModalTitle') });
                contentEl.createEl('p', { text: `${t('diagSavedPath')}: ${this.savedPath}`, cls: 'vam-muted' });
                contentEl.createEl('p', { text: t('diagModalHint'), cls: 'vam-muted' });
                contentEl.createEl('pre', { text: this.report, cls: 'vam-diag-report' });

                const s = new Setting(contentEl);
                s.addButton((b) => {
                        b.setButtonText(t('diagCopyBtn'));
                        b.setCta();
                        b.onClick(async () => {
                                let copied = false;
                                try {
                                        await navigator.clipboard.writeText(this.report);
                                        copied = true;
                                } catch {
                                        // clipboard недоступен (мобайл/старый Electron) — текст
                                        // выделяется вручную в <pre> ниже
                                        copied = false;
                                }
                                try {
                                        new Notice(copied ? t('diagCopied') : t('diagCopyFailed'));
                                } catch {
                                        // тестовое окружение
                                }
                        });
                });
        }

        onClose(): void {
                this.contentEl.empty();
        }
}
