// src/ui/settings-tab.ts — вкладка настроек, обе роли (§10.1, FR-1..32).
// Шапка: чип статуса + «проверено N мин назад» + «нет связи» при staleAt > checkedAt.
// Режим пользователя: Учётная запись → Канал → Заявка → Диагностика.
// Режим хозяина: гейт по хозяйскому паролю → Канал (+метаданные, бэкап) → Доступ.

import { Modal, Notice, PluginSettingTab, Setting } from 'obsidian';
import { t } from '../i18n';
import type { Translations } from '../i18n';
import type ManagerPlugin from '../../legacy-manager';
import type { AuthBlockReason } from '../core/auth-state';
import type { AuthStateDetail } from '../core/auth-state';
import { hashOwnerPassword, verifyOwnerPassword } from '../core/store';
import { DEFAULT_CHANNEL_META } from '../core/channel';
import { semverCompare } from '../core/semver';
import { UsersModal } from './users-modal';
import { RequestsModal } from './requests-modal';
import { ConfirmModal } from './confirm-modal';
import { PluginPolicyModal } from './plugin-policy-modal';
import { failed, loading, ready } from './loadable';
import type { Loadable } from './loadable';

const REASON_KEY: Record<AuthBlockReason, keyof Translations> = {
        'key-mismatch': 'reasonKeyMismatch', // v0.5 (M2 §4.3): честно вместо «rotated»
        revoked: 'reasonRevoked',
        expired: 'reasonExpired',
        'wrong-password': 'reasonWrongPassword',
        'kill-switch': 'reasonKillSwitch',
        ttl: 'reasonTtl',
        'channel-error': 'reasonChannelError',
        'no-password': 'reasonNoPassword',
};

function displayUrl(cfg: { baseUrl: string; owner: string; repo: string } | null): string {
        if (!cfg) return '';
        if (cfg.baseUrl === 'https://api.github.com') return `https://github.com/${cfg.owner}/${cfg.repo}`;
        const host = cfg.baseUrl.replace(/^https?:\/\//, '').replace(/\/api\/v1$/, '');
        return `https://${host}/${cfg.owner}/${cfg.repo}`;
}

// Полные литеральные классы (для styles-coverage TC-42)
const CHIP_CLS: Record<AuthStateDetail['status'], string> = {
        ok: 'vam-chip vam-chip--ok',
        checking: 'vam-chip vam-chip--checking',
        blocked: 'vam-chip vam-chip--blocked',
        'unconfigured': 'vam-chip vam-chip--unset',
        'awaiting-approval': 'vam-chip vam-chip--checking',
        // v0.5 (M2 §4.3): грейс канала — отдельный честный чип (не «ok» и не «blocked»)
        'degraded-channel': 'vam-chip vam-chip--degraded',
};

function minutesBetween(from: number, to: number): number {
        return Math.max(0, Math.round((to - from) / 60_000));
}

export class ManagerSettingsTab extends PluginSettingTab {
        private plugin: ManagerPlugin;
        private ownerUnlocked = false;
        private channelUrlDraft = '';
        private channelTokenDraft = '';

        constructor(app: ConstructorParameters<typeof PluginSettingTab>[0], plugin: ManagerPlugin) {
                super(app, plugin);
                this.plugin = plugin;
        }

        display(): void {
                const { containerEl } = this;
                containerEl.empty();
                const role = this.plugin.settings?.role ?? 'unset';
                if (role === 'unset') {
                        this.renderUnset(containerEl);
                        return;
                }
                this.renderHeader(containerEl);
                if (role === 'user') this.renderUserBlocks(containerEl);
                else this.renderOwnerBlocks(containerEl);
        }

        // --- незарегистрированный ---

        private renderUnset(container: HTMLElement): void {
                container.createEl('h3', { text: t('tabTitle') });
                const s = new Setting(container);
                s.setName(t('onbTitle'));
                s.addButton((b) => {
                        b.setButtonText(t('onbUserRole'));
                        b.setCta();
                        b.onClick(() => this.plugin.openOnboarding());
                });
        }

        // --- шапка (обе роли) ---

        private renderHeader(container: HTMLElement): void {
                const state = this.plugin.authState;
                const header = container.createEl('div');
                const chip = header.createEl('span', { cls: CHIP_CLS[state.status] });
                chip.textContent = statusText(state);
                if (state.checkedAt !== null) {
                        chip.textContent += ` · ${t('lastChecked', minutesBetween(state.checkedAt, this.plugin.now()))}`;
                }
                if (state.status === 'blocked' && state.reason) {
                        header.createEl('div', { text: t(REASON_KEY[state.reason]), cls: 'vam-muted' });
                }
                if (state.staleAt !== null && (state.checkedAt === null || state.staleAt > state.checkedAt)) {
                        const base = state.checkedAt ?? state.staleAt;
                        header.createEl('div', { cls: 'vam-muted' }).textContent = `${t('staleNotice')} ${t('lastChecked', minutesBetween(base, this.plugin.now()))}`;
                }
        }

        // --- режим пользователя (§10.1) — v0.6.1 (директива владельца): без
        //     пояснительных подписей «что как запрещает» — только названия, значения
        //     и действия; подробности — в «О системе» и консоли разработчика ---
        private renderUserBlocks(container: HTMLElement): void {
                this.renderQuickConnectBlock(container);
                this.renderAccountBlock(container);
                this.renderChannelBlock(container);
                this.renderRequestBlock(container);
                this.renderDiagnosticsBlock(container);
                this.renderPluginPolicyBlock(container);
                this.renderHookPluginsBlock(container);
        }

        private renderChannelBlock(container: HTMLElement, opts?: { owner?: boolean }): void {
                container.createEl('h4', { text: t('channelTitle') });
                const s = this.plugin.settings;

                // Гайд хозяина: показываем компактные шаги, пока канал не настроен (аудит v0.3.1:
                // раньше владелец не видел в UI ни требований к токену, ни требования
                // инициализировать репозиторий — это ловило его только по 409/401 в логах).
                if (opts?.owner && !s.channel) this.renderOwnerGuideInline(container);

                const url = new Setting(container);
                url.setName(t('channelUrlLabel'));
                if (opts?.owner) url.setDesc(t('channelUrlHint'));
                url.addText((text) => {
                        text.setPlaceholder('https://github.com/corp/vault-access');
                        text.setValue(displayUrl(s.channel));
                        text.onChange(() => {
                                this.channelUrlDraft = text.getValue();
                        });
                });

                const token = new Setting(container);
                token.setName(t('tokenLabel'));
                if (opts?.owner) token.setDesc(t('tokenHint'));
                token.addText((text) => {
                        text.inputEl.type = 'password';
                        text.setValue(s.channel?.token ?? '');
                        text.onChange(() => {
                                this.channelTokenDraft = text.getValue();
                        });
                });

                const test = new Setting(container);
                test.addButton((b) => {
                        b.setButtonText(t('testChannelBtn'));
                        b.onClick(() => void this.testChannelFlow());
                });
                // v0.5 (M2 §4.5): «О системе» — честный текст границ (Р7/B-7) обязан быть
                // ДОСТИЖИМ: AboutModal v0.4 был мёртв (аудит) и тексты orphaned — TC-41.
                test.addButton((b) => {
                        b.setButtonText(t('aboutTitle'));
                        b.onClick(() => {
                                try { new AboutModal(this.app).open(); } catch { /* нет DOM в тестах */ }
                        });
                });
                if (opts?.owner) {
                        test.addButton((b) => {
                                b.setButtonText(t('ogGuideBtn'));
                                b.onClick(() => new OwnerGuideModal(this.app).open());
                        });
                }
        }

        // --- компактный гайд хозяина при первом настраивании канала ---

        private renderOwnerGuideInline(container: HTMLElement): void {
                container.createEl('h4', { text: t('ogTitle') });
                const intro = container.createEl('p', { cls: 'vam-muted' });
                intro.textContent = t('ogIntro');
                for (const key of ['ogStep1', 'ogStep2', 'ogStep3', 'ogStep4'] as const) {
                        const step = container.createEl('div', { cls: 'vam-pre vam-muted' });
                        step.textContent = t(key);
                }
        }

        // --- быстрое подключение одним кодом VAMI1 (v0.3) ---

        private renderQuickConnectBlock(container: HTMLElement): void {
                container.createEl('h4', { text: t('quickTitle') });
                let code = '';
                const s = new Setting(container);
                // v0.6.1: подпись-пояснение убрана (директива владельца) — осталась строка ввода и кнопка
                s.setName(t('quickTitle'));
                s.addText((text) => {
                        text.setPlaceholder('VAMI1.…');
                        text.onChange(() => {
                                code = text.getValue();
                        });
                });
                s.addButton((b) => {
                        b.setButtonText(t('quickApplyBtn'));
                        b.setCta();
                        b.onClick(() => void this.applyQuickConnectFlow(code));
                });
        }

        private async applyQuickConnectFlow(code: string): Promise<void> {
                const error = await this.plugin.applyInviteCode(code);
                try {
                        new Notice(error ?? t('quickApplied'));
                } catch {
                        // тестовое окружение
                }
                this.display();
        }

        // --- статус контроля плагинов (v0.3; v0.5.5 — без режимов, regulated-список) ---

        private renderPluginPolicyBlock(container: HTMLElement): void {
                const info = this.plugin.getPluginPolicyInfo();
                if (!info.policy) return; // нет plugins.json — блок не показывается
                container.createEl('h4', { text: t('ppTitle') });
                const wrap = container.createEl('div');
                if (info.status && !info.status.ok) {
                        wrap.createEl('span', { cls: 'vam-chip vam-chip--warn' }).textContent = t('ppNoticeViolations');
                        const list = wrap.createEl('div', { cls: 'vam-pre vam-muted' });
                        // v0.5.5: нарушение одно — «запрещённый включён» (regulated не нарушает никогда)
                        list.textContent = info.status.violations
                                .map((v) => `${v.id} — ${t('ppForbidden')}, ${t('ppPresent')}`)
                                .join('\n');
                } else {
                        wrap.createEl('span', { cls: 'vam-chip vam-chip--ok' }).textContent = t('ppStatusOk');
                }
                // v0.6.1: подпись-пояснение «что как запрещает» убрана (директива владельца);
                // статусные списки ниже остаются — это данные, а не пояснения
                // v0.5.5 (аудит §6.2: «у пользователя нет списка правил до факта блокировки»):
                // список записей — какие плагины под контролем, какие запрещены.
                if (info.policy.plugins.length > 0) {
                        const list = wrap.createEl('div', { cls: 'vam-pre vam-muted' });
                        list.textContent = info.policy.plugins
                                .map((e) => `  • ${e.id} — ${e.action === 'forbidden' ? t('ppForbidden') : t('ppRegulated')}`)
                                .join('\n');
                }

                // v0.5 (W-C): список запертых плагинов (для user-mode) — из lock-registry.
                // Пользователь видит, что скрыто и почему; асинхронно, рендер не ждёт.
                const lockedList = wrap.createEl('div', { cls: 'vam-pre vam-muted' });
                lockedList.textContent = t('lockedLoading');
                void (async () => {
                        try {
                                const locked = await this.plugin.listLockedPlugins();
                                if (locked.length === 0) {
                                        lockedList.textContent = t('lockedEmpty');
                                } else {
                                        lockedList.textContent = `${t('lockedLabel')}:\n${locked.map(e => `  • ${e.manifestId} (${e.folder}) — ${t('lockedHint')}`).join('\n')}`;
                                }
                        } catch {
                                lockedList.textContent = '';
                        }
                })();
        }

        // --- v0.5.5: hook-плагины, замеченные менеджером (обе роли) ---
        // v0.6.1 (директива владельца): пояснения (вводная + API-подсказка) —
        // только в режиме администратора; пользовательской стороне они не нужны
        private renderHookPluginsBlock(container: HTMLElement, opts?: { owner?: boolean }): void {
                container.createEl('h4', { text: t('hkTitle') });
                if (opts?.owner) {
                        const intro = container.createEl('p', { cls: 'vam-muted' });
                        intro.textContent = t('hkIntro');
                }

                const hooks = this.plugin.listHookPlugins();
                if (hooks.length === 0) {
                        container.createEl('p', { text: t('hkEmpty'), cls: 'vam-muted' });
                } else {
                        const list = container.createEl('div', { cls: 'vam-pre' });
                        list.textContent = hooks
                                .map((h) => `  • ${h.id} — ${h.active ? t('hkActiveChip') : t('hkSeenChip')} · ${t('hkLastSeen', Math.max(0, Math.round((this.plugin.now() - h.lastSeen) / 60_000)))}`)
                                .join('\n');
                }
                const api = opts?.owner
                        ? container.createEl('p', { cls: 'vam-muted vam-plugin-note' })
                        : null;
                if (api) api.textContent = t('hkApiHint');
        }

        private renderAccountBlock(container: HTMLElement): void {
                container.createEl('h4', { text: t('accountTitle') });
                const s = this.plugin.settings;

                const identifier = new Setting(container);
                identifier.setName(t('identifierLabel'));
                identifier.addText((text) => {
                        text.setPlaceholder(t('identifierPlaceholder'));
                        text.setValue(s.identifier ?? '');
                        text.onChange(() => void this.plugin.saveIdentifier(text.getValue()));
                });

                const pw = new Setting(container);
                pw.addButton((b) => {
                        b.setButtonText(t('enterPasswordBtn'));
                        b.setCta();
                        b.onClick(() => this.plugin.openPasswordModal('first'));
                });
                pw.addButton((b) => {
                        b.setButtonText(t('forgotPasswordBtn'));
                        b.onClick(() => void this.forgetPasswordFlow());
                });

                const remember = new Setting(container);
                // v0.6.1: длинная подпись про хранение/отзыв убрана (директива владельца)
                remember.setName(t('rememberLabel'));
                remember.addToggle((toggle) => {
                        toggle.setValue(s.remember);
                        toggle.onChange((v) => this.plugin.setRemember(v));
                });

                const userId = new Setting(container);
                userId.setName(t('userIdLabel')).setDesc(s.derivedUserId ?? '—');
        }

        private async forgetPasswordFlow(): Promise<void> {
                await this.plugin.forgetPassword();
                this.display();
        }

        private async testChannelFlow(): Promise<void> {
                const rawUrl = this.channelUrlDraft || displayUrl(this.plugin.settings.channel);
                const token = this.channelTokenDraft || this.plugin.settings.channel?.token || '';
                const error = await this.plugin.saveChannel(rawUrl, token);
                if (error) {
                        try {
                                new Notice(error);
                        } catch {
                                // тестовое окружение
                        }
                        this.display();
                        return;
                }
                const res = await this.plugin.testChannel();
                try {
                        new Notice(res.message);
                } catch {
                        // тестовое окружение
                }
                this.display();
        }

        private renderRequestBlock(container: HTMLElement): void {
                const state = this.plugin.authState;
                const show = state.status === 'awaiting-approval' || (state.status === 'blocked' && state.reason === 'revoked');
                if (!show) return;
                container.createEl('h4', { text: t('requestTitle') });
                const s = new Setting(container);
                if (state.status === 'awaiting-approval') {
                        const since = state.awaitingSince ? ` · ${new Date(state.awaitingSince).toLocaleTimeString()}` : '';
                        s.setName(t('requestPending') + since);
                } else {
                        s.setName(t('requestRejected'));
                }
                s.addButton((b) => {
                        b.setButtonText(t('requestResendBtn'));
                        b.onClick(() => void this.plugin.resendRequest());
                });
                // v0.3.3: последняя отправка могла молча провалиться (сеть/токен без записи) —
                // показываем причину прямо в блоке, чтобы «ожидает подтверждения» не вводило в заблуждение
                const lastErr = this.plugin.getLastRequestError();
                if (lastErr) {
                        const line = container.createEl('div', { cls: 'vam-chip vam-chip--warn' });
                        line.textContent = `${t('requestFailedDetail')}: ${lastErr}`;
                }
        }

        private renderDiagnosticsBlock(container: HTMLElement): void {
                container.createEl('h4', { text: t('diagTitle') });
                const state = this.plugin.authState;

                const checked = new Setting(container);
                checked.setName(t('diagCheckedAt')).setDesc(state.checkedAt !== null ? new Date(state.checkedAt).toLocaleString() : '—');

                const head = new Setting(container);
                const shortHead = state.channelHead ? state.channelHead.slice(0, 16) : '—';
                head.setName(t('diagChannelHead')).setDesc(shortHead);

                const ttl = new Setting(container);
                ttl.setName(t('diagTtlLeft'));
                if (state.checkedAt !== null) {
                        const hoursLeft = Math.max(0, Math.ceil((this.plugin.getTtlHours() - (this.plugin.now() - state.checkedAt) / 3_600_000) * 10) / 10);
                        ttl.setDesc(t('hoursValue', hoursLeft));
                } else {
                        ttl.setDesc('—');
                }

                // чипы деградации §3.6 + §6.4
                this.renderSyncChips(container);

                const pullNow = new Setting(container);
                pullNow.addButton((b) => {
                        b.setButtonText(t('diagPullNowBtn'));
                        b.onClick(() => void this.pullNowFlow());
                });

                // v0.5.3 (репорт №3): полный отчёт диагностики — рядом с «Проверить сейчас».
                // Поле: «доступ разрешён, но включение блокируется» без улик — теперь
                // одна кнопка собирает ВСЕ входы решений + живой probe канала.
                // v0.6.1: подпись-пояснение убрана (директива владельца); журнал — в
                // консоли разработчика (команда палитры + зеркало каждой записи).
                const fullReport = new Setting(container);
                fullReport.addButton((b) => {
                        b.setButtonText(t('diagRunBtn'));
                        b.setCta();
                        b.onClick(() => void this.plugin.runDiagnostics().catch(() => undefined));
                });
        }

        private renderSyncChips(container: HTMLElement): void {
                const info = this.plugin.getSyncPluginInfo();
                const wrap = container.createEl('div');
                if (!info.present) {
                        wrap.createEl('span', { cls: 'vam-chip vam-chip--warn' }).textContent = t('syncPluginMissing');
                        return;
                }
                if (!info.perSession) {
                        wrap.createEl('span', { cls: 'vam-chip vam-chip--warn' }).textContent = t('syncPluginOld');
                } else {
                        wrap.createEl('span', { cls: 'vam-chip vam-chip--ok' }).textContent = t('syncPluginOk');
                }
                const minVersion = this.plugin.getMinManagerVersion();
                if (minVersion && semverCompare(minVersion, this.plugin.manifest.version) > 0) {
                        wrap.createEl('span', { cls: 'vam-chip vam-chip--warn' }).textContent = `${t('minVersionWarn')} (≥ ${minVersion})`;
                }
        }

        private async pullNowFlow(): Promise<void> {
                await this.plugin.runPullCycle({ context: 'background', trigger: 'manual' });
                this.display();
        }

        // --- режим хозяина (§10.1) ---

        private renderOwnerBlocks(container: HTMLElement): void {
                const s = this.plugin.settings;
                if (!s.ownerPassword) {
                        this.renderOwnerSetup(container);
                        return;
                }
                if (!this.ownerUnlocked) {
                        this.renderOwnerGate(container);
                        return;
                }
                this.renderChannelBlock(container, { owner: true });
                this.renderChannelMetaBlock(container);
                this.renderAccessBlock(container);
                this.renderHookPluginsBlock(container, { owner: true });
        }

        private renderOwnerSetup(container: HTMLElement): void {
                container.createEl('h4', { text: t('ownerGateTitle') });
                container.createEl('p', { text: t('ownerGateSetup'), cls: 'vam-muted' });
                let pw1 = '';
                let pw2 = '';
                const first = new Setting(container);
                first.setName(t('passwordLabel'));
                first.addText((text) => {
                        text.inputEl.type = 'password';
                        text.onChange(() => {
                                pw1 = text.getValue();
                        });
                });
                const second = new Setting(container);
                second.setName(t('repeatLabel'));
                second.addText((text) => {
                        text.inputEl.type = 'password';
                        text.onChange(() => {
                                pw2 = text.getValue();
                        });
                });
                const submit = new Setting(container);
                submit.addButton((b) => {
                        b.setButtonText(t('submitBtn'));
                        b.setCta();
                        b.onClick(() => void (async () => {
                                if (!pw1 || pw1 !== pw2) {
                                        try {
                                                new Notice(t('ownerGateWrong'));
                                        } catch {
                                                // тестовое окружение
                                        }
                                        return;
                                }
                                this.plugin.settings.ownerPassword = await hashOwnerPassword(pw1);
                                await this.plugin.saveData(this.plugin.settings);
                                this.ownerUnlocked = true;
                                this.display();
                        })());
                });
        }

        private renderOwnerGate(container: HTMLElement): void {
                container.createEl('h4', { text: t('ownerGateTitle') });
                let pw = '';
                const input = new Setting(container);
                input.setName(t('passwordLabel'));
                input.addText((text) => {
                        text.inputEl.type = 'password';
                        text.onChange(() => {
                                pw = text.getValue();
                        });
                });
                const submit = new Setting(container);
                submit.addButton((b) => {
                        b.setButtonText(t('submitBtn'));
                        b.setCta();
                        b.onClick(() => void (async () => {
                                const stored = this.plugin.settings.ownerPassword;
                                if (stored && (await verifyOwnerPassword(pw, stored))) {
                                        this.ownerUnlocked = true;
                                        this.display();
                                } else {
                                        try {
                                                new Notice(t('ownerGateWrong'));
                                        } catch {
                                                // тестовое окружение
                                        }
                                }
                        })());
                });
        }

        private renderChannelMetaBlock(container: HTMLElement): void {
                const meta = new Setting(container);
                meta.setName(t('ownerChannelMetaBtn'));
                meta.addButton((b) => {
                        b.setButtonText(t('ownerChannelMetaBtn'));
                        b.onClick(() => new ChannelMetaModal(this.app, this.plugin).open());
                });

                // Код канала для заявок (v0.3): одна строка вместо «URL + токен»
                const invite = new Setting(container);
                invite.setName(t('qcChannelBtn')).setDesc(t('qcChannelDesc'));
                invite.addButton((b) => {
                        b.setButtonText(t('qcChannelBtn'));
                        b.onClick(() => {
                                const code = this.plugin.makeChannelInviteCode();
                                if (code === null) {
                                        try {
                                                new Notice(t('channelTestFail'));
                                        } catch {
                                                // тестовое окружение
                                        }
                                        return;
                                }
                                void copyCodeToClipboard(code);
                        });
                });

                // Контроль плагинов (v0.3): plugins.json канала.
                // v0.5.5: подпись — семантика «какие плагины под контролем» (не «требования»).
                const policy = new Setting(container);
                policy.setName(t('ppEditBtn')).setDesc(t('ppEditBtnDesc'));
                policy.addButton((b) => {
                        b.setButtonText(t('ppEditBtn'));
                        b.onClick(() => new PluginPolicyModal(this.app, this.plugin).open());
                });

                // v0.5.5: расширенный режим — показать действие «запрещён» в модалке.
                // По умолчанию выключен: запрет — редкое действие, UI не должен
                // предлагать его случайно (запрос владельца: «вариант слаб, но пусть будет»).
                const advanced = new Setting(container);
                advanced.setName(t('ppAdvancedName')).setDesc(t('ppAdvancedDesc'));
                advanced.addToggle((toggle) => {
                        toggle.setValue(this.plugin.settings.policyAdvanced);
                        toggle.onChange((v) => {
                                this.plugin.settings.policyAdvanced = v;
                                void this.plugin.saveData(this.plugin.settings).catch(() => undefined);
                        });
                });

                // Экспорт бэкапа users/ (FR-26)
                let folder = 'VaultAccessManagerBackup';
                const backup = new Setting(container);
                backup.setName(t('ownerBackupBtn'));
                backup.addText((text) => {
                        text.setValue(folder);
                        text.onChange(() => {
                                folder = text.getValue() || 'VaultAccessManagerBackup';
                        });
                });
                backup.addButton((b) => {
                        b.setButtonText(t('ownerBackupBtn'));
                        b.onClick(() => void (async () => {
                                try {
                                        const count = await this.plugin.backupUsers(folder);
                                        try {
                                                new Notice(t('backupResult', count));
                                        } catch {
                                                // тестовое окружение
                                        }
                                } catch (err) {
                                        console.warn('[VaultAccessManager] backup failed:', err instanceof Error ? err.message : String(err));
                                }
                        })());
                });
        }

        private renderAccessBlock(container: HTMLElement): void {
                container.createEl('h4', { text: t('accessTitle') });
                const s = this.plugin.settings;

                const defaultPw = new Setting(container);
                defaultPw.setName(t('ownerDefaultPwLabel'));
                defaultPw.addText((text) => {
                        text.inputEl.type = 'password';
                        text.setValue(s.defaultPassword ?? '');
                        const apply = (): void => {
                                s.defaultPassword = text.getValue() || null;
                                void this.plugin.saveData(s).catch(() => undefined);
                                // v0.3.6: авто-подтверждение оживает в той же сессии (таймер
                                // + дебаунс-скан), а не после перезапуска Obsidian
                                this.plugin.ensureAutoApprove();
                        };
                        text.onChange(apply);
                        // v0.3.6: onChange компонента привязан к DOM-событию 'change', которое
                        // НЕ срабатывает, если панель настроек закрыта без потери фокуса полем
                        // (жалоба: «дефолтный пароль не сохраняется»). Дубль на 'input'
                        // персистит каждое нажатие немедленно; двойной вызов (input+change)
                        // идемпотентен — безвреден.
                        text.inputEl.addEventListener('input', apply);
                });

                const auto = new Setting(container);
                auto.setName(t('ownerAutoApproveLabel')).setDesc(t('ownerAutoApproveDesc'));
                auto.addToggle((toggle) => {
                        toggle.setValue(s.autoApprove);
                        toggle.onChange((v) => {
                                s.autoApprove = v;
                                void this.plugin.saveData(s).catch(() => undefined);
                                this.plugin.ensureAutoApprove(); // v0.3.6: включил авто — скан заработал сразу
                        });
                });

                const users = new Setting(container);
                // v0.5.5: подпись — ЧТО даёт запись (аудит: пользователь не понимал,
                // что «одобрение» = право на плагины, а не список разрешённых им плагинов)
                users.setName(t('ownerUsersBtn')).setDesc(t('ownerUsersBtnDesc'));
                users.addButton((b) => {
                        b.setButtonText(t('ownerUsersBtn'));
                        b.setCta();
                        b.onClick(() => new UsersModal(this.app, this.plugin).open());
                });

                const requests = new Setting(container);
                requests.addButton((b) => {
                        b.setButtonText(t('ownerRequestsBtn'));
                        b.onClick(() => new RequestsModal(this.app, this.plugin).open());
                });

                // v0.5 (W-C/C-5): Recovery UI — «Разблокировать все» из lock-registry.
                // С подтверждением: манифесты возвращаются, включённые до блокировки
                // включаются; политика канала при следующей сверке вернёт свой запрет.
                const recovery = new Setting(container);
                recovery.setName(t('ownerRecoveryLabel'));
                recovery.setDesc(t('ownerRecoveryDesc'));
                recovery.addButton((b) => {
                        b.setButtonText(t('ownerRecoveryBtn'));
                        b.setWarning();
                        b.onClick(() => {
                                new ConfirmModal(this.app, t('ownerRecoveryBtn'), t('ownerRecoveryConfirm'), async () => {
                                        try {
                                                const count = await this.plugin.unlockAllPlugins('owner manual');
                                                try {
                                                        new Notice(count > 0 ? t('ownerRecoveryDone', count) : t('ownerRecoveryEmpty'));
                                                } catch {
                                                        // тестовое окружение
                                                }
                                                this.display();
                                        } catch (err) {
                                                console.warn('[VaultAccessManager] recovery failed:', err instanceof Error ? err.message : String(err));
                                                try {
                                                        new Notice(`${t('ownerOpFailed')}: ${err instanceof Error ? err.message : String(err)}`);
                                                } catch {
                                                        // тестовое окружение
                                                }
                                        }
                                }).open();
                        });
                });
        }
}

// --- статус-хелперы ---

function statusText(state: AuthStateDetail): string {
        if (state.status === 'ok') return t('statusOk');
        if (state.status === 'blocked') return t('statusBlocked');
        if (state.status === 'unconfigured') return t('statusUnset');
        if (state.status === 'degraded-channel') return t('statusDegraded'); // M2 §4.3: грейс канала
        return t('statusChecking');
}

async function copyCodeToClipboard(code: string): Promise<void> {
        // Код подключения в буфере — осознанное действие хозяина (код = секрет, §2).
        try {
                await navigator.clipboard.writeText(code);
                new Notice(t('copiedNotice'));
        } catch {
                // clipboard недоступен — код остаётся в поле
        }
}

// --- «О системе» (Р7/B-7: честные границы — что делает / чего НЕ делает) ---

// v0.5 (M2 §4.5): модалка возрождена ДОСТИЖИМОЙ — в v0.4 не импортировалась (мёртвый
// код аудита), а честные тексты about* (B-7) оставались orphaned. Кнопка — в блоке
// канальных настроек (доступна и хозяину, и пользователю).
export class AboutModal extends Modal {
        onOpen(): void {
                const { contentEl } = this;
                contentEl.empty();
                contentEl.createEl('h3', { text: t('aboutTitle') });
                contentEl.createEl('div', { cls: 'vam-pre' }).textContent = t('aboutBody');
                new Setting(contentEl).addButton((b) => {
                        b.setButtonText(t('closeBtn'));
                        b.onClick(() => this.close());
                });
        }
}

// --- channel.json (FR-24) ---

/** редактируемые поля channel.json (без служебного v) */
interface ChannelMetaForm {
        minManagerVersion: string;
        killSwitch: boolean;
        offlineTtlHours: number;
}

function toChannelMetaForm(m: { minManagerVersion: string; killSwitch: boolean; offlineTtlHours: number }): ChannelMetaForm {
        return { minManagerVersion: m.minManagerVersion, killSwitch: m.killSwitch, offlineTtlHours: m.offlineTtlHours };
}

export class ChannelMetaModal extends Modal {
        private plugin: ManagerPlugin;
        // B-4 (RC-3: «ошибка ≠ пусто»): пока channel.json грузится — экран «Checking…»,
        // НЕ пустой бланк; при сбое — явная ошибка БЕЗ формы и без Save. Раньше сбой
        // молча подставлял DEFAULT_CHANNEL_META — пользователь затирал реальный
        // channel.json дефолтами, не зная об этом (деструктивно).
        private data: Loadable<ChannelMetaForm> = loading();

        constructor(app: ConstructorParameters<typeof Modal>[0], plugin: ManagerPlugin) {
                super(app);
                this.plugin = plugin;
        }

        onOpen(): void {
                this.render(); // немедленный экран «Checking…», не пустое окно
                void this.load();
        }

        private async load(): Promise<void> {
                try {
                        const res = await this.plugin.makeClient().getChannelMeta();
                        if (res.status === 'ok') {
                                this.data = ready(toChannelMetaForm(res.meta));
                        } else {
                                // not-found (файла нет) / not-modified без etag: редактирование
                                // дефолтов — легитимный сценарий, это НЕ ошибка
                                this.data = ready(toChannelMetaForm(DEFAULT_CHANNEL_META));
                        }
                } catch (err) {
                        // сеть/авторизация: показываем ошибку, дефолты НЕ подставляем (RC-3)
                        this.data = failed(`${t('opFailed')}${err instanceof Error ? `: ${err.message}` : ''}`);
                }
                this.render();
        }

        private render(): void {
                const { contentEl } = this;
                contentEl.empty();
                contentEl.createEl('h3', { text: t('ownerChannelMetaBtn') });

                if (this.data.state === 'loading') {
                        // RC-3: загрузка ≠ пусто — только статус, без формы
                        contentEl.createEl('p', { text: t('statusChecking'), cls: 'vam-muted' });
                        return;
                }

                if (this.data.state === 'error') {
                        // RC-3: ошибка ≠ дефолты. Без формы и без Save — затирать реальный
                        // channel.json значениями, которые мы НЕ прочитали, нельзя.
                        contentEl.createEl('p', { cls: 'vam-confirm-danger' }).textContent = this.data.message;
                        return;
                }

                this.renderForm(this.data.value);
        }

        private renderForm(meta: ChannelMetaForm): void {
                // шапку (empty + заголовок) рисует render() — общий каркас всех состояний
                const { contentEl } = this;
                let minVersion = meta.minManagerVersion;
                let killSwitch = meta.killSwitch;
                let ttlHours = String(meta.offlineTtlHours);

                const minSetting = new Setting(contentEl);
                minSetting.setName(t('metaMinVersion'));
                minSetting.addText((text) => {
                        text.setValue(minVersion);
                        text.onChange(() => {
                                minVersion = text.getValue() || DEFAULT_CHANNEL_META.minManagerVersion;
                        });
                });

                const killSetting = new Setting(contentEl);
                killSetting.setName(t('metaKillSwitch'));
                killSetting.addToggle((toggle) => {
                        toggle.setValue(killSwitch);
                        toggle.onChange((v) => {
                                if (!v) {
                                        killSwitch = false;
                                        return;
                                }
                                // v0.4.2: severity 'danger' для kill switch — критичная операция
                                new ConfirmModal(this.app, t('metaKillSwitch'), t('metaKillConfirm'), () => {
                                        killSwitch = true;
                                        toggle.setValue(true);
                                }, () => {
                                        killSwitch = false;
                                        toggle.setValue(false);
                                }, 'danger').open();
                        });
                });

                const ttlSetting = new Setting(contentEl);
                ttlSetting.setName(t('metaTtlHours'));
                ttlSetting.addText((text) => {
                        text.setValue(ttlHours);
                        text.onChange(() => {
                                ttlHours = text.getValue();
                        });
                });

                const save = new Setting(contentEl);
                save.addButton((b) => {
                        b.setButtonText(t('submitBtn'));
                        b.setCta();
                        // B-4: Save возможен только в 'ready' (форма и так рендерится лишь из
                        // 'ready', но блокируем кнопку явно — «ошибка ≠ пусто», RC-3)
                        b.buttonEl.disabled = this.data.state !== 'ready';
                        b.onClick(() => { void this.submit(minVersion, killSwitch, ttlHours); });
                });
                save.addButton((b) => {
                        b.setButtonText(t('cancelBtn'));
                        b.onClick(() => this.close());
                });
        }

        /**
         * B-4: PUT channel.json с честным результатом. Провал больше НЕ глотается:
         * раньше модал закрывался как будто сохранено (ошибка терялась). Теперь —
         * Notice «Операция не выполнена» и модал остаётся открытым.
         */
        private async submit(minVersion: string, killSwitch: boolean, ttlHours: string): Promise<void> {
                const hours = Number.parseInt(ttlHours, 10);
                try {
                        await this.plugin.saveChannelMetaUpdate(
                                minVersion,
                                killSwitch,
                                Number.isFinite(hours) && hours > 0 ? hours : DEFAULT_CHANNEL_META.offlineTtlHours,
                        );
                        this.close();
                } catch (err) {
                        console.warn('[VaultAccessManager] channel.json save failed:', err instanceof Error ? err.message : String(err));
                        try {
                                new Notice(t('opFailed'));
                        } catch {
                                // тестовое окружение
                        }
                        // модал НЕ закрываем: пользователь видит, что сохранение не прошло
                }
        }
}

// --- «Инструкция по настройке канала» (аудит v0.3.1: расширенные инструкции хозяину) ---

export class OwnerGuideModal extends Modal {
        constructor(app: ConstructorParameters<typeof Modal>[0]) {
                super(app);
        }

        onOpen(): void {
                const { contentEl } = this;
                contentEl.empty();
                contentEl.createEl('h3', { text: t('ogTitle') });
                contentEl.createEl('p', { cls: 'vam-muted' }).textContent = t('ogIntro');
                for (const key of ['ogStep1', 'ogStep2', 'ogStep3', 'ogStep4'] as const) {
                        contentEl.createEl('div', { cls: 'vam-pre' }).textContent = t(key);
                }
                contentEl.createEl('h4', { text: t('ogTokenTitle') });
                contentEl.createEl('div', { cls: 'vam-pre' }).textContent = t('ogTokenBody');
                contentEl.createEl('h4', { text: t('ogFilesTitle') });
                contentEl.createEl('div', { cls: 'vam-pre' }).textContent = t('ogFilesBody');
                contentEl.createEl('h4', { text: t('ogTroubleTitle') });
                contentEl.createEl('div', { cls: 'vam-pre vam-muted' }).textContent = t('ogTroubleBody');
                new Setting(contentEl).addButton((b) => {
                        b.setButtonText(t('closeBtn'));
                        b.setCta();
                        b.onClick(() => this.close());
                });
        }
}
