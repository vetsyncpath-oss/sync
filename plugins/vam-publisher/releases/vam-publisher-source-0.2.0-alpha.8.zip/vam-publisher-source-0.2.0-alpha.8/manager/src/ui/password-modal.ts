// src/ui/password-modal.ts — модалка ввода пароля, один класс — 3 режима.
// v0.4.4: Мягкое поведение — modal можно закрыть без пароля, но с понятным Notice
//          «хранилище работает, плагины заблокированы, для доступа войдите через настройки».
//          Пользователь может продолжать пользоваться Obsidian без принуждения.

import { Modal, Notice, Setting } from 'obsidian';
import { t } from '../i18n';
import type ManagerPlugin from '../../legacy-manager';

export type PasswordModalMode = 'first' | 'rotation' | 'retry';

export class PasswordModal extends Modal {
        private mode: PasswordModalMode;
        private plugin: ManagerPlugin;
        private passwordInput: HTMLInputElement | null = null;
        private submitButton: HTMLButtonElement | null = null;
        private showPassword = false;
        private busy = false;

        constructor(app: ConstructorParameters<typeof Modal>[0], plugin: ManagerPlugin, mode: PasswordModalMode) {
                super(app);
                this.plugin = plugin;
                this.mode = mode;
        }

        onOpen(): void {
                this.render();
        }

        private render(): void {
                const { contentEl } = this;
                this.passwordInput = null;
                this.submitButton = null;
                contentEl.empty();
                contentEl.createEl('h3', { text: this.titleText() });
                contentEl.createEl('p', { text: this.descText(), cls: 'vam-muted' });

                // v0.4.4: мягкое информационное сообщение (не предупреждение-запрет)
                // Пользователь может закрыть modal — хранилище продолжит работать,
                // но заблокированные плагины останутся заблокированными.
                const info = contentEl.createEl('p', { cls: 'vam-muted' });
                info.textContent = t('pwCloseHint');

                // v0.6 (M4): подсказка о привязке пароля к устройству (desktop, first)
                if (this.mode === 'first' && this.plugin.getDeviceIdentitySync() !== null) {
                        const bind = contentEl.createEl('p', { cls: 'vam-muted' });
                        bind.textContent = t('pwDeviceBindHint');
                }

                const inputSetting = new Setting(contentEl);
                inputSetting.setName(t('passwordLabel'));
                inputSetting.addText((text) => {
                        text.inputEl.type = 'password';
                        text.inputEl.autocomplete = 'off';
                        text.setPlaceholder('••••••••••');
                        text.inputEl.addEventListener('keydown', (evt) => {
                                if ((evt as KeyboardEvent).key === 'Enter') void this.submit();
                        });
                        this.passwordInput = text.inputEl;
                });

                // v0.4.2: В3 — toggle «показать пароль» с двумя иконками eye/eye-off
                const showSetting = new Setting(contentEl);
                showSetting.setName(t('pwShowLabel'));
                showSetting.addExtraButton((btn) => {
                        btn.setIcon('eye');
                        btn.setTooltip(t('pwShow'));
                        btn.onClick(() => {
                                this.showPassword = !this.showPassword;
                                if (this.passwordInput) {
                                        this.passwordInput.type = this.showPassword ? 'text' : 'password';
                                }
                                btn.setIcon(this.showPassword ? 'eye-off' : 'eye');
                                btn.setTooltip(this.showPassword ? t('pwHide') : t('pwShow'));
                        });
                });

                const actionSetting = new Setting(contentEl);
                actionSetting.addButton((btn) => {
                        btn.setButtonText(this.buttonText());
                        btn.setCta();
                        btn.onClick(() => void this.submit());
                        this.submitButton = btn.buttonEl;
                });
                actionSetting.addButton((btn) => {
                        btn.setButtonText(t('cancelBtn'));
                        btn.onClick(() => this.close());
                });
        }

        private titleText(): string {
                if (this.mode === 'rotation') return t('pwRotationTitle');
                if (this.mode === 'retry') return t('pwRetryTitle');
                return t('pwFirstTitle');
        }

        private descText(): string {
                if (this.mode === 'rotation') return t('pwRotationDesc');
                if (this.mode === 'retry') return t('pwRetryDesc');
                return t('pwFirstDesc');
        }

        private buttonText(): string {
                if (this.mode === 'rotation') return t('pwRotationBtn');
                if (this.mode === 'retry') return t('pwRetryBtn');
                return t('submitBtn');
        }

        private async submit(): Promise<void> {
                if (this.busy) return;
                const password = this.passwordInput?.value ?? '';
                if (!password) {
                        try { new Notice(t('pwEmptyWarn')); } catch {}
                        return;
                }
                this.busy = true;
                this.setBusy(true);
                try {
                        await this.plugin.submitPassword(password);
                        this.handleResult();
                } catch (err) {
                        console.warn('[VAM] password submit failed:', err instanceof Error ? err.message : String(err));
                        try { new Notice(`${t('pwSubmitFailed')}: ${err instanceof Error ? err.message : String(err)}`); } catch {}
                } finally {
                        this.busy = false;
                        this.setBusy(false);
                }
        }

        private setBusy(busy: boolean): void {
                if (!this.submitButton) return;
                if (busy) {
                        this.submitButton.disabled = true;
                        this.submitButton.textContent = t('statusChecking');
                } else {
                        this.submitButton.disabled = false;
                        this.submitButton.textContent = this.buttonText();
                }
        }

        private handleResult(): void {
                const state = this.plugin.authState;
                if (state.status === 'ok') {
                        try { new Notice(t('noticeAccessConfirmed')); } catch {}
                        this.close();
                        return;
                }
                if (state.status === 'blocked' && state.reason === 'wrong-password') {
                        this.mode = 'retry';
                        this.render();
                        return;
                }
                if (state.status === 'awaiting-approval') {
                        // v0.6 (M4): различаем «первичная заявка» и «устройство не зачислено» —
                        // во втором случае говорим прямо (заявка уже отправлена автоматически)
                        try {
                                new Notice(this.plugin.isDeviceMismatchPending()
                                        ? t('pwResultDeviceMismatch')
                                        : t('pwResultAwaiting'));
                        } catch {}
                } else if (state.status === 'blocked' && state.reason === 'key-mismatch') {
                        // v0.5 (M2 §4.3): честный вердикт — запись не расшифровывается, причина
                        // известна хозяину; подсказка «попросите переиздать» вместо «rotated»-лжи
                        try { new Notice(t('pwResultKeyMismatch')); } catch {}
                } else if (state.status === 'blocked' && state.reason === 'revoked') {
                        try { new Notice(t('pwResultRevoked')); } catch {}
                } else if (state.status === 'blocked' && state.reason === 'kill-switch') {
                        try { new Notice(t('pwResultKillSwitch')); } catch {}
                } else if (state.status === 'blocked') {
                        try { new Notice(`${t('noticeBlocked')}: ${state.reason}`); } catch {}
                }
                this.close();
        }
}

