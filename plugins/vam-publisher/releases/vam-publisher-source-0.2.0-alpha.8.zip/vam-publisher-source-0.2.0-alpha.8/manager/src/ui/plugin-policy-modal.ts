// src/ui/plugin-policy-modal.ts — (owner) редактор plugins.json.
//
// v0.5.5 (по итогам аудита v0.5.4 UI-audit §6.1 — переработка концепции):
//   • Режимов Report/Enforce больше НЕТ: регулировка всегда жёсткая. Блок режима
//     из шапки удалён вместе с англоязычным toggle («Report»/«Enforce» — жалоба
//     №1 терминологического аудита).
//   • «Обязателен» (required, предупреждение о невключённости — путаница)
//     заменён СТАНДАРТНЫМ состоянием «под контролем» (regulated): плагин просто
//     работает, включён ли он — решение пользователя. Regulated-запись ничего
//     не принуждает и не ругает.
//   • «Запрещён» (forbidden) — редкое действие: жёсткая блокировка (выключить +
//     вычеркнуть из автозагрузки + замок). По умолчанию СКРЫТО: появляется
//     только при включённой настройке «Расширенный режим: запрет плагинов»
//     (settings-tab). Существующие forbidden-записи видны всегда — хозяин
//     должен видеть, что блокирует пользователей, и иметь кнопку «Снять запрет».
//   • Термин «Требование» (дублировал «Режим») → «Статус» записи.
//   • Список = «какие плагины под контролем» (информация), не «предписания».
//
// B-4 (RC-3: «ошибка ≠ пусто»): состояние данных — Loadable<PluginPolicy>.
// Пока plugins.json грузится — экран «Checking…»; при сбое — явная ошибка БЕЗ формы
// и без Save (редактировать нечего); форма рендерится только из 'ready'.

import { Modal, Notice, Setting } from 'obsidian';
import { t } from '../i18n';
import type ManagerPlugin from '../../legacy-manager';
import type { PluginPolicy, PluginPolicyAction, PluginPolicyEntry } from '../core/plugin-policy';
import { ConfirmModal } from './confirm-modal';
import { failed, loading, ready } from './loadable';
import type { Loadable } from './loadable';

export class PluginPolicyModal extends Modal {
        private plugin: ManagerPlugin;
        // B-4: loading/error ≠ пустая форма; Save — только из 'ready'
        private data: Loadable<PluginPolicy> = loading();

        constructor(app: ConstructorParameters<typeof Modal>[0], plugin: ManagerPlugin) {
                super(app);
                this.plugin = plugin;
        }

        onOpen(): void {
                this.render();
                void this.load();
        }

        private async load(): Promise<void> {
                try {
                        const policy = await this.plugin.loadPluginPolicy();
                        // null = сбой канала: показываем ошибку, пустую политику НЕ подставляем (RC-3)
                        this.data = policy === null ? failed(t('opFailed')) : ready(policy);
                } catch (err) {
                        this.data = failed(`${t('opFailed')}${err instanceof Error ? `: ${err.message}` : ''}`);
                }
                this.render();
        }

        /** форма рендерится только в 'ready' — существующие render-методы берут политику отсюда */
        private get policy(): PluginPolicy {
                if (this.data.state !== 'ready') throw new Error('plugin policy is not loaded');
                return this.data.value;
        }

        /** v0.5.5: расширенный режим разрешает СОЗДАНИЕ запретов; снятие — всегда. */
        private get advanced(): boolean {
                return this.plugin.settings.policyAdvanced === true;
        }

        private render(): void {
                const { contentEl } = this;
                contentEl.empty();
                contentEl.createEl('h3', { text: t('ppTitle') });

                // Описание что это за модалка (v0.5.5: новая семантика двух слоёв)
                const intro = contentEl.createEl('p', { cls: 'vam-muted' });
                intro.textContent = t('ppModalIntro');

                if (this.data.state === 'loading') {
                        // RC-3: загрузка ≠ пусто — никаких элементов формы, только статус
                        contentEl.createEl('p', { text: t('statusChecking'), cls: 'vam-muted' });
                        return;
                }

                if (this.data.state === 'error') {
                        // RC-3: ошибка загрузки ≠ пустая форма. Редактировать нечего, Save нет.
                        contentEl.createEl('p', { cls: 'vam-confirm-danger' }).textContent = this.data.message;
                        return;
                }

                // v0.5.5: подсказка, когда действие «запрещён» скрыто (расширенный режим выключен)
                if (!this.advanced) {
                        const hidden = contentEl.createEl('p', { cls: 'vam-muted' });
                        hidden.textContent = t('ppForbiddenHiddenHint');
                }

                // --- Список плагинов (какие под контролем) ---
                this.renderPluginsList(contentEl);

                // --- Форма добавления ---
                this.renderAddForm(contentEl);

                // --- Кнопки сохранить/отмена ---
                this.renderActionButtons(contentEl);
        }

        private renderPluginsList(container: HTMLElement): void {
                const header = container.createEl('div', { cls: 'vam-list-header' });
                header.createEl('h4', { text: t('ppPluginsListTitle') });
                const count = header.createEl('span', { cls: 'vam-muted' });
                count.textContent = t('ppPluginsCount', this.policy.plugins.length);

                if (this.policy.plugins.length === 0) {
                        container.createEl('p', { text: t('ppEmpty'), cls: 'vam-muted' });
                        return;
                }

                for (const entry of this.policy.plugins) {
                        this.renderPluginEntry(container, entry);
                }
        }

        private renderPluginEntry(container: HTMLElement, entry: PluginPolicyEntry): void {
                const card = container.createEl('div', { cls: 'vam-plugin-card' });

                // Левая колонка: id + badge + note
                const left = card.createEl('div', { cls: 'vam-plugin-card-left' });
                const idEl = left.createEl('div', { cls: 'vam-plugin-id' });
                idEl.textContent = entry.id;

                // v0.5.5: regulated = «под контролем» (нейтральный), forbidden = «запрещён» (красный)
                const badge = left.createEl('span', { cls: `vam-badge vam-badge--${entry.action}` });
                badge.textContent = entry.action === 'forbidden' ? t('ppForbidden') : t('ppRegulated');

                if (entry.note) {
                        const noteEl = left.createEl('div', { cls: 'vam-muted vam-plugin-note' });
                        noteEl.textContent = entry.note;
                }

                // Правая колонка: кнопки
                const right = card.createEl('div', { cls: 'vam-plugin-card-right' });

                // v0.5.5: смена статуса:
                //   • «Снять запрет» (forbidden → regulated) — видна ВСЕГДА: хозяин должен
                //     уметь разблокировать, даже если расширенный режим выключен;
                //   • «Запретить» (regulated → forbidden) — только в расширенном режиме.
                if (entry.action === 'forbidden') {
                        const unforbidBtn = right.createEl('button', { cls: 'vam-btn-secondary' });
                        unforbidBtn.textContent = t('ppUnforbidBtn');
                        unforbidBtn.addEventListener('click', () => {
                                entry.action = 'regulated';
                                this.render();
                        });
                } else if (this.advanced) {
                        const forbidBtn = right.createEl('button', { cls: 'vam-btn-danger' });
                        forbidBtn.textContent = t('ppForbidBtn');
                        forbidBtn.addEventListener('click', () => {
                                entry.action = 'forbidden';
                                this.render();
                        });
                }

                // Кнопка удаления записи из списка
                const removeBtn = right.createEl('button', { cls: 'vam-btn-danger' });
                removeBtn.textContent = t('ppRemoveBtn');
                removeBtn.addEventListener('click', () => {
                        this.policy.plugins = this.policy.plugins.filter((e) => e !== entry);
                        this.render();
                });
        }

        private renderAddForm(container: HTMLElement): void {
                container.createEl('h4', { text: t('ppAddNewTitle') });

                let newId = '';
                // v0.5.5: стандарт добавления — «под контролем»; «запрещён» — только
                // в расширенном режиме (редкое действие, скрыто по умолчанию).
                let newAction: PluginPolicyAction = 'regulated';
                let newNote = '';

                const addId = new Setting(container);
                addId.setName(t('ppIdLabel'));
                addId.setDesc(t('ppIdHint'));
                let idText: { getValue(): string; setValue(v: string): void } | null = null;
                addId.addText((text) => {
                        text.setPlaceholder('calendar');
                        idText = text;
                        text.onChange(() => {
                                newId = text.getValue();
                        });
                });

                // v0.5.5: быстрый выбор из установленных плагинов — не обязателен знать id
                // наизусть (жалоба аудита: «поймёт ли пользователь как действовать»).
                try {
                        const manifests = (this.app as unknown as {
                                plugins?: { manifests?: Record<string, unknown> };
                        }).plugins?.manifests;
                        const ids = Object.keys(manifests ?? {}).filter(id => id !== this.plugin.manifest.id).sort();
                        if (ids.length > 0) {
                                const pick = new Setting(container);
                                pick.setName(t('ppPickLabel'));
                                pick.setDesc(t('ppPickHint'));
                                pick.addDropdown((drop) => {
                                        drop.addOption('', t('ppPickPlaceholder'));
                                        for (const id of ids) drop.addOption(id, id);
                                        drop.onChange(() => {
                                                const v = drop.getValue();
                                                if (!v) return;
                                                newId = v;
                                                try { idText?.setValue(v); } catch { /* тестовое окружение */ }
                                        });
                                });
                        }
                } catch {
                        // нет доступа к списку установленных (тестовое окружение) — поле id остаётся
                }

                const addAction = new Setting(container);
                addAction.setName(t('ppActionLabel'));
                addAction.setDesc(t('ppRegulatedHint'));
                addAction.addDropdown((drop) => {
                        drop.addOption('regulated', t('ppRegulated'));
                        if (this.advanced) drop.addOption('forbidden', t('ppForbidden'));
                        drop.setValue(newAction);
                        drop.onChange((v) => {
                                newAction = v === 'forbidden' && this.advanced ? 'forbidden' : 'regulated';
                                // Обновить подсказку под dropdown
                                const hintEl = addAction.descEl;
                                if (hintEl) {
                                        hintEl.textContent = newAction === 'forbidden' ? t('ppForbiddenHint') : t('ppRegulatedHint');
                                }
                        });
                });

                const addNote = new Setting(container);
                addNote.setName(t('noteLabel'));
                addNote.setDesc(t('ppNoteHint'));
                addNote.addText((text) => {
                        text.onChange(() => {
                                newNote = text.getValue();
                        });
                });

                const addBtn = new Setting(container);
                addBtn.addButton((b) => {
                        b.setButtonText(t('ppAddBtn'));
                        b.setCta();
                        b.onClick(() => {
                                const id = newId.trim();
                                if (!id) {
                                        try { new Notice(t('ppIdRequired')); } catch {}
                                        return;
                                }
                                if (this.policy.plugins.some((e) => e.id === id)) {
                                        try { new Notice(t('ppIdDuplicate')); } catch {}
                                        return;
                                }
                                const entry: PluginPolicyEntry = { id, action: newAction, note: newNote.trim() };
                                this.policy.plugins.push(entry);
                                this.render();
                        });
                });
        }

        private renderActionButtons(container: HTMLElement): void {
                const save = new Setting(container);
                save.addButton((b) => {
                        b.setButtonText(t('submitBtn'));
                        b.setCta();
                        // B-4: Save возможен только в 'ready'. Форма и так рендерится лишь из
                        // 'ready', но блокируем кнопку явно — «ошибка ≠ пусто» (RC-3).
                        b.buttonEl.disabled = this.data.state !== 'ready';
                        b.onClick(() => void this.confirmAndSave());
                });
                save.addButton((b) => {
                        b.setButtonText(t('cancelBtn'));
                        b.onClick(() => this.close());
                });
        }

        // v0.5.5: подтверждение с честным описанием последствий (жёсткая регулировка)
        private async confirmAndSave(): Promise<void> {
                new ConfirmModal(this.app, t('ppSaveConfirmTitle'),
                        t('ppSaveConfirmMsg'),
                        () => void this.save(),
                        undefined,
                        'warning',
                ).open();
        }

        private async save(): Promise<void> {
                try {
                        await this.plugin.savePluginPolicy(this.policy);
                        try {
                                new Notice(t('ppSaved'));
                        } catch {
                                // тестовое окружение
                        }
                        this.close();
                } catch (err) {
                        console.warn('[VaultAccessManager] plugins.json save failed:', err instanceof Error ? err.message : String(err));
                        try {
                                new Notice(t('opFailed'));
                        } catch {
                                // тестовое окружение
                        }
                }
        }
}
