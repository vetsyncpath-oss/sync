// src/ui/loadable.ts — UI-состояние «данные, которые надо загрузить» (W-B/B-4).
//
// Правило RC-3: ошибка ≠ пусто; загрузка ≠ пусто. Состояния «loading» и «error»
// НЕ имеют права рендериться как пустые данные/дефолты: иначе пользователь видит
// пустую форму, жмёт Save и затирает реальную удалённую политику поверх сбоя сети
// (деструктивно). Кнопка Save возможна только в состоянии 'ready'.

export type Loadable<T> =
    | { state: 'loading' }
    | { state: 'ready'; value: T }
    | { state: 'error'; message: string };

export const loading = <T,>(): Loadable<T> => ({ state: 'loading' });
export const ready = <T,>(value: T): Loadable<T> => ({ state: 'ready', value });
export const failed = (message: string): Loadable<never> => ({ state: 'error', message });
