// src/ui/onboarding-modal.ts — первый запуск: выбор режима доступа.
// v0.4.6: разделён на отдельные модалки — после выбора открывается НОВАЯ модалка
//          с формой (а не stage transition в той же), чтобы было очевидно что нужен ввод.

import { Modal, Notice, Setting } from 'obsidian';
import { parseRepoUrl } from '../core/channel';
import { t } from '../i18n';
import type ManagerPlugin from '../../legacy-manager';

/**
 * OnboardingModal — выбор режима: «У меня есть токен» / «Подать заявку» / «Я администратор».
 * После клика по карточке — закрывается и открывает соответствующую модалку.
 */
export class OnboardingModal extends Modal {
        private plugin: ManagerPlugin;

        constructor(app: ConstructorParameters<typeof Modal>[0], plugin: ManagerPlugin) {
                super(app);
                this.plugin = plugin;
        }

        onOpen(): void {
                const { contentEl } = this;
                contentEl.empty();
                contentEl.createEl('h3', { text: t('onbTitle') });
                contentEl.createEl('p', { text: t('onbRoleIntro'), cls: 'vam-muted' });

                this.renderCard(t('onbQuickTitle'), t('onbQuickDesc'), () => {
                        this.close();
                        new QuickRegisterModal(this.app, this.plugin).open();
                });

                this.renderCard(t('onbRequestTitle'), t('onbRequestDesc'), () => {
                        this.close();
                        new ApplyRequestModal(this.app, this.plugin).open();
                });

                this.renderCard(t('onbOwnerRole'), t('onbOwnerRoleDesc'), () => {
                        this.close();
                        new OwnerWarnModal(this.app, this.plugin).open();
                });
        }

        private renderCard(title: string, desc: string, onClick: () => void): void {
                const card = this.contentEl.createEl('div', { cls: 'vam-card' });
                card.createEl('div', { text: title, cls: 'vam-card-title' });
                card.createEl('div', { text: desc, cls: 'vam-card-desc' });
                card.addEventListener('click', () => onClick());
        }
}

/**
 * QuickRegisterModal — ввод VAMI1 токена.
 * Отдельная модалка (v0.4.6) — пользователь видит, что открылось новое окно для ввода.
 */
export class QuickRegisterModal extends Modal {
        private plugin: ManagerPlugin;

        constructor(app: ConstructorParameters<typeof Modal>[0], plugin: ManagerPlugin) {
                super(app);
                this.plugin = plugin;
        }

        onOpen(): void {
                const { contentEl } = this;
                contentEl.empty();
                contentEl.createEl('h3', { text: t('onbQuickTitle') });
                contentEl.createEl('p', { text: t('onbQuickIntro'), cls: 'vam-muted' });

                // v0.6 (M4): предупреждение о привязке к устройству (desktop)
                const device = this.plugin.getDeviceIdentitySync();
                if (device !== null) {
                        const warn = contentEl.createEl('p', { cls: 'vam-muted' });
                        warn.textContent = t('onbDeviceBind', device.deviceName);
                }

                let token = '';
                const tokenSetting = new Setting(contentEl);
                tokenSetting.setName(t('onbTokenLabel'));
                tokenSetting.setDesc(t('onbTokenHint'));
                tokenSetting.addText((text) => {
                        text.setPlaceholder('VAMI1.…');
                        text.onChange(() => {
                                token = text.getValue();
                        });
                });

                const actions = new Setting(contentEl);
                actions.addButton((b) => {
                        b.setButtonText(t('onbQuickBtn'));
                        b.setCta();
                        b.onClick(() => void (async () => {
                                if (!token.trim()) {
                                        try { new Notice(t('onbTokenRequired')); } catch {}
                                        return;
                                }
                                this.plugin.applyRole('user');
                                const error = await this.plugin.applyInviteCode(token.trim());
                                if (error) {
                                        try { new Notice(error); } catch {}
                                        return;
                                }
                                try { new Notice(t('onbQuickDone')); } catch {}
                                this.close();
                        })());
                });
                actions.addButton((b) => {
                        b.setButtonText(t('onbBackBtn'));
                        b.onClick(() => {
                                this.close();
                                new OnboardingModal(this.app, this.plugin).open();
                        });
                });
        }
}

/**
 * ApplyRequestModal — подача заявки (канал + email + пароль).
 * v0.5 (B-3): канал хозяина — ПЕРВЫЙ шаг формы: без него заявка физически не
 * уходит (C-3 — раньше модала врала «Заявка отправлена» при вечном checking).
 * Кнопка отправки активна только при валидном канале (parseRepoUrl) и заполненных
 * полях; Notice о результате шлёт plugin.submitAccessRequest → pushRegistrationRequest
 * СТРОГО по факту PUT. Модала сама ничего не «обещает».
 */
export class ApplyRequestModal extends Modal {
        private plugin: ManagerPlugin;

        constructor(app: ConstructorParameters<typeof Modal>[0], plugin: ManagerPlugin) {
                super(app);
                this.plugin = plugin;
        }

        onOpen(): void {
                const { contentEl } = this;
                contentEl.empty();
                contentEl.createEl('h3', { text: t('onbRequestTitle') });
                contentEl.createEl('p', { text: t('onbRequestIntro'), cls: 'vam-muted' });

                // v0.6 (M4): предупреждение о привязке к устройству (desktop)
                const device = this.plugin.getDeviceIdentitySync();
                if (device !== null) {
                        const warn = contentEl.createEl('p', { cls: 'vam-muted' });
                        warn.textContent = t('onbDeviceBind', device.deviceName);
                }

                let channelUrl = '';
                let channelToken = '';
                let email = '';
                let password = '';

                // Шаг 1: канал хозяина — до формы идентификации
                const channelSetting = new Setting(contentEl);
                channelSetting.setName(t('onbChannelStepLabel'));
                channelSetting.setDesc(t('onbChannelStepHint'));
                channelSetting.addText((text) => {
                        text.setPlaceholder('https://host/owner/repo');
                        text.onChange(() => {
                                channelUrl = text.getValue();
                                this.updateSubmitState(submitButton, channelUrl, channelToken, email, password);
                        });
                });

                const channelTokenSetting = new Setting(contentEl);
                channelTokenSetting.setName(t('onbChannelTokenLabel'));
                channelTokenSetting.addText((text) => {
                        text.inputEl.type = 'password';
                        text.setPlaceholder('ghp_…');
                        text.onChange(() => {
                                channelToken = text.getValue();
                                this.updateSubmitState(submitButton, channelUrl, channelToken, email, password);
                        });
                });

                const emailSetting = new Setting(contentEl);
                emailSetting.setName(t('onbEmailLabel'));
                emailSetting.setDesc(t('onbEmailHint'));
                emailSetting.addText((text) => {
                        text.setPlaceholder('user@example.com');
                        text.onChange(() => {
                                email = text.getValue();
                                this.updateSubmitState(submitButton, channelUrl, channelToken, email, password);
                        });
                });

                const pwSetting = new Setting(contentEl);
                pwSetting.setName(t('onbPwLabel'));
                pwSetting.setDesc(t('onbPwHint'));
                pwSetting.addText((text) => {
                        text.inputEl.type = 'password';
                        text.setPlaceholder('••••••••••');
                        text.onChange(() => {
                                password = text.getValue();
                                this.updateSubmitState(submitButton, channelUrl, channelToken, email, password);
                        });
                });

                let submitButton: { buttonEl: { disabled: boolean } } | null = null;

                const actions = new Setting(contentEl);
                actions.addButton((b) => {
                        b.setButtonText(t('onbRequestBtn'));
                        b.setCta();
                        submitButton = b as unknown as { buttonEl: { disabled: boolean } };
                        b.buttonEl.disabled = true; // активна только при валидном вводе (B-3)
                        b.onClick(() => void (async () => {
                                // отправка и вердикт — в plugin.submitAccessRequest (факт PUT)
                                const error = await this.plugin.submitAccessRequest(channelUrl, channelToken, email, password);
                                if (error !== null) {
                                        try { new Notice(error); } catch {}
                                        return; // модалка открыта: пользователь чинит ввод
                                }
                                this.close(); // заявка ушла: Notice «отправлена» уже показан по факту
                        })());
                });
                actions.addButton((b) => {
                        b.setButtonText(t('onbBackBtn'));
                        b.onClick(() => {
                                this.close();
                                new OnboardingModal(this.app, this.plugin).open();
                        });
                });
        }

        /** Кнопка активна только при валидном канале и заполненных полях (B-3). */
        private updateSubmitState(
                button: { buttonEl: { disabled: boolean } } | null,
                channelUrl: string,
                channelToken: string,
                email: string,
                password: string,
        ): void {
                if (button === null) return;
                const channelOk = parseRepoUrl(channelUrl) !== null && channelToken.trim() !== '';
                const fieldsOk = email.trim() !== '' && password !== '';
                button.buttonEl.disabled = !(channelOk && fieldsOk);
        }
}

/**
 * OwnerWarnModal — предупреждение для хозяина.
 * Отдельная модалка (v0.4.6) — пользователь видит warning и требования.
 */
export class OwnerWarnModal extends Modal {
        private plugin: ManagerPlugin;

        constructor(app: ConstructorParameters<typeof Modal>[0], plugin: ManagerPlugin) {
                super(app);
                this.plugin = plugin;
        }

        onOpen(): void {
                const { contentEl } = this;
                contentEl.empty();
                contentEl.createEl('h3', { text: t('onbOwnerRole') });
                contentEl.createEl('p', { text: t('onbOwnerWarn'), cls: 'vam-confirm-danger' });
                contentEl.createEl('p', { text: t('onbOwnerRequirements'), cls: 'vam-muted' });

                const actions = new Setting(contentEl);
                actions.addButton((b) => {
                        b.setButtonText(t('onbOwnerConfirm'));
                        b.setWarning();
                        b.onClick(() => {
                                this.plugin.applyRole('owner');
                                this.close();
                        });
                });
                actions.addButton((b) => {
                        b.setButtonText(t('onbBackBtn'));
                        b.onClick(() => {
                                this.close();
                                new OnboardingModal(this.app, this.plugin).open();
                        });
                });
        }
}
