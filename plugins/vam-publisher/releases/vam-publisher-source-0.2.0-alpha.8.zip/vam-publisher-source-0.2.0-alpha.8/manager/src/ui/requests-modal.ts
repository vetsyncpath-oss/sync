// src/ui/requests-modal.ts — (owner) очередь заявок на регистрацию (§10.5, FR-22/23).
// v0.4.2: В1 — rmSentAt вместо diagCheckedAt; В2 — ConfirmModal для reject; В3 — кнопка «Обновить».

import { Modal, Notice, Setting } from 'obsidian';
import { t } from '../i18n';
import type ManagerPlugin from '../../legacy-manager';
import type { RequestSummary } from '../core/registration';
import { generatePassword, parseRequestJson, verifyProof } from '../core/registration';
import { ConfirmModal } from './confirm-modal';

export class RequestsModal extends Modal {
        private plugin: ManagerPlugin;
        private requests: RequestSummary[] = [];
        private loading = true;
        // v0.6 (M4): какие пользователи уже имеют запись на канале (отличаем
        // «новый пользователь» от «вход с нового устройства»), какие заявки
        // подтверждены дефолтным паролем (фоновая проверка после рендера)
        private existingUsers = new Set<string>();
        private proofVerified = new Map<string, boolean>();

        constructor(app: ConstructorParameters<typeof Modal>[0], plugin: ManagerPlugin) {
                super(app);
                this.plugin = plugin;
        }

        onOpen(): void {
                this.render();
                void this.load();
        }

        private async load(): Promise<void> {
                // при открытии очереди — авто-скан (FR-23: скан и по кнопке, и при открытии)
                try {
                        await this.plugin.scanRequestsOnce();
                } catch (err) {
                        console.warn('[VaultAccessManager] auto-scan failed:', err instanceof Error ? err.message : String(err));
                }
                try {
                        const client = this.plugin.makeClient();
                        this.requests = [];
                        for (const file of await client.listDir('requests')) {
                                if (!file.name.endsWith('.json')) continue;
                                const res = await client.getFile(`requests/${file.name}`);
                                if (res.status !== 'ok') continue;
                                const summary = parseRequestJson(file.name, new TextDecoder().decode(res.bytes));
                                if (summary) this.requests.push(summary);
                        }
                        this.requests.sort((a, b) => b.ts - a.ts);
                        // v0.6 (M4): записи на канале — тип заявки (новый пользователь vs НОВОЕ УСТРОЙСТВО)
                        this.existingUsers = new Set((await client.listDir('users'))
                                .filter((f) => f.name.endsWith('.enc'))
                                .map((f) => f.name.replace(/\.enc$/, '')));
                } catch (err) {
                        console.warn('[VaultAccessManager] requests list failed:', err instanceof Error ? err.message : String(err));
                }
                this.loading = false;
                this.render();
                // v0.6 (M4): фоновая проверка proof дефолтным паролем — пометка
                // «не подтверждён» для заявок с ротированным/чужим паролем
                void this.verifyProofs();
        }

        private async verifyProofs(): Promise<void> {
                const defaultPassword = this.plugin.settings.defaultPassword;
                if (defaultPassword === null) return;
                let changed = false;
                for (const req of [...this.requests]) {
                        if (this.proofVerified.has(req.fileName)) continue;
                        const ok = await verifyProof(req.proofB64, defaultPassword, req.userId) !== null;
                        this.proofVerified.set(req.fileName, ok);
                        changed = true;
                }
                if (changed) this.render();
        }

        /** v0.6 (M4): тип заявки для колонки «Тип» — по наличию устройства и записи. */
        private requestType(req: RequestSummary): 'new-user' | 'new-user-device' | 'new-device' {
                if (req.deviceId === undefined) return 'new-user';
                return this.existingUsers.has(req.userId) ? 'new-device' : 'new-user-device';
        }

        private render(): void {
                const { contentEl } = this;
                contentEl.empty();
                contentEl.createEl('h3', { text: t('rmTitle') });

                if (this.plugin.settings.autoApprove && this.plugin.settings.defaultPassword) {
                        contentEl.createEl('p', { text: t('rmAutoNote'), cls: 'vam-muted' });
                } else if (!this.plugin.settings.autoApprove) {
                        // v0.4.2: предупреждение что авто-approve выключен
                        contentEl.createEl('p', { text: t('rmAutoOffNote'), cls: 'vam-muted' });
                }

                if (this.loading) {
                        contentEl.createEl('p', { text: t('statusChecking'), cls: 'vam-muted' });
                        return;
                }
                if (this.requests.length === 0) {
                        contentEl.createEl('p', { text: t('rmEmpty'), cls: 'vam-muted' });
                } else {
                        const table = contentEl.createEl('table', { cls: 'vam-table' });
                        const head = table.createEl('tr');
                        // v0.4.2: В1 — rmSentAt вместо diagCheckedAt; v0.6 (M4): + колонка «Тип»
                        for (const title of [t('identifierLabel'), t('userIdLabel'), t('rmTypeCol'), t('rmSentAt'), '']) {
                                head.createEl('th', { text: title });
                        }
                        const now = this.plugin.now();
                        for (const req of this.requests) {
                                const tr = table.createEl('tr');
                                tr.createEl('td', { text: req.identifier });
                                tr.createEl('td', { text: req.userId });
                                const typeCell = tr.createEl('td');
                                const type = this.requestType(req);
                                if (type === 'new-device') {
                                        // ⚠ вход с НОВОГО устройства существующего пользователя —
                                        // ядро директивы: хозяин «видит» чужой девайс
                                        const badge = typeCell.createEl('span', { cls: 'vam-chip vam-chip--blocked' });
                                        badge.textContent = t('rmTypeNewDevice');
                                        if (req.deviceName) typeCell.createEl('span', { text: ` ${req.deviceName}` });
                                } else if (type === 'new-user-device') {
                                        const text = typeCell.createEl('span');
                                        text.textContent = req.deviceName
                                                ? `${t('rmTypeNewUserDevice')} (${req.deviceName})`
                                                : t('rmTypeNewUserDevice');
                                } else {
                                        typeCell.createEl('span', { text: t('rmTypeNewUser') });
                                }
                                // v0.6.2 (директива владельца): ПОВТОРНОЕ использование кода —
                                // устройство этого логина уже привязано, код применён снова.
                                // Заявка-уведомление пережила авто-скан: решение администратора
                                // обязательно. Подсказка — что «Отклонение» убирает уведомление,
                                // а не доступ (для отключения — сброс устройств / смена пароля).
                                if (req.reuse === true) {
                                        const reuseBadge = typeCell.createEl('span', { cls: 'vam-chip vam-chip--blocked' });
                                        reuseBadge.textContent = t('rmTypeReuse');
                                        reuseBadge.setAttribute('title', t('rmReuseHint'));
                                }
                                // v0.6 (M4): proof не подтверждается дефолтным паролем — пометка
                                const verified = this.proofVerified.get(req.fileName);
                                if (verified === false) {
                                        const stale = typeCell.createEl('span', { cls: 'vam-chip vam-chip--blocked' });
                                        stale.textContent = t('rmProofStale');
                                        stale.setAttribute('title', t('rmProofStaleHint'));
                                }
                                tr.createEl('td', { text: t('minutesAgo', Math.max(0, Math.round((now - req.ts) / 60_000))) });
                                const actions = tr.createEl('td');
                                const wrap = actions.createEl('div', { cls: 'vam-row-actions' });

                                if (type === 'new-device') {
                                        // одобрение УСТРОЙСТВА: переиздание записи с добавленным девайсом
                                        const approveDevice = wrap.createEl('button', { text: t('rmApproveDeviceBtn') });
                                        approveDevice.addEventListener('click', () => {
                                                new ApproveDeviceModal(this.app, this.plugin, req, () => void this.load()).open();
                                        });
                                } else {
                                        const approve = wrap.createEl('button', { text: t('rmApproveBtn') });
                                        approve.addEventListener('click', () => {
                                                const password = generatePassword();
                                                new ApproveRequestModal(this.app, this.plugin, req, password, () => void this.load()).open();
                                        });
                                }

                                // v0.4.2: В2 — ConfirmModal для reject; v0.6.2: reuse-заявка —
                                // это УВЕДОМЛЕНИЕ (устройство уже зачислено): «Отклонить» для неё
                                // = «принять к сведению» — и текст подтверждения другой, чтобы
                                // администратор не думал, что отклонение отключает устройство.
                                const isReuse = req.reuse === true;
                                const reject = wrap.createEl('button', { text: isReuse ? t('rmAckBtn') : t('rmRejectBtn') });
                                reject.addEventListener('click', () => {
                                        new ConfirmModal(this.app, isReuse ? t('rmAckBtn') : t('rmRejectBtn'),
                                                (isReuse ? t('rmAckConfirm') : t('rmRejectConfirm')) + ' ' + req.identifier + ' · ' + req.userId,
                                                () => void (async () => {
                                                        try {
                                                                await this.plugin.rejectRequest(req);
                                                                await this.load();
                                                        } catch (err) {
                                                                const msg = err instanceof Error ? err.message : String(err);
                                                                console.warn('[VaultAccessManager] reject failed:', msg);
                                                                try { new Notice(`${t('opFailed')}: ${msg}`); } catch {}
                                                        }
                                                })(),
                                                undefined,
                                                'danger',
                                        ).open();
                                });
                        }
                }

                // v0.4.2: В3 — кнопка «Обновить» рядом с «Закрыть»
                const footer = new Setting(contentEl);
                footer.addButton((b) => {
                        b.setButtonText(t('rmRefreshBtn'));
                        b.onClick(() => {
                                this.loading = true;
                                this.requests = [];
                                this.render();
                                void this.load();
                        });
                });
                footer.addButton((b) => {
                        b.setButtonText(t('closeBtn'));
                        b.setCta();
                        b.onClick(() => this.close());
                });
        }
}

// --- подтверждение зачисления УСТРОЙСТВА (v0.6, M4) ---

class ApproveDeviceModal extends Modal {
        private plugin: ManagerPlugin;
        private request: RequestSummary;
        private reload: () => void;
        private password = '';

        constructor(app: ConstructorParameters<typeof Modal>[0], plugin: ManagerPlugin, request: RequestSummary, reload: () => void) {
                super(app);
                this.plugin = plugin;
                this.request = request;
                this.reload = reload;
        }

        onOpen(): void {
                const { contentEl } = this;
                contentEl.empty();
                contentEl.createEl('h3', { text: t('rmApproveDeviceBtn') });
                contentEl.createEl('p', { text: `${this.request.identifier} · ${this.request.userId}`, cls: 'vam-muted' });
                const device = contentEl.createEl('p', { cls: 'vam-muted' });
                device.textContent = `${t('rmTypeNewDevice')}: ${this.request.deviceName ?? ''} (${this.request.deviceId ?? ''})`;

                contentEl.createEl('p', { text: t('rmDeviceIntro'), cls: 'vam-muted' });

                const pwSetting = new Setting(contentEl);
                pwSetting.setName(t('rmDevicePwLabel')).setDesc(t('rmDevicePwHint'));
                pwSetting.addText((text) => {
                        text.inputEl.type = 'password';
                        // дефолт: пароль канала — им и зашифрованы записи по умолчанию
                        text.setValue(this.plugin.settings.defaultPassword ?? '');
                        this.password = text.getValue();
                        text.onChange(() => {
                                this.password = text.getValue();
                        });
                });

                const actions = new Setting(contentEl);
                actions.addButton((b) => {
                        b.setButtonText(t('rmApproveDeviceBtn'));
                        b.setCta();
                        b.onClick(() => void this.submit());
                });
                actions.addButton((b) => {
                        b.setButtonText(t('cancelBtn'));
                        b.onClick(() => this.close());
                });
        }

        private async submit(): Promise<void> {
                if (!this.password) {
                        try { new Notice(t('umPwRequired')); } catch {}
                        return;
                }
                try {
                        await this.plugin.approveDeviceAccess(this.request, this.password);
                        try { new Notice(t('noticeDeviceApproved')); } catch {}
                        this.close();
                        this.reload();
                } catch (err) {
                        const msg = err instanceof Error ? err.message : String(err);
                        console.warn('[VaultAccessManager] approve device failed:', msg);
                        const isLimit = err instanceof Error && err.name === 'EnrollLimitError';
                        const isDecrypt = err instanceof Error && err.name === 'DecryptError';
                        try {
                                new Notice(isLimit
                                        ? t('deviceLimitErr')
                                        : isDecrypt
                                                ? `${t('opFailed')}: ${t('reasonWrongPassword').toLowerCase()}`
                                                : `${t('opFailed')}: ${msg}`);
                        } catch {}
                }
        }
}

// --- подтверждение принятия: показать индивидуальный пароль + копия ---

class ApproveRequestModal extends Modal {
        private plugin: ManagerPlugin;
        private request: RequestSummary;
        private password: string;
        private reload: () => void;
        // v0.4.2: BUG-01 fix — сохраняем ссылку на input
        private passwordInput: HTMLInputElement | null = null;

        constructor(app: ConstructorParameters<typeof Modal>[0], plugin: ManagerPlugin, request: RequestSummary, password: string, reload: () => void) {
                super(app);
                this.plugin = plugin;
                this.request = request;
                this.password = password;
                this.reload = reload;
        }

        onOpen(): void {
                const { contentEl } = this;
                contentEl.empty();
                contentEl.createEl('h3', { text: t('rmApproveBtn') });
                contentEl.createEl('p', { text: `${this.request.identifier} · ${this.request.userId}`, cls: 'vam-muted' });

                // v0.4.2: В2 — preview что произойдёт
                contentEl.createEl('p', { text: t('rmApprovePreview'), cls: 'vam-muted' });

                const pwSetting = new Setting(contentEl);
                pwSetting.setName(t('passwordLabel'));
                pwSetting.addText((text) => {
                        text.setValue(this.password);
                        text.onChange(() => {
                                this.password = text.getValue();
                        });
                        this.passwordInput = text.inputEl;
                });
                pwSetting.addButton((b) => {
                        b.setButtonText(t('genPasswordBtn'));
                        b.onClick(() => {
                                this.password = generatePassword();
                                if (this.passwordInput) this.passwordInput.value = this.password;
                        });
                });
                pwSetting.addButton((b) => {
                        // v0.4.2: В1 — copyBtnLabel вместо copiedNotice
                        b.setButtonText(t('copyBtnLabel'));
                        b.onClick(() => void copyToClipboard(this.password));
                });

                const actions = new Setting(contentEl);
                actions.addButton((b) => {
                        b.setButtonText(t('submitBtn'));
                        b.setCta();
                        b.onClick(() => void this.submit());
                });
                actions.addButton((b) => {
                        b.setButtonText(t('cancelBtn'));
                        b.onClick(() => this.close());
                });
        }

        private async submit(): Promise<void> {
                if (!this.password) return;
                try {
                        await this.plugin.approveRequest(this.request, this.password);
                        try { new Notice(t('noticeRequestApproved')); } catch {}
                        this.close();
                        this.reload();
                } catch (err) {
                        const msg = err instanceof Error ? err.message : String(err);
                        console.warn('[VaultAccessManager] approve failed:', msg);
                        try { new Notice(`${t('opFailed')}: ${msg}`); } catch {}
                }
        }
}

async function copyToClipboard(text: string): Promise<void> {
        try {
                await navigator.clipboard.writeText(text);
                try { new Notice(t('copiedNotice')); } catch {}
        } catch {
                // clipboard недоступен
        }
}
