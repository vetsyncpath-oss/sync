// VAM SDK v5 — copy this standalone file into each protected plugin.
//
// const gate = vamGuard({
//   bundleId: 'your-bundle',      // required with protocol 6
//   tenantId: 'your-tenant',       // trusted product/organization configuration
//   pluginId: this.manifest.id,
//   capability: 'use',
//   onChange: (status) => applyAvailability(status === 'granted'),
// });
// Check gate.isGranted() before protected operations; dispose on plugin unload.
// onChange can fire synchronously during construction: use its arguments, not
// a field to which the returned guard has not yet been assigned.
//
// v5 requires tenant + product scope. Owner appointments do not grant product
// access. isOwner() checks the configured tenant and becomes false on unload.
// A scoped consumer never downgrades to a legacy global grant. Legacy unscoped
// consumers remain usable with legacy bridges, but are blocked by v5.
// The guard reattaches when the manager reloads. A missing/locked/unconfigured
// manager blocks protected operations. This is a cooperative client SDK.

export type VamGateStatus = 'granted' | 'blocked' | 'pending';

/** Машинные коды причин (локализуйте у себя): 'kill-switch' | 'revoked' |
 *  'expired' | 'ttl' | 'wrong-password' | 'key-mismatch' | 'no-password' |
 *  'unconfigured' | 'awaiting-approval' | 'channel-error' | 'vam-missing' |
 *  'vam-unloaded' | null. */
export type VamGateReason = string | null;

export interface VamGuardOptions {
        /** Required for protocol v5: fixed tenant scope from your product configuration. */
        tenantId?: string;
        bundleId?: string;
        capability?: string;
        /** v0.5.5: id вашего плагина (this.manifest.id) — гвард зарегистрируется
         *  в реестре менеджера: Администратор увидит в настройках, что плагин с hook
         *  замечен. Блокировка по-прежнему на стороне вашего гварда. */
        pluginId?: string;
        /** Сколько ждать менеджера, загрузившегося ПОЗЖЕ нас (boot-гонка).
         *  Default 15000 мс; 0 = не ждать вовсе (менеджера нет → сразу blocked). */
        timeoutMs?: number;
        /** Каденс опроса появления менеджера (default 1000 мс). */
        pollMs?: number;
        /** Вызывается при переходе в blocked (в т.ч. стартовом). */
        onBlocked?: (reason: VamGateReason) => void;
        /** Вызывается ТОЛЬКО при отзыве после granted (mid-session). */
        onRevoked?: (reason: VamGateReason) => void;
        /** v0.5.9: вызывается при КАЖДОМ изменении состояния в обе стороны
         *  (status или reason). Если менеджер уже стоит при создании гварда —
         *  первое событие приедет немедленно (adopt); стартовое 'pending'
         *  событием не считается. Удобная точка для пересчёта UI/доступности
         *  команд — симметрична для входа и отзыва. */
        onChange?: (status: VamGateStatus, reason: VamGateReason) => void;
        /** v3 (v0.5.8): политика менеджера запретила ЭТОТ плагин (при появлении
         *  моста, если уже запрещён, и при mid-session-запрещении). Плагин должен
         *  полностью отключить себя (disablePlugin). С мостом v5/v6 «запрещён» — явный отказ доступа (отозван,
         *  срок истёк, устройство отозвано); не вошёл, идёт проверка, нет сети или менеджер
         *  перезагружается запретом не считаются. Мосты протокола v2 события
         *  не дают — гвард просто молчит (деградация без ошибок). */
        onForbidden?: (info: VamPermissionInfo) => void;
        /** v3 (v0.5.8): вердикт политики для ЭТОГО плагина изменился
         *  (allowed/regulated/forbidden). Приготовьтесь пересобрать набор команд
         *  или погасить себя. */
        onPermissionChange?: (permission: VamPermissionAction, info: VamPermissionInfo) => void;
}

/** v3: разрешение конкретного плагина (permission-ось). */
export type VamPermissionAction = 'allowed' | 'regulated' | 'forbidden';

export interface VamPermissionInfo {
        /** Какой файл дал вердикт: 'channel' (политика канала) | 'builtin' |
         *  'none' (нет политики / мост v2). */
        source: string;
        /** Пометка Администратора из записи политики (если есть). */
        note: string | null;
}

/** v3: состояние авторизации (auth-ось), как его видит менеджер. */
export interface VamAuthInfo {
        role: 'administrator' | 'owner' | 'user' | 'unconfigured' | 'unknown';
        /** true ⇔ авторизация прошла (машина Администратора или вошедший пользователь). */
        authenticated: boolean;
        gate: VamGateStatus;
        reason: VamGateReason;
        managerVersion: string;
}

export interface VamGate {
        readonly status: VamGateStatus;
        readonly reason: VamGateReason;
        /** true ⇔ доступ подтверждён сейчас. */
        isGranted(): boolean;
        /** Confirmed administrator of options.tenantId; false if manager is unavailable. */
        isAdministrator(): boolean;
        /** @deprecated Compatibility alias for isAdministrator(). */
        isOwner(): boolean;
        /** Подписка на изменения статуса; отписка — возврат. */
        onChange(cb: (status: VamGateStatus, reason: VamGateReason) => void): () => void;
        /** v3: разрешение ЭТОГО плагина (permission-ось); null — мост протокола
         *  v2 (метода нет): опирайтесь на гейт, как раньше. */
        getPermission(): { permission: VamPermissionAction } & VamPermissionInfo | null;
        /** v3: состояние авторизации (auth-ось); null — мост v2. */
        getAuthState(): VamAuthInfo | null;
        /** Остановить опрос/отписаться (зовите из onunload своего плагина). */
        dispose(): void;
}

interface VamPublicApi {
        version: string;
        getStatus(): VamGateStatus;
        getReason(): VamGateReason;
    subscribe(cb: (status: VamGateStatus, reason: VamGateReason) => void): () => void;
    /** v2 (v0.5.5): опционально у гвардов v1 — presence-регистрация. */
    register?(pluginId: string): void;
    /** v3 (v0.5.8): опционально — состояние авторизации и пер-плагинная политика. */
    getAuthState?(): VamAuthInfo;
    getPermission?(pluginId: string): { permission: VamPermissionAction } & VamPermissionInfo;
    subscribeAuth?(cb: (auth: VamAuthInfo) => void): () => void;
    /** v4 (v0.5.10): опционально — «это хранилище администратора». */
    isOwner?(tenantId?: string): boolean;
    isAdministrator?(tenantId?: string): boolean;
    access?(query: { tenantId: string; productId?: string; bundleId?: string; capability: string }): { status: VamGateStatus; reason: string | null; validUntil: number | null };
}

interface VamGlobalHost {
        __VAM__?: VamPublicApi;
        __VAM_PENDING__?: Array<(status: VamGateStatus, reason: VamGateReason) => void>;
}

function host(): VamGlobalHost {
        return globalThis as unknown as VamGlobalHost;
}

const DEFAULT_TIMEOUT_MS = 15_000;
const DEFAULT_POLL_MS = 1_000;

/**
 * Создать гвард. Статус считается сразу (см. VamGateStatus); опрос появления
 * менеджера идёт до timeoutMs, после чего — fail-closed blocked('vam-missing').
 */
export function vamGuard(options: VamGuardOptions = {}): VamGate {
        const timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
        const pollMs = options.pollMs ?? DEFAULT_POLL_MS;
        const onBlocked = options.onBlocked;
        const onRevoked = options.onRevoked;
        const onStateChange = options.onChange;

        const listeners = new Set<(status: VamGateStatus, reason: VamGateReason) => void>();
        let status: VamGateStatus = 'pending';
        let reason: VamGateReason = null;
        let unsub: (() => void) | null = null;
        let unsubAuth: (() => void) | null = null;
        // v4: живая ссылка на мост — isOwner() читает отдельную точку напрямую
        let currentApi: VamPublicApi | null = null;
        let timer: ReturnType<typeof setInterval> | null = null;
        let startedAt = Date.now();
        let disposed = false;
        // v3: последняя известная auth-ось и вердикт политики для НАШЕГО id
        let authInfo: VamAuthInfo | null = null;
        let permission: ({ permission: VamPermissionAction } & VamPermissionInfo) | null = null;
        let wasForbidden = false;
        let onForbidden = options.onForbidden;
        let onPermissionChange = options.onPermissionChange;

        const emit = (next: VamGateStatus, nextReason: VamGateReason): void => {
                if (disposed) return;
                const revoked = status === 'granted' && next !== 'granted';
                const becameBlocked = status !== 'blocked' && next === 'blocked';
                const changed = status !== next || reason !== nextReason;
                status = next;
                reason = nextReason;
                if (changed) {
                        try { onStateChange?.(status, reason); } catch { /* потребитель */ }
                }
                if (changed) for (const cb of [...listeners]) {
                        try {
                                cb(status, reason);
                        } catch {
                                // чужой слушатель не должен ронять гвард
                        }
                }
                if (becameBlocked) {
                        try { onBlocked?.(reason ?? null); } catch { /* потребитель */ }
                }
                if (revoked) {
                        try { onRevoked?.(reason ?? null); } catch { /* потребитель */ }
                }
        };

        const syncGate = (api: VamPublicApi): void => {
                if (options.bundleId && api.version !== '6') { emit('blocked', 'bundle-protocol-required'); return; }
                if (api.version === '5' || api.version === '6' || typeof api.access === 'function') {
                        if (!options.tenantId || (api.version === '6' ? !options.bundleId : !options.pluginId) || typeof api.access !== 'function') {
                                emit('blocked', 'scope-required'); return;
                        }
                        try {
                                const result = api.access({ tenantId: options.tenantId, ...(api.version === '6' ? { bundleId: options.bundleId } : { productId: options.pluginId }), capability: options.capability ?? 'use' });
                                if (!result || !['granted', 'blocked', 'pending'].includes(result.status)) throw new Error('Invalid access decision');
                                resyncPermission(api);
                                const globalAuth = api.getAuthState?.();
                                authInfo = { role: api.isAdministrator ? (api.isAdministrator(options.tenantId) ? 'administrator' : 'user') : (api.isOwner?.(options.tenantId) ? 'owner' : 'user'), authenticated: result.status === 'granted',
                                        gate: result.status, reason: result.reason, managerVersion: globalAuth?.managerVersion ?? 'unknown' };
                                emit(result.status, result.reason);
                        } catch { emit('blocked', 'access-error'); }
                        return;
                }
                // Scoped consumers require v5; do not downgrade to a global legacy grant.
                if (options.tenantId) { emit('blocked', 'scoped-access-unavailable'); return; }
                resyncPermission(api);
                if (permission?.permission === 'forbidden') emit('blocked', 'plugin-forbidden');
                else emit(api.getStatus(), api.getReason());
        };

        const adopt = (api: VamPublicApi): void => {
                if (api === currentApi) { syncGate(api); return; }
                try { unsub?.(); unsubAuth?.(); } catch { /* previous bridge */ }
                currentApi = api;
                // v0.5.5: заявляем о себе менеджеру (реестр замеченных hook-плагинов
                // в настройках). Опционально: старый мост (протокол v1) метода не
                // имеет — молча пропускаем; на блокировку это не влияет.
                if (options.pluginId) {
                        try { api.register?.(options.pluginId); } catch { /* регистрация не критична */ }
                }
                unsub = api.subscribe(() => syncGate(api));
                // v3: подписка на auth-ось + пер-плагинный вердикт (мост v2 метода
                // не имеет — деградируем молча: гейт работает как раньше).
                if (typeof api.subscribeAuth === 'function') {
                        unsubAuth = api.subscribeAuth((a) => syncAuth(api, a));
                }
                // subscribe сразу дёргает колбэк с текущим состоянием → emit уже
                // прошёл; но на случай молчаливой подписки — синхронизируем явно:
                syncGate(api);
                // v3: первичная сверка политики — если нас УЖЕ запретили, onForbidden
                // стреляет здесь (плагин ещё не успел ничего включить лишнего)
                resyncPermission(api);
        };

        /** v3: событие auth-оси — обновляем authInfo и сверяем политику
         *  (подпись изменилась → вердикт мог перевернуться). */
        const syncAuth = (api: VamPublicApi, a: VamAuthInfo): void => {
                if (disposed) return;
                authInfo = { ...a };
                resyncPermission(api);
                syncGate(api);
        };

        /** v3: перечитать вердикт для нашего pluginId; при изменении — события. */
        const resyncPermission = (api: VamPublicApi): void => {
                if (disposed) return;
                if (typeof api.getPermission !== 'function') return; // мост v2
                if (!options.pluginId && !options.bundleId) return;                         // id не заявлен
                let next: ({ permission: VamPermissionAction } & VamPermissionInfo) | null;
                try {
                        if (typeof api.access === 'function' && options.tenantId) {
                                const decision = api.access({ tenantId: options.tenantId, ...(api.version === '6' ? { bundleId: options.bundleId } : { productId: options.pluginId }), capability: options.capability ?? 'use' });
                                // The manager has no per-plugin policy in v5/v6: the verdict follows access. Only an explicit denial is 'forbidden';
								// not signed in, still checking, waiting for approval, offline or a manager that is reloading are 'regulated'.
								const denied = decision.status === 'blocked' && (decision.reason === 'access-revoked-or-expired' || decision.reason === 'device-revoked');
								next = { permission: decision.status === 'granted' ? 'allowed' : denied ? 'forbidden' : 'regulated', source: 'channel', note: decision.reason };
                        } else next = api.getPermission(options.pluginId ?? '') ?? null;
                } catch {
                        return; // сломанный мост: гейт-ось всё равно скажет своё
                }
                const changed =
                        (permission === null) !== (next === null) ||
                        (permission !== null && next !== null &&
                                (permission.permission !== next.permission || permission.source !== next.source || (typeof api.access !== 'function' && permission.note !== next.note)));
                permission = next;
                if (!changed || next === null) return;
                if (typeof api.access !== 'function' && typeof api.getAuthState === 'function') {
                        try { authInfo = api.getAuthState(); } catch { /* не критично */ }
                }
                try { onPermissionChange?.(next.permission, { source: next.source, note: next.note }); } catch { /* потребитель */ }
                if (next.permission === 'forbidden' && !wasForbidden) {
                        wasForbidden = true;
                        try { onForbidden?.({ source: next.source, note: next.note }); } catch { /* потребитель */ }
                } else if (next.permission !== 'forbidden') {
                        wasForbidden = false;
                }
        };

        const stopPoll = (): void => {
                if (timer !== null) {
                        clearInterval(timer);
                        timer = null;
                }
        };

        const checkForManager = (): void => {
                if (disposed) return;
                const api = host().__VAM__;
                if (api && typeof api.subscribe === 'function') {
                        adopt(api);
                        return;
                }
                if (currentApi !== null) {
                        try { unsub?.(); unsubAuth?.(); } catch { /* old bridge */ }
                        currentApi = null; authInfo = null; permission = null; emit('blocked', 'vam-missing');
                }
                // менеджера всё ещё нет; таймаут → fail-closed
                if (timeoutMs > 0 && Date.now() - startedAt >= timeoutMs) {
                        emit('blocked', 'vam-missing');
                }
        };

        const api = host().__VAM__;
        if (api && typeof api.subscribe === 'function') {
                adopt(api); // менеджер уже стоит (обычный порядок)
        } else {
                // boot-гонка: менеджер грузится позже — регистрируемся в очередь
                // (мост дренирует при установке) + дублируем опросом (надёжность)
                const h = host();
                if (typeof h.__VAM_PENDING__ === 'undefined' || !Array.isArray(h.__VAM_PENDING__)) {
                        h.__VAM_PENDING__ = [];
                }
                h.__VAM_PENDING__!.push((s, r) => {
                        if (!disposed) {
                                const fresh = host().__VAM__;
                                if (fresh && typeof fresh.subscribe === 'function') adopt(fresh);
                                else emit(s, r); // мост ещё не выставлен, но слово уже есть
                        }
                });
                if (pollMs > 0) {
                        timer = setInterval(() => checkForManager(), pollMs);
                } else if (timeoutMs === 0) {
                    emit('blocked', 'vam-missing');
                }
                if (timeoutMs === 0) emit('blocked', 'vam-missing');
        }

        if (pollMs > 0 && timer === null) timer = setInterval(() => checkForManager(), pollMs);

        const administratorStatus = (): boolean => {
                const api = currentApi;
                if (api !== null && typeof api.isAdministrator === 'function') {
                        try { return api.isAdministrator(options.tenantId) === true; } catch { return false; }
                }
                if (api !== null && typeof api.isOwner === 'function') {
                        try { return api.isOwner(options.tenantId) === true; } catch { return false; }
                }
                return !options.tenantId && !options.bundleId && authInfo !== null && ['administrator', 'owner'].includes(authInfo.role) && authInfo.authenticated;
        };
        return {
                get status(): VamGateStatus { return status; },
                get reason(): VamGateReason { return reason; },
                isGranted(): boolean { return status === 'granted' && permission?.permission !== 'forbidden'; },
                // v4: точка Администратора — живой запрос к мосту (если умеет), иначе
                // вывод из auth-оси; до слова менеджера — false (fail-closed)
                isAdministrator: administratorStatus,
                isOwner: administratorStatus,
                // v3: permission-ось (наш pluginId; кэш обновляют события моста)
                getPermission(): ({ permission: VamPermissionAction } & VamPermissionInfo) | null {
                        return permission === null ? null : { ...permission };
                },
                // v3: auth-ось (последнее слово менеджера; null — мост v2)
                getAuthState(): VamAuthInfo | null {
                        return authInfo === null ? null : { ...authInfo };
                },
                onChange(cb): () => void {
                        listeners.add(cb);
                        try {
                                cb(status, reason);
                        } catch {
                                // немедленный вызов с текущим состоянием
                        }
                        return () => {
                                listeners.delete(cb);
                        };
                },
                dispose(): void {
                        disposed = true;
                        stopPoll();
                        try { unsub?.(); } catch { /* мост уже ушёл */ }
                        try { unsubAuth?.(); } catch { /* см. выше */ }
                        unsub = null;
                        unsubAuth = null;
                        currentApi = null;
                        listeners.clear();
                },
        };
}
