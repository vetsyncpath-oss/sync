// VAM protocol v5: tenant/product/capability access decisions.
// Global status remains blocked in the v2 runtime: it cannot represent product rights.
// isOwner requires a tenant; disposal revokes both ownership and access exposure.
// Snapshots are copied before passing them to callers and listeners.
// Legacy API shapes are retained for migration, but cannot bypass scoped checks.

import type { AccessQuery, AccessDecision } from '../auth-v2/model';
export type VamGateStatus = 'granted' | 'blocked' | 'pending';

/** v3: состояние авторизации — «прошла или нет» с контекстом. */
export interface VamAuthState {
        /** Diagnostic role only. Product access requires access(query). */
        role: 'owner' | 'user' | 'unconfigured' | 'unknown';
        /** Global diagnostic status; the v2 runtime uses scoped access decisions. */
        authenticated: boolean;
        /** То же, что getStatus() — для удобства одним объектом. */
        gate: VamGateStatus;
        reason: string | null;
        /** Версия менеджера (моста) — диагностика в чужом плагине. */
        managerVersion: string;
}

/** v3: вердикт политики для конкретного плагина. */
export type VamPermissionAction = 'allowed' | 'regulated' | 'forbidden';

export interface VamPermissionState {
        /** forbidden — плагин должен полностью отключить себя; regulated —
         *  «под контролем», работает (включённость — решение пользователя);
         *  allowed — записи нет, ограничений нет. */
        permission: VamPermissionAction;
        /** Какой файл дал вердикт: 'channel' | 'builtin' | 'none'. */
        source: 'channel' | 'builtin' | 'none';
        /** Пометка хозяина из записи политики (если есть). */
        note: string | null;
}

export interface VamGateSnapshot {
        status: VamGateStatus;
        reason: string | null;
        /** v3 (опционально для v2-поставщиков): нормализуется, если не дано. */
        auth?: VamAuthState;
        /** v3: подпись политики (меняется при любом изменении записей) —
         *  по ней subscribeAuth детектит смену политики без смены auth. */
        policySignature?: string;
}

export type VamSnapshot = VamGateSnapshot;

export interface VamPublicApi {
        version: string;
        getStatus(): VamGateStatus;
        getReason(): string | null;
        subscribe(cb: (status: VamGateStatus, reason: string | null) => void): () => void;
        /** v2 (v0.5.5): регистрация hook-плагина в реестре менеджера. */
        register(pluginId: string): void;
        /** v3 (v0.5.8): состояние авторизации (auth-ось). */
        getAuthState(): VamAuthState;
        /** v3 (v0.5.8): вердикт политики для плагина (permission-ось). */
        getPermission(pluginId: string): VamPermissionState;
        /** v3 (v0.5.8): событие при изменении auth ИЛИ политики (сразу с текущим). */
        subscribeAuth(cb: (auth: VamAuthState) => void): () => void;
        /** Owner appointment for a particular tenant; false without scope. */
        isOwner(tenantId?: string): boolean;
        access(query: AccessQuery): AccessDecision;
}

/** v5 adds scoped access and removes unscoped owner authority. */
export const VAM_API_VERSION = '5';

export const VAM_GLOBAL = '__VAM__';
export const VAM_PENDING = '__VAM_PENDING__';

type Listener = (status: VamGateStatus, reason: string | null) => void;
type AuthListener = (auth: VamAuthState) => void;

interface VamGlobalHost {
        [VAM_PENDING]?: Listener[];
}

function host(): VamGlobalHost {
        return globalThis as unknown as VamGlobalHost;
}

const MAX_PERMISSION_ID_LEN = 200;

/** Дефолтная auth-часть для v2-поставщика ({status, reason} без auth). */
function defaultAuth(snapshot: VamGateSnapshot): VamAuthState {
        return {
                role: 'unknown',
                authenticated: snapshot.status === 'granted',
                gate: snapshot.status,
                reason: snapshot.reason,
                managerVersion: 'unknown',
        };
}

/** Полный нормализованный снапшот (v2-вход → v3-форма). */
function normalizeSnapshot(raw: VamGateSnapshot): VamGateSnapshot & { auth: VamAuthState; policySignature: string } {
        return {
                status: raw.status,
                reason: raw.reason,
                auth: Object.freeze({ ...(raw.auth ?? defaultAuth(raw)) }),
                policySignature: typeof raw.policySignature === 'string' ? raw.policySignature : '',
        };
}

/**
 * Установить мост.
 *   snapshot — ЧИСТЫЙ поставщик текущего состояния (main.ts передаёт
 *     () => this.vamGateSnapshot()); вызывается на refresh() и подписках.
 *   onRegister — колбэк реестра hook-плагинов (v2).
 *   getPermission — v3-поставщик пер-плагинного вердикта (main.ts передаёт
 *     (id) => this.vamPermissionFor(id)); если не дан (v2-сценарий) —
 *     getPermission() отвечает allowed/'none'.
 * Возвращает { refresh, dispose }:
 *   refresh() — пересчитать; legacy-рассылка ТОЛЬКО при смене статуса/причины,
 *     v3-рассылка при смене ЛЮБОЙ части (auth, политика); идемпотентно;
 *   dispose() — надгробие blocked('vam-unloaded') + финальная рассылка обеих осей.
 */
export function installVamBridge(
        snapshot: () => VamGateSnapshot,
        onRegister?: (pluginId: string) => void,
        getPermission?: (pluginId: string) => VamPermissionState,
        getAccess?: (query: AccessQuery) => AccessDecision,
        getOwner?: (tenantId: string) => boolean,
): { refresh(): void; dispose(): void } {
        const listeners = new Set<Listener>();
        const authListeners = new Set<AuthListener>();
        let disposed = false;
        let current = normalizeSnapshot(evaluateRaw());

        function evaluateRaw(): VamGateSnapshot {
                if (disposed) {
                        return { status: 'blocked', reason: 'vam-unloaded' };
                }
                try {
                        return snapshot();
                } catch {
                        // поставщик сломался — честный fail-closed, не тишина
                        return { status: 'blocked', reason: 'vam-missing' };
                }
        }

        const broadcastLegacy = (): void => {
                for (const cb of [...listeners]) {
                        try {
                                cb(current.status, current.reason);
                        } catch {
                                // чужой код не должен ронять мост
                        }
                }
        };

        const broadcastAuth = (): void => {
                for (const cb of [...authListeners]) {
                        try {
                                cb({ ...current.auth });
                        } catch {
                                // см. broadcastLegacy
                        }
                }
        };

        const api: VamPublicApi = {
                version: VAM_API_VERSION,
                getStatus: () => current.status,
                getReason: () => current.reason,
                getAuthState: (): VamAuthState => ({ ...current.auth }),
                // v4: отдельная точка экспозиции хозяина. Единственный источник —
                // роль машины из auth-снапшота (менеджер кладёт её в vamGateSnapshot);
                // отдельного поставщика не нужно — нет дрейфа между осями.
                isOwner: (tenantId): boolean => {
                        if (disposed || !tenantId || !getOwner) return false;
                        try { return getOwner(tenantId) === true; } catch { return false; }
                },
                access: (query): AccessDecision => {
                        if (disposed || !getAccess) return { status: 'blocked', reason: disposed ? 'vam-unloaded' : 'scoped-access-unavailable', validUntil: null };
                        try { return { ...getAccess(query) }; } catch { return { status: 'blocked', reason: 'access-error', validUntil: null }; }
                },
                getPermission: (rawId: string): VamPermissionState => {
                        const id = typeof rawId === 'string' ? rawId.trim() : '';
                        if (id === '' || id.length > MAX_PERMISSION_ID_LEN) {
                                return { permission: 'allowed', source: 'none', note: null };
                        }
                        if (getPermission === undefined) {
                                // v2-сценарий (нет поставщика): гейт решает, политика не заявлена
                                return { permission: 'allowed', source: 'none', note: null };
                        }
                        try {
                                const verdict = getPermission(id);
                                if (typeof verdict === 'object' && verdict !== null && typeof verdict.permission === 'string') {
                                        return {
                                                permission: verdict.permission === 'forbidden' || verdict.permission === 'regulated' ? verdict.permission : 'allowed',
                                                source: verdict.source === 'channel' || verdict.source === 'builtin' ? verdict.source : 'none',
                                                note: typeof verdict.note === 'string' && verdict.note !== '' ? verdict.note : null,
                                        };
                                }
                                return { permission: 'allowed', source: 'none', note: null };
                        } catch {
                                // поставщик сломался — fail-closed: плагин кооперативно гаснет
                                return { permission: 'forbidden', source: 'none', note: null };
                        }
                },
                // v2 (v0.5.5): гвард заявляет о себе — менеджер ведёт реестр
                // замеченных hook-плагинов (observability, не enforcement)
                register: (pluginId: string): void => {
                        try {
                                onRegister?.(pluginId);
                        } catch {
                                // чужой код/сломанный реестр не роняет мост
                        }
                },
                subscribe: (cb) => {
                        listeners.add(cb);
                        // текущее состояние — немедленно (гвард мог опоздать к событию)
                        try {
                                cb(current.status, current.reason);
                        } catch {
                                // см. broadcastLegacy
                        }
                        return () => {
                                listeners.delete(cb);
                        };
                },
                subscribeAuth: (cb) => {
                        authListeners.add(cb);
                        try {
                                cb({ ...current.auth });
                        } catch {
                                // см. broadcastLegacy
                        }
                        return () => {
                                authListeners.delete(cb);
                        };
                },
        };

        const g = host() as Record<string, unknown>;
        g[VAM_GLOBAL] = api;

        // дренаж очереди опоздавших гвардов (загрузились ДО менеджера)
        const pending = (host() as Record<string, unknown>)[VAM_PENDING];
        if (Array.isArray(pending)) {
                const queue = pending as Listener[];
                (host() as Record<string, unknown>)[VAM_PENDING] = [];
                for (const cb of [...queue]) {
                        try {
                                cb(current.status, current.reason);
                        } catch {
                                // чужой код
                        }
                }
        }

        return {
                refresh(): void {
                        if (disposed) return;
                        const next = normalizeSnapshot(evaluateRaw());
                        const legacyChanged = next.status !== current.status || next.reason !== current.reason;
                        const authChanged =
                                legacyChanged ||
                                next.policySignature !== current.policySignature ||
                                JSON.stringify(next.auth) !== JSON.stringify(current.auth);
                        current = next;
                        if (legacyChanged) broadcastLegacy();   // v2: только auth-ось
                        if (authChanged) broadcastAuth();       // v3: auth + политика
                },
                dispose(): void {
                        if (disposed) return;
                        disposed = true;
                        // надгробие: менеджера больше нет — авторизации нет, гейт заперт
                        const tombstone = normalizeSnapshot({
                                status: 'blocked',
                                reason: 'vam-unloaded',
                                auth: { ...current.auth, authenticated: false, gate: 'blocked', reason: 'vam-unloaded' },
                        });
                        current = tombstone;
                        broadcastLegacy();
                        broadcastAuth();
                        // глобал НЕ удаляем: надгробие честнее «менеджера нет» (см. шапку)
                        g[VAM_GLOBAL] = api;
                },
        };
}
