import type { Token, TokenSource } from "./types";

/**
 * Таймерный движок RSVP.
 *
 * Единая точка истины воспроизведения: все переходы (play/pause/jump/setWpm)
 * проходят только через engine — UI является подписчиком (onToken/onWait/onEnd).
 *
 * ── Плановое расписание вместо относительного ──
 * nextAt хранит ПЛАНОВОЕ время показа следующего токена: nextAt += delay,
 * таймер ставится на max(0, nextAt − now). Время, потраченное на рендер
 * (callback onToken), не удлиняет экспозицию следующего слова — таймер
 * просто срабатывает раньше на потраченное время. На 600 wpm это спасает
 * от видимого глазом замедления. Если график безнадёжно устарел (лаг > 500 мс
 * — ожидание потока, пауза системы), nextAt перебазируется на «сейчас»
 * без погони пачкой токенов.
 *
 * ── Правила длительности ──
 *   delay = (60000 / wpm) × factor
 *           + (букв > longWordLetters ? longWordAddMs : 0)   [длинное слово]
 *           × paraFactor, если isParaEnd                      [конец абзаца]
 *   Пара (чанкинг >500 wpm): delay = base × max(factorᵢ, factorᵢ₊₁) × pairFactor.
 *   Затем ИЗБИРАТЕЛЬНЫЙ пол: если каждый слово-фрагмент показа не
 *   длиннее minMsMaxLetters букв — delay = max(delay, minWordMs).
 *   Пол ловит только «мельтешащие» короткие слова; общий темп
 *   (длинные слова, паузы факторов, конец абзаца) остаётся чистой
 *   функцией wpm и настройку дополняет, а не перекрывает. 0 — выкл.
 *
 * ── Завершение и неготовность ──
 * Конец потока определяется ТОЛЬКО по length >= 0 && index >= length.
 * Пока length === −1 и токен не готов — состояние waiting (опрос 30 мс),
 * затем продолжение строго с того же индекса.
 */

export interface EngineCallbacks {
  /** Показ токена: display — что рисовать (getChunk), token — данные (pivot/factor). */
  onToken: (index: number, display: string, token: Token) => void;
  /** Поток не готов (TokenStream доготавливает) — можно показать «подготовка…». */
  onWait?: () => void;
  /** Достигнут конец потока. */
  onEnd: () => void;
}

export interface EngineOptions {
  /** Стартовая скорость, слов/мин. Default 300. */
  startWpm?: number;
  /** Букв (буквы+цифры) больше порога → добавка longWordAddMs. Default 9. */
  longWordLetters?: number;
  /** Добавка для длинных слов, мс. Default 20. */
  longWordAddMs?: number;
  /** Множитель паузы конца абзаца. Default 2.2. */
  paraFactor?: number;
  /** Множитель длительности пары слов. Default 1.3. */
  pairFactor?: number;
  /** Порог wpm, выше которого имеет смысл чанкинг пар. Default 500. */
  chunkThresholdWpm?: number;
  /**
   * Минимальная экспозиция КОРОТКИХ слов, мс (0 — выключено). Default 0.
   * Пол применяется только к показам, где каждое слово не длиннее
   * minMsMaxLetters букв — общий темп не перекрывается.
   */
  minWordMs?: number;
  /** Порог «короткого» слова для minWordMs, букв (пунктуация не в счёт). Default 4. */
  minMsMaxLetters?: number;
}

export type EngineState = "idle" | "playing" | "paused" | "ended" | "waiting";

const MS_PER_MIN = 60000;
const WAIT_POLL_MS = 30;
const MIN_WPM = 60;
const MAX_WPM = 1500;
/** Лаг больше этого — перебазирование графика (без погони пачкой). */
const REBASE_LAG_MS = 500;

const LETTER_RE = /[a-zа-яё0-9]/gi;
/** Верхний санити-предел минимальной экспозиции (UI ограничивает жёстче). */
const MIN_WORD_MS_CAP = 2000;

function letterCount(s: string): number {
  const m = s.match(LETTER_RE);
  return m ? m.length : 0;
}

function clamp(v: number, lo: number, hi: number): number {
  return v < lo ? lo : v > hi ? hi : v;
}

export class RsvpEngine {
  private readonly tokens: TokenSource;
  private readonly cb: EngineCallbacks;
  private wpmVal: number;
  private readonly longWordLetters: number;
  private readonly longWordAddMs: number;
  private readonly paraFactor: number;
  private readonly pairFactor: number;
  private readonly chunkThresholdWpm: number;
  private minWordMsVal: number;
  private minMsMaxLettersVal: number;

  private idxVal = 0;
  private timer: ReturnType<typeof setTimeout> | null = null;
  /** Плановое (абсолютное) время показа следующего токена. */
  private nextAt = 0;
  private stateVal: EngineState = "idle";

  constructor(tokens: TokenSource, cb: EngineCallbacks, opts: EngineOptions = {}) {
    this.tokens = tokens;
    this.cb = cb;
    this.wpmVal = clamp(opts.startWpm ?? 300, MIN_WPM, MAX_WPM);
    this.longWordLetters = opts.longWordLetters ?? 9;
    this.longWordAddMs = opts.longWordAddMs ?? 20;
    this.paraFactor = opts.paraFactor ?? 2.2;
    this.pairFactor = opts.pairFactor ?? 1.3;
    this.chunkThresholdWpm = opts.chunkThresholdWpm ?? 500;
    this.minWordMsVal = clamp(opts.minWordMs ?? 0, 0, MIN_WORD_MS_CAP);
    this.minMsMaxLettersVal = Math.max(1, Math.round(opts.minMsMaxLetters ?? 4));
  }

  get wpm(): number {
    return this.wpmVal;
  }

  get minWordMs(): number {
    return this.minWordMsVal;
  }

  get minWordMaxLetters(): number {
    return this.minMsMaxLettersVal;
  }

  get index(): number {
    return this.idxVal;
  }

  get state(): EngineState {
    return this.stateVal;
  }

  /** Запуск. from — стартовый индекс; из состояния ended — рестарт. */
  play(from?: number): void {
    if (from !== undefined) {
      this.idxVal = Math.max(0, from);
    } else if (this.stateVal === "ended") {
      this.idxVal = 0;
    }
    this.clearTimer();
    this.stateVal = "playing";
    this.nextAt = performance.now();
    this.tick();
  }

  pause(): void {
    this.clearTimer();
    if (this.stateVal === "playing" || this.stateVal === "waiting") {
      this.stateVal = "paused";
    }
  }

  /**
   * Относительная перемотка. Считается от последнего ПОКАЗАННОГО слова
   * (idx−1), а не от указателя «следующий»: jump(-2) переносит ровно
   * на 2 видимых слова назад. В полёте — пауза, сдвиг, продолжение.
   */
  jump(delta: number): void {
    const wasActive = this.stateVal === "playing" || this.stateVal === "waiting";
    this.pause();
    const displayed = this.idxVal - 1; // −1, если ещё ничего не показано
    let target = displayed + delta;
    const len = this.tokens.length;
    if (len >= 0) {
      target = clamp(target, 0, Math.max(0, len - 1));
    } else {
      target = Math.max(0, target);
    }
    this.idxVal = target;
    if (wasActive) this.play();
  }

  /** Скорость на лету. Влияет только на следующий интервал. */
  setWpm(wpm: number): void {
    this.wpmVal = clamp(wpm, MIN_WPM, MAX_WPM);
  }

  /** Минимальная экспозиция на лету (пульт/настройки). 0 — выключить. */
  setMinWordMs(ms: number): void {
    this.minWordMsVal = clamp(ms, 0, MIN_WORD_MS_CAP);
  }

  /** Порог «короткого» слова на лету (вкладка настроек). */
  setMinWordMaxLetters(letters: number): void {
    this.minMsMaxLettersVal = Math.max(1, Math.round(letters));
  }

  destroy(): void {
    this.clearTimer();
    this.stateVal = "idle";
  }

  /* ── внутреннее ── */

  /** Каждое слово показа (вкл. куски пары) не длиннее порога букв. */
  private isShortDisplay(display: string): boolean {
    for (const part of display.split(" ")) {
      if (letterCount(part) > this.minMsMaxLettersVal) return false;
    }
    return true;
  }

  private clearTimer(): void {
    if (this.timer !== null) {
      clearTimeout(this.timer);
      this.timer = null;
    }
  }

  private schedule(delay: number, fn: () => void): void {
    const now = performance.now();
    if (now - this.nextAt > REBASE_LAG_MS) {
      // график безнадёжно устарел — перебазируем без погони
      this.nextAt = now;
    }
    this.nextAt += delay;
    this.timer = setTimeout(fn, Math.max(0, this.nextAt - performance.now()));
  }

  private readonly tick = (): void => {
    this.timer = null;
    if (this.stateVal !== "playing") return;

    const len = this.tokens.length;
    if (len >= 0 && this.idxVal >= len) {
      this.stateVal = "ended";
      this.cb.onEnd();
      return;
    }

    if (!this.tokens.isReady(this.idxVal)) {
      this.stateVal = "waiting";
      this.cb.onWait?.();
      this.timer = setTimeout(this.pollReady, WAIT_POLL_MS);
      return;
    }

    const token = this.tokens.get(this.idxVal);
    const chunked = this.tokens.getChunk(this.idxVal, this.wpmVal);
    const isPair =
      this.wpmVal > this.chunkThresholdWpm &&
      chunked !== token.text &&
      chunked.includes(" ") &&
      this.tokens.isReady(this.idxVal + 1);
    const display = isPair ? chunked : token.text;

    this.cb.onToken(this.idxVal, display, token);

    let delay: number;
    if (isPair) {
      const next = this.tokens.get(this.idxVal + 1);
      delay = (MS_PER_MIN / this.wpmVal) * Math.max(token.factor, next.factor) * this.pairFactor;
      if (next.isParaEnd) delay *= this.paraFactor;
      this.idxVal += 2;
    } else {
      delay = (MS_PER_MIN / this.wpmVal) * token.factor;
      if (letterCount(token.text) > this.longWordLetters) delay += this.longWordAddMs;
      if (token.isParaEnd) delay *= this.paraFactor;
      this.idxVal += 1;
    }

    // Избирательный пол минимальной экспозиции — только короткие
    // показы (каждое слово ≤ minMsMaxLetters букв, пары считаются
    // по каждому слову): общий темп и паузы факторов не трогаем.
    if (this.minWordMsVal > 0 && delay < this.minWordMsVal && this.isShortDisplay(display)) {
      delay = this.minWordMsVal;
    }

    const lenAfter = this.tokens.length;
    const finished = lenAfter >= 0 && this.idxVal >= lenAfter;
    this.schedule(delay, finished ? this.finish : this.tick);
  };

  private readonly finish = (): void => {
    this.timer = null;
    if (this.stateVal !== "playing") return;
    this.stateVal = "ended";
    this.cb.onEnd();
  };

  private readonly pollReady = (): void => {
    this.timer = null;
    if (this.stateVal !== "waiting") return;
    const len = this.tokens.length;
    if (len >= 0 && this.idxVal >= len) {
      this.stateVal = "ended";
      this.cb.onEnd();
      return;
    }
    if (this.tokens.isReady(this.idxVal)) {
      this.stateVal = "playing";
      this.nextAt = performance.now(); // после ожидания — без погони
      this.tick();
      return;
    }
    this.timer = setTimeout(this.pollReady, WAIT_POLL_MS);
  };
}
