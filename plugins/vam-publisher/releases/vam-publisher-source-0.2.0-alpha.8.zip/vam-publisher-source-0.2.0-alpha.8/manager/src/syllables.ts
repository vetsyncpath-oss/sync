/**
 * Слоговая разбивка длинных слов для мобильных экранов
 * (крупный шрифт, слово не влезает в строку).
 *
 * Куски — срезы ИСХОДНОЙ строки токена (пунктуация остаётся на месте,
 * join(pieces, "") === raw). Алгоритм (задача 1-b):
 *
 *  1. raw === "" → [raw]; maxLen ≤ 0 (и NaN) → трактуется как 1.
 *  2. Краевая пунктуация срезается в ядро [start, end).
 *     core.length ≤ maxLen → [raw].
 *  3. Внутренние символы-разрезы (дефис/слэш/пробел): граница ПОСЛЕ
 *     символа, символ остаётся в конце левого куска («кто-», «12 »).
 *     Если все куски умещаются по буквенно-цифровой части — готово.
 *  4. Слоговые границы ядра (закон открытого слога, упрощённо):
 *     для каждого межгласного кластера согласных граница стоит НА
 *     последней согласной кластера («кар|та», «во|да» — последняя
 *     согласная уходит следующему слогу); ь/ъ приклеиваются к
 *     предыдущему слогу, т.е. если кластер кончается на ь/ъ, граница
 *     переносится ЗА них («объ|ект»); пустой кластер делит гласные
 *     («аи» → «а|и»); начальный кластер — первому слогу, хвост после
 *     последней гласной — последнему.
 *  5. Склейка: piecesNeeded = ceil(core.length/maxLen); идеальные
 *     точки k·coreLen/piecesNeeded снапятся к ближайшей слоговой
 *     границе (ничья → БОЛЬШАЯ); если кусок вышел > maxLen —
 *     piecesNeeded++ и повтор (сравнение расстояний точное: |b·n − k·L|).
 *  6. Нет гласных/нет границ (числа, длинный монослог) и добивка
 *     кусков, которые не удалось разрезать слоговыми границами:
 *     жёсткое разбиение на почти равные части.
 *
 * Пост-обработка: однобуквенные (и пустые) куски по возможности
 * склеиваются с соседями (предпочтение меньшему по нагрузке соседу,
 * ничья — левый), не нарушая лимит maxLen.
 *
 * «Нагрузка» куска = число букв/цифр в нём (краевая пунктуация и
 * символы-разрезы в лимит не входят; допуск инварианта: +2 краевой
 * пунктуации, +1 внутренний символ-разрез).
 */

import { isLetterCode, isVowelCode, isWordCode } from "./pivot";

/** Внутренние символы-разрезы: дефис, слэш, пробел. */
const CUT_CODES: ReadonlySet<number> = new Set<number>([0x2d, 0x2f, 0x20]);
/** ь и ъ (обе регистры) — приклеиваются к предыдущему слогу. */
const SOFT_CODES: ReadonlySet<number> = new Set<number>([0x044c, 0x044a, 0x042c, 0x042a]);

export function syllabify(raw: string, maxLen: number): string[] {
  const rawLen = raw.length;
  if (rawLen === 0) return [raw];
  if (!(maxLen >= 1)) maxLen = 1;

  // Шаг 2: ядро без краевой пунктуации.
  let start = 0;
  let end = rawLen;
  while (start < end && !isWordCode(raw.charCodeAt(start))) start++;
  while (end > start && !isWordCode(raw.charCodeAt(end - 1))) end--;
  const coreLen = end - start;
  if (coreLen <= maxLen) return [raw];

  // Шаг 3: разрез по внутренним символам-разрезам (границы в координатах ядра).
  const cutBounds: number[] = [];
  for (let i = start; i < end; i++) {
    if (CUT_CODES.has(raw.charCodeAt(i))) cutBounds.push(i - start + 1);
  }
  if (cutBounds.length > 0 && fitsByLoad(raw, start, cutBounds, maxLen)) {
    return sliceByCoreBounds(raw, start, cutBounds);
  }

  // Шаг 4: слоговые границы ядра.
  const syllBounds = syllableBounds(raw, start, end);
  const allBounds = unionSorted(cutBounds, syllBounds);

  // Шаг 5: склейка идеальных точек к границам.
  let chosen: number[];
  if (allBounds.length === 0) {
    chosen = []; // шаг 6 ниже разобьёт всё ядро целиком
  } else {
    let n = Math.ceil(coreLen / maxLen);
    if (n < 2) n = 2;
    chosen = snapBounds(allBounds, coreLen, n);
    for (let guard = 0; guard < coreLen + 4; guard++) {
      if (fitsByLoad(raw, start, chosen, maxLen)) break;
      if (chosen.length >= allBounds.length) break; // плотнее некуда
      const next = Math.max(chosen.length + 1, n + 1);
      if (next > coreLen) break;
      n = next;
      chosen = snapBounds(allBounds, coreLen, n);
    }
  }

  // Шаг 6 (добивка): куски без подходящих слоговых границ > maxLen
  // жёстко режутся на почти равные части. Границы переводим в raw.
  const rawBounds = hardFixBounds(raw, chosen.map((b) => start + b), maxLen);
  const merged = mergeTinyPieces(raw, rawBounds, maxLen);
  return sliceByRawBounds(raw, merged);
}

/* ─────────────────── Слоговые границы ─────────────────── */

/**
 * Границы слогов ядра [start, end) в координатах ядра.
 * См. правило 4 в шапке модуля. Границы строго возрастают.
 */
function syllableBounds(raw: string, start: number, end: number): number[] {
  const out: number[] = [];
  let prevVowel = -1; // индекс предыдущей гласной (в raw)
  let lastLetter = -1; // последняя буква между гласными (в raw)
  let lastLetterSoft = false;
  for (let i = start; i < end; i++) {
    const code = raw.charCodeAt(i);
    if (isVowelCode(code)) {
      if (prevVowel >= 0) {
        if (lastLetter < 0) {
          out.push(i - start); // пустой кластер: делим гласные
        } else {
          // последняя согласная начинает следующий слог,
          // но ь/ъ остаются в предыдущем (граница за ними)
          out.push((lastLetterSoft ? lastLetter + 1 : lastLetter) - start);
        }
      }
      prevVowel = i;
      lastLetter = -1;
      lastLetterSoft = false;
    } else if (isLetterCode(code)) {
      lastLetter = i;
      lastLetterSoft = SOFT_CODES.has(code);
    }
    // прочие символы (дефис и т.п.) кластер не продолжают —
    // их границы добавляет шаг 3
  }
  return out;
}

/**
 * Снап идеальных точек k·coreLen/n (k = 1..n-1) к ближайшей границе.
 * Точное сравнение: |i − kL/n| ⇔ |i·n − k·L| в целых числах.
 * Ничья → БОЛЬШАЯ граница (allBounds возрастает, поэтому «больше»
 * выигрывает при равенстве расстояний). Результат возрастает, без дублей.
 */
function snapBounds(allBounds: number[], coreLen: number, n: number): number[] {
  const chosen: number[] = [];
  for (let k = 1; k < n; k++) {
    const scaled = k * coreLen;
    let best = -1;
    let bestDist = Number.MAX_SAFE_INTEGER;
    for (const b of allBounds) {
      const dist = Math.abs(b * n - scaled);
      if (dist < bestDist || (dist === bestDist && b > best)) {
        bestDist = dist;
        best = b;
      }
    }
    if (best > 0 && (chosen.length === 0 || chosen[chosen.length - 1] !== best)) {
      chosen.push(best);
    }
  }
  return chosen;
}

/* ─────────────────── Нагрузка и срезы ─────────────────── */

/** Число букв/цифр в raw[from, to). */
function countWordChars(raw: string, from: number, to: number): number {
  let count = 0;
  for (let i = from; i < to; i++) {
    if (isWordCode(raw.charCodeAt(i))) count++;
  }
  return count;
}

/** Все ли куски (по границам ядра) укладываются в maxLen по нагрузке. */
function fitsByLoad(raw: string, start: number, coreBounds: number[], maxLen: number): boolean {
  let prev = 0;
  for (let k = 0; k <= coreBounds.length; k++) {
    const stop = k < coreBounds.length ? start + coreBounds[k] : raw.length;
    if (countWordChars(raw, prev, stop) > maxLen) return false;
    prev = stop;
  }
  return true;
}

function sliceByCoreBounds(raw: string, start: number, coreBounds: number[]): string[] {
  return sliceByRawBounds(raw, coreBounds.map((b) => start + b));
}

function sliceByRawBounds(raw: string, rawBounds: number[]): string[] {
  const out: string[] = [];
  let prev = 0;
  for (const b of rawBounds) {
    out.push(raw.slice(prev, b));
    prev = b;
  }
  out.push(raw.slice(prev));
  return out;
}

function unionSorted(a: number[], b: number[]): number[] {
  const out: number[] = [];
  let i = 0;
  let j = 0;
  while (i < a.length || j < b.length) {
    let v: number;
    if (j >= b.length || (i < a.length && a[i] <= b[j])) {
      v = a[i];
      i++;
    } else {
      v = b[j];
      j++;
    }
    if (out.length === 0 || out[out.length - 1] !== v) out.push(v);
  }
  return out;
}

/* ─────────────────── Жёсткая добивка ─────────────────── */

/**
 * Куски, чья нагрузка > maxLen (слоговых границ внутри не хватило),
 * режутся жёстко на почти равные части; исходные границы сохраняются.
 * Возвращает НОВЫЙ список внутренних границ в raw-координатах.
 */
function hardFixBounds(raw: string, rawBounds: number[], maxLen: number): number[] {
  const out: number[] = [];
  let prev = 0;
  for (let k = 0; k <= rawBounds.length; k++) {
    const isLast = k === rawBounds.length;
    const stop = isLast ? raw.length : rawBounds[k];
    if (stop > prev && countWordChars(raw, prev, stop) > maxLen) {
      const sub = hardSplitRawBounds(raw, prev, stop, maxLen);
      for (const b of sub) out.push(b);
    }
    if (!isLast) out.push(stop);
    prev = stop;
  }
  return out;
}

/**
 * Почти равные куски диапазона [from, to): частей столько, чтобы
 * нагрузка каждого уместилась в maxLen (число частей — по нагрузке,
 * размеры — по символам; проверка с наращиванием частей на всякий
 * случай смешанного содержимого).
 */
function hardSplitRawBounds(raw: string, from: number, to: number, maxLen: number): number[] {
  const len = to - from;
  let parts = Math.ceil(countWordChars(raw, from, to) / maxLen);
  if (parts < 1) parts = 1;
  if (parts > len) parts = len;
  for (;;) {
    const bounds = evenBounds(from, to, parts);
    if (parts >= len) return bounds;
    let ok = true;
    let prev = from;
    for (const b of [...bounds, to]) {
      if (countWordChars(raw, prev, b) > maxLen) {
        ok = false;
        break;
      }
      prev = b;
    }
    if (ok) return bounds;
    parts++;
  }
}

/** Внутренние границы почти равного разбиения [from, to) на parts частей. */
function evenBounds(from: number, to: number, parts: number): number[] {
  const len = to - from;
  const base = Math.floor(len / parts);
  const extra = len - base * parts;
  const out: number[] = [];
  let pos = from;
  for (let i = 1; i < parts; i++) {
    pos += base + (i <= extra ? 1 : 0);
    out.push(pos);
  }
  return out;
}

/* ─────────────────── Склейка мелочи ─────────────────── */

/**
 * Однобуквенные и пустые куски устраняются по возможности:
 *  1) прямая склейка с соседом, если суммарная нагрузка ≤ maxLen
 *     (предпочтение соседу с меньшей нагрузкой, ничья — левый);
 *  2) иначе — склейка с соседом и переразбивка объединённого куска
 *     почти поровну; принимается, только если мелочь исчезла
 *     (все новые куски ≥ 2 букв) — иначе оставляем как есть:
 *     инвариант «нет 1-буквенных кусков» принципиально невыполним
 *     при малых maxLen (например, 5 букв при maxLen 2 → 2+2+1).
 */
function mergeTinyPieces(raw: string, rawBounds: number[], maxLen: number): number[] {
  const pts = [...rawBounds];
  let changed = true;
  while (changed && pts.length > 0) {
    changed = false;
    const edges = [0, ...pts, raw.length];
    for (let i = 0; i < edges.length - 1 && !changed; i++) {
      const s = edges[i];
      const e = edges[i + 1];
      const load = countWordChars(raw, s, e);
      if (load > 1) continue;
      const hasLeft = i > 0;
      const hasRight = i < edges.length - 2;
      if (!hasLeft && !hasRight) break; // кусок один — мелочь не убрать
      const loadLeft = hasLeft ? countWordChars(raw, edges[i - 1], edges[i]) : Number.POSITIVE_INFINITY;
      const loadRight = hasRight ? countWordChars(raw, edges[i + 1], edges[i + 2]) : Number.POSITIVE_INFINITY;
      const canLeft = hasLeft && loadLeft + load <= maxLen;
      const canRight = hasRight && loadRight + load <= maxLen;
      if (canLeft && (!canRight || loadLeft <= loadRight)) {
        pts.splice(i - 1, 1); // граница edges[i] между кусками i-1 и i
        changed = true;
        break;
      }
      if (canRight) {
        pts.splice(i, 1); // граница edges[i + 1] между кусками i и i+1
        changed = true;
        break;
      }
      // склейка с переразбивкой: сосед с меньшей нагрузкой (ничья — левый)
      const useLeft = hasLeft && (!hasRight || loadLeft <= loadRight);
      const from = useLeft ? edges[i - 1] : s;
      const to = useLeft ? e : edges[i + 2];
      const dropIdx = useLeft ? i - 1 : i; // граница между склеиваемыми кусками
      const sub = hardSplitRawBounds(raw, from, to, maxLen);
      if (resplitRemovesTiny(raw, from, to, sub)) {
        pts.splice(dropIdx, 1, ...sub);
        changed = true;
      }
    }
  }
  return pts;
}

/** Переразбивка имеет смысл, только если все куски ≥ 2 букв. */
function resplitRemovesTiny(raw: string, from: number, to: number, sub: number[]): boolean {
  let prev = from;
  for (const b of [...sub, to]) {
    if (countWordChars(raw, prev, b) < 2) return false;
    prev = b;
  }
  return true;
}
