import type { Filters } from "./types";

/**
 * Значения блочных фильтров по умолчанию (см. `Filters` в types.ts).
 */
export const DEFAULT_FILTERS: Filters = {
  code: "skip",
  table: "skip",
  math: "skip",
  comments: false,
  blockquote: true,
  tags: false,
  embeds: "skip",
};

/**
 * Стабильный хэш фильтров — часть ключа кэша индекса.
 *
 * Сериализация выполняется с ФИКСИРОВАННЫМ порядком ключей
 * (порядок полей входного объекта не влияет на результат),
 * затем FNV-1a 32 бита → hex-строка из 8 символов.
 * Одинаковое значение фильтров всегда даёт одинаковый хэш.
 */
export function hashFilters(f: Filters): string {
  const serialized =
    "v1|code=" + f.code +
    "|table=" + f.table +
    "|math=" + f.math +
    "|comments=" + f.comments +
    "|blockquote=" + f.blockquote +
    "|tags=" + f.tags +
    "|embeds=" + f.embeds;
  return fnv1a32(serialized);
}

/** FNV-1a, 32 бита. */
function fnv1a32(s: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(16).padStart(8, "0");
}
