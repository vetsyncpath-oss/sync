// Archived v1 implementation for migration reference. Not imported by the v2 entry point.
// main.ts — Plugin-класс Vault Access Manager: lifecycle, таймеры, wiring (§7.7).
// Порядок onload/onunload зафиксирован спекой. Probe отправляется только при изменении
// verdict-ключа (гашение дребезга, §7.5) + всегда при unload (fail-closed, FR-16).
// Пароль пользователя живёт только в памяти инстанса (FR-27/29).

import { Notice, Plugin } from 'obsidian';

import { installVaultSyncAuth } from './src/api/vault-sync-auth';
import type { AuthApiInternal, VaultSyncAuth } from './src/api/vault-sync-auth';
import { initialAuthState, reduce, toPublicStatus } from './src/core/auth-state';
import type { AuthBlockReason, AuthEvent, AuthStateDetail, Effect } from './src/core/auth-state';
import { ChannelAuthError, ChannelClient, classifyChannelFailure, parseRepoUrl } from './src/core/channel';
import type { ChannelCfg, ChannelDeps } from './src/core/channel';
import { decryptUserRecord, shortHashIdentifier } from './src/core/crypto';
import type { DeviceBinding, UserPayload } from './src/core/crypto';
import { computeDeviceId, ensureDeviceSecret, fingerprintString, hasDeviceRegistry, isDeviceAllowed } from './src/core/device';
import { DEFAULT_MAX_DEVICES } from './src/core/device';
import type { DeviceIdentity, DeviceSecretScope, DeviceSignals } from './src/core/device';
import { buildProbe, reasonText, unloadProbe } from './src/core/probe';
import type { ManagerProbe } from './src/core/probe';
import { approveDeviceEnrollment, autoApproveScan, buildAndPushRequest, exportUsersBackup, issueUserRecord, selfEnrollDeviceRecord } from './src/core/registration';
import type { RequestSummary } from './src/core/registration';
import { buildChannelInvite, buildUserInvite, decodeInvite, repoUrlFromCfg } from './src/core/invite';
import { EMPTY_PLUGIN_POLICY, evaluatePluginPolicy, mergeWithBuiltinManagedPolicy, getBuiltinManagedPolicy, getEntryAllIds } from './src/core/plugin-policy';
import type { PluginPolicy, PluginPolicyStatus } from './src/core/plugin-policy';
import { PluginLock, digestPolicy } from './src/core/plugin-lock';
import type { LockOutcome, LockRegistryEntry } from './src/core/plugin-lock';
import { buildSnapshot, computeVerdict } from './src/core/verdict-snapshot';
import type { VerdictSnapshot } from './src/core/verdict-snapshot';
import { sweepQuarantine, sweepNeutralizedManifests } from './src/core/quarantine-sweeper';
import { installVamBridge, type VamGateSnapshot, type VamPermissionState } from './src/sdk/vam-bridge';
import { HookRegistry } from './src/core/hook-registry';
import type { HookRegistrySnapshot } from './src/core/hook-registry';
import { probeChannelConnectivity, readJournalTail, renderDiagnosticsReport } from './src/core/diagnostics';
import type { ChannelProbeLine, DiagnosticsInput, InterceptorDecision } from './src/core/diagnostics';
import { DiagnosticsModal } from './src/ui/diagnostics-modal';
import { forgetRemember, JOURNAL_RING, normalizeSettings, pushJournalEntry, readJournal, readRemember, removeOwnerUserMeta, saveOwnerUserMeta, scopeAdapter, writeRemember } from './src/core/store';
import type { DataAdapter, JournalKind, ManagerSettings, OwnerUserMeta } from './src/core/store';
import { semverCompare } from './src/core/semver';
import { detectLanguage, setLanguage, t } from './src/i18n';
import type { Translations } from './src/i18n';
import { ManagerSettingsTab } from './src/ui/settings-tab';
import { PasswordModal } from './src/ui/password-modal';
import { OnboardingModal } from './src/ui/onboarding-modal';
import { ConfirmModal } from './src/ui/confirm-modal';

const PULL_INTERVAL_MS = 300_000;     // фоновый pull — 5 минут (FR-7)
const OWNER_SCAN_MS = 60_000;         // скан заявок хозяином — 60 секунд (FR-23)
const APPROVAL_POLL_MS = 30_000;      // поллинг подтверждения — 30 секунд (FR-4)
const APPROVAL_POLL_MAX_MS = 900_000; // …не дольше 15 минут, дальше — таймер 5 минут
const AUTO_SCAN_DEBOUNCE_MS = 1_500; // v0.3.6: дебаунс немедленного скана заявок после настройки пароля
// v0.5 (M2 §4.1): ЕДИНЫЙ reconciler. Поглощённые таймеры (таблица §4.1):
//   poll 2 с (enabledPlugins — ловил только собственные баги: mid-session внешние
//   изменения до памяти Obsidian не доходят, capabilities §2);
//   file-watch 5 с (→ raw-события + debounce + такт);
//   watchdog 20 с (→ идемпотентный reconcile: цикл сам чинит рассинхрон);
//   rearm-сверка 3 с (→ reconcile по факту; zombie-таймеры M-6 исчезают классом).
// Интерцептор enablePlugin ОСТАЁТСЯ — синхронный слой UI-защиты, не таймер.
const RECONCILE_TICK_MS = 10_000;             // такт — страховка ВСЕГДА (мобайл/WSL/мёртвый ватчер)
const RECONCILE_RAW_DEBOUNCE_MS = 500;      // дребезг raw-событий ФС (§4.1)

const LOG_PREFIX = '[VaultAccessManager]';

const REASON_KEY: Record<AuthBlockReason, keyof Translations> = {
        'key-mismatch': 'reasonKeyMismatch', // v0.5 (M2 §4.3): честный вердикт вместо «rotated»
        revoked: 'reasonRevoked',
        expired: 'reasonExpired',
        'wrong-password': 'reasonWrongPassword',
        'kill-switch': 'reasonKillSwitch',
        ttl: 'reasonTtl',
        'channel-error': 'reasonChannelError',
        'no-password': 'reasonNoPassword',
};

export interface SyncPluginInfo {
        present: boolean;
        version: string | null;
        perSession: boolean; // версия ≥ 3.2.0 — синк вызывает beforeSession (§3.6)
}

interface SyncPluginLike {
        manifest?: { version?: unknown };
        applyManagerProbe?: (probe: ManagerProbe) => Promise<void>;
        [key: string]: unknown;
}

// v0.3.5: app.plugins — внутренний API Obsidian (его же используют плагин-менеджеры):
// plugins — включённые инстансы (ключ = имя папки), manifests — все установленные,
// disablePluginAndSave — выключение С записью в community-plugins.json. События на
// включение плагина Obsidian не даёт — состояние сверяется циклом reconciler'а (M2 §4.1).
interface ObsidianPluginsApi {
        plugins?: Record<string, unknown>;
        enabledPlugins?: Set<string>;
        manifests?: Record<string, { id?: unknown; dir?: unknown }>;
        disablePlugin?: (id: string) => unknown;
        disablePluginAndSave?: (id: string) => unknown;
        enablePlugin?: (id: string) => unknown;         // v0.3.6: перехват попыток включения
        enablePluginAndSave?: (id: string) => unknown;  // v0.3.6: — же (галка в Community plugins)
        loadManifest?: (dir: string) => Promise<unknown>; // v0.5/W-C: точечная регистрация папки (C-4)
        getPluginFolder?: () => string;                   // v0.5/W-C: канонический pluginsDir платформы
        loadManifests?: () => Promise<void> | void;       // v0.5.2: полный рескан .obsidian/plugins (после sweep-восстановления)
}

function getSyncPlugin(app: unknown): SyncPluginLike | null {
        // §3.1: (app as any).plugins?.plugins?.['cloud-vault-sync']
        const plugins = (app as { plugins?: { plugins?: Record<string, SyncPluginLike> } }).plugins?.plugins;
        return plugins?.['cloud-vault-sync'] ?? null;
}

function journalKindFor(reason: AuthBlockReason): JournalKind {
        switch (reason) {
                case 'key-mismatch':
                        return 'rotation';
                case 'ttl':
                        return 'ttl';
                case 'kill-switch':
                        return 'kill-switch';
                case 'revoked':
                        return 'owner';
                default:
                        return 'probe';
        }
}

// --- Node-сбор сигналов устройства (v0.6, M4; ТОЛЬКО desktop) ---
// window.require существует только в Electron-рантайме Obsidian desktop — это и есть
// детект платформы (мобильные/тесты → null → биндинга нет, NFR-1 не нарушен: весь
// Node-код живёт здесь, в main.ts, ядро получает уже собранные сигналы).

type NodeRequire = (id: string) => unknown;

function nodeRequire(): NodeRequire | null {
        try {
                const w = typeof window !== 'undefined' ? (window as unknown as { require?: unknown }) : undefined;
                if (typeof w?.require !== 'function') return null;
                return w.require as NodeRequire;
        } catch {
                return null;
        }
}

function collectDeviceSignals(): DeviceSignals | null {
        const req = nodeRequire();
        if (req === null) return null;
        try {
                const os = req('os') as {
                        hostname(): string;
                        platform(): string;
                        arch(): string;
                        cpus(): Array<{ model?: string }> | undefined;
                        totalmem(): number;
                        networkInterfaces(): Record<string, Array<{ mac?: string; internal?: boolean }> | undefined> | undefined;
                };
                const hostname = os.hostname();
                if (!hostname) return null;
                // MAC первого не-внутреннего интерфейса — переживает смену hostname,
                // при клонах ВМ (одинаковый hostname) различается последним рубежом
                let mac: string | undefined;
                try {
                        for (const ifaces of Object.values(os.networkInterfaces() ?? {})) {
                                const hit = ifaces?.find((i) => i.internal !== true && typeof i.mac === 'string' && i.mac !== '00:00:00:00:00:00');
                                if (hit?.mac !== undefined) {
                                        mac = hit.mac;
                                        break;
                                }
                        }
                } catch {
                        // опциональный сигнал
                }
                return {
                        hostname,
                        platform: os.platform(),
                        arch: os.arch(),
                        cpuModel: os.cpus()?.[0]?.model,
                        memTotalBytes: os.totalmem(),
                        mac,
                };
        } catch {
                return null;
        }
}

export default class ManagerPlugin extends Plugin {
        settings!: ManagerSettings;
        authState!: AuthStateDetail;
        auth?: VaultSyncAuth;

        // Пароль — ТОЛЬКО в памяти инстанса (FR-27); в data.json его нет (FR-29).
        password: string | null = null;

        // v0.6 (M4 «device binding light»): идентичность ЭТОЙ машины. null — не
        // desktop (мобильные, песочница без Node) или разрешение провалилось:
        // биндинг для этой сессии выключен (запись решает, проверять ли её).
        // Резолвится один раз за сессию (секрет + отпечаток стабильны).
        private deviceIdentity: DeviceIdentity | null = null;
        private deviceResolved = false;
        // v0.6 (M4): последняя заявка — зачисление устройства (а не первичная
        // регистрация): UI показывает конкретное сообщение «устройство не зачислено».
        private deviceMismatchActive = false;
        // v0.6.2: текущий эпизод mismatch-а — ПОВТОРНОЕ использование кода (реестр
        // записи на момент входа уже не пуст). Классическая заявка (pushRegistrationRequest)
        // читает флаг: reuse=true → заявка-уведомление НЕ удаляется сканом хозяина.
        private pendingDeviceReuse = false;

        private authInternal?: AuthApiInternal;
        private cleanupAuth?: () => void;
        private lastPayload: UserPayload | null = null; // 304-кэш: payload последнего успешного pull
        private metaEtag: string | null = null;         // etag channel.json (runtime, §7.7-3)
        private pluginsEtag: string | null = null;       // etag plugins.json (v0.3)
        // v0.5.3 (D-3, репорт №3): последний refreshPluginPolicy видел plugins.json
        // отсутствующим. В связке с «channel.json читается» = хозяин удалил политику.
        private pluginsJsonMissingOnChannel = false;
        private pluginPolicy: PluginPolicy | null = null;      // политика плагинов из канала (v0.3)
        private pluginPolicyIsBuiltin = false;  // v0.4.7: true если pluginPolicy = встроенная managed (не канальная)
        private pluginPolicyStatus: PluginPolicyStatus | null = null; // последний вердикт политики
        private lastPolicyKey: string | null = null;     // дедуп журнала/уведомлений политики
        private ttlHours = 48;                          // политика канала из channel.json (FR-8)
        // v0.5 (B-2): kill-пин. Однажды увиденный killSwitch=true запоминается
        // (память + кэш) и снимается ТОЛЬКО свежим полным channel.json с killSwitch:false.
        // Удаление/порча channel.json пин не снимает — fail-closed (вектор C-4).
        private killSwitchPinned = false;
        // v0.5 (M2 §4.2): срок доступа из последней успешно расшифрованной записи —
        // часть VerdictSnapshot, проверяется ЛОКАЛЬНО на тике (M-4), персистится в кэше.
        private verdictExpiresAt: number | null = null;
        private lastMinManagerVersion: string | null = null; // §6.4: чип «требуется обновление»
        private everOk = false;                         // был ли ok (сессия или кэш) — для USER_NOT_FOUND
        private lastProbeKey: string | null = null;
        private pullInFlight: Promise<void> | null = null;
        private adapter!: DataAdapter;
        private readonly deps: ChannelDeps;
        private unsubVaultSync: (() => void) | null = null;
        private lastSyncAtSeen: number | null = null;
        private approvalPollTimer: number | null = null;
        private approvalPollDeadline = 0;
        // v0.5 (M2 §4.1): reconciler — один цикл вместо 4 таймеров (watchdog/poll/file-watch/rearm)
        private reconcileTimer: number | null = null;      // такт 10 с
        private reconcileDebounceTimer: number | null = null; // raw-дребезг 500 мс
        private reconcileInFlight: Promise<void> | null = null; // single-flight (M-13 дедуп по конструкции)
        private rawUnsub: (() => void) | null = null;       // отписка vault.on('raw')
        // v0.5 (M2 §4.3): одноразовые (за сессию) Notice-ы деградации — M-16 и PAT-хозяина
        private degradedEnforcementNotified = false;
        private channelAuthNotified = false;
        private enableInterceptorInstalled = false;       // v0.3.6: патч enablePlugin/enablePluginAndSave
        private originalEnable?: (id: string) => unknown; // v0.3.6: оригиналы для восстановления
        private originalEnableAndSave?: (id: string) => unknown;
        private lastEnableBlockedLog = new Map<string, number>(); // v0.3.6: дедуп попыток включения (60 с)
        private ownerScanTimer: number | null = null;     // v0.3.6: скан заявок — в той же сессии, где задан пароль
        private autoScanDebounce: number | null = null;   // v0.3.6: дебаунс немедленного скана
        private enforcedEpisodeIds = new Set<string>();    // v0.3.5: открытые эпизоды нарушений (дедуп журнала)
        private lastRequestError: string | null = null; // v0.3.3: последняя ошибка отправки заявки (для UI/журнала)
        private settingsTab: ManagerSettingsTab | null = null;
        private deferOpenPasswordModal = false;
        // v0.5.2 (репорт №2): сессия поднята из remember.bin (пароль уже был проверен
        // ранее) — только такая сессия получает offline-грейс при мёртвой сети/канале
        // (NET_ERROR.grace, USER_NOT_FOUND.channelGone); свежевведённый пароль — нет.
        private passwordFromRemember = false;
        // v0.5.2: дедуп журнала «channel.json not found» — раз за сессию (pull каждые
        // 5 минут забивал кольцо журнала одной строкой — репорт №2).
        private channelMetaMissingLogged = false;

        private disableQueue: Map<string, Promise<void>> = new Map();  // v0.4: дедуп disable-операций
        private lastUnknownPluginsKey: string | null = null;  // v0.4: дедуп auto-discovery логов
        // v0.5 (M2 §4.6, UX-шум): дедуп Notice-ов замка — ≤1 Notice на событие, повторы
        // внутри 30-секундного окна гасятся (журнал пишет КАЖДОЕ действие — B-5 не тронут)
        private lastLockNotices = new Map<string, number>();
        // v0.5.1 (H-1): замок = disable+scrab (штатные слои) + lock-registry (учёт);
        // манипуляции манифестом УДАЛЕНЫ (полевой репорт: бут-скан не видит папку,
        // восстановление не гарантировано)
        private lock?: PluginLock;
        private lockPluginsDir = '.obsidian/plugins'; // фактический pluginsDir (getPluginFolder при наличии)
        // v0.5.1 (H-3): мост window.__VAM__ для кастомных плагинов (гварды)
        private vamBridge?: { refresh(): void; dispose(): void };
        // v0.5.5: реестр замеченных hook-плагинов (гварды с pluginId заявляют о
        // себе через window.__VAM__.register) — подсекция «Hook-плагины» в настройках
        private hookRegistry: HookRegistry | null = null;

        constructor(app: ConstructorParameters<typeof Plugin>[0], manifest: ConstructorParameters<typeof Plugin>[1], deps?: ChannelDeps) {
                super(app, manifest);
                this.deps = deps ?? {};
        }

        // --- lifecycle (§7.7) ---

        async onload(): Promise<void> {
                setLanguage(detectLanguage());

                // 1. настройки
                this.settings = normalizeSettings(await this.loadData());
                const configDir = (this.app as { vault?: { configDir?: string } }).vault?.configDir ?? '.obsidian';
                this.adapter = scopeAdapter(this.app.vault.adapter as DataAdapter, `${configDir}/plugins/${this.manifest.id}`);

                // v0.6 (M4): идентичность устройства — резолвим сразу (desktop: fs +
                // SHA ~миллисекунды; mobile/null — биндинга нет). Модалки онбординга
                // читают результат синхронно через getDeviceIdentitySync().
                void this.resolveDeviceIdentity().catch(() => undefined);

                // v0.5 (W-C/C-1): smooth-lock. pluginsDir — из платформы, если она его отдаёт
                // (capabilities §4.1: getPluginFolder() = '<configDir>/plugins'), иначе эвристика.
                // onEvent — zero-silent канал: хилы реестра и деградации идут в журнал.
                const pluginsApi = this.pluginsRuntime();
                const pluginsDir = typeof pluginsApi.getPluginFolder === 'function'
                        ? String(pluginsApi.getPluginFolder())
                        : `${configDir}/plugins`;
                this.lockPluginsDir = pluginsDir;
                this.lock = new PluginLock({
                        adapter: this.app.vault.adapter as DataAdapter,
                        configDir,
                        pluginsDir,
                        selfPluginId: this.manifest.id,
                        now: () => this.now(),
                        onEvent: (detail) => {
                                void pushJournalEntry(this.adapter, { ts: this.now(), kind: 'plugins', detail }).catch(() => undefined);
                                // v0.5 (M2 §4.3, M-16): деградация enforcement наблюдаема — не только
                                // в журнале (PluginLock дедупит по папке), но и Notice-ом один раз за
                                // сессию: «механизм не работает» ≠ тихая норма (иначе следующий аудит
                                // снова найдёт это как находку).
                                if (detail.startsWith('degraded-enforcement') && !this.degradedEnforcementNotified) {
                                        this.degradedEnforcementNotified = true;
                                        try {
                                                new Notice(t('noticeEnforcementDegraded'));
                                        } catch {
                                                // нет Notice в тестовом окружении
                                        }
                                }
                        },
                });

                // v0.5 (W-C/C-6): одноразовая автопочинка мусора v0.4.7 — ДО любого
                // enforcement: возвращённые из карантина forbidden-плагины новая политика
                // тут же запрёт (lockAllForbidden ниже по потоку). Флаг ставится только
                // при ПОЛНОМ успехе (v0.5.2: degraded=null И failed=[] — провал переноса
                // больше не считается успехом, починка повторится на следующем старте).
                if (!this.settings.migrations.quarantineSwept) {
                        const sweepReport = await sweepQuarantine({
                                adapter: this.app.vault.adapter as DataAdapter,
                                configDir,
                                pluginsDir,
                                onEvent: (detail) => {
                                        void pushJournalEntry(this.adapter, { ts: this.now(), kind: 'plugins', detail }).catch(() => undefined);
                                },
                        });
                        if (sweepReport.degraded === null && sweepReport.failed.length === 0) {
                                this.settings.migrations.quarantineSwept = true;
                                void this.saveData(this.settings).catch(() => undefined);
                        }
                        if (sweepReport.ran && (sweepReport.restored.length > 0 || sweepReport.conflicts.length > 0)) {
                                try {
                                        new Notice(t('sweepSummary', sweepReport.restored.length, sweepReport.conflicts.length));
                                } catch {
                                        // нет Notice в тестовом окружении
                                }
                        }
                }

                // v0.5.1 (H-1): одноразовая автопочинка застрявших .vam-manIFEST (нейтрализация
                // v0.5-beta удалена). ДО enforcement — восстановленный forbidden запрётся ниже
                // ШТАТНЫМИ слоями (disable+scrub), папка останется видимой Obsidian.
                // v0.5.2 (репорт №2): (а) флаг только при полном успехе — failed=[] (раньше
                // проваленные папки считались «cleaned», флаг вставал и починка больше
                // НИКОГДА не повторялась — «ничего не восстановилось» навсегда); (б) после
                // фактического восстановления — loadManifests(): бут-скан Obsidian прошёл
                // ДО onload, без перескана папки невидимы до рестарта.
                if (!this.settings.migrations.manifestSwept) {
                        const manifestReport = await sweepNeutralizedManifests({
                                adapter: this.app.vault.adapter as DataAdapter,
                                configDir,
                                pluginsDir,
                                onEvent: (detail) => {
                                        void pushJournalEntry(this.adapter, { ts: this.now(), kind: 'plugins', detail }).catch(() => undefined);
                                },
                        });
                        if (manifestReport.degraded === null && manifestReport.failed.length === 0) {
                                this.settings.migrations.manifestSwept = true;
                                void this.saveData(this.settings).catch(() => undefined);
                        }
                        if (manifestReport.restored.length > 0) {
                                await this.refreshManifestsAfterSweep(manifestReport.restored);
                        }
                        if (manifestReport.ran && (manifestReport.restored.length > 0 || manifestReport.cleaned.length > 0 || manifestReport.failed.length > 0)) {
                                try {
                                        new Notice(t('sweepManifestSummary', manifestReport.restored.length, manifestReport.cleaned.length));
                                        if (manifestReport.failed.length > 0) {
                                                new Notice(t('sweepManifestRetry', manifestReport.failed.length));
                                        }
                                } catch {
                                        // нет Notice в тестовом окружении
                                }
                        }
                }

                // v0.5 (B-1): гидрация кэша одним чтением. ttlHours — часть кэшированного
                // вердикта, а не настройка поля: восстанавливается из кэша целиком, иначе
                // после рестарта действует дефолт 48 ч при канальной политике, скажем, 1 ч —
                // fail-open (C-2). Этот объект — seed будущего VerdictSnapshot (M2 §4.2
                // расширит его, не переписывая). normalizeCache гарантирует ttlHours > 0.
                if (this.settings.cache !== null) {
                        this.ttlHours = this.settings.cache.ttlHours;
                        this.verdictExpiresAt = this.settings.cache.expiresAt ?? null; // M2 §4.2 (M-4)
                }

                // v0.5 (M2 §4.2): лёгкий анти-откат — дайджест политики в снапшоте не совпал с
                // дайджестом кэша политики → data.json редактировали по частям (или откатили
                // одно из двух). Наблюдаемо: журнал; канал выровняет pull'ом. Криптографии нет
                // (Р7) — это детектор случайности, не атаки.
                if (this.settings.cache?.policyDigest != null && this.settings.pluginPolicyCache !== null) {
                        void (async () => {
                                const digest = await digestPolicy(this.settings.pluginPolicyCache as PluginPolicy).catch(() => null);
                                if (digest !== null && digest !== this.settings.cache?.policyDigest) {
                                        await pushJournalEntry(this.adapter, {
                                                ts: this.now(),
                                                kind: 'config',
                                                detail: 'policy cache digest mismatch — possible partial rollback; channel pull required',
                                        }).catch(() => undefined);
                                }
                        })();
                }

                // 2. восстановление вердикта из кэша
                this.authState = initialAuthState(this.settings.cache);
                this.authState.userId = this.settings.derivedUserId ?? undefined;
                // v0.5 (M2 §4.3): 'degraded' из кэша = грейс канала = «был ok» (пользователь
                // уже доказывал доступ; USER_NOT_FOUND после грейса корректно даёт revoked).
                if (this.settings.cache?.publicStatus === 'ok' || this.settings.cache?.publicStatus === 'degraded') this.everOk = true;
                // v0.5.2 (репорт №2, H-2 «помнить до отзыва»): пароль из remember.bin
                // поднимается не только при ok/degraded из кэша, но и при МЯГКОЙ блокировке
                // (ttl / no-password): запомненная сессия по построению старше этих причин
                // (TTL не гасит запомненную сессию — verdict-snapshot.hasRemember). Жёсткие
                // причины (kill-switch / revoked / key-mismatch / wrong-password / expired)
                // память не поднимают — это и есть «отзыв». Kill-пин из кэша читаем ДО блока:
                // пин главнее мягкой блокировки (ниже — исходный порядок B-2 сохранён).
                const killPinnedInCache = this.settings.cache?.killSwitch === true;
                const softBlocked = this.authState.status === 'blocked'
                        && (this.authState.reason === 'ttl' || this.authState.reason === 'no-password')
                        && !killPinnedInCache;
                if (this.authState.status === 'ok' || this.authState.status === 'degraded-channel' || softBlocked) {
                        // Пароль не пережил перезапуск? (FR-27)
                        let remembered: string | null = null;
                        if (this.settings.remember) {
                                const secret = await readRemember(this.adapter);
                                remembered = secret?.password ?? null;
                        }
                        if (remembered) {
                                this.password = remembered;
                                this.passwordFromRemember = true; // v0.5.2: сессия из памяти — грейс при офлайне
                                this.trace('boot', `remember.bin lifted password (userId=${this.settings.derivedUserId}) — offline grace armed`);
                                if (softBlocked) {
                                        // мягкая блокировка снята памятью: грейс до первого pull
                                        this.authState = { ...this.authState, status: 'degraded-channel', reason: undefined };
                                        await pushJournalEntry(this.adapter, {
                                                ts: this.now(),
                                                kind: 'config',
                                                detail: 'remembered session restored over soft block (ttl/no-password) — offline grace, pull will re-verify',
                                        }).catch(() => undefined);
                                }
                        } else if (this.authState.status !== 'blocked') {
                                this.authState = { ...this.authState, status: 'blocked', reason: 'no-password' };
                                this.deferOpenPasswordModal = true;
                        } else if (this.authState.reason === 'no-password') {
                                // blocked(no-password) из кэша без памяти: пароль нужен — модалка
                                this.deferOpenPasswordModal = true;
                        }
                        // blocked(ttl) без памяти: остаётся blocked (Notice ниже, §14-8);
                        // пароль можно ввести вручную — pull перепроверит и поднимет ok.
                }

                // v0.5 (B-2): kill-пин из кэша — после восстановления пароля (чтобы при
                // снятом хозяином kill фоновый pull мог вернуть ok без ручного ввода),
                // но ДО любого pull: kill главнее всего остального в этом цикле.
                // Блокировка не молчит (§14-8): Notice + журнал.
                this.killSwitchPinned = this.settings.cache?.killSwitch === true;
                if (this.killSwitchPinned && this.authState.status !== 'unconfigured') {
                        this.authState = { ...this.authState, status: 'blocked', reason: 'kill-switch' };
                        await pushJournalEntry(this.adapter, {
                                ts: this.now(),
                                kind: 'kill-switch',
                                detail: 'kill switch pinned (cache) — blocked at boot',
                        }).catch(() => undefined);
                        try {
                                new Notice(`${t('noticeBlocked')}: ${t('reasonKillSwitch')}`);
                        } catch {
                                // нет Notice в тестовом окружении
                        }
                } else if (this.authState.status === 'blocked' && this.authState.reason && this.authState.reason !== 'kill-switch') {
                        // v0.5 (M2 §4.2, M-15): причина блокировки пережила рестарт (из снапшота) —
                        // boot-блокировка не молчит (§14-8): журнал + Notice с настоящей причиной,
                        // а не «восстанавливается первым pull».
                        const reason = this.authState.reason;
                        await pushJournalEntry(this.adapter, {
                                ts: this.now(),
                                kind: journalKindFor(reason),
                                detail: `blocked at boot (cache): ${reasonText(reason)}`,
                        }).catch(() => undefined);
                        try {
                                new Notice(`${t('noticeBlocked')}: ${t(REASON_KEY[reason])}`);
                        } catch {
                                // нет Notice в тестовом окружении
                        }
                }

                // v0.5.1 (H-3): универсальный hook — окно window.__VAM__ для кастомных
                // плагинов. Рано: гварды, грузившиеся ДО нас, ждут в __VAM_PENDING__;
                // статус пересчитывается на каждом dispatch (choke-точка автомата).
                // v0.5.5: второй аргумент — регистрация hook-плагинов (реестр для UI).
                this.hookRegistry = new HookRegistry({
                        load: () => this.settings.knownHookPlugins,
                        persist: async (recs) => {
                                this.settings.knownHookPlugins = recs;
                                await this.saveData(this.settings);
                        },
                        now: () => this.now(),
                        onFirstSeen: (id) => {
                                void pushJournalEntry(this.adapter, {
                                        ts: this.now(),
                                        kind: 'plugins',
                                        detail: `hook plugin noticed: ${id}`,
                                }).catch(() => undefined);
                                this.refreshSettingsTab();
                        },
                });
                this.vamBridge = installVamBridge(
                        () => this.vamGateSnapshot(),
                        (pluginId) => this.hookRegistry?.register(pluginId),
                        // v0.5.8 (M3, протокол v3): пер-плагинный вердикт политики —
                        // «отключиться полностью или урезать команды» решает сам плагин,
                        // менеджер честно говорит, что о нём известно сейчас.
                        // v0.5.10 (протокол v4): + isOwner() — «хранилище администратора»
                        // отдельной точкой (источник — role из vamGateSnapshot, поставщика
                        // не требует)
                        (pluginId) => this.vamPermissionFor(pluginId),
                );

                // 2.5 v0.4.7: контроль плагинов для user-role — ВСЕГДА, даже без канала.
                // v0.4.1: РАННЯЯ БЛОКИРОВКА. Obsidian загружает плагины в порядке community-plugins.json.
                // v0.5.6: managed-плагины (v-clone, open-llm-chat + aliases) без входа НЕ
                // блокируются (директива: hardcoded не forbidden) — контроль запускается
                // всегда, чтобы политика канала применилась сразу.
                if (this.settings.role === 'user') {
                        if (this.settings.pluginPolicyCache !== null) {
                                this.pluginPolicy = this.settings.pluginPolicyCache;
                        }
                        // v0.5 (M2 §4.1): единый цикл reconciler'а — ВСЕГДА для user-role:
                        // вердикт-тик (§4.2) и self-heal реестра не зависят от политики.
                        // БЫЛО (поглощено): watchdog 20с + poll 2с + file-watch 5с.
                        this.startReconciler();
                        this.installEnableInterceptor();
                        this.emergencyBlockAlreadyLoadedForbidden();
                        if (this.pluginPolicy !== null) {
                                // v0.5 (W-C/C-3): кэшированная политика при бут-е — замок на
                                // все forbidden сразу (синк мог принести папку, пока Obsidian
                                // был выключен — violations её не видят, она не включена).
                                void this.lockAllForbidden(this.pluginPolicy).catch(() => undefined);
                        }
                        void this.enforcePluginPolicyNow().catch(() => undefined);
                        // v0.5.8: кэш политики поднялся при бут-е — гварды v3 узнают
                        // актуальную политику сразу, а не при первом auth-событии
                        this.vamBridge?.refresh();
                        // Если есть канал — bootstrap политики с канала (plugins.json публичный).
                        if (this.settings.channel && this.settings.identifier) {
                                void this.bootstrapPluginPolicyFromChannel().catch(() => undefined);
                        }
                        try {
                                const workspace = (this.app as { workspace?: { onLayoutReady?: (cb: () => void) => void } }).workspace;
                                workspace?.onLayoutReady?.(() => void this.enforcePluginPolicyNow().catch(() => undefined));
                        } catch {
                                // нет workspace в тестовом окружении
                        }
                }

                // 3. публичный API window.vaultSyncAuth (FR-14/15)
                this.cleanupAuth = installVaultSyncAuth(this);
                this.authInternal = this.auth as AuthApiInternal | undefined;

                // 4. подписка window.vaultSync.onChanged (FR-18)
                this.subscribeVaultSyncHook();

                // 5. таймеры
                if (this.settings.role === 'user' && this.settings.channel && this.settings.identifier) {
                        this.registerInterval(Number(globalThis.setInterval(() => void this.onPullTimer(), PULL_INTERVAL_MS)));
                }
                // v0.3.6: таймер авто-скана заявок ставится при любой загрузке хозяина —
                // условия (канал/авто/пароль) проверяются на каждом тике. Раньше он
                // ставился только если ВСЁ было настроено ещё ДО onload: хозяин, задавший
                // дефолтный пароль позже в этой же сессии, не получал авто-подтверждение
                // до перезапуска Obsidian (жалоба «дефолтный пароль не сохраняется»).
                this.ensureOwnerScanTimer();

                // 6. онбординг / модалка ввода пароля
                if (this.settings.role === 'unset') {
                        this.openOnboarding();
                } else if (this.deferOpenPasswordModal) {
                        this.openPasswordModal('first');
                }

                // Рестарт во время ожидания заявки — поллинг перезапускаем
                if (this.authState.status === 'awaiting-approval') this.startApprovalPolling();

                // 7. фоновый pull (поймает ротацию за время простоя, S4)
                if (this.settings.role === 'user' && this.settings.channel && this.settings.identifier && this.password !== null) {
                        void this.runPullCycle({ context: 'background', trigger: 'manual' });
                }

                // 8. вкладка настроек
                this.settingsTab = new ManagerSettingsTab(this.app, this);
                this.addSettingTab(this.settingsTab);

                // v0.5 (M2 §4.4, Р6): «VAM первым» — одноразовое предложение хозяину.
                // Boot-окно 1–3 с неустранимо принципиально (порядок загрузки = порядок строк
                // файла, гарантии порядка НЕТ — capabilities §10), но VAM первым = forbidden
                // грузятся ПОСЛЕ менеджера = окно схлопывается до emergency-прохода.
                if (this.settings.role === 'owner') {
                        void this.maybeOfferVamFirst().catch(() => undefined);
                }

                // 9. команда для партнёрских инструкций
                this.addCommand({
                        id: 'vault-access-manager-open-settings',
                        name: t('tabTitle'),
                        callback: () => {
                                try {
                                        const setting = (this.app as unknown as { setting?: { open(): void; openTabById(id: string): void } }).setting;
                                        setting?.open();
                                        setting?.openTabById(this.manifest.id);
                                } catch {
                                        // настройки недоступны — тихо
                                }
                        },
                });

                // v0.6.1 (директива владельца): журнал — в консоли разработчика (Ctrl+Shift+I,
                // фильтр [VaultAccessManager]); из настроек вид убран. Команда вываливает
                // кольцо целиком — для поддержки/диагностики без открытия отчёта.
                this.addCommand({
                        id: 'vault-access-manager-show-journal',
                        name: t('journalShowCmd'),
                        callback: () => {
                                void (async () => {
                                        const entries = await readJournal(this.adapter).catch(() => []);
                                        console.info(LOG_PREFIX, `[journal] ${entries.length} entries (ring ${JOURNAL_RING})`);
                                        for (const e of entries) {
                                                console.info(LOG_PREFIX, `[journal] ${new Date(e.ts).toISOString()} [${e.kind}] ${e.detail}`);
                                        }
                                })();
                        },
                });

                // v0.5.3 (репорт №3): глубокая диагностика — команда палитры для ЛЮБОЙ роли.
                // Полный отчёт: все входы решения (вердикт/политика/интерцептор/замок) +
                // живой probe канала с фактическими URL и HTTP-кодами + гипотезы причины.
                this.addCommand({
                        id: 'vault-access-manager-diagnostics',
                        name: t('diagRunCmd'),
                        callback: () => {
                                void this.runDiagnostics().catch((err) => {
                                        this.trace('diag', `diagnostics failed: ${err instanceof Error ? err.message : String(err)}`);
                                });
                        },
                });
        }

        onunload(): void {
                // 1. fail-closed: probe {present:false} — синк блокируется немедленно (S6-а)
                this.sendProbeSync(unloadProbe());
                // 2. снять глобал + dispose реестра
                this.cleanupAuth?.();
                this.cleanupAuth = undefined;
                this.authInternal = undefined;
                // v0.5.1 (H-3): надгробие vam-unloaded + мгновенная рассылка гвардам
                // (глобал НЕ удаляем: «менеджер выгружен» честнее «менеджера нет»)
                this.vamBridge?.dispose();
                this.vamBridge = undefined;
                // 3. отписка от window.vaultSync
                this.unsubVaultSync?.();
                this.unsubVaultSync = null;
                // 4. собственные таймеры (registerInterval чистится Obsidian сам)
                this.stopReconciler(); // v0.5 (M2 §4.1): такт + raw + debounce — единый цикл
                this.uninstallEnableInterceptor(); // v0.3.6: вернуть app.plugins оригинальные методы
                if (this.autoScanDebounce !== null) {
                        globalThis.clearTimeout(this.autoScanDebounce);
                        this.autoScanDebounce = null;
                }
                if (this.ownerScanTimer !== null) {
                        globalThis.clearInterval(this.ownerScanTimer);
                        this.ownerScanTimer = null;
                }
                if (this.approvalPollTimer !== null) {
                        globalThis.clearInterval(this.approvalPollTimer);
                        this.approvalPollTimer = null;
                }
                // v0.5 (W-C/C-5): real-unload — вернуть всё из реестра. Только когда
                // enabledPlugins НЕ содержит менеджера: перезагрузка/обновление плагина
                // (self ещё включён) замок сохраняет; выгрузка пользователем — unlockAll
                // (data-driven: folder + wasEnabled у каждой записи). Интерцептор уже
                // снят (шаг 4) — включения проходят свободно. RACE-04-семантика v0.4.
                try {
                        const selfEnabled = this.pluginsRuntime().enabledPlugins?.has(this.manifest.id);
                        if (selfEnabled === false) {
                                void this.unlockAllPlugins('manager unloaded').catch(() => 0);
                        }
                } catch {
                        // enabledPlugins недоступен — safe default: НЕ восстанавливать (fail-closed)
                }
                // 5. страховка сохранения (кэш персистится по ходу)
                void this.saveData(this.settings).catch(() => undefined);
        }

        /** Права доступа (для enforcement): ok ИЛИ грейс канала (§4.3, M-5).
         *  Права = «доступ не отозван», а не «канал работает»: enforcement не деградирует
         *  вместе с каналом — политика кэширована локально. Снятие грейса — тик §4.2. */
        private userHasRights(): boolean {
                return (this.authState.status === 'ok' || this.authState.status === 'degraded-channel') && this.password !== null;
        }

        // --- диспетчер автомата ---

        async dispatch(event: AuthEvent): Promise<void> {
                const prevStatus = this.authState.status;
                const transition = reduce(this.authState, event);
                this.authState = transition.next;
                // v0.5.3 (репорт №3): трейс переходов автомата — главный вопрос поля
                // («доступ разрешён, но включение блокируется») решается просмотром
                // именно этих строк: какой event, из какого статуса, куда перешли,
                // с какой причиной и есть ли права ПОСЛЕ перехода.
                this.trace('auth', `dispatch ${event.type}: ${prevStatus}${this.authState.status !== prevStatus ? ` → ${this.authState.status}` : ''}${this.authState.reason !== undefined ? ` (${this.authState.reason})` : ''} rights=${this.userHasRights()}`);
                if (this.authState.status === 'ok') this.everOk = true;
                // v0.6 (M4): успешный вход гасит маркер ожидания зачисления устройства
                if (event.type === 'DECRYPT_OK' && this.authState.status === 'ok') this.deviceMismatchActive = false;
                // v0.6.2: эпизод входа завершён — флаг повторного использования кода
                // живёт ровно один эпизод (mismatch → заявка), дальше сбрасывается,
                // чтобы свежая заявка (напр., после отзыва записи) не несла чужой флаг.
                if (event.type === 'DECRYPT_OK' || event.type === 'USER_NOT_FOUND') this.pendingDeviceReuse = false;
                // v0.5.1 (H-2): первый успешный вход сессии = доверенный вход →
                // автозапоминание «до отзыва» (если пользователь не opted-out).
                if (this.authState.status === 'ok' && prevStatus !== 'ok') this.maybeAutoRemember();

                // Запрет §14-8: блокировка не молчит — Notice + журнал на каждый новый blocked
                if (this.authState.status === 'blocked' && prevStatus !== 'blocked' && this.authState.reason) {
                        try {
                                new Notice(`${t('noticeBlocked')}: ${t(REASON_KEY[this.authState.reason])}`);
                        } catch {
                                // нет Notice в тестовом окружении
                        }
                        void pushJournalEntry(this.adapter, {
                                ts: this.now(),
                                kind: journalKindFor(this.authState.reason),
                                detail: `blocked: ${reasonText(this.authState.reason)}`,
                        });
                }
                // v0.6 (M4): вход с нового устройства — не blocked (доступ ещё не
                // подтверждён, как у первичной заявки), но событие НЕ молчит: Notice + журнал.
                // v0.6.1: сюда попадают только СВЕРХЛИМИТ и ручной режим (сброс устройств) —
                // под капом устройство зачисляется само в verdictFromPayload.
                if (event.type === 'DEVICE_MISMATCH' && this.authState.status === 'awaiting-approval' && prevStatus !== 'awaiting-approval') {
                        this.deviceMismatchActive = true;
                        try {
                                new Notice(t('noticeDeviceMismatch'));
                        } catch {
                                // нет Notice в тестовом окружении
                        }
                        await pushJournalEntry(this.adapter, {
                                ts: this.now(),
                                kind: 'device',
                                detail: `device mismatch: ${this.deviceIdentity?.deviceId ?? 'unknown'} (${this.deviceIdentity?.deviceName ?? '?'}) — enrollment request`,
                        }).catch(() => undefined);
                }
                // v0.5 (M2 §4.3, M-5): переход в degraded — наблюдаем в журнале (не Notice:
                // доступ жив, чинить канал — хозяину; хозяин узнает на своей машине).
                if (this.authState.status === 'degraded-channel' && prevStatus !== 'degraded-channel') {
                        void pushJournalEntry(this.adapter, {
                                ts: this.now(),
                                kind: 'config',
                                detail: 'channel degraded (401/403) — access in offline grace; administrator should update PAT',
                        }).catch(() => undefined);
                }

                // v0.3.6: блокировка доступа — немедленная сверка политики. Kill-switch/отзыв
                // не ждут следующего тика вотчера: «синхронизация заблокирована» теперь
                // подкреплена мгновенным выключением запрещённых плагинов (кэш политики).
                if (this.authState.status === 'blocked' && prevStatus !== 'blocked') {
                        void this.enforcePluginPolicyNow().catch(() => undefined);
                }

                const pullContext: 'typed' | 'background' = event.type === 'PASSWORD_TYPED' ? 'typed' : 'background';
                for (const effect of transition.effects) {
                        await this.handleEffect(effect, pullContext);
                }

                // probe: только при изменении verdict-ключа (§7.5)
                if (transition.probe !== null) {
                        const key = JSON.stringify(transition.probe);
                        if (key !== this.lastProbeKey) {
                                await this.sendProbe(transition.probe);
                                this.lastProbeKey = key;
                        }
                }

                // v0.5.1 (H-3): гварды кастомных плагинов узнают новый вердикт мгновенно
                this.vamBridge?.refresh();
        }

        private async handleEffect(effect: Effect, pullContext: 'typed' | 'background'): Promise<void> {
                switch (effect) {
                        case 'pull-cycle':
                                await this.runPullCycle({ context: pullContext });
                                break;
                        case 'open-rotation-modal':
                                this.openPasswordModal('rotation');
                                break;
                        case 'open-retry-modal':
                                this.openPasswordModal('retry');
                                break;
                        case 'push-request':
                                await this.pushRegistrationRequest();
                                break;
                        case 'start-approval-polling':
                                this.startApprovalPolling();
                                break;
                        case 'stop-approval-polling':
                                this.stopApprovalPolling();
                                break;
                        case 'persist-cache':
                                await this.persistCache();
                                break;
                        case 'notify-subscribers':
                                this.authInternal?.notify();
                                this.refreshSettingsTab();
                                break;
                        case 'clear-remember':
                                this.password = null;
                                this.lastPayload = null;
                                this.verdictExpiresAt = null; // M2 §4.2: снапшот перевычислится после нового входа
                                await forgetRemember(this.adapter);
                                await this.persistCache();
                                break;
                }
        }

        // --- pull-цикл (§7.7) ---

        async runPullCycle(opts: { context: 'typed' | 'background'; trigger?: 'timer' | 'before-session' | 'onchanged' | 'manual' }): Promise<void> {
                // Дедупликация всплеска: один pull на серию вызовов (FR-6)
                if (this.pullInFlight) return this.pullInFlight;
                const run = this.doPullCycle(opts)
                        .catch((err) => {
                                console.warn(LOG_PREFIX, 'pull cycle failed:', err instanceof Error ? err.message : String(err));
                        })
                        .finally(() => {
                                this.pullInFlight = null;
                        });
                this.pullInFlight = run;
                return run;
        }

        private async doPullCycle(opts: { context: 'typed' | 'background' }): Promise<void> {
                if (this.settings.role !== 'user' || !this.settings.channel || !this.settings.identifier || !this.settings.derivedUserId) {
                        return;
                }

                // v0.4 (P0-1.1): Загрузка политики плагинов ДО проверки пароля.
                // plugins.json — публичный файл канала (Bearer-токен), не требует
                // пользовательского пароля. Раньше early return при password===null
                // блокировал ВСЁ, включая политику плагинов — это была логическая ошибка
                // (сценарий A: первичная настройка без пароля → контроль не запускался).
                await this.refreshPluginPolicy().catch(() => undefined);

                // v0.4.6: применяем политику (managed + channel) даже без пароля.
                // Раньше early return при password===null пропускал enforcePluginPolicyNow.
                // Теперь: enforcePluginPolicyNow проверяет userHasRights internally;
                // v0.5.6: без входа managed-плагины не блокируются — только отслеживаются.
                await this.enforcePluginPolicyNow().catch(() => undefined);

                if (this.password === null) {
                        // Fail-closed для «ранее был ok» (§7.7-2); первичная настройка молчит (FR-17)
                        if (this.everOk) await this.setNoPasswordBlocked();
                        return;
                }
                const client = this.makeClient();
                const userId = this.settings.derivedUserId;
                // v0.5.2 (репорт №2): канал сам нечитаем (channel.json не отдаётся — токен
                // потерял репозиторий / канал переименован / файла никогда не было) —
                // USER_NOT_FOUND при таком канале трактуется грейсом, не отзывом.
                let channelMetaMissing = false;
                try {
                        // 1. channel.json: kill-switch + TTL-политика (FR-12/8)
                        const meta = await client.getChannelMeta(this.metaEtag);
                        this.trace('pull', `channel.json → ${meta.status}${meta.status === 'not-found' ? ' (repo invisible OR no meta file)' : ''}`);
                        if (meta.status === 'ok') {
                                this.metaEtag = meta.etag;
                                this.lastMinManagerVersion = meta.meta.minManagerVersion;
                                if (meta.meta.killSwitch) {
                                        this.ttlHours = meta.meta.offlineTtlHours;
                                        await this.dispatch({ type: 'KILL_SWITCH' });
                                        if (!this.killSwitchPinned) {
                                                // v0.5 (B-2): пин + персист — kill переживает рестарт и удаление channel.json
                                                this.killSwitchPinned = true;
                                                void this.persistCache().catch(() => undefined);
                                                await pushJournalEntry(this.adapter, {
                                                        ts: this.now(),
                                                        kind: 'kill-switch',
                                                        detail: 'kill switch ON (channel.json) — pinned',
                                                }).catch(() => undefined);
                                        }
                                        return;
                                }
                                // v0.5 (B-2): killSwitch:false в СВЕЖЕМ полном ответе — единственный
                                // способ снять пин. Зашитый в кэш kill не «откатить» удалением файла.
                                if (this.killSwitchPinned) {
                                        this.killSwitchPinned = false;
                                        await pushJournalEntry(this.adapter, {
                                                ts: this.now(),
                                                kind: 'kill-switch',
                                                detail: 'kill switch OFF (fresh channel.json) — pin released',
                                        }).catch(() => undefined);
                                }
                                this.ttlHours = meta.meta.offlineTtlHours;
                                void this.persistCache().catch(() => undefined); // TTL обновлён — кэш в тонусе (B-1)
                        } else if (meta.status === 'not-found') {
                                // v0.5 (B-2): channel.json удалён (атака с write-токеном / пользователь
                                // удалил файл) — пин и TTL НЕ сбрасываются, дефолтов 48 ч нет.
                                // v0.5.2 (репорт №2): (а) журнал — раз за сессию (pull каждые
                                // 5 минут забивал кольцо журнала одной строкой); (б) «fail-closed»
                                // снят из поведения: при живом пине блокирует пин; без пина вердикт
                                // продолжается по кэшу/памяти — отсутствие мета-файла само по себе
                                // никого не блокирует (channel.json у многих каналов никогда
                                // не создавался — в v0.4.7 это было нормой).
                                channelMetaMissing = true;
                                if (!this.channelMetaMissingLogged) {
                                        this.channelMetaMissingLogged = true;
                                        await pushJournalEntry(this.adapter, {
                                                ts: this.now(),
                                                kind: 'config',
                                                detail: 'channel.json not found on channel — kill/TTL pins retained; verdict continues from cache',
                                        }).catch(() => undefined);
                                }
                                if (this.killSwitchPinned) {
                                        await this.dispatch({ type: 'KILL_SWITCH' });
                                        return;
                                }
                        }
                        // not-modified → kill-проверку пропускаем (пин не трогаем)

                        // v0.5.3 (D-3, репорт №3): канал ВИДИМ (channel.json читается/304),
                        // но plugins.json на нём 404 — хозяин удалил политику = «разрешить
                        // всё». Раньше кэш держал замки вечно: fail-closed не различал
                        // «файл удалён при живом репо» от «репозиторий не виден токену»
                        // (второй случай — channel.json тоже 404 — кэш оставляем, это
                        // репорт №2). Симптом в поле: «доступ разрешён, включение всё
                        // равно блокируется» — застрявший forbidden-кэш.
                        // v0.5.4 (D-3.1): сигнал видимости №1 — channel.json читается (D-3).
                        if (!channelMetaMissing) {
                                await this.releasePolicyIfOwnerRemovedIt('channel.json readable (D-3)');
                        }

                        // 1.5 политика плагинов (plugins.json) — уже обновлена выше через refreshPluginPolicy().
                        // v0.4: дублирующий вызов удалён (refreshPluginPolicy идемпотентен благодаря ETag).
                        // Регуляция по состоянию — выполняется и на 304 (плагин могли
                        // включить руками после прошлого pull при той же политике)
                        await this.enforcePluginPolicyNow();

                        // 2. запись пользователя (ETag/304-кэш)
                        const rec = await client.getUserRecord(userId, this.authState.channelHead);
                        this.trace('pull', `user record → ${rec.status}${rec.status === 'not-found' ? ' (never approved / revoked / repo invisible)' : ''}`);
                        // v0.5.4 (репорт №4, D-3.1): сигнал видимости №2 — запись пользователя
                        // отвечает 200/304. channel.json ОПЦИОНАЛЕН: у каналов, выросших из
                        // v0.4.7, его никогда не было — старый D-3 требовал его читаемости и
                        // на таких каналах держал замки из кэша forbidden-политики ВЕЧНО.
                        // Полевой симптом: «доступ разрешён (rights=true), включение
                        // блокируется». Ответ users/<id>.enc (данные в ТОМ ЖЕ репозитории,
                        // что и plugins.json) доказывает видимость репо токену лучше,
                        // чем опциональная мета.
                        if (rec.status === 'ok' || rec.status === 'not-modified') {
                                await this.releasePolicyIfOwnerRemovedIt('user record reachable (D-3.1)');
                        }
                        if (rec.status === 'not-modified') {
                                if (this.lastPayload) {
                                        // мгновенный cache-hit: расшифровка не повторяется (S3);
                                        // v0.6 (M4): проверка устройства переигрывается — идентичность
                                        // могла смениться (сброс хозяином) между pull-ами
                                        await this.verdictFromPayload(this.lastPayload, this.authState.channelHead ?? '');
                                } else {
                                        // после рестарта памяти нет — полноценный GET без etag
                                        const fresh = await client.getUserRecord(userId, null);
                                        if (fresh.status === 'not-found') await this.dispatch({ type: 'USER_NOT_FOUND', everOk: this.everOk, channelGone: this.channelGoneGrace(channelMetaMissing) });
                                        else if (fresh.status === 'ok') await this.decryptAndDispatch(fresh.bytes, fresh.etag, opts.context);
                                }
                                return;
                        }
                        if (rec.status === 'not-found') {
                                await this.dispatch({ type: 'USER_NOT_FOUND', everOk: this.everOk, channelGone: this.channelGoneGrace(channelMetaMissing) });
                                return;
                        }
                        // 3. расшифровка + вердикт
                        await this.decryptAndDispatch(rec.bytes, rec.etag, opts.context);
                } catch (err) {
                        // v0.5 (B-2): malformed channel.json (unexpected body / bad base64 /
                        // неподдерживаемая версия) — семантика как not-found: пины живы,
                        // TTL не сбрасывается, предупреждение в журнал.
                        if (err instanceof Error && err.message.includes('channel.json')) {
                                await pushJournalEntry(this.adapter, {
                                        ts: this.now(),
                                        kind: 'config',
                                        detail: 'channel.json malformed — pinned kill/TTL retained (fail-closed)',
                                }).catch(() => undefined);
                                if (this.killSwitchPinned) {
                                        await this.dispatch({ type: 'KILL_SWITCH' });
                                        return;
                                }
                        }
                        if (err instanceof ChannelAuthError) {
                                await this.dispatch({ type: 'CHANNEL_AUTH_ERROR' });
                                return;
                        }
                        await this.dispatch({
                                type: 'NET_ERROR',
                                now: this.now(),
                                // v0.5.2 (репорт №2): запомненная сессия + мёртвая сеть →
                                // offline-грейс degraded-channel («помнить до отзыва»);
                                // kill-пин исключён — он главнее и обрабатан выше.
                                grace: this.passwordFromRemember && this.everOk && !this.killSwitchPinned ? true : undefined,
                        });
                        // v0.5 (M2 §4.2): TTL/expire/kill — единая точка вычисления из снапшота
                        // (раньше здесь был только checkTtl по checkedAt; правила — §4.2, локально).
                        await this.tickVerdict();
                }
        }

        private async decryptAndDispatch(bytes: Uint8Array, etag: string, context: 'typed' | 'background'): Promise<void> {
                const userId = this.settings.derivedUserId as string;
                try {
                        const payload = await decryptUserRecord(this.password as string, userId, bytes);
                        await this.verdictFromPayload(payload, etag);
                } catch {
                        await this.dispatch({ type: 'DECRYPT_FAIL', context });
                }
        }

        /** v0.6 (M4): вердикт из УСПЕШНО расшифрованной записи — с проверкой привязки
         *  устройства. Единая точка для живой расшифровки и 304-кэш-хита (иначе
         *  повторный pull из кэша обходил бы проверку при смене deviceId).
         *  Правила: реестра нет (v1) → ок; deviceId неизвестен (mobile) → ок;
         *  устройство в реестре → ок. v0.6.1: устройство НЕ в реестре, но пароль верен
         *  (запись расшифрована — приглашение выдано) и запись в авто-режиме под капом →
         *  САМО-зачисление без ожидания одобрения; сверх лимита/ручной режим →
         *  DEVICE_MISMATCH (авто-заявка хозяину, как в v0.6.0).
         *  v0.6.2: семантика кода. Реестр ПУСТ (код никогда не использовался) —
         *  подтверждение автоматическое, заявка — транзитная (скан подчищает).
         *  Реестр НЕ пуст, код применяется ПОВТОРНО (новое устройство на этот логин) —
         *  уведомление администратора ОБЯЗАТЕЛЬНО: заявка переживает скан. */
        private async verdictFromPayload(payload: UserPayload, etag: string): Promise<void> {
                this.lastPayload = payload;
                // v0.5 (M2 §4.2): срок доступа — в снапшот (персистится эффектом
                // persist-cache ниже по потоку dispatch), проверяется на тике (M-4).
                this.verdictExpiresAt = payload.expiresAt;
                if (hasDeviceRegistry(payload)) {
                        const identity = await this.resolveDeviceIdentity();
                        const deviceId = identity?.deviceId ?? null;
                        if (deviceId !== null && !isDeviceAllowed(payload, deviceId)) {
                                const devices = payload.devices ?? [];
                                const max = payload.maxDevices ?? DEFAULT_MAX_DEVICES;
                                const manual = payload.autoEnroll === false;
                                // v0.6.2: непустой реестр + новое устройство = повторное
                                // использование кода — флаг для классической заявки ниже.
                                this.pendingDeviceReuse = devices.length > 0;
                                if (!manual && devices.length < max && identity !== null) {
                                        const enrolled = await this.selfEnrollDevice(payload, { id: deviceId, name: identity.deviceName });
                                        if (enrolled !== null) {
                                                await this.dispatch({ type: 'DECRYPT_OK', payload: enrolled.payload, channelHead: enrolled.head ?? etag, now: this.now() });
                                                return;
                                        }
                                        // канал не принял запись — классический путь (заявка уже
                                        // ушла из selfEnrollDevice; скан хозяина дорегистрирует)
                                        this.trace('device', 'self-enroll did not complete — classic enrollment request path');
                                } else {
                                        this.trace('device', `mismatch: local ${deviceId} not in registry (${devices.length}/${max}${manual ? ' — manual enrollment mode' : ''})`);
                                }
                                await this.dispatch({ type: 'DEVICE_MISMATCH' });
                                return;
                        }
                }
                this.pendingDeviceReuse = false;
                await this.dispatch({ type: 'DECRYPT_OK', payload, channelHead: etag, now: this.now() });
        }

        /** v0.6.1 (директива владельца): само-зачисление нового устройства. Пароль верен
         *  (запись только что расшифрована) — значит приглашение уже выдано; ждать
         *  одобрения устройства не нужно. Порядок: заявка-уведомление (скан хозяина
         *  подберёт её) → PUT записи с дописанным устройством (append-only) → DECRYPT_OK.
         *  Сбой PUT — не приговор: заявка уже в очереди, скан хозяина зачислит устройство
         *  сам (fail-open к одобрению, не к доступу). Возврат null — вызвать классический
         *  DEVICE_MISMATCH.
         *  v0.6.2 (директива владельца): семантика кода. ПЕРВОЕ использование (реестр
         *  пуст): заявка-уведомление транзитная — скан подчищает её и освежает users-local;
         *  сбоем она не критична (best-effort). ПОВТОРНОЕ использование (реестр не пуст,
         *  устройство добавляется к этому же логину): уведомление администратора
         *  ОБЯЗАТЕЛЬНО — заявка-уведомление становится ПРЕДУСЛОВИЕМ зачисления: не
         *  ушла — зачисления нет (возврат null → классический путь с видимой ошибкой);
         *  ушла — скан её НЕ удаляет (висит в очереди до решения администратора). */
        private async selfEnrollDevice(payload: UserPayload, device: { id: string; name: string }): Promise<{ payload: UserPayload; head: string | null } | null> {
                if (this.password === null || this.settings.channel === null || this.settings.identifier === null || this.settings.derivedUserId === null) return null;
                const client = this.makeClient();
                const max = payload.maxDevices ?? DEFAULT_MAX_DEVICES;
                // v0.6.2: реестр до зачисления не пуст = код используется повторно
                const reuse = (payload.devices ?? []).length > 0;
                try {
                        try {
                                // заявка-уведомление: владельческий скан по ней обновит кэш
                                // и журнал; reuse=true — заявка ещё и обязательное
                                // уведомление, которое скан не смеет удалить
                                await buildAndPushRequest(client, this.settings.identifier, this.settings.derivedUserId, this.password, { now: () => this.now() }, { id: device.id, name: device.name }, reuse);
                        } catch (err) {
                                if (reuse) {
                                        // уведомление обязательно: без него повторное зачисление
                                        // не проходит — классический путь (заявка с видимой ошибкой)
                                        this.trace('device', `self-enroll notify request failed (reuse, mandatory): ${err instanceof Error ? err.message : String(err)}`);
                                        return null;
                                }
                                this.trace('device', `self-enroll notify request failed: ${err instanceof Error ? err.message : String(err)}`);
                        }
                        const enrolled = await selfEnrollDeviceRecord(client, payload.userId, this.password, payload, device);
                        this.lastPayload = enrolled.payload;
                        this.trace('device', `self-enrolled ${device.name} (${device.id}) — ${enrolled.payload.devices?.length ?? 0}/${max}${reuse ? ' — code reuse, admin notification mandatory' : ''}`);
                        try {
                                new Notice(reuse ? t('noticeDeviceAutoEnrolledReuse', enrolled.payload.devices?.length ?? 0, max) : t('noticeDeviceAutoEnrolled', enrolled.payload.devices?.length ?? 0, max));
                        } catch {
                                // нет Notice в тестовом окружении
                        }
                        await pushJournalEntry(this.adapter, {
                                ts: this.now(),
                                kind: 'device',
                                detail: `device self-enrolled: ${device.name} (${device.id}) — ${enrolled.payload.devices?.length ?? 0}/${max}${reuse ? ' [code reuse — admin notification mandatory]' : ''}`,
                        }).catch(() => undefined);
                        return enrolled;
                } catch (err) {
                        this.trace('device', `self-enroll failed: ${err instanceof Error ? err.message : String(err)} — falling back to enrollment request`);
                        return null;
                }
        }

        private async setNoPasswordBlocked(): Promise<void> {
                if (this.authState.status === 'blocked' && this.authState.reason === 'no-password') return;
                this.authState = { ...this.authState, status: 'blocked', reason: 'no-password' };
                const probe = buildProbe(this.authState);
                if (probe) {
                        const key = JSON.stringify(probe);
                        if (key !== this.lastProbeKey) {
                                await this.sendProbe(probe);
                                this.lastProbeKey = key;
                        }
                }
                this.authInternal?.notify();
                this.refreshSettingsTab();
        }

        // --- политика плагинов (v0.3, plugins.json; v0.3.5 — непрерывная регуляция) ---
        // v0.3.5: контроль больше не «одноразовое событие» при смене plugins.json.
        // Политика кэшируется локально (data.json) и применяется по СОСТОЯНИЮ:
        //   • при старте из кэша — без сети и до ввода пароля;
        //   • после каждого pull (в т.ч. 304) и на layout-ready;
        //   • вотчером каждые 20 с (Obsidian не даёт события на включение плагина);
        // выключение персистится (disablePluginAndSave, иначе вычёркивание из
        // community-plugins.json), id сверяется по manifest.id И имени папки.
        // v0.4: refreshPluginPolicy загружает plugins.json БЕЗ требования пароля (файл публичный).

        /**
         * Загружает plugins.json с канала, не требуя пользовательского пароля.
         * Файл публичный (Bearer-токен канала). Используется:
         *   • в doPullCycle ДО проверки password (P0-1.1, фикс сценария A);
         *   • в onload через bootstrapPluginPolicyFromChannel;
         *   • в applyInviteCode при применении канального кода без пароля.
         *
         * Fail-closed: при not-found/битом JSON НЕ снимает политику (P0-1.2).
         * Старая политика (если есть) остаётся активной.
         */
        private async refreshPluginPolicy(): Promise<void> {
                if (this.settings.role !== 'user' || !this.settings.channel) return;
                const client = this.makeClient();
                try {
                        const policyRes = await client.getPluginPolicy(this.pluginsEtag);
                        // v0.5.4 (репорт №4): статус plugins.json — в общий трейс-поток [pull].
                        // Раньше пул логировал только channel.json и запись пользователя:
                        // главный виновник блокировки включения (кэш forbidden-политики при
                        // 404-или-битом файле) не оставлял в консоли НИ ОДНОЙ строки.
                        this.trace('pull', `plugins.json → ${policyRes.status}${policyRes.status === 'ok'
                                ? (policyRes.policy === null
                                        ? ' (MALFORMED — cached policy kept, fail-closed)'
                                        : ` (entries=${policyRes.policy.plugins.length}, source=channel)`)
                                : policyRes.status === 'not-found' ? ' (file absent — cached policy kept, fail-closed)' : ''}`);
                        if (policyRes.status === 'ok') {
                                this.pluginsEtag = policyRes.etag;
                                // v0.5.3 (D-3): файл существует (валидный или битый) — «политика
                                // удалена с канала» больше не подозревается.
                                this.pluginsJsonMissingOnChannel = false;
                                if (policyRes.policy !== null) {
                                        await this.setPluginPolicy(policyRes.policy);
                                } else {
                                        // Битый/чужой JSON на канале — НЕ снимаем политику (fail-closed).
                                        console.warn(LOG_PREFIX, 'plugins.json on channel is malformed; cached policy remains active (fail-closed)');
                                        await pushJournalEntry(this.adapter, {
                                                ts: this.now(),
                                                kind: 'plugins',
                                                detail: 'channel plugins.json malformed — cached policy kept (fail-closed)',
                                        }).catch(() => undefined);
                                }
                        } else if (policyRes.status === 'not-found') {
                                // Файл удалён — НЕ снимаем политику БЕЗ различения «репо не виден»
                                // от «хозяин удалил политику» (это делает D-3 в doPullCycle по
                                // факту читаемого channel.json). Здесь — только помечаем факт.
                                this.pluginsJsonMissingOnChannel = true; // v0.5.3 (D-3)
                                console.warn(LOG_PREFIX, 'plugins.json not found on channel; cached policy remains active (fail-closed until channel.json confirms repo is visible)');
                                await pushJournalEntry(this.adapter, {
                                        ts: this.now(),
                                        kind: 'plugins',
                                        detail: 'channel plugins.json not found — cached policy kept (fail-closed)',
                                }).catch(() => undefined);
                        }
                        // not-modified → политика актуальна, ничего не делаем
                        if (policyRes.status === 'not-modified') this.pluginsJsonMissingOnChannel = false; // v0.5.3 (D-3): 304 ⇒ файл существует
                } catch (err) {
                        // Сеть/auth-ошибка — тихо, кэш остаётся активным.
                        console.debug(LOG_PREFIX, 'refreshPluginPolicy failed:', err instanceof Error ? err.message : String(err));
                }
        }

        /**
         * Bootstrap политики плагинов при onload — без требования пароля.
         * Идемпотентная обёртка над refreshPluginPolicy для явного вызова из onload.
         */
        private async bootstrapPluginPolicyFromChannel(): Promise<void> {
                await this.refreshPluginPolicy();
        }

        private async setPluginPolicy(policy: PluginPolicy | null): Promise<void> {
                const previousPolicy = this.pluginPolicy;
                this.pluginPolicy = policy;
                this.pluginPolicyIsBuiltin = false;  // v0.4.7: канальная политика (не встроенная)
                if (policy !== null) {
                        // v0.5 (W-C/C-4): smooth unlock при смене политики — id, который БЫЛ
                        // forbidden, а теперь нет: манифест обратно + wasEnabled-включение.
                        // Политика уже установлена (строкой выше) — интерцептор пропустит
                        // не-forbidden id; isStillForbidden страхует актуальные
                        // forbidden-записи (v0.5.6: managed-без-входа больше не держит).
                        if (previousPolicy !== null) {
                                const lower = (ids: string[]) => new Set(ids.map(i => i.toLowerCase()));
                                const prevForbidden = lower(previousPolicy.plugins
                                        .filter(p => p.action === 'forbidden')
                                        .flatMap(p => getEntryAllIds(p)));
                                // v0.5.5: режимов нет — замок следует за политикой напрямую:
                                // id, который больше не forbidden, отпирается здесь же
                                // (smooth-lock, W-C/C-4).
                                const stillForbidden = lower(policy.plugins
                                        .filter(p => p.action === 'forbidden')
                                        .flatMap(p => getEntryAllIds(p)));
                                for (const id of prevForbidden) {
                                        if (!stillForbidden.has(id) && !this.isStillForbidden(id)) {
                                                await this.unlockPlugin(id).catch(() => false);
                                        }
                                }
                        }
                        this.settings.pluginPolicyCache = policy;
                        void this.saveData(this.settings).catch(() => undefined);
                        // v0.5 (M2 §4.1): единый цикл (было: watchdog + poll + file-watch по-отдельности)
                        this.startReconciler();
                        this.installEnableInterceptor(); // v0.3.6: перехват попыток включения
                        await this.scrubCommunityPluginsFile(policy); // v0.3.6: рестарт-безопасность
                        // v0.5 (W-C/C-3): замок на ВСЕ forbidden (включая никогда
                        // не включённые — их violations-проход не видит).
                        // v0.5.5: безусловно — режимов (report/enforce) больше нет,
                        // регулировка всегда жёсткая (решение владельца).
                        await this.lockAllForbidden(policy);
                        // v0.4 (BUG-FLOW-1 fix): НЕМЕДЛЕННЫЙ enforce, не ждём watchdog 20s.
                        // Раньше уже-загруженные forbidden плагины работали 20 секунд до первого
                        // тика watchdog. Теперь — выключаются сразу после получения политики.
                        await this.enforcePluginPolicyNow().catch(() => undefined);
                } else {
                        await this.clearPluginPolicy();
                }
                // v0.5.8 (v3): политика изменилась — подпись другая, subscribeAuth
                // гвардов стреляет (flip forbidden→regulated плагин ловит мгновенно)
                this.vamBridge?.refresh();
        }

        private async clearPluginPolicy(): Promise<void> {
                this.pluginPolicy = null;
                this.pluginPolicyIsBuiltin = false;  // v0.4.7
                this.pluginPolicyStatus = null;
                this.lastPolicyKey = null;
                this.enforcedEpisodeIds.clear();
                // v0.5 (W-C/C-5): политика исчезла — замку нечего держать. Всё из реестра
                // возвращается (data-driven). Следующий enforce-такт зафиксирует цикл
                // в журнале (v0.5.6: managed-политику без входа он только выставит
                // для отслеживания — она regulated и ничего не запирает).
                await this.unlockAllPlugins('policy cleared').catch(() => 0);
                this.uninstallEnableInterceptor(); // v0.3.6: включения снова проходят
                this.lastEnableBlockedLog.clear();
                // v0.5 (M2 §4.1): reconciler НЕ останавливаем — вердикт-цикл user-role
                // продолжается (TTL/kill/expiresAt тикают); замку нечего держать — он пуст.
                if (this.settings.pluginPolicyCache !== null) {
                        this.settings.pluginPolicyCache = null;
                        void this.saveData(this.settings).catch(() => undefined);
                }
                // v0.5.8 (v3): политика снята — гварды узнают (их вердикт → allowed)
                this.vamBridge?.refresh();
                this.refreshSettingsTab();
        }

        /** v0.5.4 (D-3.1): общая точка «хозяин удалил plugins.json». Видимость репозитория
         *  доказана (channel.json читается ИЛИ запись пользователя отвечает 200/304),
         *  plugins.json при этом 404 — политика удалена хозяином, а не «репо не виден
         *  токену»: кэш снимается, замки отпираются. ETag сбрасывается: 304 сам по себе
         *  контента не несёт — вернувшийся файл обязан быть прочитан полным GET,
         *  иначе после снятия политика «потеряна навсегда» при следующем 304. */
        private async releasePolicyIfOwnerRemovedIt(visibilityProof: string): Promise<void> {
                if (!this.pluginsJsonMissingOnChannel || this.pluginPolicy === null) return;
                await this.clearPluginPolicy();
                this.pluginsJsonMissingOnChannel = false;
                this.pluginsEtag = null;
                await pushJournalEntry(this.adapter, {
                        ts: this.now(),
                        kind: 'plugins',
                        detail: `plugins.json missing + repo visible (${visibilityProof}) → administrator removed plugin policy — locks released (D-3)`,
                }).catch(() => undefined);
                this.trace('policy', `plugins.json deleted, repo visible (${visibilityProof}) — policy cleared, locks released (D-3.1)`);
                this.refreshSettingsTab();
        }

        async enforcePluginPolicyNow(): Promise<void> {
                // v0.4.7: исправление «плагины остаются запрещёнными после ввода пароля».
                // Если пользователь вошёл (userHasRights=true) и pluginPolicy — встроенная
                // (managed, не канальная) — сбросить её (v0.5.6: builtin-политика regulated,
                // сброс — вопрос отображения: вошедшему список «под контролем» не нужен).
                // Если есть канальная политика — использовать её без merge
                // (managed плагины разблокируются, если канал их явно не запретил).
                // v0.5 (M2 §4.3): права = ok ИЛИ грейс канала — enforcement не деградирует.
                const userHasRights = this.userHasRights();

                // Шаг 1: сброс встроенной политики если пользователь вошёл
                if (userHasRights && this.pluginPolicyIsBuiltin) {
                        this.pluginPolicy = null;
                        this.pluginPolicyIsBuiltin = false;
                        this.pluginPolicyStatus = null;
                        this.lastPolicyKey = null;
                        this.enforcedEpisodeIds.clear();
                        await pushJournalEntry(this.adapter, {
                                ts: this.now(), kind: 'plugins',
                                detail: 'user logged in — builtin managed policy cleared (managed plugins are regulated, not forbidden)',
                        }).catch(() => undefined);
                        // v0.5.8 (v3): вход снял builtin-политику — гварды v3 видят смену
                        this.vamBridge?.refresh();
                        this.refreshSettingsTab();
                }
                // v0.5 (W-C/C-4+C-7): мини-сверка замков с политикой — записи реестра, чьи id
                // больше не запрещены (удалены из списка / вход
                // снял managed) — unlock. Побегает и на бут-е (кэш обновился, пока Obsidian
                // был выключен, diff внутри setPluginPolicy не видел этого), и каждым
                // тактом reconciler'а (M2 §4.1 — 10 с).
                await this.reconcileLocksWithPolicy().catch(() => undefined);

                // Шаг 2: установить встроенную политику если нет прав и нет канальной политики
                if (!userHasRights && this.pluginPolicy === null) {
                        this.pluginPolicy = getBuiltinManagedPolicy();
                        this.pluginPolicyIsBuiltin = true;
                        // v0.5 (M2 §4.1): единый цикл (было: watchdog + poll + file-watch)
                        this.startReconciler();
                        this.installEnableInterceptor();
                        // v0.5.8 (v3): builtin-подпись появилась — гварды видят regulated-вердикты
                        this.vamBridge?.refresh();
                        // v0.5.6: builtin-политика — regulated-список для отслеживания
                        // (v-clone/open-llm-chat «под контролем» без входа): она НИЧЕГО не
                        // запирает — блокирует только явный forbidden в политике канала.
                }

                if (this.pluginPolicy === null) return;

                // Шаг 3: для evaluation — если !userHasRights и есть канальная политика,
                // дополнить managed (ЛОКАЛЬНО, не мутировать this.pluginPolicy).
                // v0.5.6: добавляются regulated-записи (отображение/трекинг) —
                // блокировки merge больше не добавляет.
                let evalPolicy = this.pluginPolicy;
                if (!userHasRights && !this.pluginPolicyIsBuiltin) {
                        evalPolicy = mergeWithBuiltinManagedPolicy(this.pluginPolicy);
                }

                const status = evaluatePluginPolicy(evalPolicy, await this.getEnabledPluginIds());
                this.pluginPolicyStatus = status;
                for (const id of [...this.enforcedEpisodeIds]) {
                        if (!status.violations.some((v) => v.id === id)) this.enforcedEpisodeIds.delete(id);
                }
                const key = JSON.stringify(status);
                if (key !== this.lastPolicyKey) {
                        this.lastPolicyKey = key;
                        if (!status.ok) {
                                const detail = status.violations.map((v) => `${v.id}: ${v.problem}`).join(', ');
                                await pushJournalEntry(this.adapter, { ts: this.now(), kind: 'plugins', detail: `policy violations: ${detail}` });
                                try {
                                        new Notice(`${t('ppNoticeViolations')}: ${status.violations.map((v) => v.id).join(', ')}`);
                                } catch {
                                        // нет Notice в тестовом окружении
                                }
                        }
                        this.refreshSettingsTab();
                }
                // v0.5.5: регулировка безусловна (report удалён) — forbidden-записи
                // блокируются всегда, независимо от прав. v0.5.6: права (users) вообще
                // не связаны с плагинами: managed-плагины работают и без входа,
                // права не смягчают и не ужесточают чужой запрет.
                await this.enforceViolations(status);
                await this.logUnmanagedPlugins().catch(() => undefined);
        }

        private async enforceViolations(status: PluginPolicyStatus): Promise<void> {
                // v0.4: queue с дедупликацией + staggered batch + 4-состояний модель.
                // Для каждого violation:
                //   • loaded=true  → API disable (полная блокировка рантайма)
                //   • loaded=false + saved=true → removeFromCommunityPluginsFile
                //     (плагин в файле, но не загрузился — предотвратить автозагрузку)
                //   • loaded=false + saved=false → ничего (не включён — не нарушает)
                // Stagger 40ms между операциями — не фризит UI при batch-disable 10+ плагинов.
                const presentViolations = status.violations.filter(v => v.problem === 'present');
                if (presentViolations.length === 0) return;

                const ops: Promise<void>[] = [];
                presentViolations.forEach((v, i) => {
                        const fresh = !this.enforcedEpisodeIds.has(v.id);
                        this.enforcedEpisodeIds.add(v.id);
                        const stagger = i * 40;  // 40ms между операциями
                        ops.push(this.disableForbiddenPluginQueued(v.id, fresh, stagger));
                });
                await Promise.all(ops);
                // v0.5 (M2 §4.1): rearm-сверка 3 с поглощена идемпотентным reconcile
                // (такт 10 с + raw-триггеры + single-flight). Мгновенный re-enable ловит
                // интерцептор (синхронно), обходные пути — следующий такт.
        }

        /**
         * v0.4: Disable-queue с дедупликацией.
         * Если для того же id уже идёт disable — возвращаем тот же Promise.
         * Stagger — задержка перед вызовом (для batch-операций, чтобы не фризить UI).
         */
        private async disableForbiddenPluginQueued(policyId: string, notify: boolean, staggerMs: number = 0): Promise<void> {
                // Если уже идёт — возвращаем тот же promise (дедуп)
                const existing = this.disableQueue.get(policyId);
                if (existing) return existing;

                // Stagger delay для batch
                if (staggerMs > 0) {
                        await new Promise<void>(r => setTimeout(r, staggerMs));
                }

                const p = this.disableForbiddenPlugin(policyId, notify).finally(() => {
                        this.disableQueue.delete(policyId);
                });
                this.disableQueue.set(policyId, p);
                return p;
        }

        /**
         * v0.4.1: ЭКСТРЕННАЯ блокировка уже-загруженных forbidden плагинов.
         *
         * Вызывается из onload ПЕРЕД любыми async-операциями (bootstrap, enforce).
         * Решает проблему порядка загрузки: Obsidian загружает плагины в порядке их
         * в community-plugins.json. Если менеджер идёт ПОСЛЕ forbidden плагинов, то
         * к моменту onload менеджера они уже работают. Этот метод:
         *   1. Синхронно сканирует app.plugins.plugins на наличие forbidden id
         *   2. Для каждого найденного — немедленно disablePlugin (выгрузка из рантайма)
         *   3. Запускает async-задачу: disablePluginAndSave
         *
         * ВНИМАНИЕ: не ждёт завершения — fire-and-forget. Цель: максимально быстро
         * выгрузить запрещённый плагин из рантайма. Персистентная блокировка
         * (community-plugins.json) произойдёт в фоне.
         */
        private emergencyBlockAlreadyLoadedForbidden(): void {
                // v0.4.7: если нет политики канала — используем встроенную managed-политику
                // (v-clone, open-llm-chat и aliases) при отсутствии входа. v0.5.6: она
                // regulated — emergency-блокировки managed больше нет; метод деятелен
                // только для канальной политики с forbidden-записями.
                if (!this.pluginPolicy) {
                        const userHasRights = this.userHasRights();
                        if (userHasRights) return;  // есть права — не блокируем
                        this.pluginPolicy = getBuiltinManagedPolicy();
                        this.pluginPolicyIsBuiltin = true;
                }
                // v0.5.5: report-ветка удалена — запрещённые блокируются всегда
                // (канальная политика безусловно; builtin устанавливается только без прав).
                const api = this.pluginsRuntime();
                const loadedPlugins = (api.plugins ?? {}) as Record<string, unknown>;
                const forbiddenIds = new Set<string>();
                for (const entry of this.pluginPolicy.plugins) {
                        if (entry.action === 'forbidden') {
                                // v0.4.6: добавляем id + все aliases (case-insensitive)
                                forbiddenIds.add(entry.id.toLowerCase());
                                if (entry.aliases) {
                                        for (const a of entry.aliases) forbiddenIds.add(a.toLowerCase());
                                }
                        }
                }
                if (forbiddenIds.size === 0) return;

                const toBlock: string[] = [];
                for (const key of Object.keys(loadedPlugins)) {
                        if (this.isSelfKey(key)) continue;
                        // v0.4.6: case-insensitive matching с id + aliases
                        if (forbiddenIds.has(key.toLowerCase())) {
                                toBlock.push(key);
                        }
                }
                if (toBlock.length === 0) return;

                console.warn(LOG_PREFIX, 'emergency block: forbidden plugins already loaded before manager onload:', toBlock);

                // Синхронная выгрузка из рантайма (мгновенно)
                for (const key of toBlock) {
                        try {
                                if (typeof api.disablePlugin === 'function') {
                                        // disablePlugin может вернуть Promise, но мы не ждём
                                        void Promise.resolve(api.disablePlugin(key)).catch(() => undefined);
                                }
                        } catch {
                                // продолжаем
                        }
                }

                // Async-задача: персистентная блокировка (disablePluginAndSave)
                void (async () => {
                        for (const id of toBlock) {
                                try {
                                        await this.disableForbiddenPlugin(id, false);
                                } catch (err) {
                                        console.warn(LOG_PREFIX, 'emergency disable failed for', id, err instanceof Error ? err.message : String(err));
                                }
                        }
                        // Журнал: одна запись на всю пачку
                        await pushJournalEntry(this.adapter, {
                                ts: this.now(),
                                kind: 'plugins',
                                detail: `emergency block: ${toBlock.length} forbidden plugins already loaded at manager onload`,
                        }).catch(() => undefined);
                })();
        }

        private async disableForbiddenPlugin(policyId: string, notify: boolean): Promise<void> {
                const api = this.pluginsRuntime();
                const keys = await this.resolveRuntimeKeys(policyId);
                // v0.5.1 (H-1): журнал enforcement — только по факту. Слои свершившегося:
                // disabled (S3 выгружен) / persisted (S2+файл закрыты) / locked-registry
                // (запись учёта для smooth unlock). Файлы плагина НЕ трогаем вовсе.
                // Ничего не вышло — честная запись о провале.
                let disabled = false;
                let persisted = false;
                let registered = false;
                // v0.5 (W-C/C-3): wasEnabled ДО выключения — истина о до-блокировочном
                // состоянии для smooth unlock (C-4). Захватывать ПОСЛЕ — всегда false.
                const wasEnabled = await this.wasAnyEnabled(keys);
                const epochPolicy = this.pluginPolicy !== null ? await digestPolicy(this.pluginPolicy) : '';
                // Level 1: API disable (мгновенно, через app.plugins)
                for (const key of keys) {
                        if (this.isSelfKey(key)) continue; // менеджер себя не выключает (soft-контроль §2/U3)
                        let saved = false;
                        try {
                                if (typeof api.disablePluginAndSave === 'function') {
                                        await api.disablePluginAndSave(key); // выключение + запись в community-plugins.json
                                        saved = true;
                                        disabled = true;
                                        persisted = true;
                                }
                        } catch (err) {
                                console.warn(LOG_PREFIX, 'disablePluginAndSave failed:', err instanceof Error ? err.message : String(err));
                        }
                        try {
                                if (!saved && typeof api.disablePlugin === 'function') {
                                        await api.disablePlugin(key);
                                        disabled = true;
                                }
                        } catch (err) {
                                console.warn(LOG_PREFIX, 'disablePlugin failed:', err instanceof Error ? err.message : String(err));
                        }
                        if (!saved) {
                                // v0.5 (B-5): скраб — честный Result: true только если файл РЕАЛьНО
                                // изменён (id вычеркнут). no-op (id не было) не считается действием.
                                if (await this.removeFromCommunityPluginsFile(key)) persisted = true;
                        }
                }
                // v0.5.1 (H-1): учёт замка в lock-registry (folder + manifestId + wasEnabled —
                // данные для smooth unlock и unlockAll). ФС плагина НЕ трогаем: замок живут
                // disable+scrab, переживают рестарт штатно (community-plugins.json без id +
                // plugin disabled). ПОСЛЕ disable — обратный порядок оставил бы запись без
                // свершившегося выключения. Идемпотентно: 'already-locked' — no-op (тишина).
                const target = await this.resolveLockTarget(policyId);
                if (target !== null && this.lock !== undefined) {
                        const out = await this.lock.lockFolder({
                                policyId,
                                folder: target.folder,
                                manifestId: target.manifestId,
                                wasEnabled,
                                epochPolicy,
                        });
                        registered = out.kind === 'locked';
                        // реестр-изменение — всегда в журнал (в т.ч. emergency-путь notify=false):
                        // устойчивое состояние менялось — zero-silent требует записи.
                        await this.journalLockOutcome(out, policyId).catch(() => undefined);
                        // 'degraded' уже ушёл в журнал через onEvent; 'already-locked'/'missing' — no-op (B-5).
                }
                // v0.5 (M2 §4.6, zero-silent): журнал — БЕЗУСЛОВНО, по Result (каждое
                // реальное действие ↔ запись: повторный эпизод нарушения, emergency-путь).
                // Раньше запись жила за gate notify=fresh — повторное выключение и
                // emergency-провалы молчали (найдено гейт-тестом D-6). Notice, в отличие
                // от журнала, остаётся признаком СВЕЖЕГО эпизода + дедуп 30 с (UX-шум §4.6).
                const layers: string[] = [];
                if (disabled) layers.push('disabled (runtime)');
                if (persisted) layers.push('persisted');
                if (registered) layers.push('locked (registry)');
                if (layers.length > 0) {
                        await pushJournalEntry(this.adapter, {
                                ts: this.now(),
                                kind: 'plugins',
                                detail: `forbidden plugin ${policyId}: ${layers.join(', ')}`,
                        }).catch(() => undefined);
                        if (notify) {
                                this.lockNotice(`disable:${policyId}`, `${t('ppDisabledNotice')}: ${policyId}`);
                        }
                } else {
                        await pushJournalEntry(this.adapter, {
                                ts: this.now(),
                                kind: 'plugins',
                                detail: `forbidden plugin ${policyId}: enforcement FAILED (no layer closed)`,
                        }).catch(() => undefined);
                }
        }

        // --- v0.5 (W-C/C-3): резолв цели блокировки и lock-оркестрация ---

        /** Был ли какой-либо из ключей включён (S2 или файл) — ДО выключения. */
        private async wasAnyEnabled(keys: string[]): Promise<boolean> {
                const api = this.pluginsRuntime();
                for (const key of keys) {
                        if (api.enabledPlugins?.has(key) === true) return true;
                }
                const fileIds = await this.readCommunityPluginsFile();
                return keys.some(k => fileIds.includes(k));
        }

        /** Папка+manifestId для блокировки: реестр → S2 manifests → диск (M-3:
         *  первичный ключ — manifest.id, папка из dir; переименованная папка
         *  распознаётся по манифесту внутри). */
        private async resolveLockTarget(policyId: string): Promise<{ folder: string; manifestId: string } | null> {
                if (this.lock === undefined) return null;
                // 1) реестр уже знает папку (повторная блокировка / переименование при блоке)
                const entry = await this.lock.findEntryFor(policyId);
                if (entry !== undefined) return { folder: entry.folder, manifestId: entry.manifestId };
                // 2) реестры S2: manifests[key].dir → имя фактической папки
                const manifests = this.pluginsRuntime().manifests ?? {};
                for (const [key, m] of Object.entries(manifests)) {
                        const id = typeof m?.id === 'string' ? m.id : null;
                        if (key === policyId || id === policyId) {
                                const dir = typeof m?.dir === 'string' ? m.dir : '';
                                const folder = dir !== '' ? (dir.split('/').pop() ?? key) : key;
                                const manifestId = id ?? key;
                                if (folder === this.manifest.id) return null; // self — не блокируем
                                return { folder, manifestId };
                        }
                }
                // 3) диск: папка plugins/<policyId> с манифестом (живым или нейтрализованным)
                const diskId = await this.lock.readFolderManifestId(policyId);
                if (diskId !== null) return { folder: policyId, manifestId: diskId };
                return null;
        }

        /**
         * Применить замок ко ВСЕМ forbidden политики (включая никогда не включённые —
         * их enforcement-проход по violations не видит). Идемпотентно: повторный вызов
         * по уже запертой папке = 'already-locked', no-op без журнала.
         * v0.5.5: безусловно — режимов (report/enforce) больше нет, запрет всегда
         * жёсткий (решение владельца: «регулировка всегда жёсткая»).
         */
        private async lockAllForbidden(policy: PluginPolicy): Promise<void> {
                if (this.lock === undefined) return;
                const epochPolicy = await digestPolicy(policy);
                // v0.5 (W-C/C-7): полный S1-скан — manifestId → фактическая папка. Ловит
                // переименованные/незарегистрированные папки, которые resolveLockTarget
                // (реестр → S2 → прямой probe) пропускает. Один проход на все forbidden.
                const folderById = new Map<string, string>();
                for (const folder of await this.lock.listPluginFolders()) {
                        const id = await this.lock.readFolderManifestId(folder);
                        if (id !== null) folderById.set(id.toLowerCase(), folder);
                }
                for (const entry of policy.plugins) {
                        if (entry.action !== 'forbidden') continue;
                        for (const id of getEntryAllIds(entry)) { // canonical + aliases
                                const target = await this.resolveLockTarget(id)
                                        ?? this.targetFromScan(id, folderById);
                                if (target === null) continue;
                                const wasEnabled = await this.wasAnyEnabled([id, target.folder, target.manifestId]);
                                const out = await this.lock.lockFolder({
                                        policyId: entry.id,
                                        folder: target.folder,
                                        manifestId: target.manifestId,
                                        wasEnabled,
                                        epochPolicy,
                                });
                                await this.journalLockOutcome(out, entry.id).catch(() => undefined);
                        }
                }
        }

        /** Fallback-резолв из полного скана: папка по manifestId (case-insensitive). */
        private targetFromScan(id: string, folderById: Map<string, string>): { folder: string; manifestId: string } | null {
                const folder = folderById.get(id.toLowerCase());
                return folder !== undefined ? { folder, manifestId: id } : null;
        }

        /** Журнал по Result: действие (locked) — запись; no-op — тишина. */
        private async journalLockOutcome(out: LockOutcome, policyId: string): Promise<void> {
                if (out.kind !== 'locked') return; // degraded идёт через onEvent, already/missing — не действие
                await pushJournalEntry(this.adapter, {
                        ts: this.now(),
                        kind: 'plugins',
                        detail: `forbidden plugin ${policyId}: locked (registry)`,
                }).catch(() => undefined);
        }

        // --- v0.5.1 (H-1): smooth unlock (учёт в реестре, файлы не трогались) ---

        /**
         * Разблокировать плагин: снять запись реестра; при wasEnabled — включить
         * БЕЗ рестарта Obsidian (disable→enable — штатный живой цикл, capabilities §6).
         * Манифест всю блокировку оставался на месте — бут-скан видит плагин всегда.
         * Возвращает true только при фактически снятой записи.
         */
        private async unlockPlugin(policyOrManifestId: string): Promise<boolean> {
                if (this.lock === undefined) return false;
                const entry = await this.lock.findEntryFor(policyOrManifestId);
                if (entry === undefined) return false; // не заперт — нечего делать (no-op, тишина)
                const out = await this.lock.unlockFolder(entry.folder);
                if (out.kind === 'missing-folder') {
                        // вместо тишины: честный провал + инструкция (план C-4)
                        await pushJournalEntry(this.adapter, {
                                ts: this.now(),
                                kind: 'plugins',
                                detail: `unlock failed: folder missing for '${entry.manifestId}' — reinstall required`,
                        }).catch(() => undefined);
                        try {
                                new Notice(`${t('ppUnlockFolderMissing')}: ${entry.manifestId}`);
                        } catch {
                                // нет Notice в тестовом окружении
                        }
                        return false;
                }
                if (out.kind !== 'unlocked') return false; // not-locked (heal уже в журнале) / degraded
                await pushJournalEntry(this.adapter, {
                        ts: this.now(),
                        kind: 'plugins',
                        detail: `plugin unlocked: ${entry.manifestId} (registry entry dropped)`,
                }).catch(() => undefined);
                await this.enableAfterUnlock(entry);
                return true;
        }

        /** Включение после unlock: был включён до блокировки → enablePluginAndSave
         *  (манифест на месте всю блокировку — бут-скан видит плагин всегда). */
        private async enableAfterUnlock(entry: LockRegistryEntry): Promise<void> {
                const id = entry.manifestId;
                const api = this.pluginsRuntime();
                let registered = api.manifests?.[id] !== undefined;
                if (!registered && typeof api.loadManifest === 'function') {
                        try {
                                await api.loadManifest(`${this.lockPluginsDir}/${entry.folder}`);
                                registered = api.manifests?.[id] !== undefined;
                        } catch (err) {
                                console.warn(LOG_PREFIX, 'loadManifest failed for', entry.folder, err instanceof Error ? err.message : String(err));
                        }
                }
                this.lockNotice(`unlock:${id}`, `${t('ppUnlockNotice')}: ${id}`);
                if (!registered) {
                        // карточка появится после рестарта — плагин уже «существует» на диске
                        await pushJournalEntry(this.adapter, {
                                ts: this.now(),
                                kind: 'plugins',
                                detail: `unlock: ${id} requires restart to re-register in Settings`,
                        }).catch(() => undefined);
                        return;
                }
                if (!entry.wasEnabled) {
                        // до блокировки был выключен — smooth = вернуть как было, не включать
                        return;
                }
                try {
                        if (typeof api.enablePluginAndSave === 'function') {
                                await api.enablePluginAndSave(id);
                        } else if (typeof api.enablePlugin === 'function') {
                                await api.enablePlugin(id);
                        } else {
                                throw new Error('enable API unavailable');
                        }
                        await pushJournalEntry(this.adapter, {
                                ts: this.now(),
                                kind: 'plugins',
                                detail: `plugin re-enabled after unlock: ${id}`,
                        }).catch(() => undefined);
                } catch (err) {
                        // плагин восстановлен и видим, но включить не вышло — честно
                        try {
                                new Notice(`${t('ppUnlockRestartHint')}: ${id}`);
                        } catch {
                                // нет Notice в тестовом окружении
                        }
                        await pushJournalEntry(this.adapter, {
                                ts: this.now(),
                                kind: 'plugins',
                                detail: `re-enable failed for ${id} (${err instanceof Error ? err.message : String(err)}) — enable manually after restart`,
                        }).catch(() => undefined);
                }
        }

        /** Ещё ли запрещён id СЕЙЧАС: только forbidden-записи активной политики
         *  (канальной или builtin). v0.5.6: «managed-без-входа» больше не запрещён
         *  (директива владельца) — легаси-замки на hardcoded-плагинах отпираются
         *  reconciler'ом автоматически. Используется unlock-потоками, чтобы не
         *  отпирать то, что политика держит. */
        private isStillForbidden(id: string): boolean {
                return this.isForbiddenByPolicy(id);
        }

        /** Сверка РЕЕСТРА с текущей политикой: каждая запись, чей id больше не
         *  запрещён — unlock (manifest обратно + wasEnabled-включение). */
        private async reconcileLocksWithPolicy(): Promise<void> {
                if (this.lock === undefined) return;
                const entries = await this.lock.listLocked();
                for (const entry of entries) {
                        if (this.isStillForbidden(entry.manifestId) || this.isStillForbidden(entry.folder)) continue;
                        await this.unlockPlugin(entry.manifestId).catch(() => false);
                }
        }

        /**
         * Разблокировать ВСЁ из реестра (C-5): удаление/выключение менеджера, кнопка
         * хозяина, исчезновение политики. Data-driven: у каждой записи свои folder и
         * wasEnabled — угадывать нечего. Принудительно (без isStillForbidden):
         * вызывающие контексты сами решают, что замок больше не должен держать.
         * Возвращает число фактически восстановленных.
         */
        async unlockAllPlugins(reason: string): Promise<number> {
                if (this.lock === undefined) return 0;
                const entries = await this.lock.listLocked();
                if (entries.length === 0) return 0;
                let unlocked = 0;
                for (const entry of entries) {
                        if (await this.unlockPlugin(entry.manifestId)) unlocked++;
                }
                await pushJournalEntry(this.adapter, {
                        ts: this.now(),
                        kind: 'plugins',
                        detail: `unlock-all (${reason}): ${unlocked} of ${entries.length} restored`,
                }).catch(() => undefined);
                return unlocked;
        }

        /** Список запертых (UI user-mode: что заблокировано и когда). */
        async listLockedPlugins(): Promise<LockRegistryEntry[]> {
                return this.lock?.listLocked() ?? [];
        }

        private pluginsRuntime(): ObsidianPluginsApi {
                return (this.app as { plugins?: ObsidianPluginsApi }).plugins ?? {};
        }

        /** v0.5.2: канал целиком нечитаем + сессия из remember.bin + уже был ok + kill не
         *  запинен → 404 записи канала трактуется как «канал недоступен», а не «хозяин
         *  удалил» (редьютор даёт degraded-channel; kill-пин всё равно главнее — он
         *  обрабатан выше по потоку). Свежевведённый пароль грейса не получает —
         *  при мёртвом канале он не проверен. */
        private channelGoneGrace(channelMetaMissing: boolean): boolean | undefined {
                return channelMetaMissing && this.passwordFromRemember && this.everOk && !this.killSwitchPinned ? true : undefined;
        }

        /** v0.5.2 (репорт №2): sweep вернул manifest.json на диск, но бут-скан Obsidian
         *  прошёл ДО onload — реестр S2 (app.plugins.manifests) о папках не знает:
         *  «восстановлено, но невидимо до рестарта» = для пользователя «ничего не
         *  восстановилось». loadManifests() — штатная точка пересканирования
         *  (capabilities §5; так поднимает установленное BRAT). Провал наблюдаем
         *  и не роняет boot; восстановленный forbidden запирается ниже штатными
         *  слоями (lockAllForbidden / enforcePluginPolicyNow — как и раньше). */
        private async refreshManifestsAfterSweep(restored: string[]): Promise<void> {
                const pluginsApi = this.pluginsRuntime();
                if (typeof pluginsApi.loadManifests !== 'function') {
                        await pushJournalEntry(this.adapter, {
                                ts: this.now(),
                                kind: 'plugins',
                                detail: `manifest sweep: ${restored.length} manifest(s) restored; loadManifests unavailable — visible after Obsidian restart`,
                        }).catch(() => undefined);
                        return;
                }
                try {
                        await pluginsApi.loadManifests();
                        await pushJournalEntry(this.adapter, {
                                ts: this.now(),
                                kind: 'plugins',
                                detail: `manifest sweep: manifests registry refreshed (${restored.join(', ')})`,
                        }).catch(() => undefined);
                } catch (err) {
                        await pushJournalEntry(this.adapter, {
                                ts: this.now(),
                                kind: 'plugins',
                                detail: `manifest sweep: loadManifests failed (${err instanceof Error ? err.message : String(err)}) — visible after Obsidian restart`,
                        }).catch(() => undefined);
                }
        }

        /** UX-шум (§4.6): ≤1 Notice на событие замка; повтор в окне 30 с гасится.
         *  Журнал НЕ дедупится — там каждое действие по факту (B-5). */
        private lockNotice(key: string, message: string): void {
                const last = this.lastLockNotices.get(key);
                if (last !== undefined && this.now() - last < 30_000) return;
                this.lastLockNotices.set(key, this.now());
                try {
                        new Notice(message);
                } catch {
                        // нет Notice в тестовом окружении
                }
        }

        private isSelfKey(key: string): boolean {
                const api = this.pluginsRuntime();
                return key === this.manifest.id || api.manifests?.[key]?.id === this.manifest.id;
        }

        async getEnabledPluginIds(): Promise<string[]> {
                // Канонические id включённых плагинов: manifest.id (приоритет) + имя папки.
                // Хозяин может указать любой из двух — сверка идёт по обоим.
                // v0.3.6: «включён» = загружен (app.plugins) ИЛИ в enabledPlugins ИЛИ в
                // community-plugins.json — плагин, вписанный в файл, но ещё не загрузившийся
                // (порядок старта), тоже нарушение: загрузится вот-вот или после рестарта.
                const api = this.pluginsRuntime();
                const keys = new Set<string>();
                for (const key of Object.keys(api.plugins ?? {})) keys.add(key);
                if (api.enabledPlugins) for (const key of api.enabledPlugins) keys.add(key);
                for (const key of await this.readCommunityPluginsFile()) keys.add(key);
                return this.toCanonicalIds([...keys]);
        }

        private toCanonicalIds(keys: string[]): string[] {
                const manifests = this.pluginsRuntime().manifests;
                const out = new Set<string>();
                for (const key of keys) {
                        out.add(key);
                        const mid = manifests?.[key]?.id;
                        if (typeof mid === 'string' && mid !== '') out.add(mid);
                }
                return [...out];
        }

        private async resolveRuntimeKeys(policyId: string): Promise<string[]> {
                // какие ключи рантайма (имена папок / manifest.id) соответствуют id из
                // политики; v0.3.6: источники — загруженные инстансы, enabledPlugins и файл
                // (плагин в файле, но не загрузившийся, тоже подлежит выключению).
                const api = this.pluginsRuntime();
                const candidates = new Set<string>();
                for (const key of Object.keys(api.plugins ?? {})) candidates.add(key);
                if (api.enabledPlugins) for (const key of api.enabledPlugins) candidates.add(key);
                if (candidates.size === 0) for (const key of await this.readCommunityPluginsFile()) candidates.add(key);
                const wanted = this.policyRuntimeKeys(policyId);
                return [...candidates].filter((key) => wanted.has(key));
        }

        private policyRuntimeKeys(policyId: string): Set<string> {
                // v0.3.6: все ключи рантайма, ссылающиеся на id из политики: сам id,
                // имя папки и manifest.id (папка и id могут не совпадать).
                const api = this.pluginsRuntime();
                const keys = new Set<string>([policyId]);
                for (const [folder, manifest] of Object.entries(api.manifests ?? {})) {
                        const id = typeof manifest?.id === 'string' ? manifest.id : null;
                        if (folder === policyId || id === policyId) {
                                keys.add(folder);
                                if (id !== null) keys.add(id);
                        }
                }
                return keys;
        }

        // --- v0.3.6: перехват попыток включения ---
        // Obsidian не даёт события «плагин включается» (проверено по плагин-менеджерам:
        // Lazy Plugin Loader / Plugin Groups — все управляют состоянием, никто не получает
        // событие). Единственный способ предотвратить ЗАГРУЗКУ запрещённого плагина (его
        // onload = тут же запущенная синхронизация — окно в 20 с вотчера) — обёртка над
        // app.plugins.enablePlugin / enablePluginAndSave: попытка включить запрещённый id
        // отклоняется ДО вызова оригинала, плагин не загружается вовсе. Вотчер 20 с
        // остаётся страховкой для путей мимо app.plugins (правка файла сторонним синком,
        // стартовый порядок загрузки). Выгрузка менеджера и снятие политики
        // восстанавливают оригинальные методы.

        private installEnableInterceptor(): void {
                if (this.enableInterceptorInstalled) return;
                const api = this.pluginsRuntime() as ObsidianPluginsApi & Record<string, unknown>;
                const wrap = (name: 'enablePlugin' | 'enablePluginAndSave'): boolean => {
                        const original = api[name];
                        if (typeof original !== 'function') return false;
                        const bound = (original as (this: unknown, ...args: unknown[]) => unknown).bind(api);
                        const wrapped = (id: string, ...rest: unknown[]): unknown => {
                                // v0.5.3 (репорт №3): решение интерцептора — СО следом. Раньше голый
                                // boolean: «доступ разрешён, но включение блокируется» не оставлял
                                // улик, какой слой и почему отказал. Теперь блокировка журналируется
                                // с причиной (ветка + совпавшая запись политики + статус входа).
                                const verdict = this.explainForbiddenRuntimeKey(id);
                                if (verdict.blocked) {
                                        this.trace('interceptor', `enable BLOCKED: ${id} via ${name} — ${verdict.why} | auth=${this.authState.status}${this.authState.reason !== undefined ? `(${this.authState.reason})` : ''} rights=${this.userHasRights()} policy=${this.policySourceLabel()}`);
                                        this.onForbiddenEnableAttempt(id, name, verdict.why);
                                        return Promise.resolve(); // отклонено: оригинал не вызывается, плагин не грузится
                                }
                                this.trace('interceptor', `enable allowed: ${id} — ${verdict.why}`);
                                return bound(id, ...rest);
                        };
                        api[name] = wrapped;
                        if (name === 'enablePlugin') this.originalEnable = original as (id: string) => unknown;
                        else this.originalEnableAndSave = original as (id: string) => unknown;
                        return true;
                };
                const a = wrap('enablePlugin');
                const b = wrap('enablePluginAndSave');
                this.enableInterceptorInstalled = a || b;
        }

        private uninstallEnableInterceptor(): void {
                if (!this.enableInterceptorInstalled) return;
                const api = this.pluginsRuntime() as Record<string, unknown>;
                if (this.originalEnable !== undefined) api.enablePlugin = this.originalEnable;
                if (this.originalEnableAndSave !== undefined) api.enablePluginAndSave = this.originalEnableAndSave;
                this.originalEnable = undefined;
                this.originalEnableAndSave = undefined;
                this.enableInterceptorInstalled = false;
        }

        /** v0.5.3 (репорт №3): ПОЛНЫЙ след решения интерцептора — blocked + имя ветки.
         *  История: фикс D-2 — builtin-политика не блокирует вошедшего (окно до
         *  следующего enforce-такта). v0.5.6: builtin-политика regulated — она
         *  вообще никого не блокирует; замыкает только явный forbidden канала. */
        private explainForbiddenRuntimeKey(key: string): { blocked: boolean; why: string } {
                // проверка на каждый вызов: политика и режим читаются актуальными
                const rights = this.userHasRights();
                const policy = this.pluginPolicy;
                // v0.5.3 (D-2): ветка оставлена для трейса — при правах builtin
                // игнорируется (и сбрасывается шагом 1 enforce-такта).
                // v0.5.6: builtin-записи regulated — не блокируют и без прав.
                if (policy !== null && this.pluginPolicyIsBuiltin && rights) {
                        return { blocked: false, why: 'builtin managed policy ignored: user has rights (D-2)' };
                }
                if (policy === null) {
                        if (rights) return { blocked: false, why: 'no policy + user has rights' };
                        // v0.5.6: директива владельца — hardcoded (managed) плагины больше
                        // НЕ запрещены без входа. Блокировка только из forbidden-записей
                        // политики канала; без политики не блокируется ничто.
                        return { blocked: false, why: 'no policy (managed plugins are tracked, not forbidden)' };
                }
                if (this.isSelfKey(key)) return { blocked: false, why: 'self (manager never blocks itself)' }; // soft-контроль §2/U3
                // v0.5.5: report-режим удалён — запрещённые записи канала блокируют
                // включение ВСЕГДА (в т.ч. у вошедшего пользователя: право пользования
                // плагинами выдаётся в «Пользователях», а не смягчает чужой запрет).
                const keyLower = key.toLowerCase();
                for (const entry of policy.plugins) {
                        if (entry.action !== 'forbidden') continue;
                        // v0.4.6: проверка id + aliases (case-insensitive)
                        const allIds = getEntryAllIds(entry);
                        const hit = allIds.find(id => id.toLowerCase() === keyLower);
                        if (hit !== undefined) {
                                return {
                                        blocked: true,
                                        why: `${this.pluginPolicyIsBuiltin ? 'builtin managed' : 'channel policy'} entry '${entry.id}' action=forbidden (matched '${hit}'${rights ? '' : ', NO RIGHTS'})`,
                                };
                        }
                }
                return { blocked: false, why: `no forbidden entry for '${key}'` };
        }

        /** v0.5.3: компактная метка источника политики для трейса/журнала/отчёта. */
        private policySourceLabel(): string {
                if (this.pluginPolicy === null) return 'none';
                return this.pluginPolicyIsBuiltin ? 'builtin' : 'channel';
        }

        /** v0.5.3 (репорт №3): структурный verbose-трейс полевой сборки — только консоль
         *  (журнал не забиваем: решения и так пишутся). Префикс [VaultAccessManager]
         *  фильтруется в DevTools; вызовы дешёвые — оставляем включённым всегда. */
        private trace(kind: string, msg: string): void {
                console.info(LOG_PREFIX, `[${kind}]`, msg);
        }

        private onForbiddenEnableAttempt(key: string, via: string, why: string): void {
                // журнал + Notice с дедупом 60 с на id: lazy-загрузчик, дёргающий
                // enablePlugin по расписанию, не должен заспамить ни журнал, ни пользователя
                const last = this.lastEnableBlockedLog.get(key);
                if (last !== undefined && this.now() - last < 60_000) return;
                this.lastEnableBlockedLog.set(key, this.now());
                void pushJournalEntry(this.adapter, { ts: this.now(), kind: 'plugins', detail: `enable attempt blocked: ${key} (${via}) — ${why}` }).catch(() => undefined);
                try {
                        new Notice(`${t('ppEnableBlockedNotice')}: ${key}`);
                } catch {
                        // нет Notice в тестовом окружении
                }
        }

        private async scrubCommunityPluginsFile(policy: PluginPolicy): Promise<void> {
                // v0.3.6: вычеркнуть запрещённые id из community-plugins.json при активации
                // политики — плагин не включится сам после перезапуска Obsidian. Чужие
                // записи и битый файл не трогаются (removeFromCommunityPluginsFile).
                // Плагин, включённый прямо сейчас, выключит enforce-проход —
                // disablePluginAndSave перепишет файл сам.
                for (const entry of policy.plugins) {
                        if (entry.action !== 'forbidden') continue;
                        for (const key of this.policyRuntimeKeys(entry.id)) {
                                if (this.isSelfKey(key)) continue;
                                await this.removeFromCommunityPluginsFile(key);
                        }
                }
        }

        private async readCommunityPluginsFile(): Promise<string[]> {
                try {
                        const configDir = (this.app as { vault?: { configDir?: string } }).vault?.configDir ?? '.obsidian';
                        const raw = await (this.app.vault.adapter as DataAdapter).read(`${configDir}/community-plugins.json`);
                        const parsed: unknown = JSON.parse(raw);
                        if (Array.isArray(parsed)) return parsed.filter((x): x is string => typeof x === 'string');
                } catch {
                        // нет файла — включённых плагинов нет
                }
                return [];
        }

        private async removeFromCommunityPluginsFile(key: string): Promise<boolean> {
                // фолбэк-персистенция: вычеркнуть id из community-plugins.json. Битый или
                // отсутствующий файл не трогаем — не портим чужие данные.
                // v0.5 (B-5): возвращает true только при фактическом изменении файла.
                try {
                        const configDir = (this.app as { vault?: { configDir?: string } }).vault?.configDir ?? '.obsidian';
                        const path = `${configDir}/community-plugins.json`;
                        const raw = await (this.app.vault.adapter as DataAdapter).read(path);
                        const parsed: unknown = JSON.parse(raw);
                        if (!Array.isArray(parsed)) return false;
                        const filtered = parsed.filter((x) => x !== key);
                        if (filtered.length === parsed.length) return false;
                        await (this.app.vault.adapter as DataAdapter).write(path, JSON.stringify(filtered, null, 2));
                        return true;
                } catch {
                        // файла нет или он не JSON — плагин включён только в рантайме, вычёркивать нечего
                        return false;
                }
        }

        // --- v0.5 (M2 §4.1): reconciler — ОДИН цикл вместо 4 таймеров ---
        //
        // ТРИГГЕРЫ (§4.1): 'raw'-событие ФС (debounce 500 мс) | изменение политики
        // (pull: setPluginPolicy/enforce-шаги зовут reconcile немедленно) | такт 10 с |
        // boot | onExternalSettingsChange (наш data.json правили извне).
        // Свойства: идемпотентность (повторный прогон = noop в журнале), single-flight
        // (параллельные вызовы ждут тот же прогон — M-13 дедуп по конструкции),
        // self-heal (любой рассинхрон чинится следующим тактом), деградация наблюдаема
        // (degraded-watcher/degraded-enforcement — журнал).
        //
        // Поглощены: poll 2 с (enabledPlugins), file-watch 5 с, watchdog 20 с,
        // rearm-сверка 3 с. Сетевые таймеры (pull 5 мин / owner-scan 60 с /
        // approval-poll 30 с) — НЕ enforcement, живут как были. Интерцептор
        // enablePlugin — синхронный слой UI-защиты, остаётся (§4.1, «интерцептор»).

        /**
         * Один проход сверки «желаемое × фактическое». Порядок шагов важен:
         *   1. вердикт вычисляем (§4.2) — kill/expiresAt/TTL локально, без сети;
         *   2. self-heal реестра замка — безусловно (структура не зависит от политики);
         *   3. новые/возвращённые запрещённые папки — идемпотентный замок (D-3);
         *   4. регуляция по состоянию — violations + мини-сверка замков + unmanaged.
         * Каждый шаг ловит свои ошибки сам: цикл не прерывается (частичный провал =
         * следующая попытка тактом, zero-silent — по факту в журнал).
         */
        async reconcile(trigger: 'tick' | 'raw' | 'policy' | 'external-settings' | 'boot'): Promise<void> {
                // single-flight: параллельный вызов ждёт ТЕ ЖЕ вычисления, не дублирует
                if (this.reconcileInFlight) return this.reconcileInFlight;
                const run = this.doReconcile(trigger)
                        .catch((err) => {
                                console.warn(LOG_PREFIX, `reconcile (${trigger}) failed:`, err instanceof Error ? err.message : String(err));
                        })
                        .finally(() => {
                                this.reconcileInFlight = null;
                        });
                this.reconcileInFlight = run;
                return run;
        }

        private async doReconcile(_trigger: string): Promise<void> {
                await this.tickVerdict();
                if (this.lock !== undefined) {
                        // v0.5.1 (H-1): только структурное самолечение реестра —
                        // policy-unlock — прерогатива reconcileLocksWithPolicy (единый
                        // путь с wasEnabled-включением)
                        await this.lock.syncRegistry().catch(() => undefined);
                        await this.lockNewForbiddenFolders().catch(() => undefined);
                }
                await this.enforcePluginPolicyNow().catch(() => undefined);
        }

        /**
         * Шаг 3 reconcile: новые/возвращённые папки с манифестом запрещённого id —
         * замок (нейтрализация + write-ahead). Идемпотентен: уже запертая папка →
         * 'already-locked' (no-op, тишина), поэтому полный скан дешевле поддержки
         * снапшотов имён (v0.4 поддерживал lastPluginsDirSnapshot — удалён).
         * Ловит: установку плагина, «sync принёс запрещённую папку в сессию» (D-3),
         * возврат папки из-под замка с переименованием. v0.5.5: безусловно —
         * режимов больше нет, запрет всегда держит замок.
         */
        private async lockNewForbiddenFolders(): Promise<void> {
                if (this.lock === undefined || this.pluginPolicy === null) return;
                const epochPolicy = await digestPolicy(this.pluginPolicy);
                for (const folder of await this.lock.listPluginFolders()) {
                        if (folder === this.manifest.id) continue; // self — никогда
                        const manifestId = await this.lock.readFolderManifestId(folder);
                        if (manifestId === null) continue; // не плагин (или мусор)
                        const entry = this.findForbiddenEntryFor(manifestId, folder);
                        if (entry === null) continue;
                        // новая папка не может быть включённой в S2/S3 — но файл мог
                        // прилететь синком с уже-вписанным id: честно захватываем состояние
                        const wasEnabled = await this.wasAnyEnabled([manifestId, folder]);
                        const out = await this.lock.lockFolder({
                                policyId: entry.id,
                                folder,
                                manifestId,
                                wasEnabled,
                                epochPolicy,
                        });
                        await this.journalLockOutcome(out, entry.id).catch(() => undefined);
                }
        }

        /** Такт 10 с + подписка на raw. Старт идемпотентен; вызывается из user-role
         *  бут-путей, установки политики и builtin-ветки — лишний вызов безопасен. */
        private startReconciler(): void {
                this.subscribeRawEvents();
                if (this.reconcileTimer !== null) return;
                this.reconcileTimer = Number(
                        globalThis.setInterval(() => void this.reconcile('tick').catch(() => undefined), RECONCILE_TICK_MS),
                );
                this.registerInterval(this.reconcileTimer);
        }

        private stopReconciler(): void {
                if (this.reconcileTimer !== null) {
                        globalThis.clearInterval(this.reconcileTimer);
                        this.reconcileTimer = null;
                }
                if (this.reconcileDebounceTimer !== null) {
                        globalThis.clearTimeout(this.reconcileDebounceTimer);
                        this.reconcileDebounceTimer = null;
                }
                this.rawUnsub?.();
                this.rawUnsub = null;
        }

        /**
         * Платформенные триггеры (§4.1): десктоп — vault.on('raw') с фильтром путей
         * по pluginsDir (образец — hot-reload/BRAT, capabilities §7). Мобайл/нет API —
         * тихо, такт 10 с страхует. Linux-нюанс: события о новых ПОДпапках plugins/
         * приходят только после явного adapter.startWatchPath(pluginsFolder) —
         * feature-detect; метод бросает → деградация наблюдаема (журнал), такт живёт.
         */
        private subscribeRawEvents(): void {
                if (this.rawUnsub !== null) return;
                const vault = this.app.vault as {
                        on?: (name: string, cb: (file: string, data: unknown) => void) => unknown;
                        offref?: (ref: unknown) => void;
                };
                if (typeof vault.on !== 'function') return; // мобайл-семантика — без raw
                const handler = (file: string): void => {
                        if (!file.startsWith(`${this.lockPluginsDir}/`)) return; // только plugins/
                        this.scheduleReconcileDebounced();
                };
                let ref: unknown;
                try {
                        ref = vault.on('raw', handler);
                } catch {
                        return; // ватчер не завёлся — такт 10 с страхует
                }
                this.rawUnsub = () => {
                        try {
                                (vault.offref as ((r: unknown) => void) | undefined)?.(ref);
                        } catch {
                                // уже снят платформой
                        }
                };
                const adapter = this.app.vault.adapter as { startWatchPath?: (p: string) => void };
                if (typeof adapter.startWatchPath === 'function') {
                        try {
                                adapter.startWatchPath(this.lockPluginsDir);
                        } catch (err) {
                                void pushJournalEntry(this.adapter, {
                                        ts: this.now(),
                                        kind: 'config',
                                        detail: `degraded-watcher: startWatchPath failed (${err instanceof Error ? err.message : String(err)}) — relying on 10s reconcile tick`,
                                }).catch(() => undefined);
                        }
                }
        }

        /** Дребезг raw-событий: один reconcile на серию (окно 500 мс). */
        private scheduleReconcileDebounced(): void {
                if (this.reconcileDebounceTimer !== null) return;
                this.reconcileDebounceTimer = Number(globalThis.setTimeout(() => {
                        this.reconcileDebounceTimer = null;
                        void this.reconcile('raw').catch(() => undefined);
                }, RECONCILE_RAW_DEBOUNCE_MS));
        }

        /**
         * v0.5 (M2 §4.1): наш data.json изменён извне (партнёрский синк / вторая копия
         * Obsidian). Дёшево и полезно: цикл прогонится, подлечит рассинхрон замка и
         * реестра. Новая политика из data.json применяется штатно — pull'ом или
         * рестартом (честная граница; raw-событие по тому же файлу дойдёт и так).
         */
        onExternalSettingsChange(): void {
                this.scheduleReconcileDebounced();
        }

        /** forbidden-запись политики, которой принадлежит id/папка (case-insensitive). */
        private findForbiddenEntryFor(...ids: string[]): { id: string } | null {
                if (this.pluginPolicy === null) return null;
                const wanted = new Set(ids.map(i => i.toLowerCase()));
                for (const entry of this.pluginPolicy.plugins) {
                        if (entry.action !== 'forbidden') continue;
                        if (getEntryAllIds(entry).some(id => wanted.has(id.toLowerCase()))) {
                                return { id: entry.id };
                        }
                }
                return null;
        }

        // --- v0.4: auto-discovery новых (unmanaged) плагинов ---
        /**
         * При каждом enforcePluginPolicyNow логировать установленные плагины,
         * которые не упомянуты в политике. Помогает хозяину при аудите.
         */
        private async logUnmanagedPlugins(): Promise<void> {
                if (!this.pluginPolicy) return;
                const installed = Object.keys(this.pluginsRuntime().manifests ?? {});
                const mentioned = new Set(this.pluginPolicy.plugins.map(p => p.id));
                const unknown = installed.filter(id => !mentioned.has(id) && id !== this.manifest.id);
                if (unknown.length === 0) {
                        this.lastUnknownPluginsKey = null;
                        return;
                }
                const key = JSON.stringify(unknown);
                if (key === this.lastUnknownPluginsKey) return;
                this.lastUnknownPluginsKey = key;
                await pushJournalEntry(this.adapter, {
                        ts: this.now(),
                        kind: 'plugins',
                        detail: `unmanaged plugins detected: ${unknown.join(', ')}`,
                }).catch(() => undefined);
        }

        /**
         * Проверка: является ли id запрещённым политикой (с учётом aliases, case-insensitive).
         * v0.4.6: добавлена поддержка aliases и case-insensitive matching.
         */
        private isForbiddenByPolicy(id: string): boolean {
                if (!this.pluginPolicy) return false;
                if (this.isSelfKey(id)) return false;
                const idLower = id.toLowerCase();
                return this.pluginPolicy.plugins.some(p => {
                        if (p.action !== 'forbidden') return false;
                        const allIds = getEntryAllIds(p);
                        return allIds.some(aid => aid.toLowerCase() === idLower);
                });
        }

        getPluginPolicyInfo(): { policy: PluginPolicy | null; status: PluginPolicyStatus | null } {
                // для вкладки настроек: политика === null → блок «Контроль плагинов» скрыт
                return { policy: this.pluginPolicy, status: this.pluginPolicyStatus };
        }

        /** v0.5.5: снимок реестра hook-плагинов для вкладки настроек (обе роли).
         *  active=true — гвард зарегистрировался в этой сессии (плагин загружен). */
        listHookPlugins(): HookRegistrySnapshot[] {
                return this.hookRegistry?.list() ?? [];
        }

        // --- быстрое подключение одним кодом (v0.3, VAMI1) ---

        async applyInviteCode(code: string): Promise<string | null> {
                // null = применено; строка = ошибка (quickBadCode / quickNotUser / channelBadUrl).
                const payload = decodeInvite(code);
                if (payload === null) return t('quickBadCode');
                if (this.settings.role !== 'user') return t('quickNotUser');
                // 1. канал: URL собираем из кода, токен — из кода или уже настроенный
                const token = payload.token ?? this.settings.channel?.token ?? '';
                const urlError = await this.saveChannel(repoUrlFromCfg(payload), token);
                if (urlError !== null) return urlError;
                // 2. идентификатор (смена идентичности инвалидирует 304-кэш — см. saveIdentifier)
                if (payload.identifier) await this.saveIdentifier(payload.identifier);
                // 3. пароль: PASSWORD_TYPED → pull; при уже-ok (noChange) страхуемся ручным pull
                if (payload.password) {
                        await this.submitPassword(payload.password);
                        await this.runPullCycle({ context: 'typed', trigger: 'manual' }); // дедуп внутри
                } else if (this.password === null) {
                        // v0.4 (P0-1.4): Загрузить политику плагинов даже без пароля.
                        // Файл публичный, перехватчик начнёт работать до ввода пароля.
                        void this.bootstrapPluginPolicyFromChannel().catch(() => undefined);
                        // v0.3.3: канальный код без пароля — заявка требует пароля (proof),
                        // а UI раньше об этом молчал. Подталкиваем вводом дефолтного пароля.
                        try {
                                new Notice(t('quickNeedPassword'));
                        } catch {
                                // нет Notice в тестовом окружении
                        }
                        this.openPasswordModal('first');
                } else {
                        // v0.4: пароль уже есть в памяти, но в коде VAMI1 его нет —
                        // запускаем pull, чтобы вердикт обновился для нового канала.
                        await this.runPullCycle({ context: 'typed', trigger: 'manual' });
                }
                this.refreshSettingsTab();
                return null;
        }

        makeUserInviteCode(identifier: string, password: string): string | null {
                // Хозяйская сторона: одна строка = канал + логин + пароль. null = канал не настроен.
                const cfg = this.settings.channel;
                if (!cfg || !identifier.trim() || !password) return null;
                return buildUserInvite(cfg, identifier.trim(), password);
        }

        makeChannelInviteCode(): string | null {
                // Канальный код без логина/пароля — для самостоятельных заявок (авто-подтверждение).
                const cfg = this.settings.channel;
                if (!cfg) return null;
                return buildChannelInvite(cfg);
        }

        // --- идентичность устройства (v0.6, M4 «device binding light») ---

        getDeviceIdentitySync(): DeviceIdentity | null {
                // для UI (модалки онбординга/предупреждение о привязке): результат
                // резолва, уже случившегося при onload
                return this.deviceIdentity;
        }

        /** v0.6 (M4): текущее ожидание — зачисление УСТРОЙСТВА (не первичная заявка)?
         *  UI показывает точное сообщение вместо общего «ждём подтверждения». */
        isDeviceMismatchPending(): boolean {
                return this.deviceMismatchActive;
        }

        /** Явное задание идентичности (инъекция для тестов/UI). null — «эта машина
         *  без биндинга» (мобильная семантика). Приоритетнее автосбора. */
        applyDeviceIdentity(identity: DeviceIdentity | null): void {
                this.deviceIdentity = identity;
                this.deviceResolved = true;
        }

        async resolveDeviceIdentity(): Promise<DeviceIdentity | null> {
                if (this.deviceResolved) return this.deviceIdentity;
                this.deviceResolved = true; // один резолв за сессию — секрет и отпечаток стабильны
                if (this.deviceIdentity !== null) return this.deviceIdentity;
                try {
                        const signals = collectDeviceSignals();
                        if (signals === null) return null; // не desktop (мобильные/песочница)
                        let scope: DeviceSecretScope = 'app-root';
                        let secret: Uint8Array | null = null;
                        const appRoot = this.appRootSecretAdapter();
                        if (appRoot !== null) {
                                try {
                                        secret = await ensureDeviceSecret(appRoot);
                                } catch {
                                        secret = null;
                                }
                        }
                        if (secret === null) {
                                // app-root недоступен (серая зона платформы) — секрет в папке
                                // плагина: биндинг слабеет до vault-scoped, но не ломается
                                scope = 'plugin-folder';
                                secret = await ensureDeviceSecret(this.adapter);
                        }
                        const deviceId = await computeDeviceId(secret, fingerprintString(signals));
                        this.deviceIdentity = { deviceId, deviceName: signals.hostname, scope };
                        this.trace('device', `identity resolved: ${deviceId} (${this.deviceIdentity.deviceName}, secret ${scope})`);
                        return this.deviceIdentity;
                } catch (err) {
                        this.trace('device', `identity resolve failed: ${err instanceof Error ? err.message : String(err)}`);
                        return null;
                }
        }

        private appSupportDir(): string | null {
                // корень Obsidian-как-приложения (не хранилища): там живёт obsidian.json.
                // Только desktop; окружение достаём через window.require-мир, НЕ через
                // голый process (в тестах process есть — нельзя трогать реальную ФС).
                const req = nodeRequire();
                if (req === null) return null;
                try {
                        const proc = req('process') as { env?: Record<string, string | undefined>; platform?: string } | undefined;
                        const env = proc?.env;
                        if (!env) return null;
                        if (env.APPDATA) return `${env.APPDATA}/obsidian`;
                        const home = env.HOME ?? env.USERPROFILE ?? null;
                        if (home === null) return null;
                        const platform = proc?.platform ?? '';
                        if (platform === 'darwin') return `${home}/Library/Application Support/obsidian`;
                        return `${env.XDG_CONFIG_HOME ?? `${home}/.config`}/obsidian`;
                } catch {
                        return null;
                }
        }

        private appRootSecretAdapter(): DataAdapter | null {
                // device.bin ВНЕ хранилища (app-root): копия vault секрет не уносит,
                // все хранилища машины делят один deviceId. Любая ошибка — null
                // (вызывающий откатится на папку плагина). Серая зона: работа с ФС
                // через Electron-require, не через vault.adapter.
                const req = nodeRequire();
                if (req === null) return null;
                const dir = this.appSupportDir();
                if (dir === null) return null;
                try {
                        const fs = req('fs') as {
                                promises: {
                                        readFile(path: string, enc: string): Promise<string>;
                                        writeFile(path: string, data: string, enc: string): Promise<void>;
                                        unlink(path: string): Promise<void>;
                                        access(path: string): Promise<void>;
                                        mkdir(path: string, opts: { recursive: boolean }): Promise<void>;
                                };
                        };
                        const exists = async (p: string): Promise<boolean> => {
                                try {
                                        await fs.promises.access(p);
                                        return true;
                                } catch {
                                        return false;
                                }
                        };
                        return {
                                read: (p) => fs.promises.readFile(`${dir}/${p}`, 'utf8'),
                                write: async (p, d) => {
                                        await fs.promises.mkdir(dir, { recursive: true });
                                        await fs.promises.writeFile(`${dir}/${p}`, d, 'utf8');
                                },
                                remove: async (p) => {
                                        try {
                                                await fs.promises.unlink(`${dir}/${p}`);
                                        } catch {
                                                // молча
                                        }
                                },
                                exists: (p) => exists(`${dir}/${p}`),
                                mkdir: async () => {
                                        await fs.promises.mkdir(dir, { recursive: true });
                                },
                        };
                } catch {
                        return null;
                }
        }

        // --- заявки (FR-4/5) ---

        /**
         * v0.5 (B-3): единая точка подачи заявки «с нуля» (онбординг). Канал —
         * обязательный ПЕРВЫЙ шаг: валидируется и сохраняется до всего остального.
         * Закрывает C-3: раньше модала без канала показывала «Заявка отправлена»,
         * а PUT физически не мог произойти (doPullCycle выходит без channel) —
         * вечный checking и ложный Notice. Теперь:
         *   • null = заявка ушла (awaiting-approval, PUT подтверждён);
         *   • строка = ошибка; Notice о результате шлёт pushRegistrationRequest
         *     СТРОГО по факту PUT — UI сам ничего не «обещает».
         */
        async submitAccessRequest(rawUrl: string, token: string, identifier: string, password: string): Promise<string | null> {
                if (!rawUrl.trim() || !token.trim() || !identifier.trim() || !password) {
                        return t('onbAllFieldsRequired');
                }
                if (parseRepoUrl(rawUrl) === null) {
                        return t('channelBadUrl');
                }
                this.applyRole('user');
                const urlError = await this.saveChannel(rawUrl, token);
                if (urlError !== null) return urlError;
                await this.saveIdentifier(identifier.trim());
                this.lastRequestError = null; // дальше — только фактический исход PUT
                await this.submitPassword(password); // → pull → USER_NOT_FOUND → push-request
                // ВАЖНО (сердце C-3): saveIdentifier уже перевёл статус в 'checking'
                // (CONFIGURED), а PASSWORD_TYPED из 'checking' — no-op без pull. Без
                // явного запуска заявка физически не уходит — вечный checking. Запускаем
                // цикл сами; runPullCycle дедуплицирован (pullInFlight).
                await this.runPullCycle({ context: 'typed', trigger: 'manual' });
                if (this.authState.status === 'awaiting-approval' && this.lastRequestError === null) {
                        return null; // заявка физически доставлена в канал
                }
                return this.lastRequestError ?? t('noticeRequestFailed');
        }

        private async pushRegistrationRequest(): Promise<void> {
                if (!this.settings.channel || !this.settings.identifier || !this.settings.derivedUserId) return;
                if (this.password === null) return; // proof нужен пароль (дефолтный) — спросим модалкой
                const client = this.makeClient();
                try {
                        // v0.6 (M4): заявка несёт устройство (desktop) — «вход с нового девайса»
                        // для хозяина и зачисление при одобрении; mobile — v1-заявка без полей.
                        // v0.6.2: повторное использование кода (эпизод mismatch-а с непустым
                        // реестром) — reuse=true: заявка-уведомление не удаляется сканом.
                        const identity = await this.resolveDeviceIdentity();
                        const device = identity !== null ? { id: identity.deviceId, name: identity.deviceName } : undefined;
                        const reuse = this.pendingDeviceReuse === true;
                        await buildAndPushRequest(client, this.settings.identifier, this.settings.derivedUserId, this.password, { now: () => this.now() }, device, reuse);
                        this.lastRequestError = null;
                        try {
                                new Notice(t('noticeRequestSent'));
                        } catch {
                                // нет Notice в тестовом окружении
                        }
                        await this.dispatch({ type: 'REQUEST_PUSHED', now: this.now() });
                        await pushJournalEntry(this.adapter, { ts: this.now(), kind: 'request', detail: `request pushed for ${this.settings.derivedUserId}` });
                } catch (err) {
                        // v0.3.3: раньше здесь был только console.warn — статус уже показывал
                        // «заявка отправлена, ждём подтверждения» (переход в awaiting-approval
                        // происходит по USER_NOT_FOUND ещё ДО фактической отправки), а PUT молча
                        // падал (сеть/токен без записи/409) — репозиторий не менялся, UI врал.
                        // Теперь: причина видна в Notice + в блоке «Заявка» + в журнале.
                        const msg = err instanceof Error ? err.message : String(err);
                        this.lastRequestError = msg;
                        console.warn(LOG_PREFIX, 'push request failed:', msg);
                        try {
                                new Notice(t('noticeRequestFailed'));
                        } catch {
                                // нет Notice в тестовом окружении
                        }
                        await pushJournalEntry(this.adapter, { ts: this.now(), kind: 'request', detail: `request push FAILED for ${this.settings.derivedUserId}: ${msg}` });
                }
        }

        getLastRequestError(): string | null {
                return this.lastRequestError;
        }

        async resendRequest(): Promise<void> {
                // FR-5: пароль в памяти — сразу новая заявка; иначе модалка (пароль нужен для proof)
                if (this.password !== null) {
                        await this.pushRegistrationRequest();
                } else {
                        this.openPasswordModal('first');
                }
        }

        // --- пароль (FR-9/13/27/28) ---

        async submitPassword(password: string): Promise<void> {
                this.password = password;
                // v0.5.3 (D-4, репорт №3): введённый пароль, СОВПАВШИЙ с remember.bin —
                // локально подтверждённая сессия. Раньше offline-грейс требовал
                // passwordFromRemember, а тот ставился только ПОСЛЕ сетевого ok →
                // «ввёл правильный пароль, а канал мёртв (404)» = USER_NOT_FOUND →
                // blocked(revoked) — жёсткая причина, которую память не поднимает.
                // Теперь совпадение с remember.bin — достаточное локальное доказательство
                // (файл пишется только после верифицированного входа).
                if (this.settings.derivedUserId !== null && !this.passwordFromRemember) {
                        try {
                                const remembered = await readRemember(this.adapter);
                                if (remembered !== null
                                        && remembered.userId === this.settings.derivedUserId
                                        && remembered.password === password) {
                                        this.passwordFromRemember = true;
                                        this.trace('auth', 'typed password matches remember.bin — offline grace eligible (D-4)');
                                        void pushJournalEntry(this.adapter, {
                                                ts: this.now(),
                                                kind: 'config',
                                                detail: 'typed password matches remember.bin — offline grace eligible (D-4)',
                                        }).catch(() => undefined);
                                }
                        } catch {
                                // remember.bin не читается — не критично, грейса не будет
                        }
                }
                if (this.settings.remember && this.settings.derivedUserId) {
                        try {
                                await writeRemember(this.adapter, { userId: this.settings.derivedUserId, password });
                        } catch {
                                // молча: remember не критичен
                        }
                }
                await this.dispatch({ type: 'PASSWORD_TYPED' });
        }

        async forgetPassword(): Promise<void> {
                await this.dispatch({ type: 'PASSWORD_FORGOTTEN' });
                this.password = null;
                this.passwordFromRemember = false; // v0.5.2: сессия памяти сброшена — грейс недоступен
        }

        setRemember(enabled: boolean): void {
                this.settings.remember = enabled;
                this.settings.rememberOptOut = !enabled; // v0.5.1 (H-2): явное «нет» — автозапоминание не поднимет
                if (enabled && this.password !== null && this.settings.derivedUserId) {
                        // v0.5.2: явно включённое «запомнить» с проверенным паролем — сессия
                        // считается запомненной (offline-грейс доступен).
                        this.passwordFromRemember = true;
                        void writeRemember(this.adapter, { userId: this.settings.derivedUserId, password: this.password }).catch(() => undefined);
                } else if (!enabled) {
                        this.passwordFromRemember = false;
                        void forgetRemember(this.adapter);
                }
                void this.saveData(this.settings).catch(() => undefined);
        }

        /** v0.5.1 (H-2): первый успешный вход — запомнить «до отзыва», если пользователь
         *  явно не отказывался (rememberOptOut). Лечит легаси remember:false (дефолт
         *  старых установок): один повторный ввод пароля — и больше не спрашиваем.
         *  Выключается только явным тумблером настроек. */
        private maybeAutoRemember(): void {
                if (this.settings.role !== 'user') return;
                if (this.settings.remember) return; // уже включено
                if (this.settings.rememberOptOut) return;
                if (this.password === null || this.settings.derivedUserId === null) return;
                this.settings.remember = true;
                void writeRemember(this.adapter, { userId: this.settings.derivedUserId, password: this.password })
                        .then(() => {
                                this.passwordFromRemember = true; // v0.5.2: пароль в памяти — грейс доступен
                                return pushJournalEntry(this.adapter, {
                                        ts: this.now(),
                                        kind: 'config',
                                        detail: 'remember auto-enabled (default: keep session until administrator revokes)',
                                });
                        })
                        .catch(() => undefined);
                void this.saveData(this.settings).catch(() => undefined);
        }

        /** v0.5.1 (H-3): снапшот для window.__VAM__ (машиночитаемые коды — не i18n,
         *  локализует потребитель hook'а). Семантика: доступ ограничен/менеджер не
         *  настроен → blocked; boot-гонка/заявка → pending; права есть → granted.
         *  v0.5.8 (v3): дополнен auth-частью (роль/авторизованность) и подписью
         *  политики — по ним subscribeAuth гвардов детектит смену политики без
         *  смены auth-вердикта. */
        private vamGateSnapshot(): VamGateSnapshot {
                const gate = this.vamGateCore();
                return {
                        ...gate,
                        auth: {
                                role: this.settings.role === 'owner' || this.settings.role === 'user' ? this.settings.role : 'unconfigured',
                                authenticated: this.settings.role === 'owner' || (this.settings.role === 'user' && this.userHasRights()),
                                gate: gate.status,
                                reason: gate.reason,
                                managerVersion: this.manifest.version,
                        },
                        policySignature: this.vamPolicySignature(),
                };
        }

        /** Чистая auth-ось гейта (v0.5.1 семантика — без v3-полей). */
        private vamGateCore(): { status: 'granted' | 'blocked' | 'pending'; reason: string | null } {
                if (this.settings.role === 'owner') return { status: 'granted', reason: null };
                if (this.settings.role !== 'user') return { status: 'blocked', reason: 'unconfigured' };
                if (this.userHasRights()) return { status: 'granted', reason: null };
                const st = this.authState.status;
                if (st === 'awaiting-approval' || st === 'checking') return { status: 'pending', reason: 'awaiting-approval' };
                if (st === 'unconfigured') return { status: 'blocked', reason: 'unconfigured' };
                return { status: 'blocked', reason: this.authState.reason ?? 'no-password' };
        }

        /** v0.5.8 (v3): подпись текущей политики — меняется при любом изменении
         *  записей (id/алиасы/действия) или источника. subscribeAuth-события гвардов
         *  детектят смену политики даже когда auth-ось не шевельнулась. */
        private vamPolicySignature(): string {
                if (this.pluginPolicy === null) return 'none';
                const src = this.pluginPolicyIsBuiltin ? 'builtin' : 'channel';
                const parts = this.pluginPolicy.plugins
                        .map(e => `${getEntryAllIds(e).join('/').toLowerCase()}=${e.action}`)
                        .sort();
                return `${src}|${parts.join(',')}`;
        }

        /** v0.5.8 (M3, v3): пер-плагинный вердикт для window.__VAM__.getPermission(id).
         *  Семантика согласована с интерцептором (explainForbiddenRuntimeKey):
         *  • owner/unconfigured — политики нет, вердикт allowed (гейт всё равно скажет);
         *  • плагин вне записей — allowed с указанием источника консультируемой политики;
         *  • запись найдена (id или alias, case-insensitive) — её действие + пометка.
         *  Директива v0.5.6 соблюдена: builtin-политика отдаёт regulated, не forbidden. */
        private vamPermissionFor(rawPluginId: string): VamPermissionState {
                const id = typeof rawPluginId === 'string' ? rawPluginId.trim() : '';
                if (id === '') return { permission: 'allowed', source: 'none', note: null };
                if (this.settings.role !== 'user') return { permission: 'allowed', source: 'none', note: null };
                if (this.isSelfKey(id)) return { permission: 'allowed', source: 'none', note: null };
                const policy = this.pluginPolicy;
                if (policy === null) return { permission: 'allowed', source: 'none', note: null };
                const source = this.pluginPolicyIsBuiltin ? 'builtin' : 'channel';
                const idLower = id.toLowerCase();
                for (const entry of policy.plugins) {
                        const hit = getEntryAllIds(entry).find(a => a.toLowerCase() === idLower);
                        if (hit !== undefined) {
                                return { permission: entry.action, source, note: entry.note !== '' ? entry.note : null };
                        }
                }
                return { permission: 'allowed', source, note: null };
        }

        // --- v0.5.3 (репорт №3): глубокая диагностика ---

        /**
         * Полный отчёт «почему доступ/включение ведут себя именно так» для поля.
         * Собирает ВСЕ входы каждого решения: вердикт FSM, источник политики,
         * решение интерцептора на сегодня для каждого известного id, реестр замка,
         * community-plugins.json, что видит hook (window.__VAM__), remember.bin
         * (только факт), хвост журнала — и живой probe канала теми же запросами,
         * что делает продакшн-pull (фактические URL + HTTP-коды). Отчёт:
         *   • в консоль (построчно, префикс [VaultAccessManager]);
         *   • в файл VAM-diagnostics.txt в папке менеджера (переживает рестарт);
         *   • в модалку с кнопкой Copy (пользователь шлёт текст хозяину/разработчику).
         * Секреты не покидают машину: пароль не собирается вовсе, токен маскируется.
         */
        async runDiagnostics(): Promise<string> {
                const started = this.now();
                this.trace('diag', 'diagnostics started');

                // 1. живой probe канала (тем же клиентом, что и pull — одинаковые URL/ретраи)
                let channelProbe: ChannelProbeLine[] | null = null;
                if (this.settings.channel !== null) {
                        try {
                                channelProbe = await probeChannelConnectivity(this.makeClient(), this.settings.derivedUserId);
                        } catch (err) {
                                this.trace('diag', `channel probe crashed: ${err instanceof Error ? err.message : String(err)}`);
                        }
                }

                // 2. remember.bin — только существование + совпадение userId (пароль НЕ собираем)
                let rememberBin: { exists: boolean; userIdMatch: boolean } | null = null;
                try {
                        const secret = await readRemember(this.adapter);
                        rememberBin = {
                                exists: secret !== null,
                                userIdMatch: secret !== null && secret.userId === this.settings.derivedUserId,
                        };
                } catch {
                        rememberBin = null;
                }

                // 3. хвост журнала (кольцо 100 — берём последние 30)
                const journal = await readJournalTail(this.adapter, 30).catch(() => []);

                // 4. таблица решений интерцептора: все id, о которых знает рантайм
                const ids = new Set<string>();
                const api = this.pluginsRuntime();
                for (const key of Object.keys(api.plugins ?? {})) ids.add(key);
                for (const key of Object.keys(api.manifests ?? {})) ids.add(key);
                if (api.enabledPlugins) for (const key of api.enabledPlugins) ids.add(key);
                for (const key of await this.readCommunityPluginsFile()) ids.add(key);
                ids.delete(this.manifest.id); // self — всегда allow, в таблице неинтересно
                const interceptor: InterceptorDecision[] = [...ids].sort().map((id) => {
                        const v = this.explainForbiddenRuntimeKey(id);
                        return { id, blocked: v.blocked, why: v.why };
                });

                // 5. реестр замка (null = модуль недоступен; [] — успешно прочитан и пуст)
                let lockEntries: LockRegistryEntry[] | null = null;
                if (this.lock !== undefined) {
                        lockEntries = await this.lock.listLocked().catch(() => null);
                }

                const syncInfo = this.getSyncPluginInfo();
                const inp: DiagnosticsInput = {
                        generatedAt: this.now(),
                        managerVersion: this.manifest.version,
                        settings: this.settings,
                        authState: this.authState,
                        userHasRights: this.userHasRights(),
                        passwordInMemory: this.password !== null,
                        passwordFromRemember: this.passwordFromRemember,
                        everOk: this.everOk,
                        killSwitchPinned: this.killSwitchPinned,
                        ttlHours: this.ttlHours,
                        verdictExpiresAt: this.verdictExpiresAt,
                        metaEtag: this.metaEtag,
                        pluginsEtag: this.pluginsEtag,
                        pluginPolicy: this.pluginPolicy,
                        pluginPolicyIsBuiltin: this.pluginPolicyIsBuiltin,
                        lockEntries,
                        communityPlugins: await this.readCommunityPluginsFile().catch(() => null),
                        gate: this.vamGateSnapshot(),
                        rememberBin,
                        syncPlugin: { present: syncInfo.present, perSession: syncInfo.perSession, minManagerVersion: this.getMinManagerVersion() },
                        journal,
                        interceptor,
                        channelProbe,
                        lastRequestError: this.lastRequestError,
                        reasonText: this.authState.reason !== undefined ? t(REASON_KEY[this.authState.reason]) : '',
                };

                const report = renderDiagnosticsReport(inp);

                // 6. консоль — построчно, чтобы DevTools читались без горизонтального скролла
                for (const ln of report.split('\n')) console.info(LOG_PREFIX, ln);

                // 7. файл в папку менеджера (не попадает в синк vault, переживает рестарт)
                const DIAG_FILE = 'VAM-diagnostics.txt';
                try {
                        await this.adapter.write(DIAG_FILE, report);
                } catch (err) {
                        this.trace('diag', `failed to write ${DIAG_FILE}: ${err instanceof Error ? err.message : String(err)}`);
                }

                await pushJournalEntry(this.adapter, {
                        ts: this.now(),
                        kind: 'config',
                        detail: `diagnostics report generated (${this.now() - started}ms, channel probe: ${channelProbe === null ? 'skipped (no channel)' : channelProbe.map((l) => `${l.path}=${l.outcome}`).join(', ')})`,
                }).catch(() => undefined);
                this.trace('diag', `report ready: ${this.manifest.dir}/${DIAG_FILE}`);

                // 8. модалка с полным текстом + Copy (то, что пользователь шлёт обратно)
                try {
                        new DiagnosticsModal(this.app, report, `${this.manifest.dir}/${DIAG_FILE}`).open();
                } catch {
                        // тестовое окружение без Modal — отчёт уже в консоли и файле
                }
                return report;
        }

        // --- identity (FR-2) ---

        async saveIdentifier(identifier: string): Promise<void> {
                const trimmed = identifier.trim();
                this.settings.identifier = trimmed || null;
                this.settings.derivedUserId = trimmed ? await shortHashIdentifier(trimmed) : null;
                this.authState.userId = this.settings.derivedUserId ?? undefined;
                // смена идентичности инвалидирует 304-кэш
                this.lastPayload = null;
                this.metaEtag = null;
                await this.saveData(this.settings);
                if (this.isUserIdentityReady() && this.authState.status === 'unconfigured') {
                        await this.dispatch({ type: 'CONFIGURED' });
                }
                // v0.4 (BUG-FLOW-3 fix): всегда bootstrap политику при готовой идентичности.
                // Раньше: если status !== 'unconfigured' (например, 'ok' из кэша),
                // dispatch CONFIGURED — no-op, и политика НЕ загружалась до таймера 5 мин.
                // Теперь: bootstrap запускается независимо от статуса.
                if (this.isUserIdentityReady()) {
                        void this.bootstrapPluginPolicyFromChannel().catch(() => undefined);
                }
                this.refreshSettingsTab();
        }

        async saveChannel(rawUrl: string, token: string): Promise<string | null> {
                // null = сохранено; строка = ошибка формата (channelBadUrl)
                if (rawUrl.trim()) {
                        const parsed = parseRepoUrl(rawUrl);
                        if (!parsed) return t('channelBadUrl');
                        this.settings.channel = { ...parsed, token: token.trim() || this.settings.channel?.token || '' };
                } else if (this.settings.channel) {
                        this.settings.channel = { ...this.settings.channel, token: token.trim() || this.settings.channel.token };
                }
                await this.saveData(this.settings);
                if (this.settings.role === 'owner') this.ensureAutoApprove(); // v0.3.6: канал появился — авто-скан заработает в этой же сессии
                if (this.isUserIdentityReady() && this.authState.status === 'unconfigured') {
                        await this.dispatch({ type: 'CONFIGURED' });
                }
                // v0.4 (BUG-FLOW-3 fix): всегда bootstrap политику при готовой идентичности.
                // Раньше: если status !== 'unconfigured', политика НЕ загружалась.
                if (this.isUserIdentityReady()) {
                        void this.bootstrapPluginPolicyFromChannel().catch(() => undefined);
                }
                this.refreshSettingsTab();
                return null;
        }

        private isUserIdentityReady(): boolean {
                return this.settings.role === 'user' && !!this.settings.channel && !!this.settings.identifier && !!this.settings.derivedUserId;
        }

        // --- probe-мост (FR-16) ---

        private async sendProbe(probe: ManagerProbe): Promise<void> {
                try {
                        const syncPlugin = getSyncPlugin(this.app);
                        if (syncPlugin && typeof syncPlugin.applyManagerProbe === 'function') {
                                await syncPlugin.applyManagerProbe(probe);
                        }
                } catch (err) {
                        console.warn(LOG_PREFIX, 'applyManagerProbe failed:', err instanceof Error ? err.message : String(err));
                }
                await pushJournalEntry(this.adapter, {
                        ts: this.now(),
                        kind: 'probe',
                        detail: probe.present ? (probe.authOk ? 'probe: ok' : `probe: blocked (${probe.reason})`) : 'probe: manager unloaded',
                });
        }

        private sendProbeSync(probe: ManagerProbe): void {
                // onunload синхронный: вызов без await, ошибки глотаются (NFR-7)
                try {
                        const syncPlugin = getSyncPlugin(this.app);
                        if (syncPlugin && typeof syncPlugin.applyManagerProbe === 'function') {
                                void syncPlugin.applyManagerProbe(probe).catch(() => undefined);
                        }
                } catch {
                        // тихо
                }
        }

        private resendProbeIfNeeded(): void {
                // §3.6-3: синк-плагин перезагрузился и потерял вердикт при нашем ok — шлём повторно
                if (this.authState.status !== 'ok') return;
                try {
                        const hook = (typeof window !== 'undefined'
                                ? (window as unknown as { vaultSync?: { getState(): { governance?: { status?: string } } | null } }).vaultSync
                                : undefined);
                        const governance = hook?.getState?.()?.governance;
                        if (governance?.status === 'blocked') {
                                const probe = buildProbe(this.authState);
                                if (probe) {
                                        void this.sendProbe(probe);
                                        this.lastProbeKey = JSON.stringify(probe);
                                }
                        }
                } catch {
                        // нет хука — живём на таймере
                }
        }

        // --- подписка на window.vaultSync (FR-18) ---

        private subscribeVaultSyncHook(): void {
                try {
                        const hook = (typeof window !== 'undefined'
                                ? (window as unknown as {
                                                vaultSync?: {
                                                        getState(): { lastSyncAt?: number } | null;
                                                        onChanged(cb: () => void): () => void;
                                                };
                                  }).vaultSync
                                : undefined);
                        if (!hook || typeof hook.onChanged !== 'function') return; // §3.6-4: живём на таймере
                        this.lastSyncAtSeen = hook.getState()?.lastSyncAt ?? null;
                        this.unsubVaultSync = hook.onChanged(() => {
                                try {
                                        const s = hook.getState();
                                        if (s && typeof s.lastSyncAt === 'number' && s.lastSyncAt !== this.lastSyncAtSeen) {
                                                this.lastSyncAtSeen = s.lastSyncAt;
                                                void this.runPullCycle({ context: 'background', trigger: 'onchanged' });
                                        }
                                } catch {
                                        // тихо
                                }
                        });
                } catch {
                        // нет хука — живём на таймере
                }
        }

        // --- таймеры ---

        private async onPullTimer(): Promise<void> {
                try {
                        this.resendProbeIfNeeded();
                        await this.runPullCycle({ context: 'background', trigger: 'timer' });
                } catch (err) {
                        console.warn(LOG_PREFIX, 'pull timer failed:', err instanceof Error ? err.message : String(err));
                }
        }

        private async onOwnerScanTimer(): Promise<void> {
                try {
                        if (this.settings.role !== 'owner' || !this.settings.channel || !this.settings.autoApprove || !this.settings.defaultPassword) return;
                        const client = this.makeClient();
                        await this.runAutoApproveScan(client);
                } catch (err) {
                        console.warn(LOG_PREFIX, 'owner scan failed:', err instanceof Error ? err.message : String(err));
                        // v0.5 (M2 §4.3, M-5): 401/403 на хозяйской машине = PAT истёк — это про
                        // хозяина, только он может починить. Notice (один раз за сессию) + журнал:
                        // «Notice хозяину при следующем входе» — вот он. Юзеры в это время живут
                        // грейсом (degraded-channel), их доступ не отрубается одним битым токеном.
                        if (classifyChannelFailure(err) === 'auth') {
                                await pushJournalEntry(this.adapter, {
                                        ts: this.now(),
                                        kind: 'config',
                                        detail: 'channel auth failed (PAT expired?) — update token in settings',
                                }).catch(() => undefined);
                                if (!this.channelAuthNotified) {
                                        this.channelAuthNotified = true;
                                        try {
                                                new Notice(t('noticeChannelAuth'));
                                        } catch {
                                                // нет Notice в тестовом окружении
                                        }
                                }
                        }
                }
        }

        // --- v0.3.6: авто-подтверждение в той же сессии, где задан дефолтный пароль ---

        ensureAutoApprove(): void {
                // Жалоба: «дефолтный пароль для авто-подключения не сохраняется». Пароль
                // сохранялся в data.json, но авто-подтверждение не работало до перезапуска
                // Obsidian: таймер скана заявок ставился только на onload и только при
                // полностью настроенном канале. Теперь: таймер гарантируется при любом
                // изменении хозяйских настроек, а сразу за изменением — отложенный
                // (дебаунс 1.5 с) одиночный скан: заявка подтверждается без перезапуска.
                if (this.settings.role !== 'owner') return;
                this.ensureOwnerScanTimer();
                if (this.settings.channel && this.settings.autoApprove && this.settings.defaultPassword) {
                        this.scheduleAutoScan();
                }
        }

        private ensureOwnerScanTimer(): void {
                if (this.ownerScanTimer !== null || this.settings.role !== 'owner') return;
                this.ownerScanTimer = Number(globalThis.setInterval(() => void this.onOwnerScanTimer(), OWNER_SCAN_MS));
                this.registerInterval(this.ownerScanTimer);
        }

        private scheduleAutoScan(): void {
                if (this.autoScanDebounce !== null) globalThis.clearTimeout(this.autoScanDebounce);
                this.autoScanDebounce = Number(
                        globalThis.setTimeout(() => {
                                this.autoScanDebounce = null;
                                void this.scanRequestsOnce().catch(() => undefined);
                        }, AUTO_SCAN_DEBOUNCE_MS),
                );
        }

        private startApprovalPolling(): void {
                if (this.approvalPollTimer !== null) return;
                this.approvalPollDeadline = this.now() + APPROVAL_POLL_MAX_MS;
                this.approvalPollTimer = Number(
                        globalThis.setInterval(() => {
                                if (this.now() > this.approvalPollDeadline) {
                                        this.stopApprovalPolling(); // дальше — страховка таймера 5 минут
                                        return;
                                }
                                void this.runPullCycle({ context: 'background', trigger: 'timer' });
                        }, APPROVAL_POLL_MS),
                );
        }

        private stopApprovalPolling(): void {
                if (this.approvalPollTimer !== null) {
                        globalThis.clearInterval(this.approvalPollTimer);
                        this.approvalPollTimer = null;
                }
        }

        // --- кэш / VerdictSnapshot (M2 §4.2) ---

        /** Снапшот текущего вердикта — единый источник для persist и тика. */
        private currentSnapshot(): VerdictSnapshot {
                return buildSnapshot({
                        status: this.authState.status,
                        reason: this.authState.reason,
                        checkedAt: this.authState.checkedAt,
                        ttlHours: this.ttlHours,
                        expiresAt: this.verdictExpiresAt,
                        killSwitch: this.killSwitchPinned,
                        // v0.5.1 (H-2): запомненная сессия — «до отзыва», TTL не гасит
                        hasRemember: this.settings.remember === true && this.password !== null,
                });
        }

        /**
         * Тик вычисляемого вердикта (план §4.2): ЧИСТАЯ функция над снапшотом, диспатч —
         * только при реальном изменении (идемпотентно: повторный тик на уже-blocked
         * состоянии не порождает новых событий). Вызывается reconciler'ом (такт 10 с)
         * и падением pull'а — правила проверяются ЛОКАЛЬНО, без сети.
         */
        private async tickVerdict(): Promise<void> {
                if (this.settings.role !== 'user') return; // вердикт существует только у пользователя
                const computed = computeVerdict(this.currentSnapshot(), this.now());
                if (computed.verdict !== 'blocked') return;
                const st = this.authState;
                if (computed.reason === 'kill-switch') {
                        if (st.status !== 'blocked') await this.dispatch({ type: 'KILL_SWITCH' });
                        return;
                }
                if (computed.reason === 'expired') {
                        if (st.reason !== 'expired') await this.dispatch({ type: 'ACCESS_EXPIRED' });
                        return;
                }
                if (computed.reason === 'ttl') {
                        // ok без доказуемой свежести / после грейса — одно событие, дальше тишина
                        if (st.status !== 'blocked' || st.reason !== 'ttl') await this.dispatch({ type: 'TTL_EXPIRED' });
                        return;
                }
                // иные blocked-причины уже в состоянии (M-15: регидрированы из снапшота) — их
                // источник — канал, не тик: ждём pull, локально не «лечим».
        }

        private async persistCache(): Promise<void> {
                // v0.5 (M2 §4.2): персистится ВЕСЬ снапшот (B-1/B-2 — поля ttlHours/killSwitch
                // сохранены как были, добавлены reason/expiresAt/policyDigest — М-15/М-4/анти-откат).
                const snapshot = this.currentSnapshot();
                const policyDigest = this.settings.pluginPolicyCache !== null
                        ? await digestPolicy(this.settings.pluginPolicyCache).catch(() => null)
                        : null;
                this.settings.cache = {
                        publicStatus: toPublicStatus(this.authState),
                        checkedAt: this.authState.checkedAt,
                        channelHead: this.authState.channelHead,
                        ttlHours: this.ttlHours,
                        killSwitch: this.killSwitchPinned,
                        reason: snapshot.reason,
                        expiresAt: snapshot.expiresAt,
                        policyDigest,
                        // v0.5.1 (H-2): рестарт восстанавливает и «запомненность» —
                        // TTL не гасит запомненную сессию и после рестарта
                        remembered: this.settings.remember === true && this.password !== null,
                };
                await this.saveData(this.settings);
        }

        // --- UI-точки входа ---

        openPasswordModal(mode: 'first' | 'rotation' | 'retry'): void {
                try {
                        new PasswordModal(this.app, this, mode).open();
                } catch {
                        // нет DOM (тестовое окружение)
                }
        }

        openOnboarding(): void {
                try {
                        new OnboardingModal(this.app, this).open();
                } catch {
                        // нет DOM
                }
        }

        refreshSettingsTab(): void {
                try {
                        this.settingsTab?.display();
                } catch {
                        // вкладка не открыта
                }
        }

        // --- v0.5 (M2 §4.4, Р6): порядок загрузки — «VAM первым» ---

        /**
         * Одноразовое предложение хозяину: VAM не первым в community-plugins.json →
         * спросить ОТКРЫТО (ConfirmModal с кнопкой). Решение (любое) фиксируется
         * флагом миграции — повторных вопросов и тихих правок нет (Р6).
         * Возвращает решение (наблюдаемость/тесты):
         *   'skip'      — не хозяин (юзеру не предлагаем: низкая грамотность = случайный клик);
         *   'done'      — уже спрашивали (флаг стоит);
         *   'not-first' — VAM уже первый / выключен / файла нет — предлагать нечего;
         *   'offered'   — модалка показана, флаг зафиксирован.
         */
        async maybeOfferVamFirst(): Promise<'skip' | 'done' | 'not-first' | 'offered'> {
                if (this.settings.role !== 'owner') return 'skip';
                if (this.settings.migrations.vamFirstPromptDone) return 'done';
                const ids = await this.readCommunityPluginsFile();
                const pos = ids.indexOf(this.manifest.id);
                if (pos <= 0) return 'not-first'; // 0 = уже первый; -1 = выключен/файла нет
                // одноразово: флаг ставится при ПРЕДЛОЖЕНИИ, отказ тоже закрывает вопрос
                this.settings.migrations.vamFirstPromptDone = true;
                void this.saveData(this.settings).catch(() => undefined);
                try {
                        new ConfirmModal(
                                this.app,
                                t('vamFirstTitle'),
                                t('vamFirstBody', pos + 1),
                                () => {
                                        void this.applyVamFirstBootOrder().catch(() => undefined);
                                },
                        ).open();
                } catch {
                        // нет DOM в тестовом окружении — решение (флаг) уже зафиксировано
                }
                return 'offered';
        }

        /**
         * Перенос своего id в начало community-plugins.json — ОТКРЫТО: правка файла +
         * запись в журнал + Notice (Р6: «правка выполняется открыто и попадает в журнал;
         * повторных тихих правок нет»). Идемпотентен: уже первый → false без записей.
         */
        async applyVamFirstBootOrder(): Promise<boolean> {
                const ids = await this.readCommunityPluginsFile();
                const pos = ids.indexOf(this.manifest.id);
                if (pos <= 0) return false;
                const configDir = (this.app as { vault?: { configDir?: string } }).vault?.configDir ?? '.obsidian';
                const path = `${configDir}/community-plugins.json`;
                const reordered = [this.manifest.id, ...ids.filter((i) => i !== this.manifest.id)];
                try {
                        await (this.app.vault.adapter as DataAdapter).write(path, JSON.stringify(reordered, null, 2));
                } catch (err) {
                        await pushJournalEntry(this.adapter, {
                                ts: this.now(),
                                kind: 'config',
                                detail: `boot order change FAILED: cannot write community-plugins.json (${err instanceof Error ? err.message : String(err)})`,
                        }).catch(() => undefined);
                        try {
                                new Notice(t('opFailed'));
                        } catch {
                                // нет Notice в тестовом окружении
                        }
                        return false;
                }
                await pushJournalEntry(this.adapter, {
                        ts: this.now(),
                        kind: 'config',
                        detail: `boot order: '${this.manifest.id}' moved to first position (was #${pos + 1}) in community-plugins.json`,
                }).catch(() => undefined);
                try {
                        new Notice(t('vamFirstDone'));
                } catch {
                        // нет Notice в тестовом окружении
                }
                return true;
        }

        applyRole(role: 'user' | 'owner'): void {
                this.settings.role = role;
                void this.saveData(this.settings).catch(() => undefined);
                void pushJournalEntry(this.adapter, { ts: this.now(), kind: 'config', detail: `role set: ${role}` });
                if (role === 'owner') this.ensureAutoApprove();
                // v0.4.7: для user-role — немедленно применить контроль: hardcoded-плагины
                // попадают в список «под контролем» даже без канала (v0.5.6: без блокировки).
                if (role === 'user') {
                        this.installEnableInterceptor();
                        this.startReconciler(); // v0.5 (M2 §4.1): единый цикл
                        this.emergencyBlockAlreadyLoadedForbidden();
                        void this.enforcePluginPolicyNow().catch(() => undefined);
                }
                this.refreshSettingsTab();
        }

        // --- диагностика ---

        getSyncPluginInfo(): SyncPluginInfo {
                const syncPlugin = getSyncPlugin(this.app);
                if (!syncPlugin) return { present: false, version: null, perSession: false };
                const version = typeof syncPlugin.manifest?.version === 'string' ? syncPlugin.manifest.version : null;
                return {
                        present: true,
                        version,
                        perSession: version !== null && semverCompare(version, '3.2.0') >= 0,
                };
        }

        getMinManagerVersion(): string | null {
                return this.lastMinManagerVersion;
        }

        getTtlHours(): number {
                return this.ttlHours;
        }

        // --- хозяйские операции (FR-20..26) ---

        makeClient(): ChannelClient {
                return new ChannelClient(this.settings.channel as ChannelCfg, { fetchImpl: this.deps.fetchImpl, sleep: this.deps.sleep, now: this.deps.now });
        }

        now(): number {
                return this.deps.now?.() ?? Date.now();
        }

        getPluginAdapter(): DataAdapter {
                return this.adapter;
        }

        async testChannel(): Promise<{ ok: boolean; message: string }> {
                // Проверка в две фазы. Фаза 1 (чтение) — ловит пустой репозиторий (409) и
                // kill-switch. Фаза 2 (запись) — read-only токен прочитает канал, но «Выдать /
                // Отозвать / kill-switch» упадут на PUT/DELETE позже; поэтому проверяем сразу:
                // probe-файл создаётся и удаляется, в истории репозитория останется пара
                // коммитов «channel write test» — это нормально.
                const WRITE_PROBE_PATH = 'manager-write-test.tmp';
                const client = this.makeClient();
                try {
                        const meta = await client.getChannelMeta();
                        if (meta.status === 'ok' && meta.meta.killSwitch) {
                                return { ok: false, message: t('reasonKillSwitch') };
                        }
                } catch (err) {
                        return { ok: false, message: this.channelTestHint(err, false) };
                }
                try {
                        await client.putFile(WRITE_PROBE_PATH, new TextEncoder().encode(`probe ${this.now()}`), 'Vault Access Manager: channel write test');
                        await client.deleteFile(WRITE_PROBE_PATH, 'Vault Access Manager: channel write test');
                } catch (err) {
                        return { ok: false, message: this.channelTestHint(err, true) };
                }
                return { ok: true, message: t('channelTestOkWrite') };
        }

        private channelTestHint(err: unknown, writePhase: boolean): string {
                // Классификация сбоев → конкретная подсказка хозяину (аудит workflow: раньше
                // все ошибки сваливались в безликое «Проверка канала не удалась»).
                switch (classifyChannelFailure(err)) {
                        case 'auth':
                                return writePhase ? t('channelTestErrWrite') : t('channelTestErrAuth');
                        case 'empty-repo':
                                return t('channelTestErrEmpty');
                        case 'repo-missing':
                                return t('channelTestErrNotFound');
                        case 'network':
                                return t('channelTestErrNet');
                        default:
                                return writePhase ? t('channelTestErrWrite') : t('channelTestFail');
                }
        }

        async issueAccess(identifier: string, password: string, expiresAt: number | null, note?: string, envelope?: { iterations?: number; salt?: Uint8Array; nonce?: Uint8Array }, maxDevices?: number): Promise<OwnerUserMeta> {
                // envelope — служебный параметр для быстрых интеграционных тестов.
                // v0.6 (M4): запись активируется с реестром устройств (maxDevices,
                // default 2). v0.6.1: под капом новые устройства с верным паролем
                // зачисляются сами (приглашение = выданный пароль); сверх лимита —
                // заявка хозяину. 0/отрицательное = «без реестра» (v1-запись, как раньше).
                const devices: DeviceBinding[] | undefined = maxDevices !== undefined && maxDevices >= 1 ? [] : undefined;
                const limit = devices !== undefined ? (maxDevices ?? DEFAULT_MAX_DEVICES) : undefined;
                const client = this.makeClient();
                const meta = await issueUserRecord(client, { identifier, password, expiresAt, note, devices, maxDevices: limit }, { now: () => this.now(), envelope });
                await saveOwnerUserMeta(this.adapter, meta);
                await pushJournalEntry(this.adapter, { ts: this.now(), kind: 'owner', detail: `issued access ${meta.userId} (${meta.note})${devices !== undefined ? `, device registry armed (max ${limit})` : ''}` });
                return meta;
        }

        /** v0.6 (M4): реестр устройств записи — из самой записи (источник истины),
         *  расшифровка дефолтным паролем; недоступна/ротация — локальный кэш users-local.
         *  Возврат undefined = v1-запись без реестра (не активирована). */
        private async currentDeviceRegistry(userId: string, password: string | null, metaDevices: DeviceBinding[] | undefined, metaMax: number | undefined, envelope?: { iterations?: number; salt?: Uint8Array; nonce?: Uint8Array }): Promise<{ devices?: DeviceBinding[]; maxDevices?: number }> {
                if (password === null) return { devices: metaDevices, maxDevices: metaMax };
                try {
                        const res = await this.makeClient().getUserRecord(userId);
                        if (res.status !== 'ok') return { devices: metaDevices, maxDevices: metaMax };
                        const payload = await decryptUserRecord(password, userId, res.bytes, envelope?.iterations !== undefined ? { iterations: envelope.iterations } : undefined);
                        return { devices: payload.devices, maxDevices: payload.maxDevices };
                } catch {
                        // запись не расшифровывается этим паролем (ротация) — кэш
                        return { devices: metaDevices, maxDevices: metaMax };
                }
        }

        async rotateAccess(meta: OwnerUserMeta, newPassword: string, envelope?: { iterations?: number; salt?: Uint8Array; nonce?: Uint8Array }): Promise<OwnerUserMeta> {
                const client = this.makeClient();
                // v0.6 (M4): реестр устройств ПЕРЕНОСИТСЯ при смене пароля — смена пароля
                // не устраивает волну device-mismatch (сброс устройств — отдельное явное
                // действие). Источник: расшифровка текущей записи дефолтным паролем,
                // fallback — кэш users-local; оба молчат → v1-запись как была.
                const registry = await this.currentDeviceRegistry(meta.userId, this.settings.defaultPassword, meta.devices, meta.maxDevices, envelope);
                const updated = await issueUserRecord(
                        client,
                        { identifier: meta.note, userId: meta.userId, password: newPassword, expiresAt: meta.expiresAt, note: meta.note, permissions: meta.permissions, devices: registry.devices, maxDevices: registry.maxDevices },
                        { now: () => this.now(), envelope },
                );
                await saveOwnerUserMeta(this.adapter, updated);
                await pushJournalEntry(this.adapter, { ts: this.now(), kind: 'rotation', detail: `rotated password for ${meta.userId}${registry.devices === undefined ? ' (no device registry)' : ` (devices kept: ${registry.devices.length})`}` });
                return updated;
        }

        async reissueAccess(meta: OwnerUserMeta, newPassword: string, expiresAt: number | null, envelope?: { iterations?: number; salt?: Uint8Array; nonce?: Uint8Array }): Promise<OwnerUserMeta> {
                // Переиздание = новая запись: expiresAt обновляется, файл перешифровывается НОВЫМ паролем
                // (старый пароль хозяину неизвестен — §7.2; новый передаётся пользователю лично).
                // v0.6 (M4): реестр устройств переносится — как у rotateAccess.
                const client = this.makeClient();
                const registry = await this.currentDeviceRegistry(meta.userId, this.settings.defaultPassword, meta.devices, meta.maxDevices, envelope);
                const updated = await issueUserRecord(
                        client,
                        { identifier: meta.note, userId: meta.userId, password: newPassword, expiresAt, note: meta.note, permissions: meta.permissions, devices: registry.devices, maxDevices: registry.maxDevices },
                        { now: () => this.now(), envelope },
                );
                await saveOwnerUserMeta(this.adapter, updated);
                await pushJournalEntry(this.adapter, { ts: this.now(), kind: 'owner', detail: `re-issued access ${meta.userId}` });
                return updated;
        }

        async revokeAccess(userId: string): Promise<void> {
                const client = this.makeClient();
                await client.deleteFile(`users/${userId}.enc`, `Vault Access Manager: revoke access ${userId}`);
                await removeOwnerUserMeta(this.adapter, userId);
                await pushJournalEntry(this.adapter, { ts: this.now(), kind: 'owner', detail: `revoked access ${userId}` });
        }

        async approveRequest(summary: RequestSummary, password: string, envelope?: { iterations?: number; salt?: Uint8Array; nonce?: Uint8Array }): Promise<OwnerUserMeta> {
                const client = this.makeClient();
                // v0.6 (M4): заявка с устройства → запись сразу с зачисленным устройством
                // («код выдан администратором — данные привязываются к устройству»);
                // mobile-заявка — v1-запись без реестра, как раньше.
                const devices = summary.deviceId !== undefined
                        ? [{ id: summary.deviceId, name: summary.deviceName ?? '', addedAt: this.now() }]
                        : undefined;
                const meta = await issueUserRecord(client, { identifier: summary.identifier, userId: summary.userId, password, expiresAt: null, devices, maxDevices: devices !== undefined ? DEFAULT_MAX_DEVICES : undefined }, { now: () => this.now(), envelope });
                await client.deleteFile(`requests/${summary.fileName}`, 'Vault Access Manager: approve request');
                await saveOwnerUserMeta(this.adapter, meta);
                await pushJournalEntry(this.adapter, { ts: this.now(), kind: 'approve', detail: `approved ${summary.identifier} (${summary.userId})${summary.deviceId !== undefined ? `, device ${summary.deviceName ?? ''} bound` : ''}` });
                return meta;
        }

        /** v0.6 (M4): одобрить заявку «вход с нового устройства» — переиздать запись
         *  пользователя с добавленным устройством (пароль записи вводит хозяин).
         *  Ошибки наружу: DecryptError (неверный пароль), EnrollLimitError (лимит). */
        async approveDeviceAccess(summary: RequestSummary, password: string, envelope?: { iterations?: number; salt?: Uint8Array; nonce?: Uint8Array }): Promise<OwnerUserMeta> {
                const meta = await approveDeviceEnrollment(this.makeClient(), summary, password, this.adapter, { now: () => this.now(), envelope });
                return meta;
        }

        /** v0.6 (M4): «сбросить устройства» — переиздать запись с ПУСТЫМ реестром и
         *  ручным режимом (v0.6.1: autoEnroll=false — само-зачисление выключено, иначе
         *  сброс был бы бессмыслен: устройства вернулись бы сами за секунду): каждое
         *  новое устройство — только заявкой и одобрением (кража/продажа ПК). Вернуть
         *  авто-режим — смена/переиздание пароля (инцидент закрыт, старый пароль мёртв).
         *  Требует пароль записи (переиздание). */
        async resetDevicesAccess(meta: OwnerUserMeta, password: string, envelope?: { iterations?: number; salt?: Uint8Array; nonce?: Uint8Array }): Promise<OwnerUserMeta> {
                const client = this.makeClient();
                const registry = await this.currentDeviceRegistry(meta.userId, password, meta.devices, meta.maxDevices, envelope);
                const updated = await issueUserRecord(
                        client,
                        { identifier: meta.note, userId: meta.userId, password, expiresAt: meta.expiresAt, note: meta.note, permissions: meta.permissions, devices: [], maxDevices: registry.maxDevices ?? DEFAULT_MAX_DEVICES, autoEnroll: false },
                        { now: () => this.now(), envelope },
                );
                await saveOwnerUserMeta(this.adapter, updated);
                await pushJournalEntry(this.adapter, { ts: this.now(), kind: 'device', detail: `devices reset for ${meta.userId} (was ${(registry.devices ?? []).length}) — manual enrollment ON` });
                return updated;
        }

        async rejectRequest(summary: RequestSummary): Promise<void> {
                const client = this.makeClient();
                await client.deleteFile(`requests/${summary.fileName}`, 'Vault Access Manager: reject request');
                await pushJournalEntry(this.adapter, { ts: this.now(), kind: 'request', detail: `rejected ${summary.identifier} (${summary.userId})` });
        }

        async scanRequestsOnce(envelope?: { iterations?: number; salt?: Uint8Array; nonce?: Uint8Array }): Promise<void> {
                if (!this.settings.channel || !this.settings.defaultPassword) return;
                const client = this.makeClient();
                await this.runAutoApproveScan(client, envelope);
        }

        /** v0.6.2: скан + НЕМОЛЧАЩЕЕ уведомление о повторном использовании кода.
         *  Директива владельца: заявки с reuse=true обязаны достучаться до
         *  администратора — скан оставляет их в очереди и поднимает Notice
         *  (дедуп: свежий users-local = уведомление уже поднято, повтор тихий).
         *  Журнал пишет сам скан; Notice — здесь, один раз на новое событие. */
        private async runAutoApproveScan(client: ChannelClient, envelope?: { iterations?: number; salt?: Uint8Array; nonce?: Uint8Array }): Promise<void> {
                const result = await autoApproveScan(client, this.settings.defaultPassword as string, this.adapter, { now: () => this.now(), envelope });
                if (result.notified.length > 0) {
                        try {
                                new Notice(t('noticeReuseKept', result.notified.join(', ')));
                        } catch {
                                // нет Notice в тестовом окружении
                        }
                }
        }

        async backupUsers(targetFolder: string): Promise<number> {
                const client = this.makeClient();
                const count = await exportUsersBackup(client, this.app.vault.adapter as DataAdapter, targetFolder);
                await pushJournalEntry(this.adapter, { ts: this.now(), kind: 'owner', detail: `backup exported ${count} files to ${targetFolder}` });
                return count;
        }

        async saveChannelMetaUpdate(minManagerVersion: string, killSwitch: boolean, offlineTtlHours: number): Promise<void> {
                const client = this.makeClient();
                await client.putChannelMeta({ v: 1, minManagerVersion, killSwitch, offlineTtlHours });
                await pushJournalEntry(this.adapter, { ts: this.now(), kind: 'config', detail: `channel.json updated (killSwitch=${killSwitch}, ttl=${offlineTtlHours}h)` });
        }

        // --- хозяйские операции с plugins.json (v0.3) ---

        /**
         * Загрузка plugins.json для owner-редактора (B-4, RC-3: «ошибка ≠ пусто»).
         * Контракт:
         * - null — сеть/канал упали: редактор обязан показать ошибку, Save недоступен
         *   (раньше сбой молча подставлял EMPTY_PLUGIN_POLICY — пользователь мог
         *   сохранить пустую политику поверх реальной, деструктивно);
         * - политика — файл прочитан и распознан (status ok);
         * - {...EMPTY_PLUGIN_POLICY} — файла нет (not-found) или формат чужой/битый:
         *   легитимный чистый старт редактора, это НЕ ошибка.
         */
        async loadPluginPolicy(): Promise<PluginPolicy | null> {
                try {
                        const res = await this.makeClient().getPluginPolicy();
                        if (res.status === 'ok' && res.policy) return res.policy;
                } catch (err) {
                        console.warn(LOG_PREFIX, 'plugins.json load failed:', err instanceof Error ? err.message : String(err));
                        return null; // явный сигнал сбоя: пустая политика НЕ подставляется (RC-3)
                }
                // not-found / битый формат — файла на канале нет, редактор честно начинается с пустого
                return { ...EMPTY_PLUGIN_POLICY };
        }

        async savePluginPolicy(policy: PluginPolicy): Promise<void> {
                const client = this.makeClient();
                await client.putPluginPolicy(policy);
                const regulated = policy.plugins.filter(p => p.action === 'regulated').length;
                const forbidden = policy.plugins.filter(p => p.action === 'forbidden').length;
                await pushJournalEntry(this.adapter, {
                        ts: this.now(),
                        kind: 'config',
                        detail: `plugins.json updated (${policy.plugins.length} entries: ${regulated} regulated, ${forbidden} forbidden)`,
                });
        }
}
