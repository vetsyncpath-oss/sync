/** Small standard ZIP writer (stored entries). No Node.js or external ZIP dependency in Obsidian. */
export function zip(files: Record<string, string>, modifiedAt: number = Date.now()): Uint8Array {
    const when = new Date(modifiedAt), year = when.getUTCFullYear();
    if (!Number.isFinite(modifiedAt) || year < 1980 || year > 2107) throw new Error('Некорректная дата архива');
    const dosTime = (when.getUTCHours() << 11) | (when.getUTCMinutes() << 5) | (when.getUTCSeconds() >> 1);
    const dosDate = ((year - 1980) << 9) | ((when.getUTCMonth() + 1) << 5) | when.getUTCDate();
    const unix = Math.floor(modifiedAt / 1000);
    // Extended timestamp (0x5455): unambiguous UTC mtime for unzip, macOS, Android and Windows extractors.
    const extra = new Uint8Array(9), extraView = new DataView(extra.buffer);
    extraView.setUint16(0, 0x5455, true); extraView.setUint16(2, 5, true); extra[4] = 1; extraView.setUint32(5, unix, true);
    const enc = new TextEncoder(), parts: Uint8Array[] = [], central: Uint8Array[] = []; let offset = 0, directorySize = 0;
    const u16 = (view: DataView, at: number, value: number) => view.setUint16(at, value, true), u32 = (view: DataView, at: number, value: number) => view.setUint32(at, value, true);
    for (const [path, text] of Object.entries(files)) {
        if (!/^[a-zA-Z0-9._/-]+$/.test(path) || path.startsWith('/') || path.split('/').includes('..')) throw new Error('Некорректный путь в архиве');
        const name = enc.encode(path), data = enc.encode(text); let crc = 0xffffffff;
        for (const byte of data) { crc ^= byte; for (let bit = 0; bit < 8; bit++) crc = (crc >>> 1) ^ ((crc & 1) ? 0xedb88320 : 0); }
        crc = (crc ^ 0xffffffff) >>> 0;
        const header = new Uint8Array(30 + name.length + extra.length), local = new DataView(header.buffer);
        u32(local, 0, 0x04034b50); u16(local, 4, 20); u16(local, 6, 0x800); u16(local, 10, dosTime); u16(local, 12, dosDate); u32(local, 14, crc); u32(local, 18, data.length); u32(local, 22, data.length); u16(local, 26, name.length); u16(local, 28, extra.length); header.set(name, 30); header.set(extra, 30 + name.length);
        parts.push(header, data);
        const entry = new Uint8Array(46 + name.length + extra.length), view = new DataView(entry.buffer);
        u32(view, 0, 0x02014b50); u16(view, 4, (3 << 8) | 20); u16(view, 6, 20); u16(view, 8, 0x800); u16(view, 12, dosTime); u16(view, 14, dosDate); u32(view, 16, crc); u32(view, 20, data.length); u32(view, 24, data.length); u16(view, 28, name.length); u16(view, 30, extra.length); u32(view, 38, (0o100644 << 16) >>> 0); u32(view, 42, offset); entry.set(name, 46); entry.set(extra, 46 + name.length);
        central.push(entry); directorySize += entry.length; offset += header.length + data.length;
    }
    if (central.length > 65535 || offset + directorySize > 0xffffffff) throw new Error('Архив слишком большой');
    const end = new Uint8Array(22), view = new DataView(end.buffer);
    u32(view, 0, 0x06054b50); u16(view, 8, central.length); u16(view, 10, central.length); u32(view, 12, directorySize); u32(view, 16, offset);
    const result = new Uint8Array(offset + directorySize + end.length); let position = 0;
    for (const part of [...parts, ...central, end]) { result.set(part, position); position += part.length; }
    return result;
}
