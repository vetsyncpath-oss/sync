# Воспроизводимая облачная среда

Репозиторий `vetsyncpath-oss/manager`, рабочая копия `/workspace/manager`. Настройка выполнена с `cloud-environment-onboarding:setup`; отдельные worktree не создаются. Используйте существующую изолированную рабочую копию.

```sh
cd /workspace/manager
npm ci --cache /tmp/vam-npm-cache --no-audit --no-fund
npm run typecheck
npm test
npm run test:release
```

Node.js 20.18.0, 22.x и 24+; Vitest 4.1.11/Vite 6.4.4 закреплены. Установка требует npm-сеть. Runtime Obsidian не требует системную Node.js.

`test:release` собирает менеджер и приватный Publisher, выпускает ZIP через собранный Publisher и запускает собранный менеджер с тестовым приватным Git API. Production-PAT, ключи и внешние Git-записи не нужны. `npm run test:issuer` — отдельная регрессия архивного CLI v3.

В тестах IndexedDB эмулируется `fake-indexeddb`, DOM — `linkedom`; это не приёмка настоящего Obsidian. Текущий entry point использует v4, совместимый SDK-мост, общие модули хранения/транспорта/криптографии и чтение прежнего реестра/восстановление блокировок. Старые runtime и издательские назначения исключены из менеджера проверкой build metafile.

`npm run dev` запускает watch, пишет `manager/main.js` и пересобирает корневой `main.js` Издателя. `npm run build` также создаёт `dist/vam-publisher`, содержащий шаблон менеджера. Шаблон без подготовленного профиля блокирует доступ и направляет к Издателю. Для тестового выпуска создайте профиль в Publisher; публичные корни больше не настраиваются.

На настоящем Node.js 20.18.0 прошли typecheck, 158 тестов, сборки и smoke-сценарии. Полный npm audit: 0 известных уязвимостей. Реальная приёмка GitHub/Gitea и Obsidian перечислена в ACCEPTANCE.md.

Критическая проверка изоляции: test/vault-session-v4.test.ts использует одну IndexedDB для нескольких vault. Мок Plugin задаёт vault ID по умолчанию; специализированные тесты явно задают разные пути/ID и отсутствие обоих.
