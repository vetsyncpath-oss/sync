import 'fake-indexeddb/auto';
import { afterEach, describe, expect, it } from 'vitest';
import { Plugin, Notice } from 'obsidian';
import { generateIdentity, inspectJws, signJws } from '../manager/src/auth-v2/crypto';
import { LocalStore } from '../manager/src/auth-v3/local';
import { GitError } from '../manager/src/auth-v3/git-store';
import { Service } from '../manager/src/auth-v4/service';
import { Runtime } from '../manager/src/auth-v4/runtime';
import { CONFIG_PATH, DAY, decodeCode, encodeCode } from '../manager/src/auth-v4/model';
import { build, Repository } from './helpers/v4';
import { vamGuard } from '../manager/src/sdk/vam-guard';
const active: Array<{ dispose(): void }> = [];
afterEach(() => { active.splice(0).forEach(item => item.dispose()); delete (globalThis as any).__VAM__; delete (globalThis as any).vaultSyncAuth; });
async function fixture() { const repo = new Repository(), admin = new Service(build, await generateIdentity(), 'old-token', 0, { store: repo.store }); active.push(admin); await admin.loginAdministrator(build.defaultPassword); return { repo, admin }; }
async function user(repo: Repository, token = 'old-token') { const service = new Service(build, await generateIdentity(), token, 0, { store: repo.store }); active.push(service); await service.refresh(); return service; }
function runtime(repo: Repository, name = crypto.randomUUID()) { const plugin = new Plugin({ vault: {}, initialSettings: { role: 'owner' } } as any, { id: 'vault-access-manager', version: 'test' }); const r = new Runtime(plugin, build, { fetcher: repo.fetcher }, new LocalStore(name)); active.push(r); return { r, plugin }; }
async function activate(service: Service, code: string) { const c = decodeCode(code, build); service.validateInvitation(c); const outbox = await service.request(c.accountId, { kind: 'invitation', id: c.invitationId!, secret: c.secret! }); service.restoreSession({ kind: 'user', accountId: c.accountId }); await service.submit(outbox); return outbox; }

describe('bound repository and plain administrator password', () => {
    it('initializes one repository only with the publisher initial password and a valid private Git connection', async () => {
        const repo = new Repository(), s = await user(repo);
        await expect(s.loginAdministrator('wrong')).rejects.toThrow('Неверный пароль'); expect(repo.writes).toBe(0);
        await s.loginAdministrator(build.defaultPassword); expect(repo.document().adminPassword).toBe(build.defaultPassword); expect(s.isAdministrator()).toBe(true); expect([...repo.files.keys()]).toEqual([CONFIG_PATH]);
    });
    it('accepts a password edited directly in Git without a version bump, rebuild or key recovery', async () => {
        const { repo, admin } = await fixture(); repo.edit(d => { d.adminPassword = 'new-password'; }); await admin.refresh();
        expect(admin.isAdministrator()).toBe(false); await expect(admin.loginAdministrator(build.defaultPassword)).rejects.toThrow('Неверный пароль'); await admin.loginAdministrator('new-password'); expect(admin.isAdministrator()).toBe(true);
    });
    it('rechecks the current password for writes even before a stale session notices its replacement', async () => {
        const { repo, admin } = await fixture(); repo.edit(d => { d.adminPassword = 'new-password'; }); await expect(admin.invite('No')).rejects.toThrow('актуальным паролем'); expect(repo.document().members).toHaveLength(0);
    });
    it('blocks public repositories and configurations belonging to another organization', async () => {
        const { repo, admin } = await fixture(); repo.privateRepo = false; await admin.refresh(); expect(admin.isAdministrator()).toBe(false);
        repo.privateRepo = true; repo.edit(d => { d.tenantId = 'foreign'; }); await admin.refresh(); expect(admin.document).toBeNull(); expect(admin.error).toContain('другой организации');
    });
});
describe('single-use enrollment and device limits', () => {
    it('automatically approves the first device, while a second device cannot reuse the key', async () => {
        const { repo, admin } = await fixture(), invitation = await admin.invite('User', { accountId: 'alice', password: 'alice-pass' }), one = await user(repo), two = await user(repo);
        await activate(one, invitation.code); await admin.processRequests(); await one.refresh(); expect(one.access({ tenantId: build.tenantId, bundleId: build.bundleId }).status).toBe('granted');
        await two.refresh(); await expect(activate(two, invitation.code)).rejects.toThrow('уже использован'); expect(repo.document().members[0].devices).toHaveLength(1);
        await expect(two.loginUser('alice', 'alice-pass')).rejects.toThrow('Лимит');
    });
    it('keeps the default limit of one when two administrator clients process racing enrollments', async () => {
        const { repo, admin } = await fixture(), first = await admin.invite('User', { accountId: 'alice' }), second = await admin.invite('User', { accountId: 'alice' });
        const one = await user(repo), two = await user(repo); await activate(one, first.code); await activate(two, second.code);
        const otherAdmin = new Service(build, await generateIdentity(), 'old-token', 0, { store: repo.store }); active.push(otherAdmin); await otherAdmin.loginAdministrator(build.defaultPassword);
        await Promise.all([admin.processRequests(), otherAdmin.processRequests()]); expect(repo.document().members[0].devices).toHaveLength(1);
    });
    it('requires confirmation for replacement, then blocks the old device and password reenrollment', async () => {
        const { repo, admin } = await fixture(), invitation = await admin.invite('User', { accountId: 'alice', password: 'alice-pass' }), one = await user(repo); await activate(one, invitation.code); await admin.processRequests(); await one.refresh();
        const replacement = await admin.invite('User', { accountId: 'alice', replaceDeviceId: one.device.keyId }), two = await user(repo); await activate(two, replacement.code); await admin.processRequests();
        expect(admin.pending).toHaveLength(1); expect(repo.document().members[0].devices[0].deviceId).toBe(one.device.keyId);
        await admin.approve(admin.pending[0].code); await one.refresh(); await two.refresh(); expect(repo.document().members[0].devices[0].deviceId).toBe(two.device.keyId); await expect(one.loginUser('alice', 'alice-pass')).rejects.toThrow('отозвано');
    });
    it('does not recreate a revoked member when a concurrent write forces CAS recomputation', async () => {
        const { repo, admin } = await fixture(), invitation = await admin.invite('User', { accountId: 'alice' }), one = await user(repo); await activate(one, invitation.code);
        repo.beforeWrite = path => { if (path === CONFIG_PATH) { repo.beforeWrite = undefined; repo.edit(d => { d.members[0].active = false; }); } };
        await admin.processRequests(); expect(repo.document().members[0].active).toBe(false); expect(repo.document().members[0].devices).toHaveLength(0);
    });
    it('rejects device-proof tampering and does not duplicate already acknowledged enrollment', async () => {
        const { repo, admin } = await fixture(), invitation = await admin.invite('User'), one = await user(repo), outbox = await activate(one, invitation.code);
        const request = inspectJws(outbox.code) as any; request.deviceId = (await generateIdentity()).keyId; const tampered = await signJws(request, one.device); repo.files.set(`vam/requests/${outbox.id}.json`, { sha: 'tamper', text: JSON.stringify({ v: 4, deviceProof: tampered }) });
        await admin.processRequests(); expect(admin.rejected).toBe(1); expect(repo.document().members[0].devices).toHaveLength(0);
        repo.files.delete(`vam/requests/${outbox.id}.json`); await one.submit(outbox); await admin.processRequests(); const count = repo.writes; await admin.processRequests(); expect(repo.writes).toBe(count);
    });
});
describe('automatic PAT delivery and recovery', () => {
    it('rotates through the old PAT, preserving device, account, session and request count', async () => {
        const { repo, admin } = await fixture(), invitation = await admin.invite('User'), one = await user(repo); await activate(one, invitation.code); await admin.processRequests(); await one.refresh();
        const device = one.device.keyId, requests = [...repo.files.keys()].filter(p => p.startsWith('vam/requests/')).length;
        await admin.rotateToken('new-token', null); await one.refresh(); expect(one.transport.token).toBe('new-token'); expect(one.transport.version).toBe(2); expect(one.device.keyId).toBe(device); expect(one.session?.kind).toBe('user'); expect([...repo.files.keys()].filter(p => p.startsWith('vam/requests/')).length).toBe(requests);
        repo.tokens.delete('old-token'); await one.refresh(); expect(one.online).toBe(true);
    });
    it('does not publish a bad replacement or inherit the previous expiry date', async () => {
        const { repo, admin } = await fixture(); repo.edit(d => { d.transport.expiresOn = '2026-10-16'; });
        await expect(admin.rotateToken('bad-token', null)).rejects.toThrow(); expect(repo.document().transport.token).toBe('old-token');
        await admin.rotateToken('new-token', null); expect(repo.document().transport.expiresOn).toBeNull();
    });
    it('retains a working old transport if a manually published new token cannot connect', async () => {
        const { repo } = await fixture(), one = await user(repo); repo.edit(d => { d.transport = { token: 'invalid-token', version: 2, expiresOn: null }; }); await one.refresh(); expect(one.transport.token).toBe('old-token'); expect(one.online).toBe(true); expect(one.error).toContain('Новый PAT');
    });
    it('cannot download a replacement after the old PAT is revoked', async () => {
        const { repo, admin } = await fixture(), one = await user(repo); await admin.rotateToken('new-token', null); repo.tokens.delete('old-token'); await one.refresh(); expect(one.online).toBe(false); expect(one.document).toBeNull(); expect(one.transport.token).toBe('old-token');
    });
});
describe('runtime, storage, logout and scoped bundle SDK', () => {
    it('cancels an in-progress administrator login when the logout command is issued', async () => {
        const repo = new Repository(); let release!: () => void, started!: () => void; const ready = new Promise<void>(resolve => { started = resolve; }), wait = new Promise<void>(resolve => { release = resolve; }); const original = repo.fetcher;
        repo.fetcher = async (url, init) => { started(); await wait; return original(url, init); };
        const { r } = runtime(repo); await r.start(); const login = r.loginAdministrator(build.defaultPassword, 'old-token'); await ready; await r.logout(); release(); await expect(login).rejects.toThrow('отменено'); expect(r.decision.status).toBe('blocked'); expect(repo.writes).toBe(0);
    });
    it('activates once, restores after restart without data.json and logs out without freeing the device slot', async () => {
        const { repo, admin } = await fixture(), invitation = await admin.invite('User', { accountId: 'alice', password: 'alice-pass' }), name = crypto.randomUUID(), { r: one } = runtime(repo, name); await one.start(); await one.applyCode(invitation.code); await admin.processRequests(); await one.tick(); expect(one.decision.status).toBe('granted');
        const device = one.device.keyId; one.dispose(); const { r: restored, plugin } = runtime(repo, name); await restored.start(); expect(restored.decision.status).toBe('granted'); expect(restored.device.keyId).toBe(device);
        expect((plugin as any).commands.some((c: any) => c.id === 'vam-logout')).toBe(true); await restored.logout(); expect(restored.decision.status).toBe('blocked'); expect(repo.document().members[0].devices).toHaveLength(1);
        await restored.loginUser('alice', 'alice-pass'); expect(restored.decision.status).toBe('granted'); expect([...repo.files.keys()].filter(p => p.startsWith('vam/requests/'))).toHaveLength(1);
        expect((plugin.app as any).savedSettings).toBeUndefined();
    });
    it('saves automatic PAT updates and recovers an offline device with a code, without adding rights', async () => {
        const { repo, admin } = await fixture(), invitation = await admin.invite('User', { accountId: 'alice' }), { r } = runtime(repo); await r.start(); await r.applyCode(invitation.code); await admin.processRequests(); await r.tick();
        const device = r.device.keyId; await admin.rotateToken('new-token', null); repo.tokens.delete('old-token'); await r.tick(); expect(r.decision.status).toBe('blocked'); await r.applyCode(admin.recoveryCode('alice')); expect(r.decision.status).toBe('granted'); expect(r.profile.transport?.token).toBe('new-token'); expect(r.device.keyId).toBe(device);
        await admin.change('revoke-member', 'alice'); await r.tick(); const recovery = encodeCode({ v: 4, tenantId: build.tenantId, bundleId: build.bundleId, accountId: 'alice', purpose: 'update', transport: admin.transport }); await expect(r.applyCode(recovery)).rejects.toThrow('отозвано');
    });
    it('persists an automatically delivered PAT across restart after the old token is removed', async () => {
        const { repo, admin } = await fixture(), invitation = await admin.invite('User'), name = crypto.randomUUID(), { r } = runtime(repo, name); await r.start(); await r.applyCode(invitation.code); await admin.processRequests(); await r.tick(); const device = r.device.keyId;
        await admin.rotateToken('new-token', null); await r.tick(); expect(r.profile.transport?.token).toBe('new-token'); r.dispose(); repo.tokens.delete('old-token');
        const restored = runtime(repo, name).r; await restored.start(); expect(restored.profile.transport?.token).toBe('new-token'); expect(restored.device.keyId).toBe(device); expect(restored.decision.status).toBe('granted');
    });
    it('preserves the exact outbox when submission fails and the same invitation is retried', async () => {
        const { repo, admin } = await fixture(), invitation = await admin.invite('User'), { r } = runtime(repo); const base = repo.fetcher; let fail = true;
        repo.fetcher = async (url, init) => fail && init?.method === 'PUT' && String(url).includes('/vam/requests/') ? Response.json({}, { status: 403 }) : base(url, init);
        // Runtime captured the original fetch function, so use a runtime with the failing transport.
        const retry = runtime(repo).r; await retry.start(); await expect(retry.applyCode(invitation.code)).rejects.toThrow('Недостаточно'); const id = retry.profile.outbox!.id; expect(retry.profile.outbox!.submitted).toBe(false);
        fail = false; await retry.applyCode(invitation.code); expect(retry.profile.outbox!.id).toBe(id); expect(retry.profile.outbox!.submitted).toBe(true);
    });
    it('rejects a foreign organization before any token is sent', async () => {
        const { repo, admin } = await fixture(), invitation = await admin.invite('User'), { r } = runtime(repo); await r.start(); const decoded = decodeCode(invitation.code, build); decoded.tenantId = 'foreign'; await expect(r.applyCode(encodeCode(decoded))).rejects.toThrow('другой организации'); expect(r.profile.transport).toBeUndefined();
    });
    it('warns the administrator once per startup and invalidates the stored session after manual password change', async () => {
        const { repo } = await fixture(), { r } = runtime(repo); repo.edit(d => { d.transport.expiresOn = new Date(Date.now() + 7 * DAY).toISOString().slice(0, 10); }); await r.start(); (Notice as any).messages = []; await r.loginAdministrator(build.defaultPassword, 'old-token'); await r.tick(); await r.tick(); expect((Notice as any).messages).toHaveLength(1); expect((Notice as any).messages[0][0]).toContain('7 дней');
        repo.edit(d => { d.adminPassword = 'new-password'; }); await r.tick(); expect(r.session).toBeNull(); expect(r.decision.status).toBe('blocked'); await r.loginAdministrator('new-password'); expect(r.service?.isAdministrator()).toBe(true);
        const guard = vamGuard({ tenantId: build.tenantId, bundleId: build.bundleId }); active.push(guard); expect(guard.isAdministrator()).toBe(true); expect(guard.getAuthState()?.role).toBe('administrator'); await r.logout(); expect(guard.isAdministrator()).toBe(false);
    });
    it('uses an existing device key, bounds offline access, and closes the SDK after logout', async () => {
        const { repo, admin } = await fixture(), invitation = await admin.invite('User'), { r } = runtime(repo); await r.start(); await r.applyCode(invitation.code); await admin.processRequests(); await r.tick();
        const guard = vamGuard({ tenantId: build.tenantId, bundleId: build.bundleId, pluginId: 'any-product' }); active.push(guard); expect(guard.isGranted()).toBe(true);
        repo.failure = new GitError('network'); await r.tick(); expect(r.decision.status).toBe('granted'); r.service!.cache!.fetchedAt -= DAY + 1; expect(r.decision.status).toBe('blocked'); repo.failure = null; await r.tick(); await r.logout(); expect(guard.isGranted()).toBe(false);
    });
});
