import 'fake-indexeddb/auto';
import { describe, expect, it } from 'vitest';
import { LocalStore } from '../manager/src/auth-v3/local';
import { PublisherService, prepareRelease } from '../src/service';
import { zip } from '../src/zip';
import { build } from './helpers/v4';
const template = { main: 'module.exports = "__VAM_PROFILE_V4_JSON__";', manifest: '{"id":"vault-access-manager","version":"test"}', styles: '/* style */' };
describe('private publisher as a baking tool', () => {
    it('creates and restores a registry without a publisher password or signing identity', async () => {
        const name = crypto.randomUUID(), local = new LocalStore(name), publisher = new PublisherService(local); await publisher.start();
        const { v, tenantId, ...input } = build; const profile = await publisher.create(input); expect(profile.adminId).toBe(build.adminId); expect(profile.tenantId).not.toBe(build.tenantId);
        expect(await local.get('device')).toBeUndefined(); expect(await local.get('user')).toBeUndefined(); expect(JSON.stringify(await local.get('registry'))).not.toContain(build.defaultPassword);
        await publisher.close(); const restored = new PublisherService(new LocalStore(name)); await restored.start(); expect(restored.registry.profiles[0]).toEqual(profile); await restored.close();
    });
    it('keeps one organization identity across repository/profile edits and prevents duplicate IDs', async () => {
        const publisher = new PublisherService(new LocalStore(crypto.randomUUID())); await publisher.start();
        try { const { v, tenantId, ...input } = build, profile = await publisher.create(input); await expect(publisher.create(input)).rejects.toThrow('уже существует'); await publisher.updateProfile(profile.tenantId, { ...input, defaultPassword: 'changed', repository: { ...input.repository, repo: 'replacement' } }); expect(publisher.registry.profiles[0].tenantId).toBe(profile.tenantId); expect(publisher.registry.profiles[0].repository.repo).toBe('replacement'); }
        finally { await publisher.close(); }
    });
    it('produces exactly three manager files with a safely escaped fixed profile and no issuer code', () => {
        const profile = { ...build, defaultPassword: 'quote" backslash\\ newline\n $& ` ${1} Юникод' }, release = prepareRelease(profile, template);
        expect(Object.keys(release.files)).toEqual(['vault-access-manager/main.js', 'vault-access-manager/manifest.json', 'vault-access-manager/styles.css']);
        const runtime: any = { exports: '' }; new Function('module', release.files['vault-access-manager/main.js'])(runtime); expect(JSON.parse(runtime.exports)).toEqual(profile);
        expect(release.document).toContain('repository'); expect(release.files['vault-access-manager/main.js']).not.toContain('__VAM_PROFILE_V4_JSON__');
    });
    it('rejects already baked, missing-marker, duplicate-marker and insecure endpoint templates', () => {
        expect(() => prepareRelease(build, { ...template, main: 'no marker' })).toThrow('несовместим'); expect(() => prepareRelease(build, { ...template, main: template.main + template.main })).toThrow('несовместим'); expect(() => prepareRelease({ ...build, repository: { ...build.repository, baseUrl: 'http://insecure/api/v1' } }, template)).toThrow('HTTPS');
    });
    it('merges backups without silently replacing a current administrator profile', async () => {
        const one = new PublisherService(new LocalStore(crypto.randomUUID())), two = new PublisherService(new LocalStore(crypto.randomUUID())); await one.start(); await two.start();
        try { const { v, tenantId, ...input } = build; const profile = await one.create(input); await two.restoreRegistry(one.release(profile.tenantId, template).document); const snapshot = two.exportRegistry(); await expect(two.restoreRegistry(one.exportRegistry())).rejects.toThrow('существующий'); expect(two.exportRegistry()).toBe(snapshot); }
        finally { await one.close(); await two.close(); }
    });
    it('writes standard ZIP headers and the known CRC-32 vector; rejects path traversal', () => {
        const archive = zip({ 'plugin/vector.txt': '123456789' }), view = new DataView(archive.buffer);
        expect(view.getUint32(0, true)).toBe(0x04034b50); expect(view.getUint32(14, true)).toBe(0xcbf43926); expect(view.getUint32(archive.length - 22, true)).toBe(0x06054b50); expect(view.getUint16(archive.length - 12, true)).toBe(1); expect(() => zip({ '../secret': 'bad' })).toThrow('путь');
    });
});
