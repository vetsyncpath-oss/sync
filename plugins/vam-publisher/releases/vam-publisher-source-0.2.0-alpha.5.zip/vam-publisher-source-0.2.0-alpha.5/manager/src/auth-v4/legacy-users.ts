import { ChannelClient } from '../core/channel';
import { decryptUserRecord, type UserPayload } from '../core/crypto';
import type { BuildProfile } from './model';
export interface LegacyUser { accountId: string; label: string; expiresAt?: number | null; inRepository: boolean }
/** Read-only access to the original encrypted registry. It never modifies users/*.enc. */
export class LegacyUsers {
    private client: ChannelClient;
    constructor(build: BuildProfile, token: string, fetchImpl?: typeof fetch) { this.client = new ChannelClient({ ...build.repository, token }, { fetchImpl }); }
    async list(): Promise<LegacyUser[]> {
        return (await this.client.listDir('users')).filter(f => /^[a-f0-9]{7}\.enc$/i.test(f.name)).map(f => ({ accountId: f.name.slice(0, -4), label: '', inRepository: true }));
    }
    async decrypt(accountId: string, password: string): Promise<UserPayload> {
        if (!/^[a-f0-9]{7}$/i.test(accountId)) throw new Error('Некорректный ID прежнего пользователя');
        const result = await this.client.getUserRecord(accountId);
        if (result.status !== 'ok') throw new Error('Прежняя запись удалена или недоступна. Перенос отменён.');
        const payload = await decryptUserRecord(password, accountId, result.bytes);
        if (payload.userId !== accountId || (payload.expiresAt !== null && (!Number.isSafeInteger(payload.expiresAt) || payload.expiresAt <= Date.now()))) throw new Error('Срок прежнего доступа истёк. Перенос не продлевает доступ.');
        return payload;
    }
}
