import { studioPanel } from "./studio-diagnostics";
import { Notice, PluginSettingTab, type App, type Plugin } from 'obsidian';
import type { Runtime } from './runtime';
import { ConfirmModal } from './confirm-modal';
import { RESTRICTIONS, RESTRICTION_TITLES, knownRestrictions, memberActive, type Member } from './model';
export class SettingsTab extends PluginSettingTab {
    private closeStudioPanel?: () => void;
    private unsubscribe?: () => void;
    private visible = false;
    private executing = false;
    private loginChoice: 'administrator' | 'password' | 'key' | null = null;
    constructor(app: App, private manager: Plugin, private runtime: Runtime) { super(app, manager); }
    private text(parent: HTMLElement, value: string): HTMLElement { const p = document.createElement('p'); p.textContent = value; parent.append(p); return p; }
    private group(parent: HTMLElement, title: string, open = false, key?: string): HTMLDetailsElement { const d = document.createElement('details'), s = document.createElement('summary'); s.textContent = title; d.open = open; if (key) d.dataset.key = key; d.append(s); parent.append(d); return d; }
    private ago(ms: number): string { const minutes = Math.max(0, Math.floor(ms / 60000)); if (minutes < 1) return 'только что'; if (minutes < 60) return `${minutes} мин назад`; const hours = Math.floor(minutes / 60); return hours < 48 ? `${hours} ч назад` : `${Math.floor(hours / 24)} дн. назад`; }
    private short(id: string): string { return '…' + id.slice(-8); }
    private async copyText(value: string, input?: HTMLInputElement | HTMLTextAreaElement): Promise<void> {
        if (!value) return;
        if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) { await navigator.clipboard.writeText(value); new Notice('Скопировано'); }
        else if (input) { input.focus(); input.select(); input.setSelectionRange(0, input.value.length); new Notice('Текст выделен. Скопируйте его командой «Копировать» вашего устройства.'); }
        else new Notice('Буфер обмена недоступен на этом устройстве.');
    }
    private invitation(organization: string, member: Member, key: string): string {
        return [`Приглашение в Vault Access Manager (${organization})`, `Пользователь: ${member.label || member.accountId} (ID: ${member.accountId})`, '', '1. Установите плагин Vault Access Manager в Obsidian и включите его.', '2. Откройте его настройки, выберите «У меня есть ключ доступа» и вставьте ключ ниже. ID и пароль при подключении не нужны.', '', 'Ключ:', key].join('\n');
    }
    private field(parent: HTMLElement, title: string, value = '', type = 'text', readonly = false): HTMLInputElement | HTMLTextAreaElement {
        const label = document.createElement('label'); label.className = 'vam3-field'; label.textContent = title;
        const input = document.createElement(type === 'textarea' ? 'textarea' : 'input'); input.value = value; input.readOnly = readonly;
        if (input instanceof HTMLInputElement) { input.type = type; input.autocomplete = type === 'password' ? 'current-password' : 'off'; } else input.rows = 4;
        input.spellcheck = false; label.append(input); parent.append(label);
        if (readonly && type === 'textarea') this.button(parent, 'Скопировать', () => this.copyText(input.value, input), false);
        return input;
    }
    private button(parent: HTMLElement, title: string, action: () => unknown | Promise<unknown>, redraw = true): void {
        const b = document.createElement('button'); b.textContent = title; b.className = 'vam3-button'; parent.append(b);
        b.onclick = async () => { b.disabled = true; this.executing = true; try { await action(); if (redraw && this.visible) this.display(); } catch (e) { new Notice(e instanceof Error ? e.message : 'Действие не выполнено'); } finally { b.disabled = false; this.executing = false; } };
    }
    hide(): void { this.closeStudioPanel?.(); this.closeStudioPanel=undefined; this.visible = false; this.unsubscribe?.(); this.unsubscribe = undefined; }
    private async confirm(message: string, work: () => Promise<void>, labels?: { title?: string; action?: string; danger?: boolean }): Promise<void> { const confirmed = await new Promise<boolean>(resolve => new ConfirmModal(this.app, message, resolve, labels).open()); if (confirmed) await work(); }
    display(): void {
        this.hide(); this.visible = true; const root = this.containerEl; root.replaceChildren(); root.classList.add('vam3-settings', 'vam-dashboard'); const r = this.runtime;
        const title = document.createElement('h2'); title.textContent = 'Vault Access Manager'; root.append(title);
        this.closeStudioPanel = studioPanel(root, this.app, this.manager);
        const status = this.text(root, r.status); status.className = 'vam3-status'; status.dataset.state = r.decision.status; status.setAttribute('role', 'status');
        const mode = () => r.service?.isAdministrator() ? 'administrator' : r.session?.kind ?? 'none'; let displayedMode = mode();
        this.unsubscribe = r.subscribe(() => { if (!this.visible) return; status.textContent = r.status; status.dataset.state = r.decision.status; const next = mode(); if (next !== displayedMode) { displayedMode = next; this.display(); } });
        if (!r.build) { this.text(root, 'Получите у Издателя готовую сборку для вашей организации. Самостоятельно создавать административный ключ или отправлять заявку больше не нужно.'); return; }
        this.text(root, `Организация: ${r.build.adminId}`);
        this.text(root, 'Профиль входа относится только к текущему хранилищу.');
        if (r.legacyDetected && !r.profile.transport) this.text(root, 'Данные прежней версии сохранены. Для первого входа в этой сборке используйте пароль Администратора или новый ключ доступа.');
        if (!r.session || (r.session.kind === 'administrator' && !r.service?.isAdministrator())) {
            if (!this.loginChoice) {
                this.text(root, 'Выберите способ входа. Подключённый профиль сохраняется между запусками.');
                const cards = document.createElement('div'); cards.className = 'vam-login-cards'; root.append(cards);
                for (const [choice, title, description] of [
                    ['key', 'У меня есть ключ доступа', 'Вставьте ключ от Администратора. Устройство подключится автоматически.'],
                    ['password', 'Я уже подключён', 'Войти по ID и паролю пользователя.'],
                    ['administrator', 'Я Администратор', 'Войти с паролем от Издателя и управлять доступом.'],
                ] as const) {
                    const card = document.createElement('button'); card.type = 'button'; card.className = 'vam-card';
                    const heading = document.createElement('span'); heading.className = 'vam-card-title'; heading.textContent = title;
                    const descriptionEl = document.createElement('span'); descriptionEl.className = 'vam-card-desc'; descriptionEl.textContent = description;
                    card.append(heading, descriptionEl); cards.append(card); card.onclick = () => { this.loginChoice = choice; this.display(); };
                }
                return;
            }
            this.button(root, '← Выбрать другой способ входа', () => { this.loginChoice = null; });
            const form = document.createElement('form'); form.className = 'vam-login-form'; root.append(form);
            const submit = (label: string, work: () => Promise<void>) => {
                this.button(form, label, work);
                const button = form.querySelector('button')!; button.type = 'button'; button.classList.add('mod-cta');
                form.onsubmit = event => { event.preventDefault(); if (!button.disabled) button.click(); };
                form.onkeydown = event => { if (event.key === 'Enter' && !(event.target instanceof HTMLTextAreaElement)) { event.preventDefault(); if (!button.disabled) button.click(); } };
            };
            if (this.loginChoice === 'administrator') {
                const phrase = this.field(form, 'Пароль Администратора', '', 'password');
                this.text(form, 'Если вы не знаете пароля, пожалуйста, обратитесь к Издателю плагина.');
                const connection = this.group(form, r.profile.transport ? 'Восстановить подключение Git' : 'Первое подключение Git', (!r.profile.transport && !r.build.bootstrapToken) || (r.session?.kind === 'administrator' && !r.service?.online));
                this.text(connection, 'PAT нужен только Администратору для подключения или восстановления доступа. Репозиторий закреплён Издателем.');
                const token = this.field(connection, 'PAT Администратора', '', 'password'), expiry = this.field(connection, 'Срок действия PAT (UTC; необязательно)', '', 'date');
                submit('Войти как Администратор', async () => { await r.loginAdministrator(phrase.value, token.value, expiry.value || null); phrase.value = ''; token.value = ''; this.loginChoice = null; });
            } else if (this.loginChoice === 'password') {
                const account = this.field(form, 'ID пользователя', r.profile.accountId ?? ''), password = this.field(form, 'Пароль пользователя', '', 'password');
                // Phone keyboards must not capitalise or "correct" an identifier, which is case-sensitive.
                for (const [name, value] of [['autocapitalize', 'off'], ['autocorrect', 'off'], ['autocomplete', 'username'], ['enterkeyhint', 'next']] as const) account.setAttribute(name, value);
                this.text(form, 'При первом подключении используйте ключ доступа от Администратора.');
                submit('Войти', async () => { await r.loginUser(account.value, password.value); password.value = ''; this.loginChoice = null; });
            } else {
                const code = this.field(form, 'Ключ доступа от Администратора', '', 'textarea');
                this.text(form, 'Введите ключ один раз. Регистрация устройства и следующие подключения выполняются автоматически.');
                submit('Подключиться', async () => { await r.applyCode(code.value); code.value = ''; this.loginChoice = null; });
            }
            form.querySelector('input, textarea')?.setAttribute('autofocus', '');
            return;
        }
        this.button(root, 'Выйти из текущего профиля', () => r.logout());
        this.button(root, 'Проверить доступ', () => r.tick(), false);
        const connected = this.group(root, 'Подключённые плагины', !r.service?.isAdministrator());
        const pluginList = document.createElement('div'); connected.append(pluginList);
        const renderPlugins = () => {
            pluginList.replaceChildren();
            if (r.plugins.error) this.text(pluginList, r.plugins.error);
            const plugins = r.plugins.list();
            if (!plugins.length) this.text(pluginList, 'Подключённые плагины пока не обнаружены. Их регистрация появится после загрузки в Obsidian.');
            for (const plugin of plugins) {
                const row = document.createElement('div'); row.className = 'vam-plugin-card'; pluginList.append(row);
                this.text(row, `${plugin.name} · ${plugin.enabled ? 'Включён' : 'Выключен в Obsidian'}`);
                if (!plugin.enabled && r.decision.status === 'granted') this.button(row, 'Включить', () => r.plugins.enable(plugin.id));
            }
        };
        renderPlugins();
        if (r.service?.isAdministrator()) this.button(connected, 'Восстановить прежние блокировки', () => r.plugins.restore());
        if (!r.service?.isAdministrator()) {
            if (r.profile.outbox && !r.profile.outbox.submitted) this.button(root, 'Повторить отправку устройства', () => r.sendPending());
            const recovery = this.group(root, 'Восстановить подключение'), code = this.field(recovery, 'Код восстановления от Администратора', '', 'textarea');
            this.text(recovery, 'Обычно подключение обновляется автоматически. Если доступ к Git истёк, запросите код восстановления у Администратора.');
            this.button(recovery, 'Восстановить подключение', async () => { await r.applyCode(code.value); code.value = ''; });
            const info = this.group(root, 'Профиль'); this.field(info, 'ID пользователя', r.profile.accountId ?? '', 'text', true); this.field(info, 'Устройство', r.device?.keyId ?? '', 'text', true);
            return;
        }
        const s = r.service;
        const stats = document.createElement('div'); stats.className = 'vam-overview'; root.append(stats);
        const summary = this.text(stats, ''), syncLine = this.text(stats, '');
        const updateSummary = () => {
            const members = s.document?.members ?? [], now = Date.now(), live = members.filter(m => memberActive(m, now)).length, revoked = members.filter(m => !m.active).length, lapsed = members.length - live - revoked;
            summary.textContent = `Пользователей: ${live} действующих${revoked ? ` · ${revoked} отозвано` : ''}${lapsed ? ` · ${lapsed} с истёкшим сроком` : ''} · Устройств: ${members.reduce((n, m) => n + m.devices.length, 0)} · Заявок на рассмотрении: ${s.pending.length}`;
            const expires = s.document?.transport.expiresOn ?? null, left = expires ? Math.ceil((Date.parse(expires + 'T23:59:59Z') - now) / 86400000) : null;
            const pat = expires === null ? 'не задан' : left! < 0 ? `${expires} (истёк)` : `${expires} (осталось ${left} дн.)`;
            const synced = s.lastSyncAt; syncLine.textContent = `Подключение №${s.transport.version} · срок PAT: ${pat} · данные получены ${synced === null ? 'ещё не получены' : this.ago(now - synced)}`;
            syncLine.dataset.warn = expires !== null && left! <= 14 ? '1' : '';
        };
        updateSummary();
        const queue = document.createElement('div'); root.append(queue);
        const git = this.group(root, 'Подключение организации');
        this.field(git, 'Закреплённый репозиторий', `${r.build.repository.baseUrl}/repos/${r.build.repository.owner}/${r.build.repository.repo}`, 'text', true);
        this.text(git, 'Для перевыпуска репозитория или смены пароля обратитесь к Издателю плагина. Владельцу репозитория доступна ручная смена adminPassword в vam/config.json.');
        const token = this.field(git, 'Новый PAT', '', 'password'), expiry = this.field(git, 'Срок нового PAT (UTC; необязательно)', '', 'date');
        this.text(git, 'Обновите PAT до истечения старого. Пользователи получат замену при следующем запуске или фоновой синхронизации. Устройства, пропустившие этот период, подключаются по коду восстановления.');
        this.button(git, 'Проверить и обновить PAT организации', async () => { await r.rotateToken(token.value, expiry.value || null); token.value = ''; });
        const issue = this.group(root, 'Добавить пользователя и выдать ключ', !s.document?.members.length);
        const account = this.field(issue, 'ID пользователя (пусто — создать автоматически)'), label = this.field(issue, 'Имя или метка пользователя'), password = this.field(issue, 'Пароль пользователя (пусто — создать автоматически)', '', 'password'), until = this.field(issue, 'Доступ по дату включительно (UTC; необязательно)', '', 'date');
        const deviceLimit = this.field(issue, 'Лимит устройств', '1', 'number');
        const issueGuards = this.group(issue, 'Ограничения интерфейса (задаются до выдачи ключа)', true);
        this.text(issueGuards, 'Действуют с первого входа пользователя. Защита от случайных действий, а не от намеренного обхода. Администратора не касаются; позже их можно изменить в карточке пользователя.');
        const issueBoxes = RESTRICTIONS.map(name => { const box = this.field(issueGuards, RESTRICTION_TITLES[name], '', 'checkbox') as HTMLInputElement; return [name, box] as const; });
        const output = this.field(issue, 'Данные для личной передачи пользователю', '', 'textarea', true);
        this.button(issue, 'Выдать ключ доступа', async () => {
            const result = await s.addUser(label.value, { accountId: account.value.trim() || undefined, password: password.value || undefined, expiresAt: until.value ? Date.parse(until.value) + 86400000 : null, maxDevices: Number(deviceLimit.value) || 1, restrictions: issueBoxes.filter(([, box]) => box.checked).map(([name]) => name) });
            output.value = `ID: ${result.accountId}\nПароль: ${result.password}\n\nКлюч доступа:\n${result.code}`;
            account.value = ''; label.value = ''; password.value = ''; until.value = ''; deviceLimit.value = '1'; issueBoxes.forEach(([, box]) => { box.checked = false; });
            await r.tick();
            // The new user's card, with the key, appears at once (the guard would otherwise wait for the next background refresh).
            this.executing = false; renderInventory(true);
        }, false);
        const filters = document.createElement('div'); filters.className = 'vam-filters'; root.append(filters);
        const search = this.field(filters, 'Найти пользователя по ID или имени');
        const stateLabel = document.createElement('label'); stateLabel.className = 'vam3-field'; stateLabel.textContent = 'Показать'; const stateFilter = document.createElement('select');
        for (const [value, text] of [['all', 'Все'], ['active', 'Действующие'], ['revoked', 'Отозванные'], ['expired', 'Срок истёк'], ['full', 'Лимит устройств исчерпан'], ['empty', 'Без устройств'], ['guarded', 'С ограничениями интерфейса']]) { const option = document.createElement('option'); option.value = value; option.textContent = text; stateFilter.append(option); }
        stateLabel.append(stateFilter); filters.append(stateLabel);
        const inventory = document.createElement('div'); root.append(inventory);
        const filterUsers = () => { const query = search.value.trim().toLocaleLowerCase(), state = stateFilter.value || 'all'; for (const row of Array.from(inventory.querySelectorAll<HTMLElement>('[data-user-search]'))) row.hidden = !row.dataset.userSearch!.includes(query) || (state !== 'all' && row.dataset.userFlags !== undefined && !row.dataset.userFlags.split(' ').includes(state)); };
        search.oninput = filterUsers; stateFilter.onchange = filterUsers;
        let editingInventory = false;
        inventory.addEventListener('input', () => { editingInventory = true; });
        queue.addEventListener('input', () => { editingInventory = true; });
        // An action refreshes the lists in place: opened cards stay opened (keyed by user, not by title) and the page does not jump.
        const act = (parent: HTMLElement, title: string, work: () => Promise<unknown>): void => this.button(parent, title, async () => { await work(); await r.tick(); this.executing = false; renderInventory(true); }, false);
        const openState = new Map<string, boolean>();
        let inventoryKey = '', lastWaiting = 0;
        const renderInventory = (force = false) => {
            const key = JSON.stringify([s.document?.members, s.document?.transport.version, s.document?.invitations.filter(i => i.standing).map(i => i.id), s.pending, s.rejected, s.rejectedList, r.legacyUsers, r.legacyError]);
            if (!force && (key === inventoryKey || editingInventory || this.executing || inventory.contains(document.activeElement) || queue.contains(document.activeElement) || Array.from(inventory.querySelectorAll<HTMLTextAreaElement>('textarea[readonly]:not([data-standing])')).some(el => !!el.value))) return;
            inventoryKey = key; editingInventory = false;
            for (const d of Array.from(root.querySelectorAll<HTMLDetailsElement>('details[data-key]'))) openState.set(d.dataset.key!, d.open);
            queue.replaceChildren(); inventory.replaceChildren();
            const now = Date.now(), waiting = s.pending.length;
            const waitingGroup = this.group(queue, `Заявки на рассмотрении: ${waiting}`, waiting > 0, 'queue');
            if (!waiting) this.text(waitingGroup, 'Новых заявок нет.');
            for (const request of s.pending.slice(0, 50)) {
                const item = document.createElement('div'); item.className = 'vam-request'; waitingGroup.append(item);
                const owner = s.document?.members.find(m => m.accountId === request.accountId);
                this.text(item, `${request.label ? `${request.label} (${request.accountId})` : request.accountId} · ${request.kind === 'replace' ? 'замена устройства' : 'дополнительное устройство'} · ${this.ago(now - request.issuedAt)}`);
                this.text(item, request.kind === 'replace' ? `Новое устройство ${this.short(request.deviceId)} заменит ${request.replaceDeviceId ? this.short(request.replaceDeviceId) : 'прежнее'}.` : `Новое устройство ${this.short(request.deviceId)}. Занято ${owner?.devices.length ?? 0} из ${owner?.maxDevices ?? 0}; после подтверждения лимит станет ${(owner?.devices.length ?? 0) + 1}.`);
                act(item, 'Подтвердить', () => s.approve(request.code));
                act(item, 'Отклонить', () => s.reject(request.code));
            }
            if (waiting > 50) this.text(waitingGroup, `Показаны первые 50 из ${waiting}. Остальные появятся после решения по этим.`);
            if (s.rejected) {
                const declined = this.group(queue, `Отклонённые заявки: ${s.rejected}`, false, 'declined');
                for (const item of s.rejectedList) this.text(declined, `${item.accountId ?? 'неизвестно'} · ${item.reason}`);
                if (s.rejected > s.rejectedList.length) this.text(declined, `Показаны первые ${s.rejectedList.length}.`);
                this.text(declined, 'Файлы заявок остаются в Git; их можно архивировать вручную.');
            }
            if (waiting > lastWaiting) openState.set('queue', true);
            lastWaiting = waiting;
            const members = this.group(inventory, 'Пользователи и устройства', true, 'members');
            this.text(members, 'Ключ пользователя подключает любое новое устройство без ID и пароля, пока есть свободные места; при их нехватке заявка приходит вам.');
            if (!s.document?.members.length) this.text(members, 'Новых пользователей пока нет. Прежние записи из репозитория показаны ниже.');
            for (const member of s.document?.members ?? []) {
                const live = memberActive(member, now), state = !member.active ? 'revoked' : live ? 'active' : 'expired', guarded = knownRestrictions(member), name = member.label || member.accountId;
                const row = this.group(members, `${name} · ${member.devices.length}/${member.maxDevices}${state === 'revoked' ? ' · отозван' : state === 'expired' ? ' · срок истёк' : ''}${guarded.length ? ' · ограничения' : ''}`, false, `user:${member.accountId}`);
                row.dataset.userSearch = `${member.accountId} ${member.label}`.toLocaleLowerCase();
                row.dataset.userFlags = [state, member.devices.length >= member.maxDevices ? 'full' : '', member.devices.length === 0 ? 'empty' : '', guarded.length ? 'guarded' : ''].filter(Boolean).join(' ');
                this.field(row, 'ID пользователя', member.accountId, 'text', true);
                this.text(row, `Срок доступа: ${member.expiresAt === null ? 'без ограничения' : new Date(member.expiresAt - 1).toLocaleDateString(undefined, { timeZone: 'UTC' }) + ' (UTC)'}${state === 'expired' ? ' · истёк' : ''}`);
                if (state === 'revoked') {
                    this.text(row, 'Доступ отозван. Подключённые устройства сохранены.');
                    act(row, 'Восстановить доступ', () => this.confirm(`Вернуть доступ пользователю ${name}? Его устройства снова заработают, будет создан новый ключ.`, () => s.restoreMember(member.accountId), { title: 'Подтвердите восстановление доступа', action: 'Восстановить доступ', danger: false }));
                } else if (state === 'expired') this.text(row, 'Срок доступа истёк. Продлите его в настройках пользователя.');
                else {
                    const standingKey = s.userKey(member.accountId);
                    if (standingKey) {
                        const standing = this.field(row, 'Ключ пользователя', standingKey, 'textarea', true); standing.dataset.standing = '1';
                        this.text(row, `Подключает устройство без ID и пароля · занято ${member.devices.length} из ${member.maxDevices}.`);
                        this.button(row, 'Скопировать приглашение', () => this.copyText(this.invitation(r.build!.adminId, member, standingKey)), false);
                        act(row, 'Перевыпустить ключ', () => this.confirm('Старый ключ перестанет подключать новые устройства. Подключённые устройства не затронуты.', async () => { await s.reissueKey(member.accountId); }, { title: 'Перевыпуск ключа', action: 'Перевыпустить ключ' }));
                    } else {
                        this.text(row, 'У этого пользователя ещё нет постоянного ключа.');
                        act(row, 'Создать постоянный ключ', () => s.reissueKey(member.accountId));
                    }
                }
                const edit = this.group(row, 'Настройки пользователя', false, `user:${member.accountId}:edit`);
                const labelField = this.field(edit, 'Имя пользователя', member.label), until = this.field(edit, 'Доступ по дату включительно (UTC)', member.expiresAt === null ? '' : new Date(member.expiresAt - 1).toISOString().slice(0, 10), 'date');
                const limit = this.field(edit, 'Лимит устройств', String(member.maxDevices), 'number'), pass = this.field(edit, 'Новый пароль (пусто — оставить прежний)', '', 'password');
                this.text(edit, 'Ограничения интерфейса: защита от случайных действий, а не от намеренного обхода. Администратора они не касаются.');
                const boxes = RESTRICTIONS.map(restriction => { const box = this.field(edit, RESTRICTION_TITLES[restriction], '', 'checkbox') as HTMLInputElement; box.checked = guarded.includes(restriction); return [restriction, box] as const; });
                act(edit, 'Сохранить изменения', () => s.updateUser(member.accountId, { label: labelField.value, password: pass.value || undefined, expiresAt: until.value ? Date.parse(until.value) + 86400000 : null, maxDevices: Number(limit.value), restrictions: boxes.filter(([, box]) => box.checked).map(([restriction]) => restriction) }));
                if (member.devices.length) {
                    const devices = this.group(row, `Устройства: ${member.devices.length}`, false, `user:${member.accountId}:devices`);
                    const result = this.field(devices, 'Ключ замены устройства', '', 'textarea', true);
                    for (const device of member.devices) {
                        this.text(devices, `Устройство ${this.short(device.deviceId)} · добавлено ${new Date(device.addedAt).toLocaleDateString()}`);
                        if (state === 'active') this.button(devices, 'Выдать ключ замены', async () => { result.value = (await s.invite(member.label, { accountId: member.accountId, replaceDeviceId: device.deviceId })).code; await r.tick(); }, false);
                        act(devices, 'Отозвать устройство', () => this.confirm(`Отозвать устройство ${this.short(device.deviceId)} пользователя ${name}? Оно потеряет доступ к организации.`, () => s.change('remove-device', member.accountId, device.deviceId), { title: 'Подтвердите отзыв устройства', action: 'Отозвать устройство' }));
                    }
                }
                if (member.active) act(row, 'Отозвать пользователя', () => this.confirm(`Все устройства пользователя ${name} потеряют доступ. Позже доступ можно вернуть кнопкой «Восстановить доступ».`, () => s.change('revoke-member', member.accountId)));
            }
            const legacy = this.group(inventory, `Пользователи прежней версии: ${r.legacyUsers.length}`, r.legacyUsers.length > 0, 'legacy');
            if (r.legacyError) this.text(legacy, r.legacyError);
            this.button(legacy, 'Обновить список из репозитория', () => r.refreshLegacy());
            this.text(legacy, 'Список загружается из users/. Для переноса нужен прежний пароль пользователя. ID, пароль, срок и лимит сохраняются; устройство регистрируется заново через выданный ключ. Исходные файлы остаются в репозитории.');
            for (const member of r.legacyUsers) {
                const imported = s.document?.members.some(m => m.accountId === member.accountId);
                const row = this.group(legacy, `${member.label || member.accountId}${imported ? ' · перенесён' : ' · прежняя запись'}`, false, `legacy:${member.accountId}`);
                row.dataset.userSearch = `${member.accountId} ${member.label}`.toLocaleLowerCase();
                if (imported) { this.text(row, 'Профиль находится в разделе «Пользователи и устройства».'); continue; }
                this.field(row, 'Прежний ID', member.accountId, 'text', true);
                const password = this.field(row, 'Прежний пароль пользователя', '', 'password');
                const output = this.field(row, 'Новый ключ для пользователя', '', 'textarea', true);
                this.button(row, 'Перенести и выдать ключ', async () => { output.value = await r.importLegacy(member.accountId, password.value); password.value = ''; }, false);
            }
            filterUsers();
            for (const d of Array.from(root.querySelectorAll<HTMLDetailsElement>('details[data-key]'))) { const saved = openState.get(d.dataset.key!); if (saved !== undefined) d.open = saved; }
        };
        renderInventory(true);
        const unsubscribeStatus = this.unsubscribe;
        const unsubscribeInventory = r.subscribe(() => { if (!this.visible) return; updateSummary(); renderInventory(); renderPlugins(); });
        this.unsubscribe = () => { unsubscribeStatus?.(); unsubscribeInventory(); };
    }
}
