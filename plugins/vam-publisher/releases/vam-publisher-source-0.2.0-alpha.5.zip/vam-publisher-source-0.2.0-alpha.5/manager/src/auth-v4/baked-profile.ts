import { validateBuild, type BuildProfile } from './model';
// The publisher replaces this one JS string literal in the compiled manager template.
const PROFILE_JSON = '__VAM_PROFILE_V4_JSON__';
export function bakedProfile(): BuildProfile | null { return PROFILE_JSON.startsWith('__') ? null : validateBuild(JSON.parse(PROFILE_JSON)); }
