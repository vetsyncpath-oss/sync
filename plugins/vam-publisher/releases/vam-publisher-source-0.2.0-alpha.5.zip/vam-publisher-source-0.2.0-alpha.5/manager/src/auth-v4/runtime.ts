import { Notice, type Plugin } from 'obsidian';
import { inspectJws, type Identity } from '../auth-v2/crypto';
import { installCompatibilityBridge } from './bridge';
import { LoginModal } from './login-modal';
import { LegacyUsers, type LegacyUser } from './legacy-users';
import { ConnectedPlugins } from './plugins';
import { vaultScope } from './vault-scope';
import { Notifications } from './notifications';
import { listOwnerUsers, scopeAdapter } from '../core/store';
import { LocalStore } from '../auth-v3/local';
import { patWarning } from '../auth-v3/pat';
import type { Decision, Query } from '../auth-v3/model';
import { bakedProfile } from './baked-profile';
import { decodeCode, memberActive, validateTransport, type BuildProfile, type Cache, type Outbox, type Session, type Transport } from './model';
import { Service, type Options } from './service';
import { UiRestrictions } from './restrictions';
import { SettingsTab } from './settings-tab';

export interface Profile { transport?: Transport; cache?: Cache | null; session?: Session | null; accountId?: string; outbox?: Outbox; knownPlugins?: string[] }
export class Runtime {
    service: Service | null = null;
    device!: Identity;
    profile: Profile = {};
    error = '';
    busy = false;
    sending = false;
    legacyDetected = false;
    legacyUsers: LegacyUser[] = [];
    legacyError = '';
    legacyLoading = false;
    readonly plugins: ConnectedPlugins;
    private legacySettings: any = null;
    private loginModal?: LoginModal;
    private layoutReady = false;
    /** Settles when the first synchronisation with Git after start has finished (it never blocks plugin loading when started in the background). */
    ready: Promise<void> = Promise.resolve();
    private disposed = false;
    private settingsTab?: SettingsTab;
    /** True from construction until the first check against Git has finished: other plugins see "checking", not a refusal. */
    private starting = true;
    private onVisible?: () => void;
    private restrictions: UiRestrictions;
    private epoch = 0;
    private ticking = false;
    private warnedPat = '';
    private profileReady = false;
    private notifications = new Notifications();
    private listeners = new Set<() => void>();
    private timers: ReturnType<typeof setInterval>[] = [];
    private bridge?: ReturnType<typeof installCompatibilityBridge>;
    private candidate: Service | null = null;
    private saveQueue: Promise<void> = Promise.resolve();
    private key: string;
    private connectionKey: string;
    constructor(private plugin: Plugin, readonly build: BuildProfile | null = bakedProfile(), private options: Options = {}, readonly local = new LocalStore('vam-installation-v4')) {
        this.key = build ? `profile:${build.tenantId}:${JSON.stringify(build.repository)}` : 'unconfigured';
        this.connectionKey = `connection:${this.key}`; this.restrictions = new UiRestrictions(plugin.app);
        this.plugins = new ConnectedPlugins(plugin, () => !this.disposed && this.decision.status === 'granted', () => this.changed());
    }
    /** `awaitRefresh: false` (used by the plugin entry) returns after local initialisation; the network check continues in the background. */
    async start(options: { awaitRefresh?: boolean } = {}): Promise<void> {
        this.bridge = installCompatibilityBridge(this, this.plugin, id => { this.plugins.register(id); this.profile.knownPlugins = [...this.plugins.known]; if (this.device) void this.save().catch(() => {}); });
        this.settingsTab = new SettingsTab(this.plugin.app, this.plugin, this);
        this.plugin.addSettingTab(this.settingsTab);
        this.plugin.addCommand({ id: 'vam-access', name: 'Открыть профиль и доступ к бандлу', callback: () => this.openSettings() });
        this.plugin.addCommand({ id: 'vam-login', name: 'Войти в профиль', callback: () => this.openLogin() });
        this.plugin.addCommand({ id: 'vam-logout', name: 'Выйти из текущего профиля', callback: () => { void this.logout(); } });
        try {
            this.legacySettings = await this.plugin.loadData(); this.legacyDetected = !!this.legacySettings;
            this.device = await this.local.identity('device');
            const previousKey = this.key, scope = await vaultScope(this.plugin.app);
            this.key = `${previousKey}:vault:${scope.id}:bundle:${this.build?.bundleId ?? 'none'}`;
            const scoped = await this.local.secret<Profile>(this.key);
            this.profile = scoped ?? {};
            const connectionVersion = await this.local.get<number>(`${this.connectionKey}:version`);
            if (connectionVersion && Number.isSafeInteger(connectionVersion)) {
                try {
                    const connection = validateTransport(await this.local.secret(`${this.connectionKey}:${connectionVersion}`));
                    if (!this.profile.transport || connection.version > this.profile.transport.version) this.profile.transport = connection;
                } catch { /* Invalid shared transport never supplies a session or cached rights. */ }
            }
            if (!scoped && this.build) {
                // The old installation-wide profile cannot prove which vault authenticated it.
                // Retain only transport, never its session, cache, account or pending device request.
                const previous = await this.local.secret<Profile>(previousKey);
                if (!this.profile.transport && previous?.transport) { try { this.profile.transport = validateTransport(previous.transport); } catch {} }
                if (previous?.session) new Notice('Вход теперь привязан к конкретному vault. Пожалуйста, войдите в профиль заново в этом хранилище.', 15000);
            }
            this.profileReady = true;
            if (!scope.persistent) new Notice('Не удалось определить постоянный ID vault. Вход сохраняется только до закрытия Obsidian.', 15000);
            for (const id of this.profile.knownPlugins ?? []) this.plugins.register(id);
            for (const entry of this.legacySettings?.knownHookPlugins ?? []) if (typeof entry?.id === 'string') this.plugins.register(entry.id);
            this.profile.knownPlugins = [...this.plugins.known];
            if (this.disposed || !this.build) { this.starting = false; return; }
            const token = this.profile.transport?.token || this.build.bootstrapToken;
            if (token) {
                this.service = this.createService(token, this.profile.transport?.version ?? 0);
                try { this.service.restoreCache(this.profile.cache ?? null); } catch { this.profile.cache = null; }
                this.service.restoreSession(this.profile.session ?? null);
            }
        } catch { this.error = 'Не удалось открыть локальный профиль. Доступ закрыт; прежние данные сохранены.'; }
        if (this.disposed) return;
        this.timers.push(setInterval(() => { void this.tick(); }, 60000));
        this.timers.push(setInterval(() => this.changed(), 10000)); this.changed();
        // Mobile systems suspend timers in the background: refresh as soon as the app is visible again.
        if (typeof document !== 'undefined') { this.onVisible = () => { if (!document.hidden) void this.tick(); }; document.addEventListener('visibilitychange', this.onVisible); }
        this.ready = this.syncOnStart();
        const workspace = this.plugin.app.workspace as any;
        workspace?.onLayoutReady?.(() => {
            this.layoutReady = true; if (this.disposed || !this.build) return;
            const check = (): void => {
                if (this.disposed) return;
                if (!this.session || (this.session.kind === 'administrator' && !this.service?.isAdministrator())) this.openLogin();
                else if (this.decision.status !== 'granted') new Notice(this.status, 10000);
            };
            // Without a session the login cards appear at once; otherwise wait for the first check so a remembered login is not misreported.
            if (!this.session) check(); else void this.ready.then(check);
        });
        if (options.awaitRefresh !== false) await this.ready;
    }
    private async syncOnStart(): Promise<void> {
        try { if (!this.service || this.disposed) return; await this.tick(); if (this.service?.isAdministrator()) await this.plugins.restore(); }
        catch { this.error = 'Не удалось открыть локальный профиль. Доступ закрыт; прежние данные сохранены.'; }
        finally { this.starting = false; this.changed(); }
    }
    private createService(token: string, version = 0): Service {
        if (!this.build || !this.device) throw new Error('Нужна сборка для вашей организации от Издателя');
        return new Service(this.build, this.device, token, version, { ...this.options, changed: () => this.changed() });
    }
    openSettings(): void {
        // A user without access to Obsidian settings still reaches the profile (sign out, plugin list) through the manager's own window.
        if (this.restrictions.isActive('settings.open')) { this.openLogin(true); return; }
        this.plugin.app.setting?.open(); this.plugin.app.setting?.openTabById(this.plugin.manifest.id);
    }
    openLogin(keepOpen = false): void { if (this.disposed || this.loginModal) return; this.loginModal = new LoginModal(this.plugin.app, this.plugin, this, () => { this.loginModal = undefined; }, keepOpen); this.loginModal.open(); }
    subscribe(cb: () => void): () => void { this.listeners.add(cb); return () => this.listeners.delete(cb); }
    changed = (): void => {
        this.bridge?.refresh();
        this.restrictions.update(this.disposed ? [] : this.service?.restrictions() ?? []);
        if (this.profileReady && !this.disposed) this.notifications.update({ decision: this.decision, role: this.service?.isAdministrator() ? 'administrator' : this.session?.kind === 'user' ? 'user' : null, requestSubmitted: !!this.profile.outbox?.submitted, requestFailed: !!this.profile.outbox && !this.profile.outbox.submitted && !!this.error, requestRejected: !!this.profile.outbox && !!this.service?.requestRejected(this.profile.outbox.id), pending: this.service?.pending.map(p => p.path) ?? [], pluginError: this.plugins.error });
        for (const cb of [...this.listeners]) try { cb(); } catch {}
    };
    access(query: Query): Decision {
        if (this.disposed) return { status: 'blocked', reason: 'vam-unloaded', validUntil: null };
        if (!this.service) return this.starting ? { status: 'pending', reason: 'checking', validUntil: null } : { status: 'blocked', reason: 'not-configured', validUntil: null };
        const decision = this.service.access(query);
        // While the first check after start is still running, "no data yet" is not a verdict: other plugins must not treat it as a refusal.
        return this.starting && decision.status === 'blocked' && decision.reason === 'connection-unavailable' ? { status: 'pending', reason: 'checking', validUntil: null } : decision;
    }
    get decision(): Decision { return this.access({ tenantId: this.build?.tenantId ?? '', bundleId: this.build?.bundleId ?? '' }); }
    get session(): Session | null { return this.service?.session ?? null; }
    get status(): string {
        if (!this.build) return 'Эта сборка ещё не подготовлена для организации. Получите готовый менеджер у Издателя.';
        if (this.error) return this.error;
        if (this.service?.error) return this.service.error;
        if (this.sending) return 'Отправляем заявку устройства…';
        if (this.service?.isAdministrator()) return 'Вы вошли как Администратор';
        if (this.decision.reason === 'checking') return 'Проверяем доступ…';
        if (!this.session) return 'Выберите способ входа';
        if (this.decision.status === 'granted') return this.service?.online ? 'Доступ к бандлу активен' : 'Доступ активен по сохранённым данным';
        if (this.profile.outbox && this.service?.requestRejected(this.profile.outbox.id)) return 'Администратор отклонил заявку на подключение устройства. Обратитесь к нему.';
        if (this.decision.reason === 'device-limit') return this.profile.outbox?.submitted ? 'Лимит устройств исчерпан. Заявка отправлена Администратору, ожидаем решения.' : 'Лимит устройств исчерпан. Обратитесь к Администратору.';
        if (this.decision.reason === 'access-revoked-or-expired' || this.decision.reason === 'device-revoked') return 'Доступ отозван или срок доступа истёк. Обратитесь к Администратору.';
        if (this.profile.outbox) return this.profile.outbox.submitted ? 'Устройство отправлено Администратору. Ожидаем подтверждения.' : 'Заявка ещё не отправлена. Повторите отправку.';
        return 'Подключение недоступно. Обратитесь к Администратору за кодом восстановления.';
    }
    private save(): Promise<void> {
        if (this.disposed || !this.build || !this.profileReady) return Promise.resolve();
        if (this.service) { this.profile.transport = structuredClone(this.service.transport); this.profile.cache = this.service.cache; this.profile.session = this.service.session; }
        const snapshot = structuredClone(this.profile);
        const connection = this.service?.online && this.service.document?.transport.token === this.service.transport.token && this.service.document.transport.version === this.service.transport.version ? structuredClone(this.service.transport) : null;
        const task = this.saveQueue.catch(() => {}).then(async () => {
            await this.local.saveSecret(this.key, snapshot);
            // A known Git connection can be reused in another vault; it never restores a login.
            if (connection) { await this.local.saveSecret(`${this.connectionKey}:${connection.version}`, connection); await this.local.advanceVersion(`${this.connectionKey}:version`, connection.version); }
        }); this.saveQueue = task; return task;
    }
    private guard(epoch: number): void { if (this.disposed || this.epoch !== epoch) throw new Error('Действие отменено'); }
    private async exclusive(work: (epoch: number) => Promise<void>): Promise<void> {
        if (this.busy || this.disposed || !this.device || !this.profileReady) throw new Error('Профиль ещё открывается или занят');
        this.busy = true; this.error = ''; const epoch = this.epoch;
        try { await work(epoch); this.guard(epoch); await this.save(); }
        catch (e) { this.error = e instanceof Error ? e.message : 'Действие не выполнено'; throw e; }
        finally { this.candidate = null; this.busy = false; this.changed(); }
    }
    async loginAdministrator(password: string, token = '', expiresOn: string | null = null): Promise<void> {
        await this.exclusive(async epoch => {
            const transport = token.trim() || this.profile.transport?.token || this.build?.bootstrapToken;
            if (!transport) throw new Error('Для первого подключения укажите PAT в разделе подключения Администратора');
            const next = this.createService(transport, token.trim() ? 0 : this.profile.transport?.version ?? 0);
            this.candidate = next;
            try { await next.loginAdministrator(password, expiresOn); this.guard(epoch); }
            catch (e) { next.dispose(); throw e; }
            this.service?.dispose(); this.service = next; delete this.profile.outbox;
            await next.processRequests(); this.warn();
            await this.refreshLegacy(); this.guard(epoch);
            await this.plugins.restore();
        });
    }
    async loginUser(accountId: string, password: string): Promise<void> {
        await this.exclusive(async epoch => {
            const token = this.profile.transport?.token || this.build?.bootstrapToken;
            if (!token) throw new Error('Для первого подключения введите выданный ключ доступа. После этого доступен вход по ID и паролю.');
            const next = this.createService(token, this.profile.transport?.version ?? 0);
            this.candidate = next;
            let outbox: Outbox | null;
            try { outbox = await next.loginUser(accountId.trim(), password); this.guard(epoch); }
            catch (e) { next.dispose(); throw e; }
            this.service?.dispose(); this.service = next; this.profile.accountId = accountId.trim();
            if (outbox) {
                const previous = this.profile.outbox;
                const previousRequest = previous ? inspectJws(previous.code) as any : null;
                this.profile.outbox = previous && previous.expiresAt > Date.now() && !next.requestRejected(previous.id) && previousRequest.accountId === accountId.trim() && previousRequest.auth.kind === 'password' && previousRequest.auth.password === password ? previous : outbox;
                await this.save(); await this.sendPending();
            } else delete this.profile.outbox;
        });
    }
    async applyCode(text: string): Promise<void> {
        await this.exclusive(async epoch => {
            if (!this.build) throw new Error('Получите сборку организации у Издателя');
            const code = decodeCode(text.trim(), this.build), next = this.createService(code.transport.token, code.transport.version);
            this.candidate = next;
            let outbox: Outbox | undefined;
            try {
                await next.refresh(); this.guard(epoch); if (!next.online || !next.document) throw new Error(next.error || 'Организация ещё не подключена Администратором');
                if (code.purpose === 'update') {
                    if (this.profile.accountId !== code.accountId) throw new Error('Код восстановления предназначен для ранее подключённого профиля');
                    if (code.transport.version < (this.profile.transport?.version ?? 0)) throw new Error('Этот код подключения устарел');
                    const member = next.document.members.find(m => m.accountId === code.accountId);
                    if (!memberActive(member, Date.now()) || !member.devices.some(d => d.deviceId === this.device.keyId)) throw new Error('Устройство отозвано. Обновление PAT не выдаёт доступ заново.');
                    next.restoreSession(this.profile.session ?? null);
                } else {
                    const previous = this.profile.outbox;
                    if (previous && previous.expiresAt > Date.now() && !next.requestRejected(previous.id) && this.profile.accountId === code.accountId) {
                        // Reuse only the exact invitation; inspect the signed, installation-owned outbox.
                        const request = inspectJws(previous.code) as any;
                        if (request.auth.kind === 'invitation' && request.auth.id === code.invitationId && request.auth.secret === code.secret) outbox = previous;
                    }
                    if (!outbox) { next.validateInvitation(code); outbox = await next.request(code.accountId, { kind: 'invitation', id: code.invitationId!, secret: code.secret! }); }
                    next.restoreSession({ kind: 'user', accountId: code.accountId });
                }
            } catch (e) { next.dispose(); throw e; }
            this.guard(epoch); this.service?.dispose(); this.service = next; this.profile.accountId = code.accountId;
            if (outbox) this.profile.outbox = outbox;
            await this.save(); if (outbox) await this.sendPending();
        });
    }
    async sendPending(): Promise<void> {
        const outbox = this.profile.outbox, service = this.service, epoch = this.epoch;
        if (!outbox || !service || this.sending || this.disposed) return;
        this.sending = true;
        try { await service.submit(outbox); this.guard(epoch); outbox.submitted = true; this.error = ''; await this.save(); }
        catch (e) { this.error = e instanceof Error ? e.message : 'Заявка не отправлена'; throw e; }
        finally { this.sending = false; this.changed(); }
    }
    async tick(): Promise<void> {
        if (!this.service || this.ticking || this.busy || this.disposed) return;
        this.ticking = true; const epoch = this.epoch;
        try {
            await this.service.refresh(); this.guard(epoch);
            if (this.service.isAdministrator()) { this.warn(); await this.service.processRequests(); await this.refreshLegacy(); }
            if (this.profile.outbox && !this.profile.outbox.submitted && this.service.online && this.session?.kind === 'user') await this.sendPending();
            if (this.decision.status === 'granted' && this.session?.kind === 'user') delete this.profile.outbox;
            if (this.service.online && !this.service.error) this.error = '';
            await this.save();
        } catch (e) { if (epoch === this.epoch) this.error = e instanceof Error ? e.message : 'Не удалось обновить доступ'; }
        finally { this.ticking = false; this.changed(); }
    }
    private warn(): void {
        if (!this.service?.isAdministrator()) return;
        const transport = this.service.document!.transport, warning = patWarning(transport.expiresOn), key = `${transport.version}:${transport.expiresOn}`;
        if (warning && key !== this.warnedPat) { this.warnedPat = key; new Notice(warning, 15000); }
    }
    async refreshLegacy(): Promise<void> {
        const service = this.service, epoch = this.epoch;
        if (!this.build || !service?.isAdministrator() || this.legacyLoading) return;
        this.legacyLoading = true; this.legacyError = '';
        try {
            const rows = await new LegacyUsers(this.build, service.transport.token, this.options.fetcher).list(); this.guard(epoch);
            if (!service.isAdministrator()) return;
            const adapter = this.plugin.app.vault.adapter, oldRepo = this.legacySettings?.channel;
            const sameRepo = oldRepo && ['baseUrl', 'owner', 'repo'].every(key => oldRepo[key] === (this.build!.repository as any)[key]);
            // Local metadata is only a label hint, and only for the same repository. Git determines presence.
            if (sameRepo && adapter?.list) {
                const dir = typeof this.plugin.manifest.dir === 'string' ? this.plugin.manifest.dir : `${this.plugin.app.vault.configDir ?? '.obsidian'}/plugins/${this.plugin.manifest.id}`;
                const metas = await listOwnerUsers(scopeAdapter(adapter, dir)); this.guard(epoch);
                for (const row of rows) { const meta = metas.find(m => m.userId === row.accountId); if (meta) { row.label = meta.note; row.expiresAt = meta.expiresAt; } }
            }
            this.legacyUsers = rows;
        } catch { if (epoch === this.epoch) this.legacyError = 'Не удалось загрузить прежних пользователей из users/. Проверьте подключение и повторите загрузку.'; }
        finally { this.legacyLoading = false; this.changed(); }
    }
    async importLegacy(accountId: string, oldPassword: string): Promise<string> {
        let code = '';
        await this.exclusive(async epoch => {
            if (!this.build || !this.service?.isAdministrator()) throw new Error('Войдите как Администратор');
            let payload;
            try { payload = await new LegacyUsers(this.build, this.service.transport.token, this.options.fetcher).decrypt(accountId, oldPassword); }
            catch { throw new Error('Не удалось проверить прежнюю запись. Проверьте её наличие, срок доступа и прежний пароль пользователя.'); }
            this.guard(epoch); code = await this.service.importLegacy(payload, oldPassword);
        });
        return code;
    }
    async rotateToken(token: string, expiresOn: string | null): Promise<void> { await this.exclusive(async epoch => { if (!this.service?.isAdministrator()) throw new Error('Войдите как Администратор'); await this.service.rotateToken(token, expiresOn); this.guard(epoch); }); }
    async logout(): Promise<void> {
        this.notifications.reset();
        if (this.candidate && this.candidate !== this.service) this.candidate.dispose();
        this.epoch++; this.service?.logout(); this.profile.session = null; delete this.profile.outbox; this.legacyUsers = []; this.error = ''; this.changed(); await this.save(); if (this.layoutReady) this.openLogin();
    }
    dispose(): void { this.settingsTab?.hide(); this.disposed = true; this.epoch++; this.restrictions.dispose(); if (this.onVisible && typeof document !== 'undefined') document.removeEventListener('visibilitychange', this.onVisible); this.loginModal?.close(); this.timers.forEach(clearInterval); this.candidate?.dispose(); this.service?.dispose(); this.bridge?.dispose(); this.listeners.clear(); void this.saveQueue.finally(() => this.local.close()).catch(() => {}); }
}
