import 'fake-indexeddb/auto';
import { parseHTML } from 'linkedom';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { Plugin, Modal } from 'obsidian';
import { Runtime } from '../manager/src/auth-v4/runtime';
import { SettingsTab } from '../manager/src/auth-v4/settings-tab';
import { LocalStore } from '../manager/src/auth-v3/local';
import { build, Repository } from './helpers/v4';
const active: Runtime[] = [];
beforeEach(() => { const { window } = parseHTML('<!doctype html><html><body></body></html>'); for (const name of ['document', 'HTMLElement', 'HTMLInputElement', 'HTMLTextAreaElement', 'Event']) vi.stubGlobal(name, (window as any)[name]); });
afterEach(() => { active.splice(0).forEach(r => r.dispose()); for (const m of [...(Modal as any).opened]) m.close(); delete (globalThis as any).__VAM__; delete (globalThis as any).__VAM_PENDING__; delete (globalThis as any).vaultSyncAuth; vi.unstubAllGlobals(); });
function setup(repo = new Repository(), name = crypto.randomUUID()) {
    let onReady: () => void = () => {};
    const plugin = new Plugin({ vault: {}, workspace: { onLayoutReady(cb: () => void) { onReady = cb; } } } as any, { id: 'vault-access-manager', version: 'test' });
    const r = new Runtime(plugin, build, { fetcher: repo.fetcher }, new LocalStore(name)); active.push(r);
    return { r, plugin, repo, ready: () => onReady(), view: () => { const view = new SettingsTab(plugin.app, plugin, r); document.body.append(view.containerEl); view.display(); return view; } };
}
function button(root: ParentNode, title: string): HTMLButtonElement { const b = Array.from(root.querySelectorAll('button')).find(b => b.textContent === title || b.querySelector('.vam-card-title')?.textContent === title); if (!b) throw new Error('Missing button: ' + title); return b; }
function field(root: ParentNode, title: string): HTMLInputElement { const label = Array.from(root.querySelectorAll('label')).find(l => l.firstChild?.textContent === title); if (!label) throw new Error('Missing field: ' + title); return label.querySelector('input,textarea') as HTMLInputElement; }
async function click(b: HTMLButtonElement) { await (b.onclick as any)?.({ preventDefault() {} }); }

describe('startup login cards and a quiet remembered profile', () => {
    it('opens three keyboard-accessible login cards after the vault layout is ready', async () => {
        const f = setup(); await f.r.start(); expect(document.querySelector('.vam-login-modal')).toBeNull(); f.ready();
        expect(document.querySelectorAll('button.vam-card')).toHaveLength(3);
        await click(button(document, 'У меня есть ключ доступа'));
        expect(field(document, 'Ключ доступа от Администратора').tagName).toBe('TEXTAREA');
        expect(document.body.textContent).not.toContain(build.repository.repo); expect(document.querySelector('input[type=password]')).toBeNull();
        await click(button(document, '← Выбрать другой способ входа')); expect(document.querySelectorAll('.vam-card')).toHaveLength(3);
    });
    it('keeps a failed password form intact, then closes the modal after successful login', async () => {
        const f = setup(); await f.r.start(); f.ready(); await click(button(document, 'Я Администратор'));
        field(document, 'Пароль Администратора').value = 'wrong'; field(document, 'PAT Администратора').value = 'old-token';
        f.r.changed(); expect(field(document, 'Пароль Администратора').value).toBe('wrong');
        await click(button(document, 'Войти как Администратор')); expect(document.querySelector('.vam-login-modal')).not.toBeNull(); expect(document.querySelector('[role=status]')?.textContent).toContain('Неверный пароль');
        field(document, 'Пароль Администратора').value = build.defaultPassword;
        await click(button(document, 'Войти как Администратор')); expect(f.r.decision.status).toBe('granted'); expect(document.querySelector('.vam-login-modal')).toBeNull();
        expect((f.r as any).listeners.size).toBe(0);
    });
    it('shows login cards after an administrator restarts the same vault', async () => {
        const name = crypto.randomUUID(), repo = new Repository(), first = setup(repo, name); await first.r.start(); await first.r.loginAdministrator(build.defaultPassword, 'old-token'); first.r.dispose();
        const next = setup(repo, name); await next.r.start(); next.ready(); expect(document.querySelectorAll('.vam-card')).toHaveLength(3); expect(next.r.session).toBeNull();
        await next.r.logout(); expect(document.querySelectorAll('.vam-card')).toHaveLength(3); next.r.openLogin(); expect(document.querySelectorAll('.vam-login-modal')).toHaveLength(1);
    });
});
describe('administrator dashboard updates without losing work', () => {
    it('shows repository users and retains an issued key across background refreshes', async () => {
        const f = setup(); await f.r.start(); await f.r.loginAdministrator(build.defaultPassword, 'old-token'); const view = f.view();
        field(view.containerEl, 'ID пользователя (пусто — создать автоматически)').value = 'alice'; field(view.containerEl, 'Имя или метка пользователя').value = 'Alice';
        await click(button(view.containerEl, 'Выдать ключ доступа'));
        const output = field(view.containerEl, 'Данные для личной передачи пользователю').value; expect(output).toContain('VAM4.'); await f.r.tick();
        expect(field(view.containerEl, 'Данные для личной передачи пользователю').value).toBe(output); expect(view.containerEl.textContent).toContain('Alice');
        // A background list update must also retain unrelated typed administrative credentials.
        field(view.containerEl, 'Новый PAT').value = 'unsaved-private-token'; await f.r.service!.invite('Bob', { accountId: 'bob' }); f.r.changed();
        expect(field(view.containerEl, 'Новый PAT').value).toBe('unsaved-private-token'); expect(view.containerEl.textContent).toContain('Bob'); view.hide();
    });
    it('hides repository and PAT administration from the user dashboard', async () => {
        const f = setup(); await f.r.start(); await f.r.loginAdministrator(build.defaultPassword, 'old-token'); const code = await f.r.service!.invite('Alice', { accountId: 'alice' });
        const user = setup(f.repo); await user.r.start(); await user.r.applyCode(code.code); await f.r.tick(); await user.r.tick(); const view = user.view();
        expect(view.containerEl.textContent).toContain('Доступ к бандлу активен'); expect(view.containerEl.textContent).not.toContain(build.repository.repo);
        expect(view.containerEl.textContent).not.toContain('Новый PAT'); expect(view.containerEl.textContent).not.toContain('Пользователи прежней версии'); view.hide();
    });
    it('preserves unfinished member edits during refresh and filters both user lists', async () => {
        const f = setup(); await f.r.start(); await f.r.loginAdministrator(build.defaultPassword, 'old-token');
        await f.r.service!.invite('Alice', { accountId: 'alice' }); await f.r.service!.invite('Bob', { accountId: 'bob' });
        f.r.legacyUsers = [{ accountId: 'abcdef1', label: 'Legacy Alice', inRepository: true }];
        const view = f.view(); const name = field(view.containerEl, 'Имя пользователя'); name.value = 'Unsaved edit'; name.dispatchEvent(new Event('input', { bubbles: true }));
        await f.r.service!.invite('Carol', { accountId: 'carol' }); f.r.changed(); expect(field(view.containerEl, 'Имя пользователя').value).toBe('Unsaved edit');
        const search = field(view.containerEl, 'Найти пользователя по ID или имени'); search.value = 'Alice'; search.dispatchEvent(new Event('input'));
        const visible = Array.from(view.containerEl.querySelectorAll<HTMLElement>('[data-user-search]')).filter(row => !row.hidden); expect(visible).toHaveLength(2);
        view.hide();
    });

    it('requires confirmation for revocation and treats closing that modal as cancellation', async () => {
        const f = setup(); await f.r.start(); await f.r.loginAdministrator(build.defaultPassword, 'old-token'); await f.r.service!.invite('Alice', { accountId: 'alice' }); const view = f.view();
        const cancelled = click(button(view.containerEl, 'Отозвать пользователя')); (Modal as any).opened.at(-1).close(); await cancelled; expect(f.repo.document().members[0].active).toBe(true);
        const approved = click(button(view.containerEl, 'Отозвать пользователя')); await click(button(document, 'Отозвать доступ')); await approved; expect(f.repo.document().members[0].active).toBe(false); view.hide();
    });

});
