import 'fake-indexeddb/auto';
import { describe, expect, it } from 'vitest';
import { LocalStore } from '../manager/src/auth-v3/local';
import { PublisherService, prepareRelease } from '../src/service';
import { generateIdentity } from '../manager/src/auth-v2/crypto';
import { zip } from '../src/zip';
import { build } from './helpers/v4';
const template = { main: 'module.exports = "__VAM_PROFILE_V4_JSON__";', manifest: '{"id":"vault-access-manager","version":"test"}', styles: '/* style */' };
describe('private publisher as a baking tool', () => {
    it('creates and restores a registry without a publisher password or signing identity', async () => {
        const name = crypto.randomUUID(), local = new LocalStore(name), publisher = new PublisherService(local); await publisher.start();
        const { v, tenantId, ...input } = build; const profile = await publisher.create(input); expect(profile.adminId).toBe(build.adminId); expect(profile.tenantId).not.toBe(build.tenantId);
        expect(await local.get('device')).toBeUndefined(); expect(await local.get('user')).toBeUndefined(); expect(JSON.stringify(await local.get('registry'))).not.toContain(build.defaultPassword);
        await publisher.close(); const restored = new PublisherService(new LocalStore(name)); await restored.start(); expect(restored.registry.profiles[0]).toEqual(profile); await restored.close();
    });
    it('keeps one organization identity across repository/profile edits and prevents duplicate IDs', async () => {
        const publisher = new PublisherService(new LocalStore(crypto.randomUUID())); await publisher.start();
        try { const { v, tenantId, ...input } = build, profile = await publisher.create(input); await expect(publisher.create(input)).rejects.toThrow('уже существует'); await publisher.updateProfile(profile.tenantId, { ...input, defaultPassword: 'changed', repository: { ...input.repository, repo: 'replacement' } }); expect(publisher.registry.profiles[0].tenantId).toBe(profile.tenantId); expect(publisher.registry.profiles[0].repository.repo).toBe('replacement'); }
        finally { await publisher.close(); }
    });
    it('produces exactly three manager files with a safely escaped fixed profile and no issuer code', async () => {
        const issuer = await generateIdentity();
        const profile = { ...build, defaultPassword: 'quote" backslash\\ newline\n $& ` ${1} Юникод' }, release = prepareRelease({...profile, bootstrapToken: "secret-test-token"}, template, issuer.publicKey);
        expect(Object.keys(release.files)).toEqual(['vault-access-manager/main.js', 'vault-access-manager/manifest.json', 'vault-access-manager/styles.css']);
        const runtime: any = { exports: '' }; new Function('module', release.files['vault-access-manager/main.js'])(runtime); const client = JSON.parse(runtime.exports);
        expect(client).toEqual({v:4, adminId:profile.adminId,tenantId:profile.tenantId,bundleId:profile.bundleId,repository:profile.repository,ownerKey:issuer.publicKey});
        expect(runtime.exports).not.toContain("secret-test-token"); expect(client).not.toHaveProperty('defaultPassword');
        expect(release.document).toContain('repository'); expect(release.files['vault-access-manager/main.js']).not.toContain('__VAM_PROFILE_V4_JSON__');
    });
    it('rejects already baked, missing-marker, duplicate-marker and insecure endpoint templates', async () => {
        const key = (await generateIdentity()).publicKey;
        expect(() => prepareRelease(build, { ...template, main: 'no marker' },key)).toThrow('несовместим'); expect(() => prepareRelease(build, { ...template, main: template.main + template.main },key)).toThrow('несовместим'); expect(() => prepareRelease({ ...build, repository: { ...build.repository, baseUrl: 'http://insecure/api/v1' } }, template,key)).toThrow('HTTPS');
    });
    it('merges backups without silently replacing a current administrator profile', async () => {
        const one = new PublisherService(new LocalStore(crypto.randomUUID())), two = new PublisherService(new LocalStore(crypto.randomUUID())); await one.start(); await two.start();
        try { const { v, tenantId, ...input } = build; const profile = await one.create(input); await two.restoreRegistry((await one.release(profile.tenantId, template)).document); const snapshot = two.exportRegistry(); await expect(two.restoreRegistry(one.exportRegistry())).rejects.toThrow('существующий'); expect(two.exportRegistry()).toBe(snapshot); }
        finally { await one.close(); await two.close(); }
    });
    it('writes standard ZIP headers and the known CRC-32 vector; rejects path traversal', () => {
        const archive = zip({ 'plugin/vector.txt': '123456789' }), view = new DataView(archive.buffer);
        expect(view.getUint32(0, true)).toBe(0x04034b50); expect(view.getUint32(14, true)).toBe(0xcbf43926); expect(view.getUint32(archive.length - 22, true)).toBe(0x06054b50); expect(view.getUint16(archive.length - 12, true)).toBe(1); expect(() => zip({ '../secret': 'bad' })).toThrow('путь');
    });
});

it('requires a scoped, unexpired owner ticket before initializing a public build and accepts ordinary login for an existing organization', async () => {
    const {issueOwnerSetup} = await import('../manager/src/auth-v4/owner-setup');
    const {publicBuild, DAY} = await import('../manager/src/auth-v4/model');
    const {Service} = await import('../manager/src/auth-v4/service');
    const {Repository} = await import('./helpers/v4');
    const issuer = await generateIdentity(), other = await generateIdentity(), repo = new Repository();
    const client = publicBuild({v:4,adminId:build.adminId,bundleId:build.bundleId,tenantId:build.tenantId,repository:build.repository, ownerKey:issuer.publicKey});
    expect(()=>publicBuild({...client,bootstrapToken:'fixture-secret'})).toThrow();
    const now = Date.now(), service = new Service(client,await generateIdentity(),'old-token',0,{store:repo.store,now:()=>now});
    try {
        const valid = await issueOwnerSetup(build,issuer,now);
        const invalid = ['', await issueOwnerSetup(build,other,now),await issueOwnerSetup({...build,bundleId:'another'},issuer,now),await issueOwnerSetup(build,issuer,now-DAY)];
        for(const ticket of invalid) await expect(service.loginAdministrator(build.defaultPassword,null,ticket)).rejects.toThrow();
        await expect(service.loginAdministrator('incorrect',null,valid)).rejects.toThrow();
        expect(repo.writes).toBe(0); expect(service.isAdministrator()).toBe(false);
        await service.loginAdministrator(build.defaultPassword,null,valid); expect(service.isAdministrator()).toBe(true);
        service.logout(); await service.loginAdministrator(build.defaultPassword); expect(service.isAdministrator()).toBe(true);
    } finally {service.dispose();}
});
