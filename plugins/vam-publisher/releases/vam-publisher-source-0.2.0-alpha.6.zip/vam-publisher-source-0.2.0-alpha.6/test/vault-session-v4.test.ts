import {attachVaultFile} from './helpers/vault-file';
import 'fake-indexeddb/auto';
import { afterEach, describe, expect, it } from 'vitest';
import { Plugin } from 'obsidian';
import { Runtime } from '../manager/src/auth-v4/runtime';
import { LocalStore } from '../manager/src/auth-v3/local';
import { build, Repository } from './helpers/v4';
const runtimes: Runtime[] = [];
afterEach(() => { runtimes.splice(0).forEach(r => r.dispose()); delete (globalThis as any).__VAM__; delete (globalThis as any).vaultSyncAuth; });
function open(repo: Repository, installation: string, path: string | null, bootstrap = true, appId: string | null = null) {
    const plugin = new Plugin({ appId, vault: { adapter: path === null ? {} : { getBasePath: () => path } }, initialSettings: { role: 'owner' } } as any, { id: 'vault-access-manager', version: 'test' });
    attachVaultFile(plugin,JSON.stringify([installation,path,appId]));
    const runtime = new Runtime(plugin, { ...build, ...(bootstrap ? { bootstrapToken: 'old-token' } : {}) }, { fetcher: repo.fetcher }, new LocalStore(installation)); runtimes.push(runtime); return runtime;
}
describe('vault isolation within one shared installation database', () => {
    it('does not inherit administrative login in another vault, even with the same name and baked profile', async () => {
        const repo = new Repository(), installation = crypto.randomUUID();
        const a = open(repo, installation, '/first/Notes'); await a.start(); await a.loginAdministrator(build.defaultPassword);
        const b = open(repo, installation, '/second/Notes'); await b.start();
        expect(b.device.keyId).toBe(a.device.keyId);
        expect(b.session).toBeNull(); expect(b.decision.status).toBe('blocked'); expect(a.service!.isAdministrator()).toBe(true);
    });
    it('requires a fresh administrator login in the same vault after restart', async () => {
        const repo = new Repository(), installation = crypto.randomUUID(), a = open(repo, installation, '/first/Notes'); await a.start(); await a.loginAdministrator(build.defaultPassword); a.dispose();
        const again = open(repo, installation, '/first/Notes'); await again.start(); expect(again.session).toBeNull(); expect(again.service!.isAdministrator()).toBe(false);
    });
    it('does not let logout in one vault change another vault’s saved login', async () => {
        const repo = new Repository(), installation = crypto.randomUUID(), a = open(repo, installation, '/a'), b = open(repo, installation, '/b');
        await a.start(); await a.loginAdministrator(build.defaultPassword); await b.start(); await b.loginAdministrator(build.defaultPassword); await b.logout();
        expect(a.service!.isAdministrator()).toBe(true); a.dispose(); const again = open(repo, installation, '/a'); await again.start(); expect(again.session).toBeNull(); expect(again.service!.isAdministrator()).toBe(false);
        const signedOut = open(repo, installation, '/b'); await signedOut.start(); expect(signedOut.session).toBeNull();
    });
    it('never migrates the unscoped administrator session, account or outbox from alpha.3', async () => {
        const repo = new Repository(), installation = crypto.randomUUID(), old = open(repo, installation, '/old'); await old.start(); await old.loginAdministrator(build.defaultPassword);
        await old.local.saveSecret(`profile:${build.tenantId}:${JSON.stringify(build.repository)}`, { ...old.profile, accountId: 'other-vault-user', outbox: { id: 'old-request', submitted: true } });
        const next = open(repo, installation, '/new', false); await next.start();
        expect(next.profile.transport?.token).toBe('old-token'); expect(next.session).toBeNull(); expect(next.profile.accountId).toBeUndefined(); expect(next.profile.outbox).toBeUndefined(); expect(next.decision.status).toBe('blocked');
        await next.loginAdministrator(build.defaultPassword); expect(next.service!.isAdministrator()).toBe(true);
    });
    it('isolates user sessions as well while retaining the installation device and one-slot enrollment', async () => {
        const repo = new Repository(), installation = crypto.randomUUID(), admin = open(repo, installation, '/admin'); await admin.start(); await admin.loginAdministrator(build.defaultPassword);
        const invitation = await admin.service!.invite('Alice', { accountId: 'alice', password: 'alice-password' });
        const a = open(repo, installation, '/a'); await a.start(); await a.applyCode(invitation.code); await admin.tick(); await a.tick();
        const b = open(repo, installation, '/b', false); await b.start(); expect(b.session).toBeNull(); expect(b.device.keyId).toBe(a.device.keyId);
        expect(b.profile.transport?.token).toBe('old-token');
        await b.loginUser('alice', 'alice-password'); expect(b.decision.status).toBe('granted'); expect(repo.document().members[0].devices).toHaveLength(1);
    });
    it('uses distinct Obsidian vault IDs on adapters without a filesystem path', async () => {
        const repo = new Repository(), installation = crypto.randomUUID(), a = open(repo, installation, null, true, 'vault-A'); await a.start(); await a.loginAdministrator(build.defaultPassword);
        const b = open(repo, installation, null, true, 'vault-B'); await b.start(); expect(b.session).toBeNull();
        const again = open(repo, installation, null, true, 'vault-A'); await again.start(); expect(again.session).toBeNull(); expect(again.service!.isAdministrator()).toBe(false);
    });
    it('does not fall back to installation-wide login when neither path nor vault ID is available', async () => {
        const repo = new Repository(), installation = crypto.randomUUID(), a = open(repo, installation, null); await a.start(); await a.loginAdministrator(build.defaultPassword);
        const b = open(repo, installation, null); await b.start(); expect(b.session).toBeNull();
    });
    it('keeps a truly unconfigured build blocked even when the installation contains an administrator session', async () => {
        const repo = new Repository(), installation = crypto.randomUUID(), a = open(repo, installation, '/a'); await a.start(); await a.loginAdministrator(build.defaultPassword);
        const plugin = new Plugin({ vault: {}, appId: 'unconfigured' } as any, { id: 'vault-access-manager', version: 'test' });
        const raw = new Runtime(plugin, null, { fetcher: repo.fetcher }, new LocalStore(installation)); runtimes.push(raw); await raw.start(); expect(raw.decision.status).toBe('blocked'); expect(raw.service).toBeNull();
    });

    it('does not accept login until the vault-scoped profile has finished loading', async () => {
        const repo = new Repository(), r = open(repo, crypto.randomUUID(), '/loading');
        let release!: () => void, entered!: () => void;
        const wait = new Promise<void>(resolve => { release = resolve; }), ready = new Promise<void>(resolve => { entered = resolve; });
        const read = r.local.secret.bind(r.local);
        r.local.secret = (async (key: string) => { if (key.includes(':vault:')) { entered(); await wait; } return read(key); }) as typeof r.local.secret;
        const startup = r.start(); await ready; expect(r.device).toBeDefined();
        await expect(r.loginAdministrator(build.defaultPassword)).rejects.toThrow('ещё открывается'); expect(repo.writes).toBe(0);
        release(); await startup; await r.loginAdministrator(build.defaultPassword); expect(r.service!.isAdministrator()).toBe(true);
    });

    it('does not roll shared PAT delivery back when another vault saves an older verified connection', async () => {
        const repo = new Repository(), installation = crypto.randomUUID(), a = open(repo, installation, '/a'); await a.start(); await a.loginAdministrator(build.defaultPassword);
        const b = open(repo, installation, '/b'); await b.start(); await b.loginAdministrator(build.defaultPassword);
        await a.rotateToken('new-token', null); await b.logout(); // b still has the previous verified document until its next refresh
        repo.tokens.delete('old-token'); const c = open(repo, installation, '/c', false); await c.start();
        expect(c.profile.transport?.token).toBe('new-token'); expect(c.session).toBeNull(); await c.loginAdministrator(build.defaultPassword); expect(c.service!.isAdministrator()).toBe(true);
    });

});

it('rotates a copied vault UUID without consuming a new physical device slot', async () => {
    const {vaultInstance}=await import('../manager/src/auth-v4/vault-scope');
    const local=new LocalStore(crypto.randomUUID());
    const plugin=(path:string)=>new Plugin({vault:{adapter:{getBasePath:()=>path}}} as any,{id:'vault-access-manager',version:'test'});
    try {
        const a=plugin('C:/notes/A'), b=plugin('D:/notes/A');
        const first=await vaultInstance(a,local,{});
        const copy=await vaultInstance(b,local,{vaultInstanceId:first.id});
        expect(copy.id).not.toBe(first.id);
        expect((await vaultInstance(a,local,{vaultInstanceId:first.id})).id).toBe(first.id);
        expect((await vaultInstance(b,local,{vaultInstanceId:copy.id})).id).toBe(copy.id);
    } finally {await local.close();}
});

it('remembers only an opted-in user, bounds offline cache and enforces the seven-day deadline', async () => {
    const repo=new Repository(), installation=crypto.randomUUID(), admin=open(repo,installation,'/admin');
    await admin.start(); await admin.loginAdministrator(build.defaultPassword);
    const a=await admin.service!.addUser('Alice',{accountId:'alice',password:'alice-password'});
    await admin.service!.addUser('Other',{accountId:'other',password:'other-password'});
    const user=open(repo,installation,'/user');await user.start();await user.applyCode(a.code);await admin.tick();await user.tick();
    expect(user.decision.status).toBe('granted');user.dispose();
    const next=open(repo,installation,'/user');await next.start();expect(next.session).toBeNull();
    await next.loginUser('alice','alice-password',true);
    const key=(next as any).key, saved=await next.local.secret<any>(key);
    expect(saved.session).toBeUndefined();expect(saved.remembered.accountId).toBe('alice');
    const raw=JSON.stringify(saved.cache);for(const secret of [build.defaultPassword,'alice-password','other-password','"other"']) expect(raw).not.toContain(secret);
    next.dispose();const again=open(repo,installation,'/user');await again.start();expect(again.decision.status).toBe('granted');
    const expired={...saved,remembered:{...saved.remembered,issuedAt:Date.now()-8*86400000,expiresAt:Date.now()-86400000}};
    await (again as any).saveQueue; await again.local.saveSecret(key,expired);again.dispose();
    const end=open(repo,installation,'/user');await end.start();expect(end.session).toBeNull();expect(end.decision.status).toBe('blocked');
});
