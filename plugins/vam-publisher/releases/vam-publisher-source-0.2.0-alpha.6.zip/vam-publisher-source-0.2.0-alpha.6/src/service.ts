import { LocalStore } from '../manager/src/auth-v3/local';
import { validateBuild, type BuildProfile } from '../manager/src/auth-v4/model';
import { publicKey } from '../manager/src/auth-v2/crypto';
import { issueOwnerSetup } from '../manager/src/auth-v4/owner-setup';
import { zip } from './zip';
export interface Template { main: string; manifest: string; styles: string }
export interface Registry { v: 1; profiles: BuildProfile[] }
const MARKER = '__VAM_PROFILE_V4_JSON__';
export function prepareRelease(raw: BuildProfile, template: Template, issuerKey: JsonWebKey, modifiedAt: number = Date.now()): { document: string; files: Record<string, string>; archive: Uint8Array } {
    const profile = validateBuild(raw), needle = JSON.stringify(MARKER);
    if (template.main.split(needle).length !== 2) throw new Error('Шаблон менеджера несовместим или уже подготовлен для организации');
    const manifest = JSON.parse(template.manifest); if (manifest.id !== 'vault-access-manager') throw new Error('Некорректный шаблон менеджера');
    const {v,adminId,tenantId,bundleId,repository} = profile;
    const client = {v,adminId,tenantId,bundleId,repository,ownerKey:publicKey(issuerKey)};
    const files = { 'vault-access-manager/main.js': template.main.replace(needle, () => JSON.stringify(JSON.stringify(client))), 'vault-access-manager/manifest.json': JSON.stringify(manifest, null, 2) + '\n', 'vault-access-manager/styles.css': template.styles };
    return { document: JSON.stringify(profile, null, 2) + '\n', files, archive: zip(files, modifiedAt) };
}
/** Private local baking registry. No publisher identity, login, certificate or signing key. */
export class PublisherService {
    registry: Registry = { v: 1, profiles: [] };
    private queue: Promise<void> = Promise.resolve();
    constructor(readonly local = new LocalStore('vam-publisher-baking-v1')) {}
    async start(): Promise<void> { const stored = await this.local.secret<Registry>('registry'); if (stored) this.registry = this.validateRegistry(stored); }
    private validateRegistry(raw: Registry): Registry { if (!raw || raw.v !== 1 || !Array.isArray(raw.profiles) || raw.profiles.length > 1000) throw new Error('Некорректный реестр Издателя'); const profiles = raw.profiles.map(validateBuild); if (new Set(profiles.map(p => p.adminId)).size !== profiles.length || new Set(profiles.map(p => p.tenantId)).size !== profiles.length) throw new Error('Повторный профиль Администратора'); return { v: 1, profiles }; }
    private async update(work: (registry: Registry) => void): Promise<void> {
        const task = this.queue.catch(() => {}).then(async () => {
            const registry = this.validateRegistry(await this.local.secret<Registry>('registry') ?? this.registry); work(registry); this.validateRegistry(registry); await this.local.saveSecret('registry', registry); this.registry = registry;
        }); this.queue = task; return task;
    }
    async create(input: Omit<BuildProfile, 'v' | 'tenantId'>): Promise<BuildProfile> {
        const profile = validateBuild({ ...input, v: 4, tenantId: crypto.randomUUID() });
        await this.update(registry => { if (registry.profiles.some(p => p.adminId === profile.adminId)) throw new Error('Профиль с этим ID уже существует'); registry.profiles.push(profile); }); return structuredClone(profile);
    }
    async updateProfile(tenantId: string, input: Omit<BuildProfile, 'v' | 'tenantId'>): Promise<void> {
        const profile = validateBuild({ ...input, v: 4, tenantId });
        await this.update(registry => { const index = registry.profiles.findIndex(p => p.tenantId === tenantId); if (index < 0) throw new Error('Профиль не найден'); registry.profiles[index] = profile; });
    }
    private profile(tenantId: string) {
        const profile = this.registry.profiles.find(p => p.tenantId === tenantId);
        if (!profile) throw new Error('Профиль не найден');
        return profile;
    }
    async release(tenantId: string, template: Template) {
        const issuer = await this.local.identity('user');
        return prepareRelease(this.profile(tenantId), template, issuer.publicKey);
    }
    async issueSetup(tenantId: string) {
        return issueOwnerSetup(this.profile(tenantId), await this.local.identity('user'));
    }
    exportRegistry(): string { return JSON.stringify(this.registry, null, 2); }
    async restoreRegistry(text: string): Promise<void> { let registry: Registry; try { const raw = JSON.parse(text); registry = this.validateRegistry(raw.v === 4 ? { v: 1, profiles: [validateBuild(raw)] } : raw); } catch { throw new Error('Некорректный файл реестра или документ сборки'); } await this.update(current => { for (const profile of registry.profiles) { if (current.profiles.some(p => p.tenantId === profile.tenantId || p.adminId === profile.adminId)) throw new Error('Импорт содержит существующий профиль; текущий реестр сохранён'); } current.profiles.push(...registry.profiles); }); }
    async close(): Promise<void> { await this.queue.catch(() => {}); await this.local.close(); }
}
