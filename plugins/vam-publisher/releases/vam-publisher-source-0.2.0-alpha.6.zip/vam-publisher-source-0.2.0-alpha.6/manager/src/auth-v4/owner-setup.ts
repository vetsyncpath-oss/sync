import { decode64, encode64, signJws, verifyJws, type Identity } from '../auth-v2/crypto';
import type { BuildProfile, PublicBuild } from './model';

const ttl = 86400000;
async function proof(password: string, salt: Uint8Array<ArrayBuffer>) {
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
    return encode64(new Uint8Array(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',iterations:600000,salt},key,256)));
}
export async function issueOwnerSetup(profile: BuildProfile, issuer: Identity, now = Date.now()) {
    const salt = crypto.getRandomValues(new Uint8Array(16));
    return signJws({ purpose:'vam-initialize-v1', tenantId:profile.tenantId, bundleId:profile.bundleId,
        adminId:profile.adminId, repository:profile.repository, issued:now, until:now+ttl,
        salt:encode64(salt), proof:await proof(profile.defaultPassword,salt) },issuer);
}
export async function verifyOwnerSetup(build: PublicBuild, text: string, password: string, now: number) {
    try {
        if (text.length > 8192) throw Error();
        const p = await verifyJws(text.trim(),build.ownerKey) as Record<string,unknown>;
        if (p.purpose !== 'vam-initialize-v1' || p.tenantId !== build.tenantId || p.bundleId !== build.bundleId ||
            p.adminId !== build.adminId || JSON.stringify(p.repository) !== JSON.stringify(build.repository) ||
            typeof p.issued !== 'number' || !Number.isSafeInteger(p.issued) || p.issued > now ||
            p.until !== p.issued+ttl || p.issued+ttl <= now || typeof p.salt !== 'string' || decode64(p.salt).length !== 16 ||
            p.proof !== await proof(password,decode64(p.salt))) throw Error();
    } catch { throw Error('Для первого запуска нужны действующий код первичной настройки от Издателя и начальный пароль'); }
}
