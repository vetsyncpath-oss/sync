import { Plugin } from 'obsidian';
import { Runtime } from './src/auth-v4/runtime';
import type { ChannelDeps } from './src/core/channel';
import type { VaultSyncAuth } from './src/api/vault-sync-auth';

/** Repository-bound v4 entry. Old local roles and publisher appointments are never authority. */
export default class ManagerPlugin extends Plugin {
    accessV4: Runtime | null = null;
    auth?: VaultSyncAuth;
    constructor(app: ConstructorParameters<typeof Plugin>[0], manifest: ConstructorParameters<typeof Plugin>[1], private deps: ChannelDeps = {}) {
        super(app, manifest);
    }
    async onload(): Promise<void> {
        this.accessV4 = new Runtime(this, undefined, { fetcher: this.deps.fetchImpl });
        // Local initialisation only: a slow or absent network must never delay Obsidian's start or the login window.
        await this.accessV4.start({ awaitRefresh: false });
    }
    onunload(): void { this.accessV4?.dispose(); this.accessV4 = null; }
    /** Explicit rejection for integrations still trying to select a local role. */
    applyRole(_role: 'user' | 'owner'): never {
        throw new Error('Локальная роль больше не выдаёт права. Войдите как Администратор или активируйте ключ доступа.');
    }
}
