import { Notice, Plugin, PluginSettingTab, type App } from 'obsidian';
import { PublisherService, type Template } from './src/service';
import type { BuildProfile } from './manager/src/auth-v4/model';
declare const __VAM_MANAGER_TEMPLATE__: Template;

export default class PublisherPlugin extends Plugin {
    publisher = new PublisherService();
    loadError = '';
    async onload(): Promise<void> {
        try { await this.publisher.start(); } catch { this.loadError = 'Не удалось открыть реестр Издателя. Существующие данные сохранены.'; }
        this.addSettingTab(new PublisherTab(this.app, this));
        this.addCommand({ id: 'vam-prepare-manager', name: 'Подготовить сборку менеджера', callback: () => { this.app.setting?.open(); this.app.setting?.openTabById(this.manifest.id); } });
    }
    onunload(): void { void this.publisher.close(); }
    prepare(tenantId: string) { return this.publisher.release(tenantId, __VAM_MANAGER_TEMPLATE__); }
}
class PublisherTab extends PluginSettingTab {
    constructor(app: App, private plugin: PublisherPlugin) { super(app, plugin); }
    private text(parent: HTMLElement, value: string): void { const p = document.createElement('p'); p.textContent = value; parent.append(p); }
    private field(parent: HTMLElement, title: string, value = '', type = 'text'): HTMLInputElement | HTMLTextAreaElement {
        const label = document.createElement('label'); label.className = 'vam-publisher-field'; label.textContent = title;
        const input = document.createElement(type === 'textarea' ? 'textarea' : 'input'); input.value = value;
        if (input instanceof HTMLInputElement) { input.type = type; input.autocomplete = 'off'; } else input.rows = 5;
        input.spellcheck = false; label.append(input); parent.append(label); return input;
    }
    private button(parent: HTMLElement, title: string, action: () => unknown | Promise<unknown>, redraw = false): void {
        const b = document.createElement('button'); b.textContent = title; parent.append(b); b.onclick = async () => { b.disabled = true; try { await action(); if (redraw) this.display(); } catch (e) { new Notice(e instanceof Error ? e.message : 'Действие не выполнено'); } finally { b.disabled = false; } };
    }
    private download(name: string, value: string | Uint8Array): void {
        const part = typeof value === 'string' ? value : new Uint8Array(value).buffer;
        const url = URL.createObjectURL(new Blob([part], { type: typeof value === 'string' ? 'application/json' : 'application/zip' })), a = document.createElement('a'); a.href = url; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1000);
    }
    display(): void {
        const root = this.containerEl; root.replaceChildren(); root.classList.add('vam-publisher');
        this.text(root, 'Издатель — локальный инструмент выпуска менеджера. Коды первичной настройки он подписывает локальным ключом. Этот плагин остаётся у создателя.');
        if (this.plugin.loadError) { this.text(root, this.plugin.loadError); return; }
        this.text(root, 'Создайте профиль Администратора, затем скачайте готовую сборку менеджера. Все профили сохраняются в локальном реестре, вне data.json менеджера.');
        const card = document.createElement('details'), summary = document.createElement('summary'); summary.textContent = 'Создать профиль Администратора'; card.open = true; card.append(summary); root.append(card);
        this.profileForm(card);
        for (const profile of this.plugin.publisher.registry.profiles) {
            const row = document.createElement('details'), title = document.createElement('summary'); title.textContent = `${profile.adminId} · ${profile.repository.owner}/${profile.repository.repo}`; row.append(title); root.append(row);
            this.text(row, `Организация: ${profile.tenantId}. Бандл: ${profile.bundleId}.`);
            this.button(row, 'Скачать готовый менеджер ZIP', async () => this.download(`manager-${profile.tenantId}.zip`, (await this.plugin.prepare(profile.tenantId)).archive));
            this.button(row, 'Скачать закрытую резервную копию профиля', async () => this.download(`manager-profile-${profile.tenantId}.json`, (await this.plugin.prepare(profile.tenantId)).document));
            this.button(row, 'Выпустить код первичной настройки для владельца', async () => {
                const code = await this.plugin.publisher.issueSetup(profile.tenantId);
                const field = this.field(row, 'Передайте владельцу отдельно от ZIP. Код действует 24 часа', code, 'textarea');
                field.readOnly = true; field.select();
            });
            this.text(row, 'Изменение начального пароля здесь относится к новым репозиториям. В уже подключённом репозитории актуальный пароль задаёт adminPassword в vam/config.json. Смена репозитория требует новой сборки и подключения.');
            const edit = document.createElement('details'), editTitle = document.createElement('summary'); editTitle.textContent = 'Изменить профиль и перевыпустить сборку'; edit.append(editTitle); row.append(edit); this.profileForm(edit, profile);
        }
        const backup = document.createElement('details'), label = document.createElement('summary'); label.textContent = 'Резервная копия реестра'; backup.append(label); root.append(backup);
        this.text(backup, 'Файл содержит пароли Администраторов и настроенные начальные PAT. Храните его у Издателя.');
        this.button(backup, 'Скачать реестр', () => this.download('vam-publisher-registry.json', this.plugin.publisher.exportRegistry()));
        const restore = this.field(backup, 'Импортировать реестр или документ сборки (существующие профили не заменяются)', '', 'textarea');
        this.button(backup, 'Импортировать профили', () => this.plugin.publisher.restoreRegistry(restore.value), true);
    }
    private profileForm(parent: HTMLElement, profile?: BuildProfile): void {
        const id = this.field(parent, 'ID Администратора — имя или удобный идентификатор', profile?.adminId ?? ''), password = this.field(parent, 'Начальный пароль Администратора', profile?.defaultPassword ?? '', 'password');
        const api = this.field(parent, 'API GitHub/Gitea', profile?.repository.baseUrl ?? 'https://api.github.com'), owner = this.field(parent, 'Владелец репозитория', profile?.repository.owner ?? ''), repo = this.field(parent, 'Название приватного репозитория', profile?.repository.repo ?? '');
        const bundle = this.field(parent, 'ID общего бандла', profile?.bundleId ?? 'vetsyncpath-bundle');
        this.text(parent, 'Владелец вводит PAT в Manager. Для пустого репозитория отдельно передайте код первичной настройки и начальный пароль.');
        this.button(parent, profile ? 'Сохранить профиль' : 'Создать профиль Администратора', async () => {
            const input = { adminId: id.value.trim(), defaultPassword: password.value, bundleId: bundle.value.trim(), repository: { baseUrl: api.value.trim(), owner: owner.value.trim(), repo: repo.value.trim() } };
            if (profile) await this.plugin.publisher.updateProfile(profile.tenantId, input); else await this.plugin.publisher.create(input);
        }, true);
    }
}
