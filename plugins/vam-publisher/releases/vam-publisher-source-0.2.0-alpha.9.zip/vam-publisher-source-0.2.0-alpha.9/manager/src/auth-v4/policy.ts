export const permissions = ['sync.run','sync.publish','sync.manual','sync.automatic','sync.diagnostics.share','obsidian.settings.open','obsidian.note.delete','obsidian.note.edit','obsidian.note.create','obsidian.note.rename','obsidian.folder.create','obsidian.attachment.add','obsidian.attachment.delete','obsidian.folder.delete','obsidian.note.move'] as const;
export type Permission = typeof permissions[number];
export const permissionLabels: Record<Permission,string> = {
    'sync.run':'Синхронизация разрешена', 'sync.publish':'Публикация разрешена',
    'sync.manual':'Ручной запуск', 'sync.automatic':'Автосинхронизация',
    'sync.diagnostics.share':'Передача диагностики', 'obsidian.settings.open':'Открытие настроек',
    'obsidian.note.delete':'Удаление заметок', 'obsidian.note.edit':'Редактирование заметок',
    'obsidian.note.create':'Создание заметок', 'obsidian.note.rename':'Переименование заметок',
    'obsidian.note.move':'Перемещение заметок', 'obsidian.folder.create':'Создание папок',
    'obsidian.folder.delete':'Удаление папок', 'obsidian.attachment.add':'Добавление вложений',
    'obsidian.attachment.delete':'Удаление вложений'
};
export type Rules = Partial<Record<Permission,'allow'|'deny'>>;
export interface Group { id: string; name: string; rules: Rules }
export interface Policy {
    scoped?: ScopedRule[];
    mandatory?: Permission[];
    defaults?: Rules;
    roles?: Partial<Record<'user'|'operator',Rules>>;
    groups?: Group[];
}
export interface Assignment { accountId: string; groups?: string[]; role?: 'user'|'operator'; rules?: Rules }
export interface ScopedRule {
    id: string;
    level: 'mandatory' | 'user' | 'group' | 'role' | 'organization';
    subject: string;
    permission: Permission;
    effect: 'allow' | 'deny';
    folder: string;
    device: string;
    instance: string;
    from: number | null;
    until: number | null;
    reason: string;
}
export interface RuleContext { path?: string; now?: number; device?: string; instance?: string }
const uuid = /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i;

export function vaultPath(input: string): string {
    if (typeof input !== 'string' || input.length > 1024) throw Error('Укажите относительный путь внутри vault');
    const path = input.normalize('NFC').replace(/\\/g, '/');
    if (!path) return '';
    if (path.startsWith('/') || path.split('/').some(p => !p || p === '.' || p === '..' || /[:*?<>|"\x00-\x1f]/.test(p) || /[ .]$/.test(p)))
        throw Error('Укажите относительный путь без масок или переходов между каталогами');
    return path;
}
export function within(path: string, folder: string) {
    const normalize = (p: string) => p.normalize('NFC').replace(/\\/g,'/').split('/').filter(x=>x && x!=='.').join('/').toLowerCase();
    const value = normalize(path), root = normalize(folder);
    if (value.split('/').includes('..') || root.split('/').includes('..')) throw Error('Путь выходит за границы папки');
    return !root || value === root || value.startsWith(root + '/');
}
export function validateScoped(rule: ScopedRule) {
    if (!rule || !uuid.test(rule.id) || !permissions.includes(rule.permission) ||
        !['mandatory','user','group','role','organization'].includes(rule.level) ||
        !['allow','deny'].includes(rule.effect) || (rule.level === 'mandatory' && rule.effect !== 'deny') ||
        typeof rule.subject !== 'string' || typeof rule.device !== 'string' || typeof rule.instance !== 'string' ||
        (rule.device && !/^[A-Za-z0-9_-]{43}$/.test(rule.device)) || (rule.instance && !uuid.test(rule.instance)) ||
        typeof rule.reason !== 'string' || !rule.reason.trim() || rule.reason.length > 200)
        throw Error('Проверьте адресата, действие и причину правила');
    if (rule.level === 'role' ? !['user','operator'].includes(rule.subject) :
        rule.level === 'group' || rule.level === 'user' ? !/^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/.test(rule.subject) : rule.subject !== '')
        throw Error('Некорректный адресат правила');
    if (vaultPath(rule.folder) !== rule.folder || (rule.folder && (!rule.permission.startsWith('obsidian.') || rule.permission === 'obsidian.settings.open')))
        throw Error('Папка применима только к файловым операциям');
    for (const t of [rule.from,rule.until])
        if (t !== null && (!Number.isSafeInteger(t) || t < 0 || t > 8640000000000000)) throw Error('Некорректная дата');
    if (rule.from !== null && rule.until !== null && rule.until <= rule.from) throw Error('Окончание должно быть позже начала');
}
export function relevant(rule: ScopedRule, member: Assignment, ctx: RuleContext) {
    if ((rule.device && rule.device !== ctx.device) || (rule.instance && rule.instance !== ctx.instance)) return false;
    if (rule.level === 'group') return !!member.groups?.includes(rule.subject);
    if (rule.level === 'role') return (member.role ?? 'user') === rule.subject;
    return rule.level !== 'user' || member.accountId === rule.subject;
}
export function effective(policy: Policy = {}, member: Assignment, id: Permission, ctx: RuleContext = {}) {
    const now = ctx.now ?? Date.now();
    const scoped = (policy.scoped ?? []).filter(r => r.permission === id && relevant(r,member,ctx) &&
        (!r.folder || (ctx.path !== undefined && within(ctx.path,r.folder))) &&
        (r.from === null || now >= r.from) && (r.until === null || now < r.until));
    type Choice = {allowed: boolean; source: string};
    const resolve = (level: ScopedRule['level'], base: Choice[]) => {
        const options = [...scoped.filter(r=>r.level===level).map(r=>({allowed:r.effect==='allow',source:r.reason})),...base];
        return options.find(choice=>!choice.allowed) ?? options[0];
    };
    const given = (rule: 'allow'|'deny'|undefined, source: string) =>
        rule ? [{allowed:rule==='allow',source}] : [];
    const role = member.role ?? 'user';
    return resolve('mandatory',policy.mandatory?.includes(id) ? [{allowed:false,source:'Обязательный запрет организации'}] : []) ??
        resolve('user',given(member.rules?.[id],'Индивидуальное правило')) ??
        resolve('group',(policy.groups ?? []).filter(g=>member.groups?.includes(g.id)).flatMap(g=>given(g.rules[id],'Группа «'+g.name+'»'))) ??
        resolve('role',given(policy.roles?.[role]?.[id],role==='user'?'Роль пользователя':'Роль оператора')) ??
        resolve('organization',given(policy.defaults?.[id],'По умолчанию в организации')) ??
        {allowed:id!=='sync.diagnostics.share',source:'По умолчанию в организации'};
}
// A cached grant must end before either an exception expires or a scheduled denial begins.
export function nextBoundary(policy: Policy | undefined, member: Assignment, id: Permission, ctx: RuleContext & {now:number}) {
    let next = Infinity;
    for (const rule of policy?.scoped ?? []) if (rule.permission===id && relevant(rule,member,ctx)) {
        for (const t of [rule.from,rule.until]) if (t !== null && t > ctx.now) next=Math.min(next,t);
    }
    return next;
}
export function validateRules(rules: unknown): asserts rules is Rules {
    if (!rules || typeof rules !== 'object' || Array.isArray(rules) || Object.entries(rules).some(([key,v])=>!permissions.includes(key as Permission) || !['allow','deny'].includes(v))) throw Error('Некорректное правило доступа');
}
