import type {Service} from './service';
import {verifyRelease} from './updates';
import {effective,permissions,permissionLabels,vaultPath,type ScopedRule,type Rules,type Permission} from './policy';
import { studioPanel } from "./studio-diagnostics";
import { Notice, PluginSettingTab, type App, type Plugin } from 'obsidian';
import type { Runtime } from './runtime';
import { ConfirmModal } from './confirm-modal';
import { RESTRICTIONS, RESTRICTION_TITLES, knownRestrictions, memberActive, type Member } from './model';
export class SettingsTab extends PluginSettingTab {
    private closeStudioPanel?: () => void;
    private unsubscribe?: () => void;
    private visible = false;
    private executing = false;
    private loginChoice: 'administrator' | 'password' | 'key' | null = null;
    constructor(app: App, private manager: Plugin, private runtime: Runtime) { super(app, manager); }
    private text(parent: HTMLElement, value: string): HTMLElement { const p = document.createElement('p'); p.textContent = value; parent.append(p); return p; }
    private group(parent: HTMLElement, title: string, open = false, key?: string): HTMLDetailsElement { const d = document.createElement('details'), s = document.createElement('summary'); s.textContent = title; d.open = open; if (key) d.dataset.key = key; d.append(s); parent.append(d); return d; }
    private ago(ms: number): string { const minutes = Math.max(0, Math.floor(ms / 60000)); if (minutes < 1) return 'только что'; if (minutes < 60) return `${minutes} мин назад`; const hours = Math.floor(minutes / 60); return hours < 48 ? `${hours} ч назад` : `${Math.floor(hours / 24)} дн. назад`; }
    private short(id: string): string { return '…' + id.slice(-8); }
    private async copyText(value: string, input?: HTMLInputElement | HTMLTextAreaElement): Promise<void> {
        if (!value) return;
        if (typeof navigator !== 'undefined' && navigator.clipboard?.writeText) { await navigator.clipboard.writeText(value); new Notice('Скопировано'); }
        else if (input) { input.focus(); input.select(); input.setSelectionRange(0, input.value.length); new Notice('Текст выделен. Скопируйте его командой «Копировать» вашего устройства.'); }
        else new Notice('Буфер обмена недоступен на этом устройстве.');
    }
    private invitation(organization: string, member: Member, key: string): string {
        return [`Приглашение в Vault Access Manager (${organization})`, `Пользователь: ${member.label || member.accountId} (ID: ${member.accountId})`, '', '1. Установите плагин Vault Access Manager в Obsidian и включите его.', '2. Откройте его настройки, выберите «У меня есть ключ доступа» и вставьте ключ ниже. ID и пароль при подключении не нужны.', '', 'Ключ:', key].join('\n');
    }
    private field(parent: HTMLElement, title: string, value = '', type = 'text', readonly = false): HTMLInputElement | HTMLTextAreaElement {
        const label = document.createElement('label'); label.className = 'vam3-field'; label.textContent = title;
        const input = document.createElement(type === 'textarea' ? 'textarea' : 'input'); input.value = value; input.readOnly = readonly;
        if (input instanceof HTMLInputElement) { input.type = type; input.autocomplete = type === 'password' ? 'current-password' : 'off'; } else input.rows = 4;
        input.spellcheck = false; label.append(input); parent.append(label);
        if (readonly && type === 'textarea') this.button(parent, 'Скопировать', () => this.copyText(input.value, input), false);
        return input;
    }
    private button(parent: HTMLElement, title: string, action: () => unknown | Promise<unknown>, redraw = true): void {
        const b = document.createElement('button'); b.textContent = title; b.className = 'vam3-button'; parent.append(b);
        b.onclick = async () => { b.disabled = true; this.executing = true; try { await action(); if (redraw && this.visible) this.display(); } catch (e) { new Notice(e instanceof Error ? e.message : 'Действие не выполнено'); } finally { b.disabled = false; this.executing = false; } };
    }
    hide(): void { this.closeStudioPanel?.(); this.closeStudioPanel=undefined; this.visible = false; this.unsubscribe?.(); this.unsubscribe = undefined; }
    private choice(parent: HTMLElement, title: string, options: [string,string][], value: string) {
        const label = document.createElement('label'), select = document.createElement('select');
        label.className='vam3-field'; label.textContent=title;
        for (const [id,text] of options) { const option=document.createElement('option'); option.value=id; option.textContent=text; option.selected=id===value; select.append(option); }
        label.append(select); parent.append(label); return select;
    }
    private rulesEditor(parent: HTMLElement, rules: Rules = {}) {
        const advanced=this.group(parent,'Дополнительные права');
        const fields = permissions.map(id=>[id,this.choice(id==='sync.run'||id==='sync.publish'?parent:advanced,permissionLabels[id],[['','Наследовать'],['allow','Разрешить'],['deny','Запретить']],rules[id] ?? '')] as const);
        return (): Rules => Object.fromEntries(fields.filter(([,f])=>f.value).map(([id,f])=>[id,f.value]));
    }
    private scopedRules(parent: HTMLElement, service: Service) {
        const doc = service.document;
        if (!doc) return;
        const rules = doc.policy?.scoped ?? [];
        const panel = this.group(parent, 'Правила для папок, установок и сроков');
        this.text(panel,'Пустая папка означает весь vault. Срок вводится по местному времени. На одном уровне запрет имеет приоритет.');
        const selector = this.choice(panel,'Правило',[
            ['', 'Создать правило'],...rules.map(r=>[r.id,r.reason] as [string,string]),
        ],'');
        const form = document.createElement('div');
        panel.append(form);
        const render = () => {
            const saved = rules.find(r=>r.id===selector.value);
            form.replaceChildren();
            const level = this.choice(form,'Уровень назначения',[
                ['organization','Организация'],['mandatory','Обязательный запрет'],['user','Пользователь'],['group','Группа'],['role','Роль'],
            ],saved?.level ?? 'user');
            const subjectArea = document.createElement('div');
            form.append(subjectArea);
            let subject: HTMLSelectElement | undefined;
            const renderSubject = () => {
                subjectArea.replaceChildren(); subject=undefined;
                const options: [string,string][] = level.value==='user' ? doc.members.map(m=>[m.accountId,(m.label || m.accountId)+' · '+m.accountId])
                    : level.value==='group' ? (doc.policy?.groups ?? []).map(g=>[g.id,g.name])
                    : level.value==='role' ? [['user','Пользователь'],['operator','Оператор']] : [];
                if (['user','group','role'].includes(level.value)) subject=this.choice(subjectArea,'Адресат',options,saved?.subject ?? '');
            };
            const action=this.choice(form,'Операция',permissions.map(id=>[id,permissionLabels[id]]),saved?.permission ?? 'obsidian.note.edit');
            const effect=this.choice(form,'Действие правила',[['deny','Запретить'],['allow','Разрешить']],saved?.effect ?? 'deny');
            const folder=this.field(form,'Папка относительно корня vault',saved?.folder);
            const device=this.field(form,'ID устройства (необязательно)',saved?.device);
            const instance=this.field(form,'ID экземпляра vault (необязательно)',saved?.instance);
            const localTime=(ms: number|null|undefined) => {
                if (ms==null) return '';
                const date = new Date(ms);
                return new Date(ms-date.getTimezoneOffset()*60000).toISOString().slice(0,19);
            };
            const from=this.field(form,'Начало действия',localTime(saved?.from),'datetime-local');
            const until=this.field(form,'Окончание действия',localTime(saved?.until),'datetime-local');
            const reason=this.field(form,'Причина правила',saved?.reason);
            const refreshLevel=()=>{renderSubject();effect.disabled=level.value==='mandatory';if(effect.disabled)effect.value='deny';};
            const refreshFolder=()=>{folder.disabled=!action.value.startsWith('obsidian.')||action.value==='obsidian.settings.open';};
            level.onchange=refreshLevel;action.onchange=refreshFolder;refreshLevel();refreshFolder();
            const draft=():ScopedRule => ({
                id:saved?.id ?? crypto.randomUUID(), level:level.value as ScopedRule['level'], subject:subject?.value ?? '',
                permission:action.value as Permission, effect:effect.value as ScopedRule['effect'],
                folder:folder.disabled ? '' : vaultPath(folder.value),device:device.value.trim(),instance:instance.value.trim(),
                from:from.value ? Date.parse(from.value) : null,until:until.value ? Date.parse(until.value) : null,reason:reason.value.trim(),
            });
            this.button(form,'Сохранить правило',()=>service.changeScopedRule(draft(),doc.revision));
            if(saved) this.button(form,'Удалить правило',()=>this.confirm('Удалить правило «'+saved.reason+'»?',()=>service.changeScopedRule(saved.id,doc.revision)));
        };
        selector.onchange=render;render();

        const preview=this.group(panel,'Проверить фактическое право');
        const user=this.choice(preview,'Пользователь для проверки',doc.members.map(m=>[m.accountId,m.label || m.accountId]),'');
        const permission=this.choice(preview,'Проверяемая операция',permissions.map(p=>[p,permissionLabels[p]]),'obsidian.note.edit');
        const path=this.field(preview,'Путь к файлу или папке');
        const device=this.field(preview,'Проверяемое устройство');
        const instance=this.field(preview,'Проверяемый экземпляр vault');
        const when=this.field(preview,'Момент проверки (пусто — сейчас)','','datetime-local');
        const output=this.text(preview,'');
        this.button(preview,'Рассчитать право',()=>{
            const member=doc.members.find(m=>m.accountId===user.value);
            if(!member) throw Error('Выберите пользователя');
            const id=permission.value as Permission;
            const result=effective(doc.policy,member,id,{path:vaultPath(path.value),device:device.value.trim(),instance:instance.value.trim(),now:when.value?Date.parse(when.value):Date.now()});
            const legacy=id.startsWith('obsidian.') && knownRestrictions(member).some(r=>'obsidian.'+r===id);
            output.textContent=legacy?'Запрещено · ограничение в карточке пользователя':(result.allowed?'Разрешено · ':'Запрещено · ')+result.source;
        },false);
    }
    private async confirm(message: string, work: () => Promise<void>, labels?: { title?: string; action?: string; danger?: boolean }): Promise<void> { const confirmed = await new Promise<boolean>(resolve => new ConfirmModal(this.app, message, resolve, labels ?? {title:'Подтвердите действие',action:'Применить',danger:false}).open()); if (confirmed) await work(); }
    display(): void {
        this.hide(); this.visible = true; const root = this.containerEl; root.replaceChildren(); root.classList.add('vam3-settings', 'vam-dashboard'); const r = this.runtime;
        const title = document.createElement('h2'); title.textContent = 'Vault Access Manager'; root.append(title);
        this.closeStudioPanel = studioPanel(root, this.app, this.manager);
        const status = this.text(root, r.status); status.className = 'vam3-status'; status.dataset.state = r.decision.status; status.setAttribute('role', 'status');
        const mode = () => r.service?.isAdministrator() ? 'administrator' : r.session?.kind ?? 'none'; let displayedMode = mode();
        this.unsubscribe = r.subscribe(() => { if (!this.visible) return; status.textContent = r.status; status.dataset.state = r.decision.status; const next = mode(); if (next !== displayedMode) { displayedMode = next; this.display(); } });
        if (!r.build) { this.text(root, 'Получите у Издателя готовую сборку для вашей организации. Самостоятельно создавать административный ключ или отправлять заявку больше не нужно.'); return; }
        this.text(root, `Организация: ${r.build.adminId}`);
        this.text(root, 'Профиль входа относится только к текущему хранилищу.');
        if (r.legacyDetected && !r.profile.transport) this.text(root, 'Данные прежней версии сохранены. Для первого входа в этой сборке используйте пароль Администратора или новый ключ доступа.');
        if (!r.session || (r.session.kind === 'administrator' && !r.service?.isAdministrator())) {
            if (!this.loginChoice) {
                this.text(root, 'Выберите способ входа. Подключённый профиль сохраняется между запусками.');
                const cards = document.createElement('div'); cards.className = 'vam-login-cards'; root.append(cards);
                for (const [choice, title, description] of [
                    ['key', 'У меня есть ключ доступа', 'Вставьте ключ от Администратора. Устройство подключится автоматически.'],
                    ['password', 'Я уже подключён', 'Войти по ID и паролю пользователя.'],
                    ['administrator', 'Я Администратор', 'Войти с паролем от Издателя и управлять доступом.'],
                ] as const) {
                    const card = document.createElement('button'); card.type = 'button'; card.className = 'vam-card';
                    const heading = document.createElement('span'); heading.className = 'vam-card-title'; heading.textContent = title;
                    const descriptionEl = document.createElement('span'); descriptionEl.className = 'vam-card-desc'; descriptionEl.textContent = description;
                    card.append(heading, descriptionEl); cards.append(card); card.onclick = () => { this.loginChoice = choice; this.display(); };
                }
                return;
            }
            this.button(root, '← Выбрать другой способ входа', () => { this.loginChoice = null; });
            const form = document.createElement('form'); form.className = 'vam-login-form'; root.append(form);
            const submit = (label: string, work: () => Promise<void>) => {
                this.button(form, label, work);
                const button = form.querySelector('button')!; button.type = 'button'; button.classList.add('mod-cta');
                form.onsubmit = event => { event.preventDefault(); if (!button.disabled) button.click(); };
                form.onkeydown = event => { if (event.key === 'Enter' && !(event.target instanceof HTMLTextAreaElement)) { event.preventDefault(); if (!button.disabled) button.click(); } };
            };
            if (this.loginChoice === 'administrator') {
                const phrase = this.field(form, 'Пароль Администратора', '', 'password');
                this.text(form, 'Если вы не знаете пароля, пожалуйста, обратитесь к Издателю плагина.');
                const connection = this.group(form, r.profile.transport ? 'Восстановить подключение Git' : 'Первое подключение Git', (!r.profile.transport && !r.build.bootstrapToken) || (r.session?.kind === 'administrator' && !r.service?.online));
                this.text(connection, 'PAT нужен только Администратору для подключения или восстановления доступа. Репозиторий закреплён Издателем.');
                const token = this.field(connection, 'PAT Администратора', '', 'password'), expiry = this.field(connection, 'Срок действия PAT (UTC; необязательно)', '', 'date');
                const setup = r.build && 'authority' in r.build ? this.field(connection,'Код владельца из Publisher (при первом входе с другого устройства)','','textarea') : null;
                submit('Войти как Администратор', async () => { await r.loginAdministrator(phrase.value, token.value, expiry.value || null, setup?.value ?? ''); if (setup) setup.value = ''; phrase.value = ''; token.value = ''; this.loginChoice = null; });


            } else if (this.loginChoice === 'password') {
                const account = this.field(form, 'ID пользователя', r.profile.accountId ?? ''), password = this.field(form, 'Пароль пользователя', '', 'password');
                // Phone keyboards must not capitalise or "correct" an identifier, which is case-sensitive.
                for (const [name, value] of [['autocapitalize', 'off'], ['autocorrect', 'off'], ['autocomplete', 'username'], ['enterkeyhint', 'next']] as const) account.setAttribute(name, value);
                this.text(form, 'При первом подключении используйте ключ доступа от Администратора.');
                submit('Войти', async () => { await r.loginUser(account.value, password.value); password.value = ''; this.loginChoice = null; });
            } else {
                const code = this.field(form, 'Ключ доступа от Администратора', '', 'textarea');
                this.text(form, 'Введите ключ один раз. Регистрация устройства и следующие подключения выполняются автоматически.');
                submit('Подключиться', async () => { await r.applyCode(code.value); code.value = ''; this.loginChoice = null; });
            }
            form.querySelector('input, textarea')?.setAttribute('autofocus', '');
            return;
        }
        this.button(root, 'Выйти из текущего профиля', () => r.logout());
        this.button(root, 'Проверить доступ', () => r.tick(), false);
        const connected = this.group(root, 'Подключённые плагины', !r.service?.isAdministrator());
        const pluginList = document.createElement('div'); connected.append(pluginList);
        const renderPlugins = () => {
            pluginList.replaceChildren();
            if (r.plugins.error) this.text(pluginList, r.plugins.error);
            const plugins = r.plugins.list();
            if (!plugins.length) this.text(pluginList, 'Подключённые плагины пока не обнаружены. Их регистрация появится после загрузки в Obsidian.');
            for (const plugin of plugins) {
                const row = document.createElement('div'); row.className = 'vam-plugin-card'; pluginList.append(row);
                this.text(row, `${plugin.name} · ${plugin.enabled ? 'Включён' : 'Выключен в Obsidian'}`);
                if (!plugin.enabled && r.decision.status === 'granted') this.button(row, 'Включить', () => r.plugins.enable(plugin.id));
            }
        };
        renderPlugins();
        if (r.service?.isAdministrator()) this.button(connected, 'Восстановить прежние блокировки', () => r.plugins.restore());
        if (!r.service?.isAdministrator()) {
            if (r.profile.outbox && !r.profile.outbox.submitted) this.button(root, 'Повторить отправку устройства', () => r.sendPending());
            const recovery = this.group(root, 'Восстановить подключение'), code = this.field(recovery, 'Код восстановления от Администратора', '', 'textarea');
            this.text(recovery, 'Обычно подключение обновляется автоматически. Если доступ к Git истёк, запросите код восстановления у Администратора.');
            this.button(recovery, 'Восстановить подключение', async () => { await r.applyCode(code.value); code.value = ''; });
            const info = this.group(root, 'Профиль'); this.field(info, 'ID пользователя', r.profile.accountId ?? '', 'text', true); this.field(info, 'Устройство', r.device?.keyId ?? '', 'text', true);
            return;
        }
        const s = r.service;
        const stats = document.createElement('div'); stats.className = 'vam-overview'; root.append(stats);
        const summary = this.text(stats, ''), syncLine = this.text(stats, '');
        const updateSummary = () => {
            const members = s.document?.members ?? [], now = Date.now(), live = members.filter(m => memberActive(m, now)).length, revoked = members.filter(m => !m.active).length, lapsed = members.length - live - revoked;
            summary.textContent = `Пользователей: ${live} действующих${revoked ? ` · ${revoked} отозвано` : ''}${lapsed ? ` · ${lapsed} с истёкшим сроком` : ''} · Устройств: ${members.reduce((n, m) => n + m.devices.length, 0)} · Заявок на рассмотрении: ${s.pending.length}`;
            const expires = s.document?.transport.expiresOn ?? null, left = expires ? Math.ceil((Date.parse(expires + 'T23:59:59Z') - now) / 86400000) : null;
            const pat = expires === null ? 'не задан' : left! < 0 ? `${expires} (истёк)` : `${expires} (осталось ${left} дн.)`;
            const synced = s.lastSyncAt; syncLine.textContent = `Подключение №${s.transport.version} · срок PAT: ${pat} · данные получены ${synced === null ? 'ещё не получены' : this.ago(now - synced)}`;
            syncLine.dataset.warn = expires !== null && left! <= 14 ? '1' : '';
        };
        updateSummary();
        const queue = document.createElement('div'); root.append(queue);
        const git = this.group(root, 'Подключение организации');
        this.field(git, 'Закреплённый репозиторий', `${r.build.repository.baseUrl}/repos/${r.build.repository.owner}/${r.build.repository.repo}`, 'text', true);
        this.text(git, 'Для перевыпуска репозитория или смены пароля обратитесь к Издателю плагина. Manager проверяет подпись реестра при чтении.');
        const token = this.field(git, 'Новый PAT', '', 'password'), expiry = this.field(git, 'Срок нового PAT (UTC; необязательно)', '', 'date');
        this.text(git, 'Обновите PAT до истечения старого. Пользователи получат замену при следующем запуске или фоновой синхронизации. Устройства, пропустившие этот период, подключаются по коду восстановления.');
        this.button(git, 'Проверить и обновить PAT организации', async () => { await r.rotateToken(token.value, expiry.value || null); token.value = ''; });
        const fleet = this.group(root,'Установки и доставка PAT');
        const fleetList=document.createElement('div'); fleet.append(fleetList);
        const showFleet=()=>{ fleetList.replaceChildren(); const version=s.document?.transport.version;
            for(const row of r.profile.installations ?? []) this.text(fleetList, row.account+' · vault '+row.instance+' · устройство '+this.short(row.device)+' · Manager '+row.manager+' · Studio '+(row.studio ?? '—')+' · политика r'+row.revision+' · PAT v'+row.transport+(row.transport===version?' подтверждён':' ожидает')+' · '+this.ago(Date.now()-row.seen)+(Date.now()-row.seen>30*60000?' (офлайн)':'')+(row.error?' · '+row.error:''));
            for(const m of s.document?.members ?? []) for(const d of m.devices) if(!r.profile.installations?.some(i=>i.account===m.accountId && i.device===d.deviceId)) this.text(fleetList,m.accountId+' · устройство '+this.short(d.deviceId)+' · установка ещё не сообщила версию PAT');
        }; showFleet();
        this.button(fleet,'Обновить список установок',async()=>{await r.syncInstallation(true);showFleet();},false);
        const campaigns=this.group(root,'Кампании обновления');
        const component=this.choice(campaigns,'Компонент',[['refsync','Sync Studio'],['vault-access-manager','Manager']],'refsync');
        const signature=this.field(campaigns,'Подписанный манифест (.jws)','','textarea');
        const base=this.field(campaigns,'HTTPS-адрес папки с main.js, styles.css и manifest.json');
        const scope=this.choice(campaigns,'Адресаты',[['vault','Выбранные vault'],['account','Пользователи'],['device','Устройства'],['group','Группы'],['all','Все известные установки']],'vault');
        const ids=this.field(campaigns,'ID через запятую'), days=this.field(campaigns,'Срок команды в днях','7','number'), comment=this.field(campaigns,'Причина обновления');
        this.button(campaigns,'Проверить релиз и адресатов',async()=>{
            if(!r.build || !('authority' in r.build))throw Error('Нужна сборка с ключами источников');
            const doc=s.document!,revision=doc.revision,rows=[...(r.profile.installations ?? [])],requested=new Set(ids.value.split(',').map(x=>x.trim()).filter(Boolean));
            const matches=rows.filter(row=>{
                const m=doc.members.find(m=>m.accountId===row.account);
                if(!row.owner && (!memberActive(m,Date.now())||!m.devices.some(d=>d.deviceId===row.device)))return false;
                return scope.value==='all'||(scope.value==='group'?m?.groups?.some(id=>requested.has(id)):requested.has(scope.value==='vault'?row.instance:scope.value==='device'?row.device:row.account));
            });
            const target=component.value as import('./updates').Component, sig=signature.value.trim(), url=base.value;
            const rel=await verifyRelease(sig,target,r.build), expiration=Date.now()+Number(days.value)*86400000;
            const why=comment.value;
            await this.confirm(target+' '+rel.version+' · установок '+matches.length+'\n'+matches.map(x=>[x.account,x.device,x.instance].join(' · ')).join('\n'),()=>s.dispatch(matches.map(i=>i.instance),target,sig,url,expiration,why,rows,revision));
        });
        for(const c of s.document?.campaigns ?? []){
            const row=this.group(campaigns,c.component+' '+c.version+' · '+c.reason);
            for(const id of c.targets){
                const report=r.profile.installations?.find(r=>r.instance===id);
                this.text(row,(report?.account ?? '')+' · '+id+' · '+(report?.receipts.find(x=>x.id===c.id)?.status ?? (c.expires<=Date.now()?'expired':'waiting')));
            }
        }
        const issue = this.group(root, 'Добавить пользователя и выдать ключ', !s.document?.members.length);
        const account = this.field(issue, 'ID пользователя (пусто — создать автоматически)'), label = this.field(issue, 'Имя или метка пользователя'), password = this.field(issue, 'Пароль пользователя (пусто — создать автоматически)', '', 'password'), until = this.field(issue, 'Доступ по дату включительно (UTC; необязательно)', '', 'date');
        const deviceLimit = this.field(issue, 'Лимит устройств', '1', 'number');
        const issueGuards = this.group(issue, 'Ограничения интерфейса (задаются до выдачи ключа)', true);
        this.text(issueGuards, 'Действуют с первого входа пользователя. Защита от случайных действий, а не от намеренного обхода. Администратора не касаются; позже их можно изменить в карточке пользователя.');
        const issueBoxes = RESTRICTIONS.map(name => { const box = this.field(issueGuards, RESTRICTION_TITLES[name], '', 'checkbox') as HTMLInputElement; return [name, box] as const; });
        const output = this.field(issue, 'Данные для личной передачи пользователю', '', 'textarea', true);
        this.button(issue, 'Выдать ключ доступа', async () => {
            const result = await s.addUser(label.value, { accountId: account.value.trim() || undefined, password: password.value || undefined, expiresAt: until.value ? Date.parse(until.value) + 86400000 : null, maxDevices: Number(deviceLimit.value) || 1, restrictions: issueBoxes.filter(([, box]) => box.checked).map(([name]) => name) });
            output.value = `ID: ${result.accountId}\nПароль: ${result.password}\n\nКлюч доступа:\n${result.code}`;
            account.value = ''; label.value = ''; password.value = ''; until.value = ''; deviceLimit.value = '1'; issueBoxes.forEach(([, box]) => { box.checked = false; });
            await r.tick();
            // The new user's card, with the key, appears at once (the guard would otherwise wait for the next background refresh).
            this.executing = false; renderInventory(true);
        }, false);
        const policies = this.group(root,'Группы и права организации');
        this.scopedRules(policies,s);
        for (const existing of [...(s.document?.policy?.groups ?? []),null]) {
            const group = this.group(policies,existing?.name ?? 'Создать группу');
            const label = this.field(group,'Название группы',existing?.name ?? '');
            const rules = this.rulesEditor(group,existing?.rules);
            this.button(group,'Сохранить группу',()=>s.setGroup(existing?.id ?? crypto.randomUUID(),label.value,rules()));
        }
        const organization = this.group(policies,'Правила по умолчанию и роли');
        const defaults = this.rulesEditor(organization,s.document?.policy?.defaults);
        const roles = (['user','operator'] as const).map(role=>[role,this.rulesEditor(this.group(organization,role==='user'?'Пользователь':'Оператор'),s.document?.policy?.roles?.[role])] as const);
        const mandatory = this.group(organization,'Обязательные запреты');
        const locks = permissions.map(id=>{const field=this.field(mandatory,permissionLabels[id],'','checkbox') as HTMLInputElement;field.checked=s.document?.policy?.mandatory?.includes(id) ?? false;return [id,field] as const;});
        this.button(organization,'Применить политику организации',()=>this.confirm('Изменить правила для организации?',()=>s.setOrganizationPolicy({defaults:defaults(),roles:Object.fromEntries(roles.map(([role,get])=>[role,get()])),mandatory:locks.filter(([,f])=>f.checked).map(([id])=>id)})));
        const history = this.group(root,'Журнал административных действий');
        for (const e of [...(s.document?.history ?? [])].reverse()) this.text(history,new Date(e.at).toLocaleString()+' · '+e.author+' · r'+e.revision+' · '+e.action+' · '+e.targets.join(', '));
        const filters = document.createElement('div'); filters.className = 'vam-filters'; root.append(filters);
        const search = this.field(filters, 'Найти пользователя по ID или имени');
        const stateLabel = document.createElement('label'); stateLabel.className = 'vam3-field'; stateLabel.textContent = 'Показать'; const stateFilter = document.createElement('select');
        for (const [value, text] of [['all', 'Все'], ['active', 'Действующие'], ['revoked', 'Отозванные'], ['expired', 'Срок истёк'], ['full', 'Лимит устройств исчерпан'], ['empty', 'Без устройств'], ['guarded', 'С ограничениями интерфейса']]) { const option = document.createElement('option'); option.value = value; option.textContent = text; stateFilter.append(option); }
        stateLabel.append(stateFilter); filters.append(stateLabel);
        const inventory = document.createElement('div'); root.append(inventory);
        let page=0;
        const selected = new Set<string>(), pageSize=20;
        const pagination = document.createElement('div'); filters.append(pagination);
        const pageLabel=this.text(pagination,'');
        this.button(pagination,'Назад',()=>{page=Math.max(0,page-1);renderInventory(true);},false);
        this.button(pagination,'Вперёд',()=>{page++;renderInventory(true);},false);
        const groupFilter=this.choice(filters,'Группа',[['','Все группы'],...(s.document?.policy?.groups ?? []).map(g=>[g.id,g.name] as [string,string])],'');
        const matches = (m:Member) => {
            const flags=[!m.active?'revoked':memberActive(m,Date.now())?'active':'expired',m.devices.length>=m.maxDevices?'full':'',!m.devices.length?'empty':'',knownRestrictions(m).length?'guarded':''];
            return (m.accountId+' '+m.label).toLocaleLowerCase().includes(search.value.trim().toLocaleLowerCase()) &&
                (!groupFilter.value || m.groups?.includes(groupFilter.value)) && (!stateFilter.value || stateFilter.value==='all' || flags.includes(stateFilter.value));
        };
        const bulk=this.group(filters,'Массовое назначение группы');
        const groupChoice=this.choice(bulk,'Добавить в группу',(s.document?.policy?.groups ?? []).map(g=>[g.id,g.name]),'');
        const bulkReason=this.field(bulk,'Комментарий к операции');
        this.button(bulk,'Выбрать по фильтру',()=>{for(const m of s.document?.members ?? [])if(matches(m))selected.add(m.accountId);renderInventory(true);},false);
        this.button(bulk,'Снять выбор',()=>{selected.clear();renderInventory(true);},false);
        this.button(bulk,'Предпросмотр назначения',async()=>{
            const snapshot=s.document!, group=groupChoice.value, reason=bulkReason.value.trim();
            if (!group || !reason) throw Error('Выберите группу и укажите причину');
            const chosen=snapshot.members.filter(m=>selected.has(m.accountId)), active=chosen.filter(m=>memberActive(m,Date.now()));
            const lines=chosen.map(m=>{const vaults=r.profile.installations?.filter(i=>i.account===m.accountId).map(i=>i.instance) ?? [];
                return m.accountId+' · устройства: '+(m.devices.map(d=>this.short(d.deviceId)).join(', ') || '—')+' · vault: '+(vaults.join(', ') || '—')+(active.includes(m)?'':' · исключён');});
            await this.confirm('Группа '+(snapshot.policy?.groups?.find(g=>g.id===group)?.name ?? '')+'; пользователей '+active.length+'\n'+lines.join('\n'),()=>s.addToGroup(active.map(m=>m.accountId),group,snapshot.revision,reason));
        });
        const filterUsers = () => { const query = search.value.trim().toLocaleLowerCase(), state = stateFilter.value || 'all'; for (const row of Array.from(inventory.querySelectorAll<HTMLElement>('[data-user-search]'))) row.hidden = !row.dataset.userSearch!.includes(query) || (state !== 'all' && row.dataset.userFlags !== undefined && !row.dataset.userFlags.split(' ').includes(state)); };
        const filterChanged=()=>{page=0;renderInventory(true);};search.oninput=filterChanged;stateFilter.onchange=filterChanged;groupFilter.onchange=filterChanged;
        let editingInventory = false;
        inventory.addEventListener('input', () => { editingInventory = true; });
        queue.addEventListener('input', () => { editingInventory = true; });
        // An action refreshes the lists in place: opened cards stay opened (keyed by user, not by title) and the page does not jump.
        const act = (parent: HTMLElement, title: string, work: () => Promise<unknown>): void => this.button(parent, title, async () => { await work(); await r.tick(); this.executing = false; renderInventory(true); }, false);
        const openState = new Map<string, boolean>();
        let inventoryKey = '', lastWaiting = 0;
        const renderInventory = (force = false) => {
            const key = JSON.stringify([s.document?.revision, s.document?.members, s.document?.transport.version, s.document?.invitations.filter(i => i.standing).map(i => i.id), s.pending, s.rejected, s.rejectedList, r.legacyUsers, r.legacyError]);
            if (!force && (key === inventoryKey || editingInventory || this.executing || inventory.contains(document.activeElement) || queue.contains(document.activeElement) || Array.from(inventory.querySelectorAll<HTMLTextAreaElement>('textarea[readonly]:not([data-standing])')).some(el => !!el.value))) return;
            inventoryKey = key; editingInventory = false;
            for (const d of Array.from(root.querySelectorAll<HTMLDetailsElement>('details[data-key]'))) openState.set(d.dataset.key!, d.open);
            queue.replaceChildren(); inventory.replaceChildren();
            const now = Date.now(), waiting = s.pending.length;
            const waitingGroup = this.group(queue, `Заявки на рассмотрении: ${waiting}`, waiting > 0, 'queue');
            if (!waiting) this.text(waitingGroup, 'Новых заявок нет.');
            for (const request of s.pending.slice(0, 50)) {
                const item = document.createElement('div'); item.className = 'vam-request'; waitingGroup.append(item);
                const owner = s.document?.members.find(m => m.accountId === request.accountId);
                this.text(item, `${request.label ? `${request.label} (${request.accountId})` : request.accountId} · ${request.kind === 'replace' ? 'замена устройства' : 'дополнительное устройство'} · ${this.ago(now - request.issuedAt)}`);
                this.text(item, request.kind === 'replace' ? `Новое устройство ${this.short(request.deviceId)} заменит ${request.replaceDeviceId ? this.short(request.replaceDeviceId) : 'прежнее'}.` : `Новое устройство ${this.short(request.deviceId)}. Занято ${owner?.devices.length ?? 0} из ${owner?.maxDevices ?? 0}; после подтверждения лимит станет ${(owner?.devices.length ?? 0) + 1}.`);
                act(item, 'Подтвердить', () => s.approve(request.code));
                act(item, 'Отклонить', () => s.reject(request.code));
            }
            if (waiting > 50) this.text(waitingGroup, `Показаны первые 50 из ${waiting}. Остальные появятся после решения по этим.`);
            if (s.rejected) {
                const declined = this.group(queue, `Отклонённые заявки: ${s.rejected}`, false, 'declined');
                for (const item of s.rejectedList) this.text(declined, `${item.accountId ?? 'неизвестно'} · ${item.reason}`);
                if (s.rejected > s.rejectedList.length) this.text(declined, `Показаны первые ${s.rejectedList.length}.`);
                this.text(declined, 'Файлы заявок остаются в Git; их можно архивировать вручную.');
            }
            if (waiting > lastWaiting) openState.set('queue', true);
            lastWaiting = waiting;
            const members = this.group(inventory, 'Пользователи и устройства', true, 'members');
            this.text(members, 'Ключ пользователя подключает любое новое устройство без ID и пароля, пока есть свободные места; при их нехватке заявка приходит вам.');
            if (!s.document?.members.length) this.text(members, 'Новых пользователей пока нет. Прежние записи из репозитория показаны ниже.');
            const filtered=(s.document?.members ?? []).filter(matches);
            page=Math.min(page,Math.max(0,Math.ceil(filtered.length/pageSize)-1));
            pageLabel.textContent=filtered.length+' пользователей · страница '+(page+1)+' / '+Math.max(1,Math.ceil(filtered.length/pageSize))+' · выбрано '+selected.size;
            for (const member of filtered.slice(page*pageSize,(page+1)*pageSize)) {
                const live = memberActive(member, now), state = !member.active ? 'revoked' : live ? 'active' : 'expired', guarded = knownRestrictions(member), name = member.label || member.accountId;
                const row = this.group(members, `${name} · ${member.devices.length}/${member.maxDevices}${state === 'revoked' ? ' · отозван' : state === 'expired' ? ' · срок истёк' : ''}${guarded.length ? ' · ограничения' : ''}`, false, `user:${member.accountId}`);
                row.dataset.userSearch = `${member.accountId} ${member.label}`.toLocaleLowerCase();
                row.dataset.userFlags = [state, member.devices.length >= member.maxDevices ? 'full' : '', member.devices.length === 0 ? 'empty' : '', guarded.length ? 'guarded' : ''].filter(Boolean).join(' ');
                this.field(row, 'ID пользователя', member.accountId, 'text', true);
                this.text(row, `Срок доступа: ${member.expiresAt === null ? 'без ограничения' : new Date(member.expiresAt - 1).toLocaleDateString(undefined, { timeZone: 'UTC' }) + ' (UTC)'}${state === 'expired' ? ' · истёк' : ''}`);
                if (state === 'revoked') {
                    this.text(row, 'Доступ отозван. Подключённые устройства сохранены.');
                    act(row, 'Восстановить доступ', () => this.confirm(`Вернуть доступ пользователю ${name}? Его устройства снова заработают, будет создан новый ключ.`, () => s.restoreMember(member.accountId), { title: 'Подтвердите восстановление доступа', action: 'Восстановить доступ', danger: false }));
                } else if (state === 'expired') this.text(row, 'Срок доступа истёк. Продлите его в настройках пользователя.');
                else {
                    const standingKey = s.userKey(member.accountId);
                    if (standingKey) {
                        this.button(row,'Показать ключ пользователя',()=>{
                            if(row.querySelector('[data-standing]')) return;
                            const standing=this.field(row,'Ключ пользователя',standingKey,'textarea',true); standing.dataset.standing='1';
                        },false);
                        this.text(row, `Подключает устройство без ID и пароля · занято ${member.devices.length} из ${member.maxDevices}.`);
                        this.button(row, 'Скопировать приглашение', () => this.copyText(this.invitation(r.build!.adminId, member, standingKey)), false);
                        act(row, 'Перевыпустить ключ', () => this.confirm('Старый ключ перестанет подключать новые устройства. Подключённые устройства не затронуты.', async () => { await s.reissueKey(member.accountId); }, { title: 'Перевыпуск ключа', action: 'Перевыпустить ключ' }));
                    } else {
                        this.text(row, 'У этого пользователя ещё нет постоянного ключа.');
                        act(row, 'Создать постоянный ключ', () => s.reissueKey(member.accountId));
                    }
                }
                const choose=this.field(row,'Включить в массовую операцию','','checkbox') as HTMLInputElement;
                choose.checked=selected.has(member.accountId);choose.onchange=()=>{if(choose.checked)selected.add(member.accountId);else selected.delete(member.accountId);renderInventory(true);};
                const rights = this.group(row,'Эффективные права и назначения');
                for (const id of permissions) {const v=effective(s.document?.policy,member,id); this.text(rights,permissionLabels[id]+' · '+(v.allowed?'разрешено':'запрещено')+' · '+v.source);}
                const rules = this.rulesEditor(rights,member.rules), role = this.choice(rights,'Роль',[['user','Пользователь'],['operator','Оператор']],member.role ?? 'user');
                const memberships = (s.document?.policy?.groups ?? []).map(g=>{const box=this.field(rights,g.name,'','checkbox') as HTMLInputElement;box.checked=member.groups?.includes(g.id) ?? false;return [g.id,box] as const;});
                const reason = this.field(rights,'Причина изменения прав');
                act(rights,'Сохранить назначения',()=>s.assignPolicy([member.accountId],rules(),memberships.filter(([,box])=>box.checked).map(([id])=>id),role.value as 'user'|'operator',reason.value));
                const edit = this.group(row, 'Настройки пользователя', false, `user:${member.accountId}:edit`);
                const labelField = this.field(edit, 'Имя пользователя', member.label), until = this.field(edit, 'Доступ по дату включительно (UTC)', member.expiresAt === null ? '' : new Date(member.expiresAt - 1).toISOString().slice(0, 10), 'date');
                const limit = this.field(edit, 'Лимит устройств', String(member.maxDevices), 'number'), pass = this.field(edit, 'Новый пароль (пусто — оставить прежний)', '', 'password');
                this.text(edit, 'Ограничения интерфейса: защита от случайных действий, а не от намеренного обхода. Администратора они не касаются.');
                const boxes = RESTRICTIONS.map(restriction => { const box = this.field(edit, RESTRICTION_TITLES[restriction], '', 'checkbox') as HTMLInputElement; box.checked = guarded.includes(restriction); return [restriction, box] as const; });
                act(edit, 'Сохранить изменения', () => s.updateUser(member.accountId, { label: labelField.value, password: pass.value || undefined, expiresAt: until.value ? Date.parse(until.value) + 86400000 : null, maxDevices: Number(limit.value), restrictions: boxes.filter(([, box]) => box.checked).map(([restriction]) => restriction) }));
                if (member.devices.length) {
                    const devices = this.group(row, `Устройства: ${member.devices.length}`, false, `user:${member.accountId}:devices`);
                    const result = this.field(devices, 'Ключ замены устройства', '', 'textarea', true);
                    for (const device of member.devices) {
                        this.text(devices, `Устройство ${this.short(device.deviceId)} · добавлено ${new Date(device.addedAt).toLocaleDateString()}`);
                        if (state === 'active') this.button(devices, 'Выдать ключ замены', async () => { result.value = (await s.invite(member.label, { accountId: member.accountId, replaceDeviceId: device.deviceId })).code; await r.tick(); }, false);
                        act(devices, 'Отозвать устройство', () => this.confirm(`Отозвать устройство ${this.short(device.deviceId)} пользователя ${name}? Оно потеряет доступ к организации.`, () => s.change('remove-device', member.accountId, device.deviceId), { title: 'Подтвердите отзыв устройства', action: 'Отозвать устройство' }));
                    }
                }
                if (member.active) act(row, 'Отозвать пользователя', () => this.confirm(`Все устройства пользователя ${name} потеряют доступ. Позже доступ можно вернуть кнопкой «Восстановить доступ».`, () => s.change('revoke-member', member.accountId), {title:'Подтвердите отзыв доступа',action:'Отозвать доступ',danger:true}));
            }
            const legacy = this.group(inventory, `Пользователи прежней версии: ${r.legacyUsers.length}`, r.legacyUsers.length > 0, 'legacy');
            if (r.legacyError) this.text(legacy, r.legacyError);
            this.button(legacy, 'Обновить список из репозитория', () => r.refreshLegacy());
            this.text(legacy, 'Список загружается из users/. Для переноса нужен прежний пароль пользователя. ID, пароль, срок и лимит сохраняются; устройство регистрируется заново через выданный ключ. Исходные файлы остаются в репозитории.');
            for (const member of r.legacyUsers) {
                const imported = s.document?.members.some(m => m.accountId === member.accountId);
                const row = this.group(legacy, `${member.label || member.accountId}${imported ? ' · перенесён' : ' · прежняя запись'}`, false, `legacy:${member.accountId}`);
                row.dataset.userSearch = `${member.accountId} ${member.label}`.toLocaleLowerCase();
                if (imported) { this.text(row, 'Профиль находится в разделе «Пользователи и устройства».'); continue; }
                this.field(row, 'Прежний ID', member.accountId, 'text', true);
                const password = this.field(row, 'Прежний пароль пользователя', '', 'password');
                const output = this.field(row, 'Новый ключ для пользователя', '', 'textarea', true);
                this.button(row, 'Перенести и выдать ключ', async () => { output.value = await r.importLegacy(member.accountId, password.value); password.value = ''; }, false);
            }
            filterUsers();
            for (const d of Array.from(root.querySelectorAll<HTMLDetailsElement>('details[data-key]'))) { const saved = openState.get(d.dataset.key!); if (saved !== undefined) d.open = saved; }
        };
        renderInventory(true);
        const unsubscribeStatus = this.unsubscribe;
        const unsubscribeInventory = r.subscribe(() => { if (!this.visible) return; updateSummary(); showFleet(); renderInventory(); renderPlugins(); });
        this.unsubscribe = () => { unsubscribeStatus?.(); unsubscribeInventory(); };
    }
}
