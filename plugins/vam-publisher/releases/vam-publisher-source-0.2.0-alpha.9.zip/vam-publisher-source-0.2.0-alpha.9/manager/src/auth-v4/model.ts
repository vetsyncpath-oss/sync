import {validateScoped} from './policy';
import type {Assignment as importPolicyAssignment, Policy} from './policy';
import { decode64, encode64, publicKey } from '../auth-v2/crypto';
import { validateRepo, type Repo } from '../auth-v2/model';
import { validateExpiry } from '../auth-v3/pat';
export type { Repo };
export const DAY = 86_400_000;
export const CONFIG_PATH = 'vam/config.json';
export const LAYOUT = { state: CONFIG_PATH, requests: 'vam/requests', extension: 'json' };
export interface BuildProfile { studioIssuer?: JsonWebKey; v: 4; adminId: string; tenantId: string; bundleId: string; repository: Repo; defaultPassword: string; bootstrapToken?: string }
export interface ClientBuild extends Omit<BuildProfile,'defaultPassword'> {
    localOwnerOnly?: true; managerIssuer: JsonWebKey; authority: import('./authority').AuthorityPin; defaultPassword?: never
}
export type ManagerBuild = BuildProfile | ClientBuild;
export function clientBuild(raw: unknown): ClientBuild {
    const b = object(raw);
    if (b.defaultPassword !== undefined || b.v !== 4 || typeof b.adminId !== 'string' || !b.adminId.trim() || !b.authority || b.authority.signing?.d || b.authority.inbox?.d) throw Error('Некорректная клиентская сборка');
    identifier(b.tenantId); identifier(b.bundleId);
    if (b.bootstrapToken !== undefined && (typeof b.bootstrapToken !== 'string' || !b.bootstrapToken.trim() || b.bootstrapToken.length > 4096 || /[\s\x00-\x1f]/.test(b.bootstrapToken))) throw Error('Некорректный PAT');
    return {v:4,adminId:b.adminId,tenantId:b.tenantId,bundleId:b.bundleId,repository:validateRepo(b.repository),
        ...(b.localOwnerOnly === true ? {localOwnerOnly:true as const}:{}),managerIssuer:publicKey(b.managerIssuer),...(b.studioIssuer?{studioIssuer:publicKey(b.studioIssuer)}:{}),authority:{signing:publicKey(b.authority.signing),inbox:publicKey(b.authority.inbox)},...(b.bootstrapToken ? {bootstrapToken:b.bootstrapToken} : {})};
}
export interface Transport { token: string; version: number; expiresOn: string | null }
export interface Device { inbox?: JsonWebKey; deviceId: string; key: JsonWebKey; addedAt: number }
/** Soft interface guards against accidental actions. They are not a security boundary (see docs/PRE-OVERHAUL-DECISIONS.md, D1). */
export const RESTRICTIONS = ['settings.open', 'note.delete','note.create','note.edit','note.rename','note.move','folder.create','folder.delete','attachment.add','attachment.delete'] as const;
export type Restriction = typeof RESTRICTIONS[number];
export const RESTRICTION_TITLES: Record<Restriction, string> = {'note.create':'Запретить: Создание заметок','note.edit':'Запретить: Редактирование заметок','note.rename':'Запретить: Переименование заметок','note.move':'Запретить: Перемещение заметок','folder.create':'Запретить: Создание папок','folder.delete':'Запретить: Удаление папок','attachment.add':'Запретить: Добавление вложений','attachment.delete':'Запретить: Удаление вложений', 'settings.open': 'Запретить вход в настройки Obsidian', 'note.delete': 'Запретить удаление заметок и папок' };
export interface Member extends importPolicyAssignment { accountId: string; label: string; password: string; active: boolean; expiresAt: number | null; maxDevices: number; devices: Device[]; blockedDevices: string[]; restrictions?: string[] }
/** A standing invitation is the user's permanent key: it is never consumed, never pruned by date, and connects devices while the limit allows. */
export const STANDING_EXPIRY = 253402300799000;
/** An older manager may mark a permanent key as used; such a mark is ignored, the key is never consumed. */
export const consumed = (i: { standing?: true; consumedBy: string | null }): boolean => !i.standing && !!i.consumedBy;
export interface Invitation { id: string; accountId: string; secret: string; purpose: 'activate' | 'replace'; replaceDeviceId?: string; expiresAt: number; consumedBy: string | null; standing?: true }
export interface Document { campaigns?: import("./updates").Campaign[]; policy?: Policy; history?: {at:number; author:string; revision:number; action:string; targets:string[]}[]; v: 4; tenantId: string; bundleId: string; adminId: string; adminPassword: string; revision: number; updatedAt: number; transport: Transport; members: Member[]; invitations: Invitation[]; receipts: Array<{ id: string; expiresAt: number; rejected?: true }> }
export interface AccessCode { v: 4; tenantId: string; bundleId: string; accountId: string; transport: Transport; purpose: 'activate' | 'replace' | 'update'; invitationId?: string; secret?: string }
export interface Request { inbox?: JsonWebKey; v: 4; tenantId: string; bundleId: string; accountId: string; requestId: string; deviceKey: JsonWebKey; deviceId: string; auth: {kind:'inbox'} | { kind: 'invitation'; id: string; secret: string } | { kind: 'password'; password: string }; issuedAt: number; expiresAt: number }
export interface Outbox { sealed?: string; id: string; code: string; submitted: boolean; expiresAt: number }
export interface Cache { document: Document; fetchedAt: number }
export type Session = { kind: 'administrator'; password: string } | { kind: 'user'; accountId: string };
function object(value: unknown): any { if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Некорректная конфигурация'); return value; }
export function identifier(value: unknown): asserts value is string { if (typeof value !== 'string' || !/^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,127}$/.test(value)) throw new Error('Некорректный идентификатор'); }
export function password(value: unknown): asserts value is string { if (typeof value !== 'string' || !value || value.length > 1024) throw new Error('Укажите пароль'); }
function timestamp(value: unknown): asserts value is number { if (!Number.isSafeInteger(value) || (value as number) < 0) throw new Error('Некорректная дата'); }
export function validateTransport(raw: unknown): Transport { const t = object(raw); if (typeof t.token !== 'string' || !t.token.trim() || t.token.length > 4096 || !Number.isSafeInteger(t.version) || t.version < 1) throw new Error('Некорректное подключение'); validateExpiry(t.expiresOn); return { token: t.token, version: t.version, expiresOn: t.expiresOn }; }
export function validateBuild(raw: unknown): BuildProfile {
    const b = object(raw); if (b.v !== 4 || typeof b.adminId !== 'string' || !b.adminId.trim() || b.adminId.length > 120) throw new Error('Некорректный профиль Администратора');
    identifier(b.tenantId); identifier(b.bundleId); password(b.defaultPassword);
    if (b.bootstrapToken !== undefined && (typeof b.bootstrapToken !== 'string' || b.bootstrapToken.length > 4096)) throw new Error('Некорректное подключение');
    return { ...(b.studioIssuer ? {studioIssuer:publicKey(b.studioIssuer)} : {}), v: 4, adminId: b.adminId, tenantId: b.tenantId, bundleId: b.bundleId, defaultPassword: b.defaultPassword, repository: validateRepo(b.repository), ...(b.bootstrapToken ? { bootstrapToken: b.bootstrapToken } : {}) };
}
export function validateDocument(raw: unknown, build: ManagerBuild): Document {
    const d = object(raw); if (d.v !== 4 || d.tenantId !== build.tenantId || d.bundleId !== build.bundleId || d.adminId !== build.adminId) throw new Error('Конфигурация принадлежит другой организации');
    password(d.adminPassword); timestamp(d.updatedAt); if (!Number.isSafeInteger(d.revision) || d.revision < 1) throw new Error('Некорректная версия конфигурации'); validateTransport(d.transport);
    if (!Array.isArray(d.members) || d.members.length > 10000 || !Array.isArray(d.invitations) || d.invitations.length > 10000 || !Array.isArray(d.receipts) || d.receipts.length > 10000) throw new Error('Некорректный реестр');
    if (d.policy?.scoped !== undefined) {
        const scoped=d.policy.scoped;
        if (!Array.isArray(scoped) || scoped.length>512 || new Set(scoped.map(r=>r?.id)).size!==scoped.length) throw Error('Некорректный список правил');
        for (const rule of scoped) validateScoped(rule);
    }
    const accounts = new Set<string>(), devices = new Set<string>(), invites = new Set<string>(), receipts = new Set<string>();
    for (const m of d.members) {
        object(m); identifier(m.accountId); password(m.password); if (m.expiresAt !== null) timestamp(m.expiresAt);
        if (accounts.has(m.accountId) || typeof m.label !== 'string' || m.label.length > 200 || typeof m.active !== 'boolean' || !Number.isInteger(m.maxDevices) || m.maxDevices < 1 || m.maxDevices > 100 || !Array.isArray(m.devices) || m.devices.length > m.maxDevices || !Array.isArray(m.blockedDevices) || m.blockedDevices.length > 10000) throw new Error('Некорректный пользователь');
        accounts.add(m.accountId);
        for (const device of m.devices) { object(device); timestamp(device.addedAt); publicKey(device.key); if (!/^[\w-]{43}$/.test(device.deviceId) || devices.has(device.deviceId) || m.blockedDevices.includes(device.deviceId)) throw new Error('Некорректное устройство'); devices.add(device.deviceId); }
        if (new Set(m.blockedDevices).size !== m.blockedDevices.length || m.blockedDevices.some((id: unknown) => typeof id !== 'string' || !/^[\w-]{43}$/.test(id))) throw new Error('Некорректный отзыв устройства');
        // Unknown names are kept so that a newer Administrator never makes the document invalid for an older client; they are simply not enforced.
        if (m.restrictions !== undefined && (!Array.isArray(m.restrictions) || m.restrictions.length > 32 || new Set(m.restrictions).size !== m.restrictions.length || m.restrictions.some((r: unknown) => typeof r !== 'string' || !/^[a-z][a-z0-9._:-]{0,63}$/.test(r)))) throw new Error('Некорректные ограничения пользователя');
    }
    for (const i of d.invitations) { object(i); identifier(i.id); timestamp(i.expiresAt); if (invites.has(i.id) || !accounts.has(i.accountId) || !/^[\w-]{43}$/.test(i.secret) || !['activate', 'replace'].includes(i.purpose) || (i.consumedBy !== null && typeof i.consumedBy !== 'string') || (i.standing !== undefined && (i.standing !== true || i.purpose !== 'activate')) || (i.purpose === 'replace' && (typeof i.replaceDeviceId !== 'string' || !/^[\w-]{43}$/.test(i.replaceDeviceId)))) throw new Error('Некорректный ключ доступа'); invites.add(i.id); }
    for (const receipt of d.receipts) { object(receipt); identifier(receipt.id); timestamp(receipt.expiresAt); if (receipt.rejected !== undefined && receipt.rejected !== true) throw new Error('Некорректная квитанция'); if (receipts.has(receipt.id)) throw new Error('Повторная квитанция'); receipts.add(receipt.id); }
    return structuredClone(d);
}
export function initialDocument(build: ManagerBuild, token: string, expiresOn: string | null, now: number, initialPassword = build.defaultPassword): Document { return validateDocument({ v: 4, tenantId: build.tenantId, bundleId: build.bundleId, adminId: build.adminId, adminPassword: initialPassword, revision: 1, updatedAt: now, transport: { token, version: 1, expiresOn }, members: [], invitations: [], receipts: [] }, build); }
export function encodeCode(code: AccessCode): string { return 'VAM4.' + encode64(new TextEncoder().encode(JSON.stringify(code))); }
export function decodeCode(text: string, build: ManagerBuild): AccessCode {
    // Messengers and mail clients wrap long lines; whitespace and zero-width characters are never part of the key.
    text = text.replace(/[\s\u200B-\u200D\u2060\uFEFF]/g, '');
    let c: any; try { if (!text.startsWith('VAM4.') || text.length > 20000) throw new Error(); c = object(JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(decode64(text.slice(5))))); } catch { throw new Error('Некорректный ключ доступа'); }
    if (c.v !== 4 || c.tenantId !== build.tenantId || c.bundleId !== build.bundleId) throw new Error('Ключ принадлежит другой организации');
    identifier(c.accountId); c.transport = validateTransport(c.transport); if (!['activate', 'replace', 'update'].includes(c.purpose)) throw new Error('Некорректный ключ доступа');
    if (c.purpose !== 'update') { identifier(c.invitationId); if (typeof c.secret !== 'string' || !/^[\w-]{43}$/.test(c.secret)) throw new Error('Некорректный ключ доступа'); }
    return c;
}
export function memberActive(m: Member | undefined, now: number): m is Member { return !!m && m.active && (m.expiresAt === null || m.expiresAt > now); }
export function knownRestrictions(member: Member | undefined): Restriction[] { return (member?.restrictions ?? []).filter((r): r is Restriction => (RESTRICTIONS as readonly string[]).includes(r)); }
