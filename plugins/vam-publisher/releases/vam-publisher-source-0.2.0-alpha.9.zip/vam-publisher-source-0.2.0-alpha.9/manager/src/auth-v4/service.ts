import {verifyRelease,releaseBase,type Component,type Campaign} from './updates';
import {readInstallations,writeInstallation,type Installation} from './installations';
import {effective,relevant,within,nextBoundary,validateScoped,type ScopedRule,permissions,validateRules,type Permission,type Rules,type Assignment,type Policy} from './policy';
import { encode64, inspectJws, keyId, publicKey, signJws, verifyJws, type Identity } from '../auth-v2/crypto';
import { GitError, GitStore, transient, type Store } from '../auth-v3/git-store';
import { validateExpiry } from '../auth-v3/pat';
import { CONFIG_PATH, DAY, LAYOUT, STANDING_EXPIRY, consumed, decodeCode, encodeCode, initialDocument, knownRestrictions, memberActive, RESTRICTIONS, password, identifier, validateBuild, validateDocument, type AccessCode, type ManagerBuild, clientBuild, type Cache, type Document, type Member, type Outbox, type Request, type Restriction, type Session, type Transport } from './model';
import { credential, decodeState, encodeState, invitationDigest, seal, unlock, unseal, type AuthorityKeys, type SignedState } from './authority';
import type { EncryptedIdentity } from '../auth-v2/crypto';
import type { Decision, Query } from '../auth-v3/model';
import type { UserPayload } from '../core/crypto';

/** A device request that waits for the Administrator: a replacement of a device, or an extra device above the limit. */
export interface Pending { path: string; accountId: string; deviceId: string; code: string; kind: 'replace' | 'extra'; label: string; issuedAt: number; replaceDeviceId?: string }
export interface RejectedRequest { path: string; accountId?: string; reason: string }
export interface Options { ownerSetup?: () => Promise<EncryptedIdentity | undefined>; saveOwnerSetup?: (kit: EncryptedIdentity) => Promise<void>; instance?: string; inbox?: CryptoKeyPair; fetcher?: typeof fetch; store?: (token: string) => Store; now?: () => number; changed?: () => void }
/** The bound private repository is authoritative. Passwords and transport are deliberately plain configuration. */
export class Service {
    document: Document | null = null;
    cache: Cache | null = null;
    transport: Transport;
    session: Session | null = null;
    online = false;
    error = '';
    pending: Pending[] = [];
    rejected = 0;
    rejectedList: RejectedRequest[] = [];
    /** Request files are immutable (the path is the request id and `submit` refuses different text), so a processed file is not read again.
     *  An invalid file is rechecked after ten minutes because the only time-dependent rule is a device clock that runs ahead of the Administrator's. */
    private settled = new Map<string, { invalid: boolean; until: number; reason?: string; accountId?: string }>();
    private disposed = false;
    private keys?: AuthorityKeys;
    private localOwnerOnly = false;
    private wrapped?: EncryptedIdentity;
    private previous?: {view: Document; full: Document};
    private revision = 0;
    get policyRevision() { return this.revision; }
    restoreRevision(value: number) { if (Number.isSafeInteger(value)) this.revision = Math.max(this.revision,value); }
    private store: Store;
    private epoch = 0;
    private now: () => number;
    private makeStore: (token: string) => Store;
    constructor(readonly build: ManagerBuild, readonly device: Identity, token: string, version = 0, private options: Options = {}) {
        this.build = 'authority' in build ? clientBuild(build) : validateBuild(build); this.now = options.now ?? Date.now;
        this.makeStore = options.store ?? (value => new GitStore(this.build.repository, value, options.fetcher, undefined, LAYOUT));
        this.transport = { token, version, expiresOn: null }; this.store = this.makeStore(token);
    }
    private changed(): void { this.options.changed?.(); }
    private guard(epoch: number): void { if (this.disposed || epoch !== this.epoch) throw new Error('Действие отменено'); }
    private async read(store = this.store, ownerPassword?: string, suppliedKit?: EncryptedIdentity, retry = true): Promise<{ document: Document | null; sha: string | null }> {
        await store.checkPrivate?.(); const file = await store.read(CONFIG_PATH);
        if (!file) return { document: null, sha: null };
        let raw: unknown; try { raw = JSON.parse(file.text); } catch { throw new Error('Некорректная конфигурация организации'); }
        if (!('authority' in this.build)) return { document: validateDocument(raw, this.build), sha: file.sha };
        const epoch = this.epoch;
        const value = ownerPassword ?? (this.session?.kind === 'administrator' ? this.session.password : undefined);
        if (value && !this.revision && raw && typeof raw === 'object' && 'v' in raw && raw.v === 4 && !('signature' in raw)) {
            const doc = validateDocument(raw,this.build);
            const kit = suppliedKit ?? await this.options.ownerSetup?.();
            if (!kit) throw Error('Для перехода нужен код владельца из Publisher');
            const keys = await unlock(kit,value,this.build.tenantId,this.build.authority);
            // Only alpha.5 fields may cross the unsigned-to-signed boundary.
            delete doc.policy; delete doc.campaigns;
            for (const member of doc.members) {
                delete member.groups; delete member.rules; delete member.role;
                for (const device of member.devices) {
                    if (await keyId(device.key) !== device.deviceId) throw Error('Неверный идентификатор устройства');
                    delete device.inbox;
                }
            }
            doc.adminPassword = value;
            doc.updatedAt = this.now(); doc.revision++;
            doc.history = [{at:doc.updatedAt,author:doc.adminId,revision:doc.revision,action:'migration.alpha5',targets:[]}];
            const encoded = await encodeState(doc,keys,null);
            this.guard(epoch);
            if (!retry) throw Error('Реестр изменился во время перехода. Повторите подключение');
            try { await store.write(CONFIG_PATH,encoded,file.sha); }
            catch (e) { if (!(e instanceof GitError) || !['validation','conflict'].includes(e.kind)) throw e; }
            this.guard(epoch);
            this.wrapped = kit;
            return this.read(store,value,kit,false);
        }
        const state = await decodeState(raw,this.build,this.build.authority);
        if (state.view.revision < this.revision || state.view.transport.version < this.transport.version) throw Error('Получена старая ревизия реестра');
        this.revision = state.view.revision;
        this.localOwnerOnly = state.wrapped === null;
        this.wrapped = state.wrapped ?? suppliedKit ?? this.wrapped ?? (value ? await this.options.ownerSetup?.() : undefined);
        if (!this.keys && value) {
            if (!this.wrapped) throw Error('Введите код владельца из Publisher');
            this.keys = await unlock(this.wrapped,value,this.build.tenantId,this.build.authority);
            if (this.localOwnerOnly) await this.options.saveOwnerSetup?.(this.wrapped);
        }
        if (!this.keys) {
            const view = structuredClone(state.view);
            let token = this.transport.token;
            if (await invitationDigest(token) !== state.transportDigest) {
                const box = state.delivery[this.device.keyId];
                if (box && this.options.inbox) {
                    const context = JSON.stringify([view.tenantId,view.bundleId,'transport',view.transport.version]);
                    token = await unseal(this.options.inbox.privateKey,box,context);
                    if (await invitationDigest(token) !== state.transportDigest) throw Error('Некорректная доставка PAT');
                } else {
                    // An owner can unlock the signed record with the current working transport during overlap.
                    view.transport = {...this.transport, version:Math.max(1,this.transport.version)};
                    return {document:view,sha:file.sha};
                }
            }
            view.transport.token = token;
            return {document:view,sha:file.sha};
        }
        const full = validateDocument(await unseal(this.keys.inbox,state.privateState,'vam-private-policy'),this.build);
        if (full.revision !== state.view.revision) throw Error('Несовместимые ревизии реестра');
        this.previous = {view:state.view,full:structuredClone(full)};
        return {document:full,sha:file.sha};
    }
    private async encode(document: Document) {
        if (!('authority' in this.build)) return JSON.stringify(document,null,2);
        if (!this.keys || !this.wrapped) throw Error('Нужен ключ владельца');
        return encodeState(document,this.keys,this.localOwnerOnly ? null : this.wrapped,this.previous);
    }
    restoreCache(cache: Cache | null): void {
        if (!cache || cache.document?.revision < this.revision || !Number.isSafeInteger(cache.fetchedAt) || cache.fetchedAt > this.now() + 60000 || this.now() - cache.fetchedAt > DAY) return;
        this.document = validateDocument(cache.document, this.build); this.cache = structuredClone(cache);
    }
    restoreSession(session: Session | null): void { this.session = session; }
    private accept(document: Document | null): void {
        this.document = document; this.cache = document ? { document: structuredClone(document), fetchedAt: this.now() } : null; this.online = true;
        if (this.session?.kind === 'administrator' && this.session.password !== document?.adminPassword) { this.session = null; this.epoch++; this.error = 'Пароль Администратора изменён. Войдите с новым паролем.'; }
    }
    async refresh(): Promise<void> {
        const epoch = this.epoch;
        try {
            const { document } = await this.read(); this.guard(epoch); this.error = ''; this.accept(document);
            if (document && document.transport.version < this.transport.version) throw new Error('Версия подключения в репозитории устарела');
            if (document && document.transport.token !== this.transport.token) {
                if (document.transport.version <= this.transport.version) throw new Error('Администратору нужно увеличить версию подключения при смене PAT');
                const rotationEpoch = this.epoch;
                try {
                    const candidate = this.makeStore(document.transport.token), current = await this.read(candidate); this.guard(rotationEpoch);
                    if (!current.document || current.document.transport.token !== document.transport.token || current.document.transport.version !== document.transport.version) throw new Error('Обновление подключения ещё не подтверждено');
                    this.store = candidate; this.transport = structuredClone(current.document.transport); this.accept(current.document);
                } catch (e) { this.guard(rotationEpoch); this.error = 'Новый PAT не прошёл проверку. Пока используется прежнее подключение; Администратору нужно проверить замену.'; }
            } else if (document) this.transport = structuredClone(document.transport);
        } catch (error) {
            if (this.disposed) return;
            this.online = false; this.error = error instanceof Error ? error.message : 'Не удалось обновить подключение';
            if (!transient(error)) { this.document = null; this.cache = null; }
        }
        this.changed();
    }
    isAdministrator(): boolean { return !this.disposed && this.online && this.session?.kind === 'administrator' && this.session.password === this.document?.adminPassword; }
    access(query: Query): Decision {
        const blocked = (reason: string, status: 'blocked' | 'pending' = 'blocked'): Decision => ({ status, reason, validUntil: null });
        if (this.disposed || query.tenantId !== this.build.tenantId || query.bundleId !== this.build.bundleId) return blocked('bundle-scope-required');
        if (!this.session) return blocked('signed-out');
        if (!this.document || !this.cache || this.now() - this.cache.fetchedAt >= DAY) return blocked('connection-unavailable');
        if (this.session.kind === 'administrator') return this.isAdministrator() ? { status: 'granted', reason: null, validUntil: this.cache.fetchedAt + DAY } : blocked('administrator-locked');
        const member = this.document.members.find(m => m.accountId === (this.session as any)?.accountId);
        if (!memberActive(member, this.now())) return blocked('access-revoked-or-expired');
        if (member.blockedDevices.includes(this.device.keyId)) return blocked('device-revoked');
        if (!member.devices.some(d => d.deviceId === this.device.keyId)) return blocked(member.devices.length >= member.maxDevices ? 'device-limit' : 'device-not-approved', 'pending');
        let boundary = Infinity;
        if (permissions.includes(query.capability as Permission)) {
            const ctx = this.ruleContext();
            const result = effective(this.document.policy,member,query.capability as Permission,ctx);
            boundary = nextBoundary(this.document.policy,member,query.capability as Permission,ctx);
            if (!result.allowed) return blocked('policy-denied: '+result.source);
        }
        return { status: 'granted', reason: null, validUntil: Math.min(boundary, member.expiresAt ?? Infinity, this.cache.fetchedAt + DAY) };
    }
    async loginAdministrator(value: string, expiresOn: string | null = null, setup = ''): Promise<void> {
        password(value); const epoch = this.epoch; const suppliedKit = setup ? JSON.parse(setup) : undefined; const current = await this.read(this.store,value,suppliedKit); this.guard(epoch);
        if ('authority' in this.build) {
            if (!current.document && this.revision) throw Error('Отсутствует ранее подтверждённый реестр');
            const wrapped = current.document ? this.wrapped : suppliedKit ?? await this.options.ownerSetup?.();
            if (!wrapped) throw Error('Введите код первичной настройки из Publisher');
            if (!current.document) {
                this.keys = await unlock(wrapped,value,this.build.tenantId,this.build.authority);
                this.localOwnerOnly = this.build.localOwnerOnly === true;
                if (this.localOwnerOnly) await this.options.saveOwnerSetup?.(wrapped);
            }
            this.wrapped = wrapped;
        }
        if (!current.document) {
            if (!('authority' in this.build) && value !== this.build.defaultPassword) throw new Error('Неверный пароль Администратора. Обратитесь к Издателю плагина.');
            const document = initialDocument(this.build, this.transport.token, validateExpiry(expiresOn), this.now(), value);
            const encoded=await this.encode(document); this.guard(epoch);
            try { await this.store.write(CONFIG_PATH, encoded, null); }
            catch (e) { if (!(e instanceof GitError) || !['conflict', 'validation'].includes(e.kind)) throw e; }
        }
        // Verify the winning document even if another administrator initialized concurrently.
        await this.refresh(); this.guard(epoch);
        if (!this.online || !this.document) throw new Error(this.error || 'Не удалось проверить подключение');
        if (value !== this.document.adminPassword) throw new Error('Неверный пароль Администратора. Обратитесь к Издателю плагина.');
        this.session = { kind: 'administrator', password: value }; this.changed();
    }
    logout(): void { this.keys = undefined; this.previous = undefined; this.document = null; this.cache = null; this.epoch++; this.session = null; this.pending = []; this.changed(); }
    private async mutate<T>(work: (document: Document) => T, store = this.store): Promise<T> {
        const epoch = this.epoch;
        for (let attempt = 0; attempt < 3; attempt++) {
            const current = await this.read(store); this.guard(epoch);
            if (!current.document || this.session?.kind !== 'administrator' || current.document.adminPassword !== this.session.password) { this.session = null; this.changed(); throw new Error('Войдите с актуальным паролем Администратора'); }
            const document = current.document, result = work(document); this.guard(epoch);
            document.revision++; document.updatedAt = this.now(); document.receipts = document.receipts.filter(r => r.expiresAt > this.now());
            document.invitations = document.invitations.filter(i => i.standing || i.expiresAt > this.now()); validateDocument(document, this.build);
            const encoded=await this.encode(document); this.guard(epoch);
            try { await store.write(CONFIG_PATH, encoded, current.sha); this.guard(epoch); this.accept(document); this.changed(); return result; }
            catch (e) { if (!(e instanceof GitError) || e.kind !== 'conflict' || attempt === 2) throw e; }
        }
        throw new Error('Конфликт изменений. Повторите действие.');
    }
    private audit(d: Document, action: string, targets: string[]) {
        d.history = [...(d.history ?? []),{at:this.now(),author:d.adminId,revision:d.revision+1,action,targets}].slice(-250);
    }
    async assignPolicy(ids: string[], rules: Rules, groups: string[], role: 'operator'|'user', reason: string) {
        validateRules(rules);
        if (!reason.trim() || reason.length>200 || !ids.length || !['user','operator'].includes(role)) throw Error('Укажите получателей и причину изменения');
        await this.mutate(d=>{
            if (groups.some(id=>!d.policy?.groups?.some(g=>g.id===id))) throw Error('Группа не найдена');
            for (const id of ids) {
                const m = d.members.find(m=>m.accountId===id);
                if (!m) throw Error('Список пользователей изменился');
                Object.assign(m,{rules:{...rules},groups:[...groups],role});
            }
            this.audit(d,reason,ids);
        });
    }
    async addToGroup(ids: string[], groupId: string, revision: number, reason: string) {
        if (!ids.length || !reason.trim() || reason.length>200) throw Error('Выберите пользователей и укажите причину');
        await this.mutate(d=>{
            if (d.revision!==revision || !d.policy?.groups?.some(g=>g.id===groupId)) throw Error('Реестр изменился. Обновите предпросмотр.');
            for (const id of ids) {
                const member=d.members.find(m=>m.accountId===id);
                if(!memberActive(member,this.now())) throw Error('Изменился состав получателей');
                member.groups=[...new Set([...(member.groups ?? []),groupId])];
            }
            this.audit(d,reason,ids);
        });
    }
    async setGroup(id: string, name: string, rules: Rules) {
        identifier(id); validateRules(rules);
        if (!name.trim() || name.length>100) throw Error('Укажите название группы');
        await this.mutate(d=>{
            const policy = d.policy ??= {};
            policy.groups = [...(policy.groups ?? []).filter(g=>g.id!==id),{id,name,rules}];
            this.audit(d,'Группа: '+name,[id]);
        });
    }
    async changeScopedRule(rule: ScopedRule | string, revision: number) {
        if (typeof rule !== 'string') validateScoped(rule);
        await this.mutate(d=>{
            if (revision !== d.revision) throw Error('Реестр изменился. Обновите редактор правил.');
            const policy = d.policy ??= {};
            const id = typeof rule === 'string' ? rule : rule.id;
            const previous = policy.scoped ?? [];
            if (typeof rule === 'string' && !previous.some(r=>r.id===id)) throw Error('Правило уже удалено');
            const next = previous.filter(r=>r.id!==id);
            if (typeof rule !== 'string') {
                if ((rule.level==='user' && !d.members.some(m=>m.accountId===rule.subject)) ||
                    (rule.level==='group' && !policy.groups?.some(g=>g.id===rule.subject))) throw Error('Адресат не найден');
                next.push(structuredClone(rule));
            }
            policy.scoped=next;
            this.audit(d,typeof rule === 'string' ? 'Удалено правило' : rule.reason,[id]);
        });
    }
    async setOrganizationPolicy(policy: Pick<Policy,'mandatory'|'defaults'|'roles'>) {
        validateRules(policy.defaults ?? {}); validateRules(policy.roles?.user ?? {}); validateRules(policy.roles?.operator ?? {});
        if (policy.mandatory?.some(id=>!permissions.includes(id))) throw Error('Неизвестное право');
        await this.mutate(d=>{d.policy={...d.policy,...structuredClone(policy)}; this.audit(d,'Политика организации',[]);});
    }
    async dispatch(targets:string[],component:Component,signature:string,base:string,expires:number,reason:string,known:Installation[],revision:number) {
        if(!this.isAdministrator() || !('authority' in this.build)) throw Error('Требуется полномочие владельца');
        const release=await verifyRelease(signature,component,this.build);
        const ids=[...new Set(targets)].sort(), now=this.now();
        if(!reason.trim()||reason.length>200||!ids.length||!Number.isSafeInteger(expires)||expires<=now||expires>now+30*DAY||ids.some(id=>!known.some(v=>v.instance===id))) throw Error('Проверьте адресатов, причину и срок команды');
        const campaign:Campaign={id:crypto.randomUUID(),created:now,expires,component,version:release.version,targets:ids,recipients:Object.fromEntries(ids.map(id=>{const v=known.find(i=>i.instance===id)!;return [id,{account:v.account,device:v.device,owner:v.owner}];})),manifest:signature,base:releaseBase(base),reason,author:this.build.adminId};
        await this.mutate(d=>{if(d.revision!==revision)throw Error('Реестр изменился. Повторите предпросмотр.');
            d.campaigns=[...(d.campaigns ?? []).filter(c=>c.expires>now),campaign]; if(d.campaigns.length>100)throw Error('Слишком много активных кампаний');
            this.audit(d,'Обновление '+component+' '+release.version+' · '+reason,ids);});
    }
    async installations() {
        if (!this.isAdministrator() || !('authority' in this.build) || !this.document) return [];
        return readInstallations(this.store,this.document,this.build.authority.signing);
    }
    async reportInstallation(row: Installation) {
        if (!this.online || !this.session || !('authority' in this.build) || this.access({tenantId:this.build.tenantId,bundleId:this.build.bundleId}).status!=='granted') return;
        const signer=this.session.kind==='administrator' ? this.keys?.signing : this.device;
        if (signer) await writeInstallation(this.store,row,signer);
    }
    async rotateToken(token: string, expiresOn: string | null): Promise<void> {
        if (!token.trim()) throw new Error('Укажите новый PAT');
        const epoch = this.epoch, candidate = this.makeStore(token.trim()); await this.read(candidate); this.guard(epoch);
        await this.mutate(d => { this.audit(d,'Смена PAT',[]); d.transport = { token: token.trim(), version: d.transport.version + 1, expiresOn: validateExpiry(expiresOn) }; }, candidate);
        this.store = candidate; this.transport = structuredClone(this.document!.transport); this.changed();
    }
    async invite(label: string, options: { accountId?: string; password?: string; expiresAt?: number | null; replaceDeviceId?: string; restrictions?: Restriction[] } = {}): Promise<{ code: string; accountId: string; password: string }> {
        const accountId = options.accountId?.trim() || crypto.randomUUID(), accountPassword = options.password || encode64(crypto.getRandomValues(new Uint8Array(12))), guards = this.checkRestrictions(options.restrictions ?? []);
        identifier(accountId); password(accountPassword);
        const invitation: InvitationForCreation = { id: crypto.randomUUID(), accountId, secret: encode64(crypto.getRandomValues(new Uint8Array(32))), purpose: options.replaceDeviceId ? 'replace' : 'activate', ...(options.replaceDeviceId ? { replaceDeviceId: options.replaceDeviceId } : {}), expiresAt: this.now() + 7 * DAY, consumedBy: null };
        return this.mutate(d => {
            let member = d.members.find(m => m.accountId === accountId);
            if (!member) { if (options.replaceDeviceId) throw new Error('Пользователь для замены не найден'); member = { accountId, label: label.trim(), password: accountPassword, active: true, expiresAt: options.expiresAt ?? null, maxDevices: 1, devices: [], blockedDevices: [], ...(guards.length ? { restrictions: guards } : {}) }; d.members.push(member); }
            if (!memberActive(member, this.now())) throw new Error('Пользователь отозван или срок доступа истёк');
            if (options.replaceDeviceId && !member.devices.some(device => device.deviceId === options.replaceDeviceId)) throw new Error('Заменяемое устройство не найдено');
            if (!options.replaceDeviceId && member.devices.length >= member.maxDevices) throw new Error('Лимит устройств исчерпан. Выпустите ключ замены.');
            d.invitations.push(invitation);
            return { code: encodeCode({ v: 4, tenantId: d.tenantId, bundleId: d.bundleId, accountId, transport: d.transport, purpose: invitation.purpose, invitationId: invitation.id, secret: invitation.secret }), accountId, password: member.password };
        });
    }
    /** Adds a user together with the interface restrictions, before any key is issued. The returned key is the user's permanent key
     *  (see `userKey`); the user connects a device with it alone, no ID or password needed, and signs in with ID and password later. */
    async addUser(label: string, options: { accountId?: string; password?: string; expiresAt?: number | null; maxDevices?: number; restrictions?: Restriction[] } = {}): Promise<{ code: string; accountId: string; password: string }> {
        const accountId = options.accountId?.trim() || crypto.randomUUID(), accountPassword = options.password || encode64(crypto.getRandomValues(new Uint8Array(12))), maxDevices = options.maxDevices ?? 1, guards = this.checkRestrictions(options.restrictions ?? []);
        identifier(accountId); password(accountPassword);
        if (!Number.isInteger(maxDevices) || maxDevices < 1 || maxDevices > 100) throw new Error('Лимит устройств — от 1 до 100');
        return this.mutate(d => {
            if (d.members.some(m => m.accountId === accountId)) throw new Error('Пользователь с таким ID уже существует');
            d.members.push({ accountId, label: label.trim(), password: accountPassword, active: true, expiresAt: options.expiresAt ?? null, maxDevices, devices: [], blockedDevices: [], ...(guards.length ? { restrictions: guards } : {}) });
            return { code: this.standingCode(d, this.newStanding(d, accountId)), accountId, password: accountPassword };
        });
    }
    private newStanding(d: Document, accountId: string): Document['invitations'][number] {
        d.invitations = d.invitations.filter(i => !(i.accountId === accountId && i.standing));
        const invitation: Document['invitations'][number] = { id: crypto.randomUUID(), accountId, secret: encode64(crypto.getRandomValues(new Uint8Array(32))), purpose: 'activate', expiresAt: STANDING_EXPIRY, consumedBy: null, standing: true };
        d.invitations.push(invitation); return invitation;
    }
    private standingCode(d: Document, invitation: Document['invitations'][number]): string {
        // Built from the current connection every time, so the same key follows a PAT change.
        return encodeCode({ v: 4, tenantId: d.tenantId, bundleId: d.bundleId, accountId: invitation.accountId, transport: d.transport, purpose: 'activate', invitationId: invitation.id, secret: invitation.secret });
    }
    /** The user's permanent key, or null if there is none (revoked user, or a user added before permanent keys existed: call `reissueKey`). */
    userKey(accountId: string): string | null {
        if (!this.isAdministrator() || !memberActive(this.document?.members.find(m => m.accountId === accountId), this.now())) return null;
        const invitation = this.document!.invitations.find(i => i.accountId === accountId && i.standing);
        return invitation ? this.standingCode(this.document!, invitation) : null;
    }
    /** Creates the permanent key or replaces it with a new one; the old key stops connecting new devices at once.
     *  Devices that are already registered are not affected. */
    async reissueKey(accountId: string): Promise<string> {
        return this.mutate(d => {
            if (!memberActive(d.members.find(m => m.accountId === accountId), this.now())) throw new Error('Выберите действующего пользователя');
            return this.standingCode(d, this.newStanding(d, accountId));
        });
    }
    recoveryCode(accountId: string): string {
        if (!this.isAdministrator() || !memberActive(this.document?.members.find(m => m.accountId === accountId), this.now())) throw new Error('Выберите действующего пользователя');
        return encodeCode({ v: 4, tenantId: this.build.tenantId, bundleId: this.build.bundleId, accountId, purpose: 'update', transport: this.document!.transport });
    }
    async importLegacy(payload: UserPayload, oldPassword: string): Promise<string> {
        password(oldPassword); identifier(payload.userId);
        if (payload.expiresAt !== null && (!Number.isSafeInteger(payload.expiresAt) || payload.expiresAt <= this.now())) throw new Error('Прежний доступ истёк');
        const maxDevices = payload.maxDevices ?? 1;
        if (!Number.isInteger(maxDevices) || maxDevices < 1 || maxDevices > 100) throw new Error('Проверьте прежний лимит устройств');
        const invitation = { id: crypto.randomUUID(), accountId: payload.userId, secret: encode64(crypto.getRandomValues(new Uint8Array(32))), purpose: 'activate' as const, expiresAt: this.now() + 7 * DAY, consumedBy: null };
        return this.mutate(d => {
            if (d.members.some(m => m.accountId === payload.userId)) throw new Error('Пользователь уже перенесён. Используйте его действующий профиль.');
            d.members.push({ accountId: payload.userId, label: payload.note.slice(0, 200), password: oldPassword, active: true, expiresAt: payload.expiresAt, maxDevices, devices: [], blockedDevices: [] });
            d.invitations.push(invitation);
            return encodeCode({ v: 4, tenantId: d.tenantId, bundleId: d.bundleId, accountId: payload.userId, transport: d.transport, purpose: 'activate', invitationId: invitation.id, secret: invitation.secret });
        });
    }
    async change(kind: 'revoke-member' | 'remove-device' | 'set-limit', accountId: string, deviceId = '', limit = 1): Promise<void> {
        await this.mutate(d => { const member = d.members.find(m => m.accountId === accountId); if (!member) throw new Error('Пользователь не найден');
            if (kind === 'revoke-member') { member.active = false; d.invitations = d.invitations.filter(i => i.accountId !== accountId); }
            if (kind === 'remove-device') { if (!member.devices.some(v => v.deviceId === deviceId)) throw new Error('Устройство не найдено'); member.devices = member.devices.filter(v => v.deviceId !== deviceId); if (!member.blockedDevices.includes(deviceId)) member.blockedDevices.push(deviceId); }
            if (kind === 'set-limit') { if (!Number.isInteger(limit) || limit < member.devices.length || limit < 1 || limit > 100) throw new Error('Лимит не может быть меньше числа действующих устройств'); member.maxDevices = limit; }
        });
    }
    /** Saves everything the Administrator edits on a user's card in one step (one commit, one validation). Revoking and restoring stay separate actions. */
    async updateUser(accountId: string, values: { label: string; password?: string; expiresAt: number | null; maxDevices: number; restrictions: Restriction[] }): Promise<void> {
        if (values.password) password(values.password);
        if (values.expiresAt !== null && (!Number.isSafeInteger(values.expiresAt) || values.expiresAt < 0)) throw new Error('Некорректный срок доступа');
        const guards = this.checkRestrictions(values.restrictions);
        await this.mutate(d => {
            const member = d.members.find(m => m.accountId === accountId); if (!member) throw new Error('Пользователь не найден');
            if (!Number.isInteger(values.maxDevices) || values.maxDevices < member.devices.length || values.maxDevices < 1 || values.maxDevices > 100) throw new Error('Лимит не может быть меньше числа действующих устройств');
            member.label = values.label.trim(); member.expiresAt = values.expiresAt; member.maxDevices = values.maxDevices;
            if (values.password) { member.password = values.password; d.invitations = d.invitations.filter(i => i.accountId !== accountId || i.standing); }
            // Names this version does not know stay untouched; only the known set is replaced.
            const unknown = (member.restrictions ?? []).filter(r => !(RESTRICTIONS as readonly string[]).includes(r)), next = [...guards, ...unknown];
            if (next.length) member.restrictions = next; else delete member.restrictions;
        });
    }
    /** Gives access back to a revoked user. A lapsed expiry date is cleared and a new permanent key is created (revoking removed the old one). */
    async restoreMember(accountId: string): Promise<void> {
        await this.mutate(d => {
            const member = d.members.find(m => m.accountId === accountId); if (!member) throw new Error('Пользователь не найден');
            member.active = true; if (member.expiresAt !== null && member.expiresAt <= this.now()) member.expiresAt = null;
            this.newStanding(d, accountId);
        });
    }
    async updateMember(accountId: string, values: { label: string; password?: string; active: boolean; expiresAt: number | null }): Promise<void> {
        if (values.password) password(values.password);
        if (values.expiresAt !== null && (!Number.isSafeInteger(values.expiresAt) || values.expiresAt < 0)) throw new Error('Некорректный срок доступа');
        await this.mutate(d => {
            const member = d.members.find(m => m.accountId === accountId); if (!member) throw new Error('Пользователь не найден');
            member.label = values.label.trim(); member.active = values.active; member.expiresAt = values.expiresAt;
            if (values.password) member.password = values.password;
            // A password change drops pending one-time keys but keeps the user's permanent key; deactivation drops everything.
            if (!values.active) d.invitations = d.invitations.filter(i => i.accountId !== accountId);
            else if (values.password) d.invitations = d.invitations.filter(i => i.accountId !== accountId || i.standing);
        });
    }
    async validateInvitation(code: AccessCode): Promise<void> {
        const secret = 'authority' in this.build && !this.keys ? await invitationDigest(code.secret!) : code.secret;
        const member = this.document?.members.find(m => m.accountId === code.accountId), invitation = this.document?.invitations.find(i => i.id === code.invitationId && i.accountId === code.accountId && i.secret === secret && i.purpose === code.purpose);
        if (!memberActive(member, this.now()) || !invitation || invitation.expiresAt <= this.now()) throw new Error('Ключ недействителен или доступ отозван');
        if (consumed(invitation)) throw new Error('Ключ уже использован. Для входа используйте ID и пароль пользователя.');
        // Above the device limit the request is still sent: the Administrator decides whether to add a place (see `approve`).
        if (member.blockedDevices.includes(this.device.keyId)) throw new Error('Это устройство отозвано');
    }
    /** Interface guards that apply to the signed-in user on this device. Administrators and blocked sessions are never restricted. */
    private ruleContext(path?: string) {
        return {now:this.now(),device:this.device.keyId,instance:this.options.instance,path};
    }
    private restrictedMember() {
        const session = this.session;
        if (!this.document || session?.kind !== 'user' || this.access({tenantId:this.build.tenantId,bundleId:this.build.bundleId}).status !== 'granted') return;
        return this.document.members.find(m=>m.accountId===session.accountId);
    }
    conditionalRestrictions(): Restriction[] {
        const member=this.restrictedMember();
        if (!member) return [];
        const rules=this.document?.policy?.scoped ?? [];
        return RESTRICTIONS.filter(id=>rules.some(r=>r.permission==='obsidian.'+id && relevant(r,member,this.ruleContext())));
    }
    restrictions(): Restriction[] {
        const member=this.restrictedMember();
        if (!member) return [];
        return [...new Set([...knownRestrictions(member),...RESTRICTIONS.filter(id=>!effective(this.document?.policy,member,('obsidian.'+id) as Permission,this.ruleContext()).allowed)])];
    }
    fileDenied(id: Restriction, paths: string[], tree: boolean): boolean {
        const member=this.restrictedMember();
        if(!member) return false;
        if (knownRestrictions(member).includes(id)) return true;
        const permission = ('obsidian.'+id) as Permission, policy=this.document?.policy;
        const candidates=new Set<string|undefined>(paths.length ? paths : [undefined]);
        // Folder moves/deletions can affect a protected subtree even when its parent is unrestricted.
        if (tree) for (const rule of policy?.scoped ?? []) {
            if (rule.permission===permission && rule.folder && paths.some(path=>within(rule.folder,path))) candidates.add(rule.folder);
        }
        return [...candidates].some(path=>!effective(policy,member,permission,this.ruleContext(path)).allowed);
    }
    private checkRestrictions(values: unknown): Restriction[] {
        if (!Array.isArray(values) || values.some(v => !(RESTRICTIONS as readonly string[]).includes(v)) || new Set(values).size !== values.length) throw new Error('Некорректные ограничения');
        return values as Restriction[];
    }
    async setRestrictions(accountId: string, values: Restriction[]): Promise<void> {
        this.checkRestrictions(values);
        await this.mutate(d => {
            const member = d.members.find(m => m.accountId === accountId); if (!member) throw new Error('Пользователь не найден');
            // Names this version does not know stay untouched; only the known set is replaced.
            const unknown = (member.restrictions ?? []).filter(r => !(RESTRICTIONS as readonly string[]).includes(r));
            const next = [...values, ...unknown]; if (next.length) member.restrictions = next; else delete member.restrictions;
        });
    }
    async request(accountId: string, auth: Request['auth']): Promise<Outbox> {
        const now = this.now(), requestId = crypto.randomUUID();
        const request: Request = { v: 4, tenantId: this.build.tenantId, bundleId: this.build.bundleId, accountId, requestId, deviceKey: this.device.publicKey, deviceId: this.device.keyId, auth, issuedAt: now, expiresAt: now + 7 * DAY };
        if (this.options.inbox) request.inbox = publicKey(await crypto.subtle.exportKey('jwk',this.options.inbox.publicKey));
        const code = await signJws(request,this.device);
        const sealed = 'authority' in this.build ? await seal(this.build.authority.inbox,code,'vam-request:'+requestId) : undefined;
        return { id: requestId, code, sealed, submitted: false, expiresAt: request.expiresAt };
    }
    async submit(outbox: Outbox): Promise<void> {
        if (outbox.expiresAt <= this.now()) throw new Error('Срок заявки истёк. Войдите заново или запросите новый ключ.');
        const path = `vam/requests/${outbox.id}.json`, text = JSON.stringify('authority' in this.build ? {v:5,sealed:outbox.sealed} : { v: 4, deviceProof: outbox.code }), current = await this.store.read(path);
        if (current) { if (current.text !== text) throw new Error('Конфликт идентификатора заявки'); return; }
        await this.store.write(path, text, null);
    }
    async upgradeOutbox(old: Outbox): Promise<Outbox | undefined> {
        if (this.session?.kind !== 'user' || !this.document || old.expiresAt <= this.now() ||
            this.document.receipts.some(receipt => receipt.id === old.id)) return;
        const prior = await this.verifyRequest(old.code);
        if (prior.requestId !== old.id || prior.deviceId !== this.device.keyId ||
            prior.accountId !== this.session.accountId) throw Error('Заявка принадлежит другой установке');
        return this.request(prior.accountId,prior.auth);
    }
    needsDeliveryKey(): boolean {
        if (!('authority' in this.build) || !this.online || !this.options.inbox || this.session?.kind !== 'user') return false;
        const accountId = this.session.accountId;
        const member = this.document?.members.find(m => m.accountId === accountId);
        if (!memberActive(member,this.now()) || member.blockedDevices.includes(this.device.keyId)) return false;
        const device = member.devices.find(d => d.deviceId === this.device.keyId);
        return !!device && !device.inbox;
    }
    private async matchesPassword(stored: string, value: string) {
        if (!('authority' in this.build) || this.keys) return stored === value;
        const [salt,digest] = stored.split('.');
        return digest === await credential(value,salt);
    }
    async loginUser(accountId: string, value: string): Promise<Outbox | null> {
        await this.refresh(); if (!this.online) throw new Error(this.error || 'Нет подключения к организации');
        const member = this.document?.members.find(m => m.accountId === accountId);
        if (!memberActive(member, this.now()) || !(await this.matchesPassword(member.password,value))) throw new Error('Неверный ID или пароль пользователя');
        if (member.blockedDevices.includes(this.device.keyId)) throw new Error('Это устройство отозвано. Обратитесь к Администратору.');
        if (!member.devices.some(v => v.deviceId === this.device.keyId) && member.devices.length >= member.maxDevices) throw new Error('Лимит устройств исчерпан. Обратитесь к Администратору.');
        this.session = { kind: 'user', accountId }; this.changed();
        return member.devices.some(v => v.deviceId === this.device.keyId) ? null : this.request(accountId, { kind: 'password', password: value });
    }
    private async verifyRequest(code: string): Promise<Request> {
        const hint = inspectJws(code) as Request, request = await verifyJws(code, publicKey(hint.deviceKey)) as Request;
        identifier(request.requestId); identifier(request.accountId);
        if (request.v !== 4 || request.tenantId !== this.build.tenantId || request.bundleId !== this.build.bundleId || request.deviceId !== await keyId(request.deviceKey) || !Number.isSafeInteger(request.issuedAt) || !Number.isSafeInteger(request.expiresAt) || request.issuedAt > this.now() + 60000 || request.expiresAt <= this.now() || request.expiresAt <= request.issuedAt || request.expiresAt - request.issuedAt > 7 * DAY || !request.auth || !['password', 'invitation','inbox'].includes(request.auth.kind)) throw new Error('Некорректная заявка устройства');
        return request;
    }
    private applyRequest(document: Document, request: Request, replacement: boolean): void {
        if (document.receipts.some(r => r.id === request.requestId)) return;
        const member = document.members.find(m => m.accountId === request.accountId);
        if (!memberActive(member, this.now()) || member.blockedDevices.includes(request.deviceId)) throw new Error('Доступ отозван');
        if (request.auth.kind === 'inbox') {
            const device = member.devices.find(d => d.deviceId === request.deviceId);
            if (!device || !request.inbox || !('authority' in this.build)) throw Error('Устройство не зарегистрировано');
            const inbox = publicKey(request.inbox);
            if (device.inbox && (device.inbox.x !== inbox.x || device.inbox.y !== inbox.y)) throw Error('Ключ доставки уже закреплён');
            device.inbox = inbox;
            document.receipts.push({id:request.requestId,expiresAt:request.expiresAt});
            return;
        }
        let invitation = request.auth.kind === 'invitation' ? document.invitations.find(i => i.id === (request.auth as any).id && i.secret === (request.auth as any).secret && i.accountId === request.accountId && i.expiresAt > this.now()) : undefined;
        if (request.auth.kind === 'password' ? member.password !== request.auth.password : !invitation || consumed(invitation)) throw new Error('Заявка больше не действительна');
        if (invitation?.purpose === 'replace') {
            if (!replacement) throw new Error('Требуется подтверждение замены');
            if (!member.devices.some(d => d.deviceId === invitation!.replaceDeviceId)) throw new Error('Старое устройство уже отозвано');
            if (invitation.replaceDeviceId === request.deviceId) throw new Error('Для замены нужно другое устройство');
            member.devices = member.devices.filter(d => d.deviceId !== invitation!.replaceDeviceId); member.blockedDevices.push(invitation.replaceDeviceId!);
        }
        const registered = document.members.flatMap(m => m.devices).some(d => d.deviceId === request.deviceId);
        if (registered && !member.devices.some(d => d.deviceId === request.deviceId)) throw new Error('Устройство принадлежит другому пользователю');
        if (!member.devices.some(d => d.deviceId === request.deviceId)) { if (member.devices.length >= member.maxDevices) throw new Error('Лимит устройств исчерпан'); member.devices.push({ deviceId: request.deviceId, key: request.deviceKey, ...(request.inbox ? {inbox:publicKey(request.inbox)} : {}), addedAt: this.now() }); }
        if (invitation && !invitation.standing) invitation.consumedBy = request.requestId;
        document.receipts.push({ id: request.requestId, expiresAt: request.expiresAt });
    }
    /** Approves a waiting request. For an extra device above the limit the limit grows by one place. */
    async approve(code: string): Promise<void> {
        const request = await this.verifyRequest(code);
        await this.mutate(document => {
            const member = document.members.find(m => m.accountId === request.accountId);
            const invitation = request.auth.kind === 'invitation' ? document.invitations.find(i => i.id === (request.auth as any).id && i.secret === (request.auth as any).secret && i.accountId === request.accountId && i.expiresAt > this.now()) : undefined;
            if (member && invitation?.purpose === 'activate' && !member.devices.some(d => d.deviceId === request.deviceId) && member.devices.length >= member.maxDevices) {
                if (member.devices.length >= 100) throw new Error('Достигнут предельный лимит устройств — 100');
                member.maxDevices = member.devices.length + 1;
            }
            this.applyRequest(document, request, true);
        });
    }
    /** Declines a waiting request. The request file stays in Git, so the decision is recorded as a receipt; a one-time replacement key is spent. */
    async reject(code: string): Promise<void> {
        const request = await this.verifyRequest(code);
        await this.mutate(document => {
            if (document.receipts.some(r => r.id === request.requestId)) return;
            const invitation = request.auth.kind === 'invitation' ? document.invitations.find(i => i.id === (request.auth as any).id && i.secret === (request.auth as any).secret && i.accountId === request.accountId) : undefined;
            if (invitation && !invitation.standing) invitation.consumedBy = request.requestId;
            document.receipts.push({ id: request.requestId, expiresAt: request.expiresAt, rejected: true });
        });
    }
    /** True if the Administrator declined this request (the device shows it to its user). */
    requestRejected(requestId: string): boolean { return !!this.document?.receipts.some(r => r.id === requestId && r.rejected); }
    /** When the configuration was last fetched from Git. */
    get lastSyncAt(): number | null { return this.cache?.fetchedAt ?? null; }
    async processRequests(): Promise<void> {
        if (!this.isAdministrator()) return;
        const epoch = this.epoch, paths = await this.store.listRequests(), pending: Pending[] = [], rejectedList: RejectedRequest[] = []; let rejected = 0;
        const decline = (path: string, reason: string, accountId?: string): void => { rejected++; if (rejectedList.length < 50) rejectedList.push({ path, reason, ...(accountId ? { accountId } : {}) }); };
        for (const path of paths) {
            this.guard(epoch);
            const known = this.settled.get(path); if (known && this.now() < known.until) { if (known.invalid) decline(path, known.reason ?? 'Заявка отклонена', known.accountId); continue; }
            const file = await this.store.read(path); if (!file) continue;
            let request: Request;
            let proof: string;
            try { const wrapper = JSON.parse(file.text); if ('authority' in this.build) {
                    if (wrapper.v !== 5 || !this.keys) throw Error();
                    proof = await unseal(this.keys.inbox,wrapper.sealed,'vam-request:'+path.slice('vam/requests/'.length,-5));
                } else { if (wrapper.v !== 4 || typeof wrapper.deviceProof !== 'string') throw Error(); proof = wrapper.deviceProof; } request = await this.verifyRequest(proof); if (path !== `vam/requests/${request.requestId}.json`) throw new Error(); } catch { const reason = 'Некорректная или просроченная заявка'; this.settled.set(path, { invalid: true, until: this.now() + 600000, reason }); decline(path, reason); continue; }
            const receipt = this.document?.receipts.find(r => r.id === request.requestId);
            if (receipt) { this.settled.set(path, { invalid: false, until: Infinity }); if (receipt.rejected) decline(path, 'Отклонена Администратором', request.accountId); continue; }
            const member = this.document?.members.find(m => m.accountId === request.accountId);
            const invitation = request.auth.kind === 'invitation' ? this.document?.invitations.find(i => i.id === (request.auth as any).id && i.secret === (request.auth as any).secret && i.accountId === request.accountId && !consumed(i) && i.expiresAt > this.now()) : undefined;
            const base = { path, code: proof, accountId: request.accountId, deviceId: request.deviceId, label: member?.label ?? '', issuedAt: request.issuedAt };
            if (invitation?.purpose === 'replace') { pending.push({ ...base, kind: 'replace', ...(invitation.replaceDeviceId ? { replaceDeviceId: invitation.replaceDeviceId } : {}) }); continue; }
            // A new device above the limit waits for the Administrator instead of being refused.
            const owned = this.document?.members.some(m => m.devices.some(d => d.deviceId === request.deviceId));
            if (invitation?.purpose === 'activate' && memberActive(member, this.now()) && !member.blockedDevices.includes(request.deviceId) && !owned && member.devices.length >= member.maxDevices) { pending.push({ ...base, kind: 'extra' }); continue; }
            try { await this.mutate(d => this.applyRequest(d, request, false)); this.settled.set(path, { invalid: false, until: Infinity }); }
            catch (e) { if (e instanceof GitError || !this.isAdministrator()) throw e; const reason = e instanceof Error ? e.message : 'Заявка отклонена'; this.settled.set(path, { invalid: true, until: this.now() + 600000, reason, accountId: request.accountId }); decline(path, reason, request.accountId); }
        }
        this.pending = pending; this.rejected = rejected; this.rejectedList = rejectedList; this.changed();
    }
    dispose(): void { this.disposed = true; this.epoch++; this.session = null; }
}
type InvitationForCreation = Document['invitations'][number];
