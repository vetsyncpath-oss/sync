# Исходники VAM Publisher 0.2.0-alpha.9

Корень проекта — Издатель (главный плагин):
main.ts — точка входа, manifest.json и styles.css — манифест и стили,
src/ — логика реестра и выпуска (service.ts, zip.ts).

Исходники менеджера лежат внутри проекта Издателя, в папке manager/: main.ts, manifest.json, styles.css, vam-guard.ts и manager/src/ (auth-v2/v3/v4, core, api, sdk, ui, types). Сборка Издателя встраивает собранный шаблон manager 0.8.0-alpha.9. Это самостоятельный комплект исходников для штатной сборки. Исторические модули сохранены как в репозитории; активная точка входа Издателя — main.ts в корне.

## Сборка

Используйте Node.js 20.18.0 или другую версию, поддержанную package.json.
Из корневой папки распакованного архива выполните:

```sh
npm ci
npm run build
```

Шаблон менеджера собирается в dist/manager/, а готовый плагин Издателя — в dist/vam-publisher/:
main.js, manifest.json, styles.css.
Скопируйте папку vam-publisher в .obsidian/plugins/ своего vault и включите плагин.

Проверка полного выпуска:

```sh
node scripts/smoke-release.mjs
```

Инструкция по работе: docs/PUBLISHER.md.
Личные профили, пароли и PAT в архив не включены; их задают в установленном Издателе.
