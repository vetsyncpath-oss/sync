import {digest,filenames,type Release} from '../manager/src/auth-v4/updates';
import {importIdentity,signJws} from '../manager/src/auth-v2/crypto';
import { LocalStore } from '../manager/src/auth-v3/local';
import { validateBuild, type BuildProfile } from '../manager/src/auth-v4/model';
import { generateIdentity, publicKey, encryptSecret, decryptSecret, type EncryptedIdentity } from '../manager/src/auth-v2/crypto';
import { ownerSetupSlot, passphrase, type AuthorityPin } from '../manager/src/auth-v4/authority';
import { clientBuild } from '../manager/src/auth-v4/model';
import { zip } from './zip';
export interface Template { main: string; manifest: string; styles: string }
interface PublisherProfile extends BuildProfile { migratedAlpha5?: true; owner?: {releaseKey:JsonWebKey; pin: AuthorityPin; wrapped: EncryptedIdentity} }
export interface Registry { v: 1; profiles: PublisherProfile[] }
function readProfile(raw: PublisherProfile): PublisherProfile {
    const profile = validateBuild(raw);
    if (!raw.owner) return profile;
    const {pin,wrapped} = raw.owner;
    if (!wrapped || wrapped.v !== 2 || typeof wrapped.ciphertext !== 'string') throw Error('Некорректная резервная копия владельца');
    if (!raw.owner.releaseKey?.d) throw Error('Отсутствует закрытый ключ выпуска Publisher');
    return {...profile,...(raw.migratedAlpha5===true?{migratedAlpha5:true as const}:{}),owner:{releaseKey:raw.owner.releaseKey,pin:{signing:publicKey(pin.signing),inbox:publicKey(pin.inbox)},wrapped}};
}
async function makeOwner(profile: BuildProfile) {
    const signing = await generateIdentity();
    const inbox = await crypto.subtle.generateKey({name:'ECDH',namedCurve:'P-256'},true,['deriveKey']);
    const keys = {signing:await crypto.subtle.exportKey('jwk',signing.privateKey),inbox:await crypto.subtle.exportKey('jwk',inbox.privateKey)};
    const issuer=await generateIdentity();
    return {releaseKey:await crypto.subtle.exportKey('jwk',issuer.privateKey),pin:{signing:signing.publicKey,inbox:publicKey(keys.inbox)},wrapped:await encryptSecret(keys,passphrase(profile.tenantId,profile.defaultPassword))};
}
const MARKER = '__VAM_PROFILE_V4_JSON__';
export function prepareRelease(raw: PublisherProfile, template: Template, modifiedAt: number = Date.now()): { document: string; files: Record<string, string>; archive: Uint8Array } {
    const profile = validateBuild(raw), needle = JSON.stringify(MARKER);
    if (template.main.split(needle).length !== 2) throw new Error('Шаблон менеджера несовместим или уже подготовлен для организации');
    const manifest = JSON.parse(template.manifest); if (manifest.id !== 'vault-access-manager') throw new Error('Некорректный шаблон менеджера');
    if (!raw.owner) throw Error('Отсутствует ключ выпуска');
    const {v,adminId,tenantId,bundleId,repository,bootstrapToken} = profile;
    const client = clientBuild({v,adminId,tenantId,bundleId,repository,bootstrapToken,localOwnerOnly:raw.migratedAlpha5,studioIssuer:profile.studioIssuer,managerIssuer:publicKey(raw.owner.releaseKey),authority:raw.owner.pin});
    const files = { 'vault-access-manager/main.js': template.main.replace(needle, () => JSON.stringify(JSON.stringify(client))), 'vault-access-manager/manifest.json': JSON.stringify(manifest, null, 2) + '\n', 'vault-access-manager/styles.css': template.styles };
    return { document: JSON.stringify(readProfile(raw), null, 2) + '\n', files, archive: zip(files, modifiedAt) };
}
/** Private local baking registry. No publisher identity, login, certificate or signing key. */
export class PublisherService {
    registry: Registry = { v: 1, profiles: [] };
    private queue: Promise<void> = Promise.resolve();
    constructor(readonly local = new LocalStore('vam-publisher-baking-v1')) {}
    async start(): Promise<void> { const stored = await this.local.secret<Registry>('registry'); if (stored) this.registry = this.validateRegistry(stored); }
    private validateRegistry(raw: Registry): Registry { if (!raw || raw.v !== 1 || !Array.isArray(raw.profiles) || raw.profiles.length > 1000) throw new Error('Некорректный реестр Издателя'); const profiles = raw.profiles.map(readProfile); if (new Set(profiles.map(p => p.adminId)).size !== profiles.length || new Set(profiles.map(p => p.tenantId)).size !== profiles.length) throw new Error('Повторный профиль Администратора'); return { v: 1, profiles }; }
    private async update(work: (registry: Registry) => Promise<void> | void): Promise<void> {
        const write = async () => {
            const registry = this.validateRegistry(await this.local.secret<Registry>('registry') ?? this.registry); await work(registry); this.validateRegistry(registry); await this.local.saveSecret('registry', registry); this.registry = registry;
        };
        const task = this.queue.catch(() => {}).then(async () => globalThis.navigator?.locks
            ? navigator.locks.request('vam-publisher-registry',write) : write());
        this.queue = task; return task;
    }
    async create(input: Omit<BuildProfile, 'v' | 'tenantId'>): Promise<BuildProfile> {
        const base = validateBuild({ ...input, v: 4, tenantId: crypto.randomUUID() });
        const profile = {...base,owner:await makeOwner(base)};
        await this.update(registry => { if (registry.profiles.some(p => p.adminId === profile.adminId)) throw new Error('Профиль с этим ID уже существует'); registry.profiles.push(profile); }); return structuredClone(profile);
    }
    async updateProfile(tenantId: string, input: Omit<BuildProfile, 'v' | 'tenantId'>): Promise<void> {
        const profile = validateBuild({ ...input, v: 4, tenantId });
        await this.update(async registry => { const index = registry.profiles.findIndex(p => p.tenantId === tenantId); if (index < 0) throw new Error('Профиль не найден'); let owner = registry.profiles[index].owner; const prior=registry.profiles[index];
            if (!owner) owner=await makeOwner(profile);
            if (prior.owner && prior.defaultPassword !== profile.defaultPassword) {
                const keys = await decryptSecret(owner.wrapped,passphrase(tenantId,prior.defaultPassword));
                owner.wrapped = await encryptSecret(keys,passphrase(tenantId,profile.defaultPassword));
            }
            registry.profiles[index] = {...profile,...(!prior.owner || prior.migratedAlpha5 ? {migratedAlpha5:true as const}:{}),owner}; });
    }
    private async withOwner(tenantId: string) {
        const find = () => this.registry.profiles.find(p=>p.tenantId===tenantId);
        if (!find()) throw Error('Профиль не найден');
        if (!find()!.owner) await this.update(async registry => {
            const profile = registry.profiles.find(p => p.tenantId === tenantId)!;
            if (!profile.owner) { profile.owner = await makeOwner(profile); profile.migratedAlpha5 = true; }
        });
        return find()!;
    }
    async release(tenantId: string, template: Template) { const profile = await this.withOwner(tenantId);
        const release = prepareRelease(profile,template);
        const installation = new LocalStore('vam-installation-v4');
        try { await installation.saveSecret(await ownerSetupSlot(tenantId,profile.owner!.pin),profile.owner!.wrapped); }
        finally { await installation.close(); }
        return release; }
    async releaseSignature(tenantId:string,template:Template) {
        const profile=await this.withOwner(tenantId), release=prepareRelease(profile,template), files={} as Release['files'];
        for(const name of filenames){const bytes=new TextEncoder().encode(release.files['vault-access-manager/'+name]);files[name]={size:bytes.length,sha256:await digest(bytes)};}
        return signJws({kind:'vam-release-1',component:'vault-access-manager',tenant:profile.tenantId,bundle:profile.bundleId,version:JSON.parse(template.manifest).version,files},await importIdentity(profile.owner!.releaseKey));
    }
    async issueSetup(tenantId: string) { return JSON.stringify((await this.withOwner(tenantId)).owner!.wrapped); }
    exportRegistry(): string { return JSON.stringify(this.registry, null, 2); }
    async restoreRegistry(text: string): Promise<void> { let registry: Registry; try { const raw = JSON.parse(text); registry = this.validateRegistry(raw.v === 4 ? { v: 1, profiles: [readProfile(raw)] } : raw); } catch { throw new Error('Некорректный файл реестра или документ сборки'); } await this.update(current => { for (const profile of registry.profiles) { if (current.profiles.some(p => p.tenantId === profile.tenantId || p.adminId === profile.adminId)) throw new Error('Импорт содержит существующий профиль; текущий реестр сохранён'); } current.profiles.push(...registry.profiles); }); }
    async close(): Promise<void> { await this.queue.catch(() => {}); await this.local.close(); }
}
