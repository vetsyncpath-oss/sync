"""Exercise a released Manager in two real Obsidian vaults with one app profile."""
import argparse
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import tempfile
import time
from zipfile import ZipFile

from playwright.sync_api import sync_playwright

args = argparse.ArgumentParser()
args.add_argument("--obsidian", type=Path, required=True)
args.add_argument("--sync-zip", type=Path, required=True)
args.add_argument("--upgrade-from", type=Path, help="Exercise in-place migration from a released alpha.5 Publisher ZIP")
args.add_argument("--headless", action="store_true")
options = args.parse_args()
root = Path(__file__).resolve().parents[1]

with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as temp, sync_playwright() as playwright:
    home = Path(temp)
    first, second = home / "A" / "Test", home / "B" / "Test"
    profile = home / "profile"
    profile.mkdir()
    for vault in [first, second]:
        plugins = vault / ".obsidian" / "plugins"
        plugins.mkdir(parents=True)
        with ZipFile(options.sync_zip) as archive:
            archive.extractall(plugins)
    shutil.copytree(root / "dist/vam-publisher", first / ".obsidian/plugins/vam-publisher")

    repository = {}
    update_fixture = (root / "scripts/native-update-fixture.mjs").read_text(encoding="utf-8")
    studio_dir = first / ".obsidian/plugins/refsync"
    assets = {n: (studio_dir/n).read_bytes().decode("utf-8") for n in ("main.js","manifest.json","styles.css")}
    manifest = json.loads(assets["manifest.json"])
    major, minor, patch = map(int,manifest["version"].split("."))
    test_version = f"{major}.{minor}.{patch+1}-test.1"
    manifest["version"] = test_version
    assets["manifest.json"] = json.dumps(manifest)


    def visit(vault, callback):
        (vault / '.obsidian/community-plugins.json').write_text('[]', encoding='utf-8')
        identifier = "0123456789abcdef" if vault == first else "fedcba9876543210"
        (profile / "obsidian.json").write_text(json.dumps({"vaults": {identifier: {"path": str(vault), "ts": int(time.time()*1000), "open": True}}}), encoding="utf-8")
        with socket.socket() as sock:
            sock.bind(("127.0.0.1", 0))
            port = sock.getsockname()[1]
        flags = ["--headless", "--ozone-platform=headless", "--disable-gpu", "--no-sandbox"] if options.headless else []
        env = dict(os.environ, APPDATA=str(home/"roaming"), LOCALAPPDATA=str(home/"local"), XDG_CONFIG_HOME=str(home/"config"), XDG_DATA_HOME=str(home/"data"), XDG_CACHE_HOME=str(home/"cache"))
        proc = subprocess.Popen([str(options.obsidian), *flags, "--remote-debugging-address=127.0.0.1", f"--remote-debugging-port={port}", "--user-data-dir="+str(profile)], env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            deadline = time.monotonic()+65
            while True:
                try:
                    browser = playwright.chromium.connect_over_cdp(f"http://127.0.0.1:{port}", timeout=1500)
                    page = browser.contexts[0].pages[0]
                    page.wait_for_function("!!window.app?.plugins?.enablePluginAndSave")
                    break
                except Exception:
                    if time.monotonic() >= deadline: raise
                    time.sleep(.2)
            page.evaluate("()=>new Promise(resolve => app.workspace.onLayoutReady(resolve))")
            assert Path(page.evaluate("app.vault.adapter.getBasePath()")) == vault
            page.evaluate("(state)=>Object.assign(localStorage,state)", repository)
            page.evaluate("""async()=>{ const p=app.plugins; if(!p.isEnabled())await p.setEnable(true); await p.loadManifests();
              window.fetch=async (url,init={})=>{
                if(!String(url).startsWith('https://api.github.com/repos/fixture/private')) throw Error('offline fixture');
                const path=String(url).split('/contents/')[1]; if(!path)return Response.json({private:true});
                if(path==='vam/requests')return Response.json([]);
                if(path==='vam/installations')return Response.json(Object.keys(localStorage).filter(k=>k.startsWith('vam/installations/')).map(k=>({name:k.split('/').pop()})));
                if(init.method==='PUT'){localStorage.setItem(path,JSON.parse(init.body).content);return Response.json({}, {status:201});}
                const content=localStorage.getItem(path);return content?Response.json({sha:'1',encoding:'base64',content}):Response.json({}, {status:404});
              };}""")
            result = callback(page)
            repository.update(page.evaluate("()=>Object.fromEntries(Object.entries(localStorage).filter(([k])=>k.startsWith('vam/')))"))
            return result
        finally:
            proc.kill()
            proc.wait(timeout=20)

    if options.upgrade_from:
        plugin_dir = first / ".obsidian/plugins"
        with ZipFile(options.upgrade_from) as archive:
            archive.extractall(plugin_dir)

        def write_manager(files):
            for path, contents in files.items():
                target = plugin_dir / path
                target.parent.mkdir(exist_ok=True)
                target.write_text(contents, encoding="utf-8")

        def legacy_login(page):
            files = page.evaluate("""async()=>{
                await app.plugins.enablePlugin('vam-publisher');
                const plugin=app.plugins.plugins['vam-publisher'];
                const profile=await plugin.publisher.create({adminId:'Fixture',defaultPassword:'old',bootstrapToken:'fixture-token',bundleId:'test',repository:{baseUrl:'https://api.github.com',owner:'fixture',repo:'private'}});
                return (await plugin.prepare(profile.tenantId)).files;
            }""")
            write_manager(files)
            shutil.copytree(plugin_dir / "vault-access-manager", second / ".obsidian/plugins/vault-access-manager")
            return page.evaluate("""async()=>{
                await app.plugins.loadManifests(); await app.plugins.enablePlugin('vault-access-manager');
                const rt=app.plugins.plugins['vault-access-manager'].accessV4;await rt.ready;
                await rt.loginAdministrator('old');await rt.service.invite('Fixture user',{accountId:'reader',password:'abc'});
                await rt.tick();
                return rt.device.keyId;
            }""")

        device = visit(first, legacy_login)
        def rotate_from_other_vault(page):
            page.evaluate("""async()=>{
                await app.plugins.enablePlugin('vault-access-manager');
                const rt=app.plugins.plugins['vault-access-manager'].accessV4; await rt.ready;
                await rt.loginAdministrator('old'); await rt.rotateToken('rotated-fixture-token',null);
                await rt.tick();
            }""")
        visit(second,rotate_from_other_vault)
        shutil.copytree(root / "dist/vam-publisher", plugin_dir / "vam-publisher", dirs_exist_ok=True)

        def upgrade(page):
            files = page.evaluate("""async()=>{
                await app.plugins.enablePlugin('vam-publisher');
                const plugin=app.plugins.plugins['vam-publisher'];
                const [profile]=plugin.publisher.registry.profiles;
                return (await plugin.prepare(profile.tenantId)).files;
            }""")
            write_manager(files)
            page.evaluate("""async expectedDevice=>{
                const originalFetch=window.fetch;
                window.fetch=(url,init)=>new Headers(init?.headers).get('Authorization')==='Bearer rotated-fixture-token'
                    ? originalFetch(url,init) : Promise.resolve(Response.json({}, {status:401}));
                await app.plugins.loadManifests();await app.plugins.enablePlugin('vault-access-manager');
                const rt=app.plugins.plugins['vault-access-manager'].accessV4;await rt.ready;
                if (!rt.service?.isAdministrator() || rt.device.keyId!==expectedDevice) throw Error('Saved alpha.5 owner session missing: '+rt.error+' '+rt.service?.error);
                const doc=rt.service.document;
                if(doc.adminPassword!=='old' || doc.members[0]?.password!=='abc' || !doc.invitations.length || doc.transport.version!==2) throw Error('Legacy registry fields changed');
                if (!JSON.parse(atob(localStorage.getItem('vam/config.json'))).signature) throw Error('Unsigned registry after migration');
            }""",device)

            exported = page.evaluate("""async()=>{
                const publisher=app.plugins.plugins['vam-publisher'];
                const org=publisher.publisher.registry.profiles[0].tenantId;
                const rt=app.plugins.plugins['vault-access-manager'].accessV4;
                await rt.logout();rt.openLogin(true);
                return {setup:await publisher.publisher.issueSetup(org),release:await publisher.signRelease(org)};
            }""")
            modal=page.locator('.vam-login-modal').last
            modal.get_by_role('button', name='Я Администратор', exact=False).click()
            modal.locator('input[type=file]').set_input_files({"name":"owner-setup.json","mimeType":"application/json","buffer":exported["setup"].encode()})
            modal.get_by_text('Файл загружен.',exact=False).wait_for()
            modal.get_by_label('Пароль Администратора',exact=True).fill('old')
            modal.get_by_role('button',name='Войти как Администратор',exact=True).click()
            page.wait_for_function("app.plugins.plugins['vault-access-manager'].accessV4.service?.isAdministrator()")
            page.evaluate("""()=>{const rt=app.plugins.plugins['vault-access-manager'].accessV4;rt.openLogin(true)}""")
            dashboard=page.locator('.vam-login-modal').last
            dashboard.get_by_text('Кампании обновления',exact=True).click()
            dashboard.locator('input[accept=".jws"]').set_input_files({"name":"release.jws","mimeType":"text/plain","buffer":exported["release"].encode()})
            dashboard.get_by_text('Подпись проверена',exact=False).wait_for()
            assert dashboard.get_by_label('Компонент',exact=True).input_value()=='vault-access-manager'

        visit(first, upgrade)
        print("Installed alpha.5 ZIP upgraded in place. Remembered owner, three-character passwords, invitation and PAT version survived signed migration.")
        raise SystemExit(0)

    def enter(first_page):
        signed = first_page.evaluate(update_fixture,{"operation":"sign","files":assets,"version":test_version})
        release = first_page.evaluate("""async publicKey=>{await app.plugins.enablePlugin('vam-publisher');
            const p=app.plugins.plugins['vam-publisher'], row=await p.publisher.create({studioIssuer:publicKey,adminId:'Fixture',defaultPassword:'fixture-password',bootstrapToken:'fixture-token',bundleId:'test',repository:{baseUrl:'https://api.github.com',owner:'fixture',repo:'private'}});
            return {files:(await p.prepare(row.tenantId)).files, setup:await p.publisher.issueSetup(row.tenantId)};}""",signed["publicKey"])
        for path, data in release["files"].items():
            for vault in [first, second]:
                if vault == second and path.endswith("styles.css"): continue
                dest = vault / ".obsidian/plugins" / path
                dest.parent.mkdir(exist_ok=True)
                dest.write_text(data, encoding="utf-8")
        first_page.evaluate("""async code=>{const p=app.plugins;await p.loadManifests();await p.enablePluginAndSave('refsync');await p.enablePluginAndSave('vault-access-manager');
            if(!p.plugins['vault-access-manager']) throw Error('Manager missing. Loaded='+Object.keys(p.plugins)+' manifests='+Object.keys(p.manifests)+' enabled='+[...p.enabledPlugins]);
            const rt=p.plugins['vault-access-manager'].accessV4;await rt.ready; await rt.loginAdministrator('fixture-password','',null,code);
            if(!rt.service.isAdministrator())throw Error('expected authenticated A');p.plugins.refsync.gate.require();}""", release["setup"])
        first_page.evaluate(update_fixture,{"operation":"stage","signature":signed["signature"],"version":test_version,"files":assets})
        return first_page.evaluate("app.plugins.plugins['vault-access-manager'].accessV4.device.keyId")

    def check(page):
        return page.evaluate("""async()=>{const p=app.plugins;await p.enablePluginAndSave('vault-access-manager');await p.enablePluginAndSave('refsync');
            if(!p.plugins['vault-access-manager']) throw Error('Manager missing. Loaded='+Object.keys(p.plugins)+' manifests='+Object.keys(p.manifests)+' enabled='+[...p.enabledPlugins]);
            const rt=p.plugins['vault-access-manager'].accessV4;await rt.ready;await p.plugins.refsync.ready;
            if(rt.session||rt.service?.isAdministrator()||p.plugins.refsync.gate.refresh()==='vamGranted')throw Error('unexpected session');
            if(!document.querySelector('.vam-login-modal'))throw Error('login UI missing');
            return rt.device.keyId;}""")

    key = visit(first, enter)
    assert visit(second, check) == key
    def login_second(page):
        return page.evaluate("""async()=>{const p=app.plugins;await p.enablePluginAndSave('vault-access-manager');
            const rt=p.plugins['vault-access-manager'].accessV4;await rt.ready;
            if(rt.session)throw Error('B has not logged in yet');
            await rt.loginAdministrator('fixture-password');
            if(!rt.service.isAdministrator())throw Error('B explicit login failed');
            return rt.device.keyId;}""")
    def logout_second(page):
        return page.evaluate("""async()=>{const p=app.plugins;await p.enablePluginAndSave('vault-access-manager');
            const rt=p.plugins['vault-access-manager'].accessV4;await rt.ready;
            if(!rt.service.isAdministrator())throw Error('B remembered login missing');
            await rt.logout();if(rt.session)throw Error('B logout failed');return rt.device.keyId;}""")
    assert visit(second, login_second) == key
    assert visit(second, logout_second) == key
    def restored(page):
        return page.evaluate("""async()=>{const p=app.plugins; await p.enablePluginAndSave('vault-access-manager'); await p.enablePluginAndSave('refsync');
            if(!p.plugins['vault-access-manager']) throw Error('Manager missing. Loaded='+Object.keys(p.plugins)+' manifests='+Object.keys(p.manifests)+' enabled='+[...p.enabledPlugins]);
            const rt=p.plugins['vault-access-manager'].accessV4; await rt.ready; await p.plugins.refsync.ready;
            if(!rt.service?.isAdministrator()) throw Error('A session missing: '+rt.status+' '+rt.error);
            p.plugins.refsync.gate.require();
            return rt.device.keyId;}""")
    def verify_reopened(page):
        device=restored(page)
        page.evaluate(update_fixture,{"operation":"verify","version":test_version})
        return device
    assert visit(first, verify_reopened) == key
    assert json.loads((second/".obsidian/plugins/refsync/manifest.json").read_text(encoding="utf-8"))["version"] != test_version
    print("Signed Studio update respected the active queue and selected vault; Manager-first restart reported activation.")
    print("Same installation: A explicitly granted, B (main.js + manifest.json) signed out with login UI, B remembers its own login, logout in B leaves A authenticated after restart.")
