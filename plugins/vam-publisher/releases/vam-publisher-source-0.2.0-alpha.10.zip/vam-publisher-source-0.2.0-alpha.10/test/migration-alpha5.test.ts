import 'fake-indexeddb/auto';
import {expect,it} from 'vitest';
import {Plugin} from 'obsidian';
import {PublisherService} from '../src/service';
import {LocalStore} from '../manager/src/auth-v3/local';
import {Runtime} from '../manager/src/auth-v4/runtime';
import {Service} from '../manager/src/auth-v4/service';
import {clientBuild,CONFIG_PATH,type Session} from '../manager/src/auth-v4/model';
import {vaultScope} from '../manager/src/auth-v4/vault-scope';
import {inspectJws} from '../manager/src/auth-v2/crypto';
import {build,Repository} from './helpers/v4';
import {attachVaultFile} from './helpers/vault-file';
import {effective,nextBoundary,validateScoped,type ScopedRule} from '../manager/src/auth-v4/policy';

it('upgrades the alpha.5 Publisher registry and two remembered Windows vault sessions with a three-character owner password',async()=>{
    const profile={...build,tenantId:crypto.randomUUID(),defaultPassword:'old',bootstrapToken:'old-token'};
    const repo=new Repository(profile);
    const installation='vam-installation-v4', db=new LocalStore(installation);
    const publisher=new PublisherService(new LocalStore(crypto.randomUUID()));
    await publisher.local.saveSecret('registry',{v:1,profiles:[profile]});
    await publisher.start();
    const template={main:'module.exports="__VAM_PROFILE_V4_JSON__"',manifest:'{"id":"vault-access-manager"}',styles:''};
    const release=await publisher.release(profile.tenantId,template);
    const mod={exports:''}; new Function('module',release.files['vault-access-manager/main.js'])(mod);
    const client=clientBuild(JSON.parse(mod.exports));
    const old=new Service(profile,await db.identity('device'),'old-token',0,{store:repo.store});
    await old.loginAdministrator('old');
    const issued=await old.invite('Alice',{accountId:'alice',password:'usr'});
    const user=new Service(profile,await db.identity('device'),'old-token',0,{store:repo.store});
    const registration=await user.loginUser('alice','usr');
    await user.submit(registration!);await old.processRequests();
    const original=repo.document();
    const running:Runtime[]=[];
    const open=async(path:string,remember?:Session)=>{
        const plugin=new Plugin({vault:{adapter:{getBasePath:()=>path}}} as any,{id:'vault-access-manager',version:'test'});
        attachVaultFile(plugin,profile.tenantId+path);
        if(remember){
            const loc=await vaultScope(plugin.app);
            const key='profile:'+profile.tenantId+':'+JSON.stringify(client.repository)+':vault:'+loc.id+':bundle:'+profile.bundleId;
            await db.saveSecret(key,{session:remember,transport:original.transport});
        }
        const runtime=new Runtime(plugin,client,{store:repo.store},new LocalStore(installation));
        running.push(runtime);await runtime.start();return runtime;
    };
    try {
        const away=new Service(client,await db.identity('device'),'old-token',0,{store:repo.store});
        await expect(away.loginAdministrator('old')).rejects.toThrow('код');
        const participant=await open('C:/VAM/member',{kind:'user',accountId:'alice'});
        expect(participant.decision.status).toBe('blocked');
        const owner=await open('C:/VAM/owner',{kind:'administrator',password:'old'});
        expect(owner.service?.isAdministrator()).toBe(true);
        expect(owner.service!.document?.members).toEqual(original.members);
        expect(owner.service!.document?.invitations).toEqual(original.invitations);
        expect(issued.code).toBeTruthy();
        await participant.tick();expect(participant.decision.status).toBe('granted');
        await owner.tick();await participant.tick();
        expect(owner.service!.document!.members[0].devices[0].inbox).toBeTruthy();
        await owner.service!.rotateToken('new-token',null);await participant.tick();
        expect(participant.service!.transport.token).toBe('new-token');
        const signed=inspectJws(JSON.parse(repo.files.get(CONFIG_PATH)!.text).signature) as any;
        expect(signed.wrapped).toBeNull();expect(signed.view.adminPassword).toBe('[private]');
        await expect(away.loginAdministrator('old')).rejects.toThrow('код');
        expect((await open('D:/copy/owner')).session).toBeNull();
        const again=await open('C:/VAM/owner');expect(again.service?.isAdministrator()).toBe(true);
    } finally { for(const runtime of running) runtime.dispose();await publisher.close();await db.close(); }
},60000);

it('applies folder and time boundaries with Windows paths and respects mandatory denials',()=>{
    const member={accountId:'alice',groups:['staff']}, permission='obsidian.note.delete' as const;
    const rule:ScopedRule={id:crypto.randomUUID(),permission,level:'user',subject:'alice',effect:'allow',
        folder:'Shared/Notes',device:'',instance:'',from:10,until:20,reason:'Окно обслуживания'};
    validateScoped(rule);
    const policy={groups:[{id:'staff',name:'Staff',rules:{[permission]:'deny' as const}}],scoped:[rule]};
    const decide=(path:string,now:number)=>effective(policy,member,permission,{path,now}).allowed;
    expect(decide('shared\\Notes\\a.md',10)).toBe(true);
    expect(decide('Shared/NotesOther/a.md',11)).toBe(false);
    expect(decide('Shared/Notes/a.md',20)).toBe(false);
    expect(nextBoundary(policy,member,permission,{now:11})).toBe(20);
    expect(effective({...policy,mandatory:[permission]},member,permission,{path:rule.folder,now:11}).allowed).toBe(false);
});

it('retries a saved PAT rejected with 401 using the issued PAT, but honors an explicit PAT',async()=>{
    const profile={...build,bootstrapToken:'old-token'};
    const repo=new Repository(profile), device=await new LocalStore(crypto.randomUUID()).identity('device');
    const saved=new Service(profile,device,'revoked',0,{store:repo.store,useBootstrapFallback:true});
    await saved.loginAdministrator(profile.defaultPassword);
    expect(saved.transport.token).toBe('old-token');
    const explicit=new Service(profile,device,'revoked',0,{store:repo.store,useBootstrapFallback:false});
    await expect(explicit.loginAdministrator(profile.defaultPassword)).rejects.toThrow('HTTP 401');
});
