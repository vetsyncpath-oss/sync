# Sync Overhaul — полный комплект текущей реализации

Commit: a5a4d16bb55976aaa6a88727396c9ca54cc9d680
Branch: overhaul/s0-drive-id-browse
Base branch: overhaul/2b1-recovered
Build: overhaul-jobs-startup-2026-10-14
PR: https://github.com/vetsyncpath-oss/sync/pull/5

Все tracked файлы коммита: исходники, тесты, спецификации, лицензии,
плюс production main.js и styles.css. Без .git и node_modules.
Контрольные суммы всех файлов — SHA256SUMS.json.
Проверки коммита: 534/534 теста, TypeScript/build и 30 probes.

Реализация S0 + переходного S1a/S2a; не все будущие этапы overhaul завершены.
Статус: docs/overhaul-vnext/implementation-status.md
Контракт: docs/overhaul-vnext/09-jobs-startup.md
Live Google/Obsidian не проверен. manifest.json отсутствует в исходной
ветке и здесь не создаётся: архив не является готовым установочным
пакетом Obsidian. Сборка исходников: Node >=18.18, npm ci, npm run verify.
